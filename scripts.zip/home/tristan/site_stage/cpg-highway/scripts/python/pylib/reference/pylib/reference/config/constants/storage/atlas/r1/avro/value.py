VALUE = 'avro'
