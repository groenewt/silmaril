VALUE = 'scala-source'
