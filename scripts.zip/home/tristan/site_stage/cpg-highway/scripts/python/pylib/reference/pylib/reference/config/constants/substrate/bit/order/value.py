VALUE = 'msb-first'
