VALUE = 'icechunk-xarray'
