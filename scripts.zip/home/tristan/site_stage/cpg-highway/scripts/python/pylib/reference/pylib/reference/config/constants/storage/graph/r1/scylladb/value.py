VALUE = 'scylladb'
