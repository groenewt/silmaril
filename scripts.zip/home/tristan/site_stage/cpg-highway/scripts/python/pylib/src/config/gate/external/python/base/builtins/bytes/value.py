VALUE = bytes
