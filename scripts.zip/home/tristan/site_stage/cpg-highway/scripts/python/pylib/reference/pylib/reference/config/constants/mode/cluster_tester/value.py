VALUE = 'cluster-tester'
