VALUE = 'arrow'
