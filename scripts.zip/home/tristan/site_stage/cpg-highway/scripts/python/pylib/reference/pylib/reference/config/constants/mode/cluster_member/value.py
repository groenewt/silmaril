VALUE = 'cluster-member'
