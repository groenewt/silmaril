VALUE = 'cluster-child'
