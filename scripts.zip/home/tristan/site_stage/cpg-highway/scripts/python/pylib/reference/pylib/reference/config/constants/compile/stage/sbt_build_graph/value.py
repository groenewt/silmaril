VALUE = 'sbt-build-graph'
