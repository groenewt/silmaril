VALUE = 'virtual'
