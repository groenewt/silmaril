VALUE = 'nul-sentinel'
