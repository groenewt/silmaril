VALUE = 'scalac'
