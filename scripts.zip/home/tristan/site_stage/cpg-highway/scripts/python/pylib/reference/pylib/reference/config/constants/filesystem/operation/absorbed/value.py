VALUE = 'absorbed'
