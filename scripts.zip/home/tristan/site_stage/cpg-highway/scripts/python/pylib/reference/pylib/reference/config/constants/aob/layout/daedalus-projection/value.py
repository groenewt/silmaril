VALUE = 'daedalus'
