VALUE = 'hyper'
