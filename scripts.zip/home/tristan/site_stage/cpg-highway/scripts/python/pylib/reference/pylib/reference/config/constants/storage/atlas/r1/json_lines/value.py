VALUE = 'json-lines'
