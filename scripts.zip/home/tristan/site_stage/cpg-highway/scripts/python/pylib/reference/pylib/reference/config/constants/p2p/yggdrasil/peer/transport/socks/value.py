VALUE = 'socks'
