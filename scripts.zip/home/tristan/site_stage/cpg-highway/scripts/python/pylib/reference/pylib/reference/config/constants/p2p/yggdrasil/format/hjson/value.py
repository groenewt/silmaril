VALUE = 'hjson'
