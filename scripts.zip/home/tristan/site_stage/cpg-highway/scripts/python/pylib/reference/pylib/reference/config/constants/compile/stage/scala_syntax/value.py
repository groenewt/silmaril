VALUE = 'scala-syntax'
