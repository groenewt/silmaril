VALUE = 'length-delimited'
