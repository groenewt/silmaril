VALUE = 'solo'
