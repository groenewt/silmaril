VALUE = 'assembly'
