VALUE = '.aob.dir.materialized'
