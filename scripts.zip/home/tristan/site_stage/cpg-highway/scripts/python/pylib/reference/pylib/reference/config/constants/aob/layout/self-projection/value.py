VALUE = 'self'
