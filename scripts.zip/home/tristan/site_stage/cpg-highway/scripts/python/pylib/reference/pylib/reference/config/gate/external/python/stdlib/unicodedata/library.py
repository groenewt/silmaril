import unicodedata as DEPENDENCY
