import regex as DEPENDENCY
