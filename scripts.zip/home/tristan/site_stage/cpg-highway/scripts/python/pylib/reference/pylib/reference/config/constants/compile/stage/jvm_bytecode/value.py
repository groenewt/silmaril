VALUE = 'jvm-bytecode'
