import hashlib as DEPENDENCY
