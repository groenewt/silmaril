VALUE = 'binary-image'
