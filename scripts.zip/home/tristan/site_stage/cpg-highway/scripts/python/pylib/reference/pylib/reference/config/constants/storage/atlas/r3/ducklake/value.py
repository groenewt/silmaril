VALUE = 'ducklake'
