VALUE = 'cluster-worker'
