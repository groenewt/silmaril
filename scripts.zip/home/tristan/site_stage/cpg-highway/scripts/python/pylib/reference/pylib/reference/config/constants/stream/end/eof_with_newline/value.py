VALUE = 'eof-with-newline'
