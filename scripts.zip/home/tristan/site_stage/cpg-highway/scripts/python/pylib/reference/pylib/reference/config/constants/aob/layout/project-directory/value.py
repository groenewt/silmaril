VALUE = '.project'
