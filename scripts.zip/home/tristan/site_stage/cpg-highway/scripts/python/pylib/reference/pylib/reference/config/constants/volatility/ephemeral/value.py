VALUE = 'ephemeral'
