VALUE = 'icarus'
