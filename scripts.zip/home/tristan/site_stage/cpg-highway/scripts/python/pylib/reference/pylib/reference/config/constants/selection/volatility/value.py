VALUE = 'declarative'
