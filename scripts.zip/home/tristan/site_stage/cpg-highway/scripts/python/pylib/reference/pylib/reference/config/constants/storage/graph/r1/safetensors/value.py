VALUE = 'safetensors'
