import json as DEPENDENCY
