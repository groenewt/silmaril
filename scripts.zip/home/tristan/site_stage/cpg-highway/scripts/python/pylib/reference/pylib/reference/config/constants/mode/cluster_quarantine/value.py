VALUE = 'cluster-quarantine'
