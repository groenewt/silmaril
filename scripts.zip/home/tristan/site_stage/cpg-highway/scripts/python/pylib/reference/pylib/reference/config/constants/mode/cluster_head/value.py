VALUE = 'cluster-head'
