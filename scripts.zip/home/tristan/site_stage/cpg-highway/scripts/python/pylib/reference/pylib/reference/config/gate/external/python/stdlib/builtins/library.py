import builtins as DEPENDENCY
