VALUE = 'yggdrasil'
