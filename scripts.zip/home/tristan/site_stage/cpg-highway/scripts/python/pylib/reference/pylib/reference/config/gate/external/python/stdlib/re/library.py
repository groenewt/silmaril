import re as DEPENDENCY
