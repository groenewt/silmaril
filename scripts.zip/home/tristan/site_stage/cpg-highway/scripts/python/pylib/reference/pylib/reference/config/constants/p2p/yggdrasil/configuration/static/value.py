VALUE = 'static'
