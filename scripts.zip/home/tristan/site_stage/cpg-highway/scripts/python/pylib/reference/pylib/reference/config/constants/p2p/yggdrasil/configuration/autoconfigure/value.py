VALUE = 'autoconfigure'
