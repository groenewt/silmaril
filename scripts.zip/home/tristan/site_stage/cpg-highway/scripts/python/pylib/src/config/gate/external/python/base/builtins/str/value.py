VALUE = str
