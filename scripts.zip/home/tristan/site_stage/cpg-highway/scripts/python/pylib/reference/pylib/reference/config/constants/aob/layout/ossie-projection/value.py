VALUE = 'ossie'
