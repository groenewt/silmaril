VALUE = 'isolated'
