VALUE = 'record-framed'
