VALUE = 'machine-code'
