VALUE = 'mmap'
