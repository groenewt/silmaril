VALUE = 'external-boundary'
