VALUE = 'eof'
