VALUE = 'virtualized'
