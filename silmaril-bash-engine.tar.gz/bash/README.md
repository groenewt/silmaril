# Silmaril builtin Bash research engine

This is the continued typed, polymorphic, KV-grounded DAG implementation, not a replacement project.
It is normative computational-economics research infrastructure. It makes transformation provenance,
typed inputs and outputs, and admission failures inspectable. It does not establish an economic
effect, identify causality, or make model-generated narratives into observed data.

## Execute

Set an absolute path to this extracted `bash` directory:

```bash
SILMARIL_ROOT='/absolute/path/to/bash'
BASH_ENV='' ENV='' PATH='' /bin/bash --noprofile --norc -p \
  "${SILMARIL_ROOT}/bin/type-dag.sh" selftest
```

Existing commands are `validate`, `order`, `run`, `graph`, `resume`, `status`, `bytes`, `errors`,
`baseline`, `selftest`, and `admission`. `help` displays their argument order. The `bytes` command
is a diagnostic stream projection, not a canonical self-contained corpus document.

Run the new local-file protocol through a typed DAG:

```bash
BASH_ENV='' ENV='' PATH='' /bin/bash --noprofile --norc -p \
  "${SILMARIL_ROOT}/bin/type-dag.sh" local \
  "${SILMARIL_ROOT}/config/closure/local-read.yaml" \
  "${SILMARIL_ROOT}/config/closure/local-graph.yaml"
```

The fixture contains `A`, NUL, `B`. Its read operation constructs a typed octet product; the
following measurement operation returns the natural-number output `3` in one result frame.

Run the original reference graph:

```bash
BASH_ENV='' ENV='' PATH='' /bin/bash --noprofile --norc -p \
  "${SILMARIL_ROOT}/bin/type-dag.sh" run \
  "${SILMARIL_ROOT}/config/type-dag/graph.yaml" canonicalinput
```

For `run GRAPH INPUT CHECKPOINT`, the checkpoint path must be an existing regular file in an
existing trusted directory. `resume GRAPH INPUT CHECKPOINT` validates graph bytes, input and
dependency states before using it. A compensated node is not treated as successful.

## Runtime implementation

The runtime invokes no shipped alternate-language program. Source files are Bash. It uses
Bash builtins, arrays, namerefs, redirections, arithmetic and shell control syntax. Tests use
Bash subshells for isolation; a subshell is not a second executable image. Bash must provide
64-bit arithmetic for the included SHA-256 implementation. The measured interpreter version
is recorded in the external verification report; no untested version range is asserted.

The closed graph dispatcher selects literal registered primitives. The source-token purity
check is conservative lint, not a complete Bash parser or an adversarial sandbox. Package
source, mutable in-process state, trusted library callbacks and the filesystem must be trusted.
No graph document is sourced or evaluated as shell code. Clearing PATH alone is not proof that
an arbitrary Bash program cannot execute an absolute-path command.

`byte::walk_file` preserves all octet values, including NUL. General byte widths and octet stream
realization remain distinct. Bash strings cannot hold NUL; zero octets are explicit values.
The SHA-256 code is tested against known answers and padding boundaries, not cryptographically
certified. It is used as integrity evidence, never as semantic identity.

## Implemented closure profiles

- Multiple inheritance with C3 order, typed fields, polymorphic methods and next-method resolution.
- Contextual KV constructors, exact source-value and position replay, and declaration-linked frames.
- Typed fan-in products, deterministic order/depth, bounded retry, cooperative deadlines,
  dependency-success requirements, compensation and source/input-bound checkpoint replay.
- Finite acyclic category presentations, congruence quotients, functors, natural transformations,
  categories of elements and finite Yoneda/coend witnesses.
- Six separate axiom records, three theorem records and four construction records. General
  mathematical arguments are in `docs/proofs/category-foundation.md`; finite tests are not
  independent proof-assistant certificates.
- Finite OWL key interpretation and bounded XSD lexical/list/union handling, with explicit
  semantic adjudications in `docs/semantic-adjudications.md`.
- Strict local file-URI encoding/decoding, root and depth accounts, deterministic complete
  directory-child rings, structural taxonomy/primary/secondary/alias governance.
- Unary local file-read endpoint: declared actor/role allowlist, version, root/path and octet cap.
  Admission is transactional in process; policy declarations are not OS authentication.
- Exact source-observation Turtle projections with contextual pairs, typed lexical witnesses,
  source octets, position and provenance. `projection::verify` compares the exact supported
  canonical serialization; it is not an arbitrary RDF parser or a full SHACL engine.
- Included BFO 2020 snapshot with builtin digest verification and complete named-parent-chain
  checks. All anonymous restrictions remain in the original Turtle. CCO/CPO import closure
  and local-to-external semantic grounding are not silently claimed.

## Library entry points

Source `lib/type-dag/init.sh` in a trusted Bash session. New entry points include:

```text
locator::file_encode PATH OUTPUT_VARIABLE
locator::file_decode URI OUTPUT_VARIABLE
path::register_root ROOT_ID ABSOLUTE_DIRECTORY
path::account ROOT_ID ABSOLUTE_PATH CORPUS_DIRECTORY
ring::capture RING_ID ABSOLUTE_DIRECTORY SNAPSHOT_ID
ring::verify RING_ID
digest::sha256_text TEXT OUTPUT_VARIABLE
digest::sha256_file ABSOLUTE_FILE OUTPUT_VARIABLE
taxonomy::register ID RANK PARENT AUTHORITY DIFFERENTIA
classification::primary SPECIMEN TAXON AUTHORITY
classification::secondary SPECIMEN TAXON AUTHORITY
alias::register ALIAS_ID NOTATION TARGET AUTHORITY
endpoint::load ABSOLUTE_MANIFEST
endpoint::read REQUEST_ID
projection::write DOCUMENT_ID SOURCE_FILE EXISTING_TARGET_FILE
projection::verify DOCUMENT_ID SOURCE_FILE PROJECTION_FILE
grounding::load ABSOLUTE_MANIFEST
grounding::ancestry EXTERNAL_CLASS_IRI OUTPUT_VARIABLE
```

These lower-level implementation procedures use explicit Bash output variables/status codes.
Framed admission and graph operations are separate public boundaries. The implementation does
not claim that every helper function is already a separately materialized unary law specimen.

## Materialization and limitations

Static AOBs use full lexical directory paths and remain provisional where their grounding or
metadata is unverified. Empty projection directories mark placement, not completed projections.
The engineering `.skills/HEAD.yaml` is not an active research-admission head.

All-source KV projections are delivered as optional audit evidence rather than runtime
dependencies. They describe the captured source snapshot. Extracting to a different location
creates a new physical occurrence; exact replay uses the captured locator, not an invented
claim that movement preserves occurrence identity.

The local path gate checks symlink components but cannot provide openat/O_NOFOLLOW guarantees
against a hostile concurrent filesystem writer using Bash redirection alone. Filesystem locks,
durable transactions, general network authentication, complete Unicode grapheme handling,
arbitrary XSD schema compilation and full OWL/SHACL reasoning are not implemented.

See `docs/acceptance.md` for all 34 conditions. Research admission deliberately fails while
obligations remain. It also fails for an all-green edited ledger without independent evidence.

The original archives are preserved. Static legacy declaration accounting is not demonstrated
behavioral parity. Modeling an external effect does not execute it. No Git commit or push has
been performed. Host verification and archive tools are not runtime dependencies.

## Closed canonical reference profile

This continuation adds the finite reference-only corpus in `canonical/`, including local metadata, exact contextual key contracts, primary-lineage reconstruction, typed requirement vectors, structured theorem/datatype links and source replay. Native Turtle, SPARQL-data and GraphML views have bounded inverse decoders. See `docs/canonical-reference-profile.md` for the precise guarantees and remaining constitutional boundaries.

```bash
BASH_ENV='' ENV='' PATH='' /bin/bash --noprofile --norc -p \
  "${SILMARIL_ROOT}/bin/type-dag.sh" canonical
```

The `canonical` command is evidence-checked admission of this finite record profile. It is **not** the global research `admission` command, which still rejects outstanding obligations.
