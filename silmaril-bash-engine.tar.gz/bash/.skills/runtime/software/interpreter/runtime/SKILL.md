# Runtime

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:software:realm:execution:subdomain:bash:kingdom:runtime:phylum:interpreter:class:builtin:order:sealed:family:pure:genus:bash:species:runtime:component:engine:instance:canonical`

**Scope:** Bash builtin only runtime boundary.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/software/realm/execution/subdomain/bash/kingdom/runtime/phylum/interpreter/class/builtin/order/sealed/family/pure/genus/bash/species/runtime/component/engine/instance/canonical/atom.spec.yaml`
