# Inheritance

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:knowledge:realm:representation:subdomain:type:system:kingdom:law:phylum:inheritance:class:multiple:order:linearization:family:c:three:genus:monotonic:species:resolution:component:contract:instance:canonical`

**Scope:** Monotonic C3 multiple inheritance linearization.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/knowledge/realm/representation/subdomain/type/system/kingdom/law/phylum/inheritance/class/multiple/order/linearization/family/c/three/genus/monotonic/species/resolution/component/contract/instance/canonical/atom.spec.yaml`
