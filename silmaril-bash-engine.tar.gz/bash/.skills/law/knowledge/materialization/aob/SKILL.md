# Atom Materialization

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:knowledge:realm:representation:subdomain:semantic:identity:kingdom:law:phylum:materialization:class:atom:order:lexical:family:resource:uniform:name:genus:path:species:aob:component:contract:instance:canonical`

**Scope:** Full lexical AOB path projection.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/knowledge/realm/representation/subdomain/semantic/identity/kingdom/law/phylum/materialization/class/atom/order/lexical/family/resource/uniform/name/genus/path/species/aob/component/contract/instance/canonical/atom.spec.yaml`
