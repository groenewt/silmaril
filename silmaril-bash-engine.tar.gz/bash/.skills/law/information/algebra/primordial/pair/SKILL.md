# Primordial Pair

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:information:realm:representation:subdomain:formal:specification:kingdom:law:phylum:algebra:class:product:order:binary:product:family:key:value:binding:genus:recursive:typed:binding:species:primordial:pair:component:admission:contract:instance:corpus:law:version:one`

**Scope:** Contextual key value binding algebra projection.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/information/realm/representation/subdomain/formal/specification/kingdom/law/phylum/algebra/class/product/order/binary/product/family/key/value/binding/genus/recursive/typed/binding/species/primordial/pair/component/admission/contract/instance/corpus/law/version/one/atom.spec.yaml`
