# Operation Contract

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:operation:subdomain:callable:contract:kingdom:law:phylum:contract:class:unary:order:frame:family:typed:genus:operation:species:contract:component:admission:instance:canonical`

**Scope:** Unary domain codomain receiver and frame admission.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/operation/subdomain/callable/contract/kingdom/law/phylum/contract/class/unary/order/frame/family/typed/genus/operation/species/contract/component/admission/instance/canonical/atom.spec.yaml`
