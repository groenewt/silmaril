# Byte Parser

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:representation:subdomain:byte:stream:kingdom:law:phylum:carrier:class:stream:order:octet:family:nul:delimited:genus:bash:species:parser:component:contract:instance:canonical`

**Scope:** Ordered octet streaming under Bash host constraints.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/representation/subdomain/byte/stream/kingdom/law/phylum/carrier/class/stream/order/octet/family/nul/delimited/genus/bash/species/parser/component/contract/instance/canonical/atom.spec.yaml`
