# Purity

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:software:realm:execution:subdomain:bash:kingdom:law:phylum:purity:class:builtin:order:closed:family:external:executable:genus:prohibition:species:runtime:component:contract:instance:canonical`

**Scope:** External executable and subprocess prohibition.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/software/realm/execution/subdomain/bash/kingdom/law/phylum/purity/class/builtin/order/closed/family/external/executable/genus/prohibition/species/runtime/component/contract/instance/canonical/atom.spec.yaml`
