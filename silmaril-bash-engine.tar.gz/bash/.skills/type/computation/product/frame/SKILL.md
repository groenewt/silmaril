# Frame

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:operation:subdomain:callable:contract:kingdom:type:phylum:product:class:frame:order:unary:family:result:genus:typed:species:frame:component:type:instance:canonical`

**Scope:** One typed result with separate operational coordinates.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/operation/subdomain/callable/contract/kingdom/type/phylum/product/class/frame/order/unary/family/result/genus/typed/species/frame/component/type/instance/canonical/atom.spec.yaml`
