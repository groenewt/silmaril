# Octet

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:representation:subdomain:physical:carrier:kingdom:type:phylum:carrier:class:octet:order:eight:bit:family:byte:genus:projection:species:octet:component:type:instance:canonical`

**Scope:** Explicit eight bit byte projection.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/representation/subdomain/physical/carrier/kingdom/type/phylum/carrier/class/octet/order/eight/bit/family/byte/genus/projection/species/octet/component/type/instance/canonical/atom.spec.yaml`
