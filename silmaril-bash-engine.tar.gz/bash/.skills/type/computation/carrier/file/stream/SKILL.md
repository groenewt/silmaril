# File Stream

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:representation:subdomain:physical:carrier:kingdom:type:phylum:carrier:class:octet:order:ordered:family:stream:genus:file:species:file:stream:component:type:instance:canonical`

**Scope:** NUL safe octet stream over an existing file descriptor.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/representation/subdomain/physical/carrier/kingdom/type/phylum/carrier/class/octet/order/ordered/family/stream/genus/file/species/file/stream/component/type/instance/canonical/atom.spec.yaml`
