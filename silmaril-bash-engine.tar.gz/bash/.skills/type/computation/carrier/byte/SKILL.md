# Byte

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:representation:subdomain:physical:carrier:kingdom:type:phylum:carrier:class:byte:order:registered:family:width:genus:general:species:byte:component:type:instance:canonical`

**Scope:** Width independent registered byte ancestry.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/representation/subdomain/physical/carrier/kingdom/type/phylum/carrier/class/byte/order/registered/family/width/genus/general/species/byte/component/type/instance/canonical/atom.spec.yaml`
