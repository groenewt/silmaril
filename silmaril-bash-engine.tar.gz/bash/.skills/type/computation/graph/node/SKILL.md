# Node

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:operation:subdomain:directed:acyclic:graph:kingdom:type:phylum:graph:class:node:order:dependency:family:declarative:genus:typed:species:node:component:type:instance:canonical`

**Scope:** Typed declarative DAG node contract.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/operation/subdomain/directed/acyclic/graph/kingdom/type/phylum/graph/class/node/order/dependency/family/declarative/genus/typed/species/node/component/type/instance/canonical/atom.spec.yaml`
