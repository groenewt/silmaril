# Topology

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:mathematics:realm:topology:subdomain:finite:kingdom:type:phylum:algebra:class:topology:order:open:set:family:space:genus:finite:species:topology:component:type:instance:canonical`

**Scope:** Finite topology open set axioms.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/mathematics/realm/topology/subdomain/finite/kingdom/type/phylum/algebra/class/topology/order/open/set/family/space/genus/finite/species/topology/component/type/instance/canonical/atom.spec.yaml`
