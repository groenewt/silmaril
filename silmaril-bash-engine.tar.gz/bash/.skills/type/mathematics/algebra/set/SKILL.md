# Set

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:mathematics:realm:algebra:subdomain:set:kingdom:type:phylum:algebra:class:set:order:membership:family:extensional:genus:axiomatic:species:set:component:type:instance:canonical`

**Scope:** Finite membership and extensional equality witness.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/mathematics/realm/algebra/subdomain/set/kingdom/type/phylum/algebra/class/set/order/membership/family/extensional/genus/axiomatic/species/set/component/type/instance/canonical/atom.spec.yaml`
