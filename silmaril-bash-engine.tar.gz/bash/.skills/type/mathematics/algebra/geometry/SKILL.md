# Geometry

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:mathematics:realm:geometry:subdomain:metric:kingdom:type:phylum:algebra:class:geometry:order:distance:family:space:genus:finite:species:geometry:component:type:instance:canonical`

**Scope:** Finite metric space axioms.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/mathematics/realm/geometry/subdomain/metric/kingdom/type/phylum/algebra/class/geometry/order/distance/family/space/genus/finite/species/geometry/component/type/instance/canonical/atom.spec.yaml`
