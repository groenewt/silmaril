# Category

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:mathematics:realm:category:subdomain:small:kingdom:type:phylum:algebra:class:category:order:composition:family:morphism:genus:finite:species:category:component:type:instance:canonical`

**Scope:** Finite categorical identities and associative composition.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/mathematics/realm/category/subdomain/small/kingdom/type/phylum/algebra/class/category/order/composition/family/morphism/genus/finite/species/category/component/type/instance/canonical/atom.spec.yaml`
