# Group

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:mathematics:realm:algebra:subdomain:group:kingdom:type:phylum:algebra:class:group:order:binary:family:operation:genus:axiomatic:species:group:component:type:instance:canonical`

**Scope:** Finite group axioms and witness validation.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/mathematics/realm/algebra/subdomain/group/kingdom/type/phylum/algebra/class/group/order/binary/family/operation/genus/axiomatic/species/group/component/type/instance/canonical/atom.spec.yaml`
