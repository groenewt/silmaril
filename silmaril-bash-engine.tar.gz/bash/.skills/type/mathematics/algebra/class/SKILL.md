# Class

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:mathematics:realm:algebra:subdomain:class:kingdom:type:phylum:algebra:class:class:order:membership:family:predicate:genus:axiomatic:species:class:component:type:instance:canonical`

**Scope:** Typed predicate membership without set collapse.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/mathematics/realm/algebra/subdomain/class/kingdom/type/phylum/algebra/class/class/order/membership/family/predicate/genus/axiomatic/species/class/component/type/instance/canonical/atom.spec.yaml`
