# Object

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:knowledge:realm:representation:subdomain:object:system:kingdom:type:phylum:object:class:typed:order:sealed:family:property:genus:typed:species:object:component:type:instance:canonical`

**Scope:** Sealed typed object with inherited fields and methods.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/knowledge/realm/representation/subdomain/object/system/kingdom/type/phylum/object/class/typed/order/sealed/family/property/genus/typed/species/object/component/type/instance/canonical/atom.spec.yaml`
