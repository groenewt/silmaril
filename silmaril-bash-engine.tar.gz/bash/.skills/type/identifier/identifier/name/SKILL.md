# Resource Name

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:identifier:realm:semantic:subdomain:resource:name:kingdom:type:phylum:identifier:class:uniform:order:resource:family:name:genus:silmaril:species:name:component:type:instance:canonical`

**Scope:** Canonical full rank semantic identity parser.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/identifier/realm/semantic/subdomain/resource/name/kingdom/type/phylum/identifier/class/uniform/order/resource/family/name/genus/silmaril/species/name/component/type/instance/canonical/atom.spec.yaml`
