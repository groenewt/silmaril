# Engine

**Identity:** `urn:silmaril:type:graph:instance:instruction:code:property:domain:computation:realm:operation:subdomain:directed:acyclic:graph:kingdom:engine:phylum:graph:class:execution:order:declarative:family:typed:genus:polymorphic:species:dag:component:engine:instance:canonical`

**Scope:** Declarative typed polymorphic DAG executor.

**Runtime:** Bash builtins only. No external executable, child process, dependency, or alternate language is admitted.

**Authoritative AOB:** `aob/urn/silmaril/type/graph/instance/instruction/code/property/domain/computation/realm/operation/subdomain/directed/acyclic/graph/kingdom/engine/phylum/graph/class/execution/order/declarative/family/typed/genus/polymorphic/species/dag/component/engine/instance/canonical/atom.spec.yaml`
