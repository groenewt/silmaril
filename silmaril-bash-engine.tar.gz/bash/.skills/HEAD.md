# Silmaril engineering head

[Machine pointer index](HEAD.yaml)

[Acceptance ledger](../docs/acceptance.md)

[Categorical proof records](../docs/proofs/category-foundation.md)

[Semantic adjudications](../docs/semantic-adjudications.md)

This is a provisional engineering index, not a sealed research-admission head.
