# Closed canonical reference profile

This is a finite, self-describing schema and referentially closed graph. Each schema key has a full-context record, domain, codomain and cardinalities. Every record locally expands its metadata and uses canonical references outside the two description paths. Exact source witnesses are separate physical carriers.

The Bash parser and its shape table are the explicit bootstrap frontier. Record checking does not imply general theorem proof, complete CCO/CPO grounding, or an infinite materialization of the metadata of each metadata occurrence. The captured input source paths are relative to the trusted release root. A physical relocation is a new occurrence, not a renaming of semantic identities.

Use the engine canonical command for validation. Empty projection directories are reserved destinations; only implemented projection files are evidence.
