# Ontology build measurements

triples: 66264  
named_classes: 2688  
equivalent_class_axioms: 157  
subclass_axioms: 2923  
keys: 20  
changes: 163  
shapes: 52  
ontology_headers: 1  
source_headers_retained_as_descriptors: 12  
measurement_at: 2026-09-05T16:04:39.655427+00:00  

Structural counts and executed SHACL results do not constitute complete OWL 2 DL reasoning.
