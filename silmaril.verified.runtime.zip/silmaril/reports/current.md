# Current measured repair profile

The pre-package full native replay completed 33 suites and 274 named cases with zero failures. The exact sealed-source registry contains 277 function views. Capture adds 19 native controls and eight unary-interface controls; the source-catalog equality check adds one. These totals are synthetic verification cases, not economic observations.

The consolidated Turtle file contains 66,277 triples, 2,688 named classes, 157 equivalent-class axioms, 2,923 subclass axioms, 20 key axioms, 52 node shapes and one ontology header. Its longest asserted named-subclass path remains 46 edges. No new semantic depth is claimed from these counts.

Apache Jena 5.6.0 independently accepted the delivered data graph. The 56-case shape exercise passed, including 55 rejecting controls and one positive same-content/different-artifact control. Each of the 52 shapes has a targeted rejecting result. Forty-four shapes have targets in the data graph; eight require the separate synthetic fixture supplement. The inherited 28 rejecting controls also passed. The two-binding native capture bridge independently reconstructs Pair/BindingOccurrence coordinates, cold-replays, and passes its positive and two rejecting SHACL controls.

The archive-level clean replay and trace are recorded in the separate verification archive after packaging. A partial OWL Micro attempt timed out; no complete OWL 2 DL classification, universal recursive KV/AOB closure, full donor parity or whole-corpus seal is asserted. See remaining.md.
