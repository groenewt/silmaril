# September 5 verified repair delivery

## What changed

The repaired runtime preserves the current builtin-only engine rather than replacing it with an untested sketch. Thirty suites completed with 246 passing named cases and zero failures. Seven new implementations bring the sealed source-view census to 267. The observed process tree successfully executed only the initial Bash interpreter; an independent negative control detected an intentionally invoked external executable. This is fixture-limited process-image evidence, not an OS sandbox proof.

The scheduling repair changes FIFO Kahn ready-node selection into earliest-currently-ready declaration order. The regression fails on the predecessor and passes after the replacement. The new bounded prime-field homology and graph analysis has fifteen controls, including diamond DAGs with nonzero first homology, directed cycles, higher degrees, characteristic-dependent ranks, invalid boundaries and arithmetic injection.

## Ontology repair

The exact predecessor produced 20 independent SHACL violations over six records. The successor adds actual instrument and denominator evidence, a meaningful proposed ACS option, an explicitly proposed bargaining design, and byte-verified projection outputs. The actual homology coefficient field is now field two; integer matrix notation is separately retained rather than being presented as an integral-homology computation.

The current consolidated ontology contains 66264 triples, 2688 named classes, 157 equivalent-class axioms, 2923 subclass axioms, 20 key axioms, 52 node shapes and one ontology header. The longest asserted named subclass path has 46 edges. This is an asserted-depth witness, not a proof that every step supplies an independent strict semantic refinement.

Apache Jena 5.6.0 reports conforming data and zero validation results on the delivered graph. All 28 removal/type controls reject. Input hashes are embedded in the validation log. Forty-three shapes have production or explicitly labeled synthetic focus nodes; nine source shapes remain unexercised on the production graph. An empty graph can conform under native SHACL, so that result is not admitted as evidence of completeness. No full OWL 2 DL reasoner or general proof-assistant certificate is claimed.

A stale namespace string inside the inherited SPARQL class target was also corrected. The target now selects the rebased local classes, rather than silently matching nothing. Independent structural checks find no object-property/literal assertion mismatch, datatype-property/resource assertion mismatch, conflicting logical property-kind declaration or explicit named-class/named-individual overlap.

## Sources and quarantine

REF.md and the 580-line REFTWO.md witness are byte-preserved. The absent READING_00 original and the separately referenced longer REFTWO edition remain source obligations. The independent predecessor AOB census contains 7961 files, of which 5646 repeat a taxon reference across rank positions. All 7961 originals are retained in the separate quarantine shard. Neither the padded accounts nor the other 2315 are promoted into active authority.

## Replay and scope

`runtime.log`, `process.images.log` and `independent/validation.log` contain the actual executed checks. The companion verification archive adds the clean-extraction replay and archive integrity results. The root reference-only manifest excludes itself; the archive envelope binds its bytes. Original source editions and source ontologies are not overwritten by the active logical consolidation.

General categorical derivations and the corrected OWL/XSD mapping are in `docs/research/anchor/map/`. Research design records are proposals, not observed socioeconomic or agent behavior. Full predecessor behavioral equivalence, universal recursive KV/AOB closure, meaningful repair of the entire old taxonomy, and live external build/service execution remain unestablished. `remaining.md` and `docs/gates.md` preserve those gates. No whole-corpus acceptance seal is issued, and no Git commit or push occurred.
