# Source authentication and scope

The following exact byte witnesses were recovered from the original `corpus.zip`, preserved in `source/immutable/`, and compared with the archive members:

| Witness | Bytes | Observed physical lines | SHA-256 |
|---|---:|---:|---|
| REF.md | 108813 | 3202 lines, 3201 LF bytes | 8889824f1eb7b54be1dcefc2aaf2a490d63058bc652763d266bbcf345cfcc230 |
| REFTWO.md | 29958 | 580 | 0eb050604184f07bbbe58bf93180b1b616fd6d804e764ccde711c279e6df1b25 |

These are recovered editions, not proof that an independently referenced 1899-line REFTWO edition has been recovered. No `READING_00.md` member was found in the inspected mounted archives or the nine nested archives listed in the evidence. The Library searches did not locate a standalone original. This is a search-scope result, not a claim that the file cannot exist elsewhere. Quotations and previous generated reports are not promoted into source bytes.

`source/ontology/basic.ttl`, `common.ttl` and `cognitive.ttl` preserve the coherent recovered BFO, Common Core and Cognitive Process ontology editions. Their exact byte hashes appear in the packaging manifest and graph source descriptors. Flattening their axioms into the consolidated graph does not prove every local classification is the correct external alignment or provide a complete OWL 2 DL reasoner certificate.

No immutable file was edited and no Git commit, push, repository installation or live service operation was performed.
