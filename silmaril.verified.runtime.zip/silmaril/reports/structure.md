# Independent graph-structure and target audit

Triples: 66264. Named OWL classes: 2688. Ontology headers: 1.
Property-kind/assertion or explicit class/individual overlaps: 0.
Strict named-subclass DAG: True. Longest asserted named path: 46 edges.

These are structural checks, not a complete OWL 2 DL profile or consistency proof. Inherited external axioms are not certified by these counts.

## SHACL target coverage

| Shape | Observed focus nodes |
|---|---|
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:abstract:type:instantiation:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:agent:experiment:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:class:annotation:shape` | 1105 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:controlled:zero:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:derived:finding:grounds:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:engagement:cell:identifier:key:shape` | 5 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:engagement:cell:shape` | 5 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:engagement:premise:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:external:gate:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:final:type:extension:shape` | 79 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:frame:coordinate:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:frame:record:frame:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:game:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:gate:clause:coverage:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:gate:clause:specification:clause:identifier:key:shape` | 4 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:gate:specification:gate:identifier:key:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:higher:cell:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:homotopy:computation:receipt:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:homotopy:engagement:gate:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:homotopy:engagement:interface:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:homotopy:interface:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:homotopy:projection:signified:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:homotopy:receipt:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:information:bearing:artifact:entity:digest:key:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:known:present:control:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:mandate:completeness:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:mandate:specification:mandate:identifier:key:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:measurement:shape` | 4 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:one:cell:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:plan:question:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:process:entity:process:identifier:key:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:projection:family:identifier:key:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:projection:family:same:signified:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:projection:leg:shape` | 6 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:protocol:contract:completeness:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:protocol:contract:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:research:design:completeness:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:research:design:identifier:key:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:sealed:verdict:pending:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:service:configuration:identifier:key:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:skip:eligibility:evidence:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:source:lock:completeness:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:source:lock:identifier:key:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:specification:entity:canonical:identifier:key:shape` | 758 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:specification:identifier:shape` | 758 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:stage:no:self:precedence:shape` | 11 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:turn:resume:shape` | 0 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:two:cell:shape` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:type:kind:identifier:key:shape` | 3 |
| `urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:shape:zero:cell:shape` | 2 |
| `urn:silmaril:type:graph:instance:instruction:code:property:repair:september:five:two:thousand:twenty:six:shape:binding:occurrence` | 1 |
| `urn:silmaril:type:graph:instance:instruction:code:property:repair:september:five:two:thousand:twenty:six:shape:pair` | 1 |

## Empty-target shapes

Empty target sets are reported as unexercised. Native SHACL conformance over an empty graph cannot grant release admission. Explicit nonempty fixture and source controls are checked by the developer suite.

## Maximum-depth witness

`http://purl.obolibrary.org/obo/BFO_0000001`  
`http://purl.obolibrary.org/obo/BFO_0000002`  
`http://purl.obolibrary.org/obo/BFO_0000031`  
`https://www.commoncoreontologies.org/ont00000958`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:specification:entity`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:descriptive:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:type:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:object:type:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:algebraic:structure:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:carrier:bearing:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:nonempty:carrier:bearing:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:operation:bearing:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:finitary:operation:bearing:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:single:operation:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:binary:operation:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:closed:binary:operation:algebraic:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:magma:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:associative:magma:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:semigroup:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:unital:semigroup:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:monoid:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:cancellative:monoid:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:invertible:monoid:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:commutative:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:hausdorff:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:first:countable:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:second:countable:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:separable:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:metrizable:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:completely:metrizable:topological:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:polish:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:locally:compact:polish:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:connected:locally:compact:polish:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:path:connected:locally:compact:polish:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:simply:connected:locally:compact:polish:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:simply:connected:lie:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:finite:dimensional:lie:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:real:lie:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:one:dimensional:real:lie:abelian:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:additive:real:line:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:canonically:ordered:additive:real:line:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:complete:ordered:additive:real:line:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:dedekind:complete:ordered:additive:real:line:group:specification`  
`urn:silmaril:type:graph:instance:instruction:code:property:core:entity:structure:class:standard:real:line:additive:group:specification`  
