# Admission obligations still open

The delivered executable and ontology repairs are not a universal completion seal. The following conditions still block full-corpus admission:

| Obligation | Current evidence | Why admission remains blocked |
|---|---|---|
| Historical source editions | REF and the 580-line REFTWO witness recovered byte for byte; inspected nested archives logged | Original READING_00 and the separately referenced longer REFTWO edition have not been authenticated |
| Semantically valid rank accounts | All 7961 predecessor AOB files retained; 5646 repeat taxon references across rank positions | Quarantine does not supply the missing meaningful per-rank differentia, authority and source alignment; the other 2315 are not automatically valid |
| Universal KV/AOB closure | Native admitted YAML has separate typed pairs and occurrences; new ontology nucleus has executable shape controls | Every historical metadata binding, all term accounts and all independent persisted occurrence AOBs have not been recursively grounded and admitted |
| Complete predecessor behavior | The current native runtime has a tested finite functional profile; original archives remain unchanged | Static symbol/name coverage is not behavioral equivalence. Original mkdir/flock/compiler/network/service effects are not executed by the no-external kernel |
| Full OWL reasoning and shape coverage | Real independent SHACL execution and hostile mutations; separate structural OWL checks | No complete OWL 2 DL profile/consistency reasoner ran. Nine source shapes have no production focus nodes in this snapshot |
| External seven-protocol end-to-end build | Node/context distinctions and source-first requirements are retained as contracts | No Hadoop/BuildKit or live HBase/Solr/Atlas/Kafka/PKI deployment was performed; these external effects remain prohibited in the strict kernel profile |

The central whole-corpus admission decision is WITHHELD. `registry/head.yaml` is the inherited bounded foundation index, not an active head for the quarantined source corpus. Test-fixture admission cannot override any of the conditions above. No status is changed to accepted merely because a document or archive exists.
