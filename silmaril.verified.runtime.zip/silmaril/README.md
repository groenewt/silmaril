# Consolidated capture and ontology repair

This successor retains the repaired Bash runtime and adds observation-scoped KV capture/replay, an exact sealed-source catalog, nominal artifact keys and numeric-zero SHACL controls. Read `docs/continuation/capture.md` for the native interface and `docs/continuation/ontology.md` for the ontology delta. `ontology/consolidated.ttl` is the single consolidated ontology entry point. Independent Java/Python verification is supplied separately, not imported by the engine.

Full-corpus admission remains withheld. Missing original sources, universal recursive AOB closure, meaningful whole-corpus taxonomy repair, full donor behavioral parity, complete OWL 2 DL reasoning and live external-stack execution are not established by these finite tests.

## Retained baseline documentation

# Silmaril: reconciled builtin Bash engine

This is the September 5 repaired successor, with the current evidence in reports/release.md. It contains one active Bash engine, a strict reference-valued key/value interface, typed polymorphic objects, native DAG execution and recovery, finite categorical checks, binary carriers, source projections, address parsing and a bounded RDF/SHACL/import profile.

The executable profile is not the entire historical ontology corpus. See docs/gates.md for all 34 acceptance criteria and docs/parity.md for historical functionality. The external delivery report and clean-extraction log contain the observed test and execution-audit results. Historical claims in docs/baseline.md are not current verification.

## Research purpose

The research capability is auditable local execution of computational-economics contracts and finite strategic-agent experiments. The unit of verification is a binding, object, graph, finite model or execution occurrence. The tested population is the admitted fixture inputs; geography and survey period are not applicable. Verification is descriptive and the execution policy is normative. No economic effect, survey-weighted estimate, causal result or observed sentiment is asserted.

## Run

After the supplied directory is placed on disk, invoke Bash by absolute path. Output directories are already included. No package manager, compiler, external parser, hashing program or service is required by the runtime or tests.

```bash
PATH=/nonexistent /bin/bash /absolute/path/to/silmaril/tests/all.sh
PATH=/nonexistent /bin/bash /absolute/path/to/silmaril/engine.sh validate /absolute/path/to/silmaril/examples/polymorphic.yaml
PATH=/nonexistent /bin/bash /absolute/path/to/silmaril/engine.sh run /absolute/path/to/silmaril/examples/polymorphic.yaml
PATH=/nonexistent /bin/bash /absolute/path/to/silmaril/engine.sh certify /absolute/path/to/silmaril/examples/walking.yaml
```

Bash 5.2 or newer is the target. The report pins the actually tested interpreter. PATH independence alone would not prove no external execution; the delivery also uses an independent host syscall observer, whose findings are explicitly fixture-limited.

Verify the manifest before running tests, because tests intentionally create scratch files and the manifest rejects unlisted files:

```bash
PATH=/nonexistent /bin/bash -c '
  source "$1/engine.sh"
  manifest::verify "$1" "$1/manifest.yaml" || exit
  printf "verified files=%s bytes=%s\n" "$manifestVerified" "$manifestCheckedBytes"
' verify /absolute/path/to/silmaril
```

This verification checks bytes and extents, not publisher authenticity. The self-excluded manifest is covered by the external ZIP digest. Full-tree native SHA-256 verification can be slow; the delivered independent packaging replay checks every file separately and does not represent that host check as native execution. The manifest binds source paths separately from content hashes and supports relocation to the supplied destination root.

## Current diagnostic analysis

```bash
PATH=/nonexistent /bin/bash /absolute/path/to/silmaril/engine.sh analyze /absolute/path/to/silmaril/examples/polymorphic.yaml
```

The emitted reference-only graph diagnostic separates directed acyclicity from undirected cycle rank and reports unit-edge critical-path length. See docs/research/anchor/map/topology.md for the finite homology profile and limits.

## Canonical pair model

`Pair = Key × Value`. Pair identity is reversible and independent of subject and location. A binding occurrence separately records subject, pair, carrier, position and provenance. Every accepted mapping entry has these runtime coordinates. A failed candidate cannot replace the committed mapping graph or reference registry.

The semantic root is `urn:silmaril:type:graph:instance:instruction:code:property`. Canonical YAML admits two-space block mappings with registered lexical keys. All scalar leaves are registered or explicitly constructed references, except prose at METADATA / SHORT / DESCRIPTION and METADATA / LONG / DESCRIPTION. Raw scalar authority, sequences, flow collections, aliases, anchors, duplicate keys and empty anonymous maps reject. Vectors use a referenced constructor and cardinality plus a prefix-sharing ordinal trie. Source offsets, lengths and byte carriers are retained.

Registration and parsing do not establish complete ontology grounding for every possible reference. Recursive metadata and independent persisted AOB closure of the whole corpus remain outside this executable seal.

## Objects and execution

Typed owner/value/cardinality checks, abstract-type rejection, C3 multiple inheritance, polymorphic method resolution and next-method dispatch are executable. The public semantic interface is `engine::apply REQUEST`, returning a Frame identity in `engineResult`. Status, output, effect and error remain separate. Internal helper functions use a physical Bash ABI, including multiargument functions and mutation.

The scheduler uses earliest-currently-ready declaration-order Kahn ordering, native Bash child processes, bounded batches, declaration-order result commits, dependency-success preconditions, retries, timed reads, builtin signals and reverse-commit compensation. Worker outputs must belong to the parent's predeclared immutable object universe. Child-created objects do not silently cross that boundary. Compensation is not a general inverse of external side effects.

Checkpoints bind graph identity, the exact source snapshot, dependency-closed successful nodes and typed outputs. Changed/incomplete checkpoints reject. Parents must exist and one writer must own the output. There is no claim of atomic rename, fsync, kernel locking, crash-atomic persistence or hard real-time deadlines. Live external executable hooks are not admitted.

## Carriers, addresses and integrity

Octet file I/O preserves all 256 values and NUL positions using bounded builtin reads and writes. UTF-8 scalar decoding and source-text validation reject malformed encodings; full grapheme segmentation is not supplied. `wide::*` adds registered width-one-through-128 bitstring schemas with independent bit order, octet order and encoding. No implicit padding or host-integer truncation is used.

`uri::*`, `urn::*` and local `path::*` locator functions separate envelope grammar, equivalence and filesystem location. They do not supply HTTP/TLS/network policy execution. `hash::*` implements native SHA-256. `manifest::*` and `inventory::*` verify membership, original extents, hashes, parent/layer/depth/ordinal and child counts in their bounded profiles.

## Mathematics and ontology

The finite profile checks complete typed category tables, equations, functor identity/composition, naturality, elements, Yoneda, full faithfulness and a coend quotient. It also checks finite groups, topologies and integer-valued metrics. General theorem records and written proofs remain separate from finite execution evidence. Arbitrary presentation word problems and universally machine-checked proof certificates are not claimed.

OWL hasKey uses the named/shared-witness semantics rather than replacing it with database uniqueness or general joint monicity. XSD lexical/value/canonical/facet records remain distinct; lists, overlapping unions and schema-module transformations are modeled but a general XSD processor is not supplied.

`rdf::*` parses the delivered bounded Turtle profile; `shape::*` executes the documented constraint subset and emits standard reports. Unsupported or recursive evaluation fails explicitly. `projection::semanticVerify` checks generated pair graph equality; `projection::verify` separately checks exact rendering bytes. No general OWL consistency claim follows from parsing. Separately, the added consolidated ontology was run through Apache Jena 5.6.0 SHACL by the independent developer tool; see reports/independent. Java is not a runtime dependency.

`ontology/external/imports.ttl` contains the 14,690-triple external projection from the preserved source at evidence/external/source.ttl. The import loader checks exact snapshot digest/version and all declared import edges in that projection. Named BFO/CCO/CPO class chains are checked without treating programming inheritance as grounding, or every shell execution as a cognitive mental act. See docs/grounding.md.

## Files and source views

`engine.sh` is the sole active runtime. `functions/` contains an exact one-function source projection for every sealed implementation, with full lexical rank paths and ABI bridge descriptions in registry/functions.yaml. Those views are verification artifacts, not competing loaded runtimes. `source::verify` checks bodies and canonical path reversal. `registry/head.yaml` remains a bounded foundation index, not a whole-corpus head.

`tests/` is entirely Bash. `evidence/` is the pre-existing scratch root; evidence/external contains preserved provenance. `docs/changes.md` describes repairs; docs/gates.md and docs/parity.md distinguish implemented behavior from policy-blocked or unproved global requirements.

No repository, branch, commit, push or pull request operation was performed. This archive does not claim that groenewt/silmaril has already been updated.
