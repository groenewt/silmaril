# Universal Unary Byte-Frame Law

Observed: `2026-07-14`

Status: **active red migration; the law is specified, but the enforcement
implementation does not yet satisfy the law it enforces**

## Law

Every exposed callable, independent of language, file type, path, declaration
spelling, or generated status, is inventoried as a typed arrow with one
explicit input and one explicit physical frame result. The current syntax
inventory includes Scala `def`, extension methods, callable-valued `val`
bindings and lambdas plus Java methods, explicit constructors, and Java
lambda/SAM bodies; those examples do not bound the law:

```text
T -> Frame(output: X, error|effect: Y)
```

This is the typed product required to construct a frame around a byte stream.
It is not a tuple, `Either`, `Try`, `Future`, raw `Result`, implicit exception,
or success/error sum substituted for the product. The input, output, and
error/effect are separately navigable coordinates. The frame is the Yoneda
point at which the callable's one observed input maps to its output and typed
effect.

This arrow law does **not** redefine the functional-programming triad. The FP
triad is exactly **Haskell, Elixir, Scala**. `T`, `X`, and `Y` name the three
separately normalized carrier positions of one callable frame; they are not
language identities and must never be described, generated, or queried as the
FP triad.

The callable positions also do not flatten the graph coordinate. `S`, `O`, and
`P` are independently typed, nth-dimensional vector/tower coordinates. Their
URN-addressed composition supplies the geometry used by frames, plans,
execution, and micro-partitioning. A scalar triple, raw tuple, or three unrelated
URN strings is not an admissible substitute for those towers.

For each callable, the Source Discipline audit now requires:

1. exactly one parameter clause containing exactly one parameter;
2. an explicit, non-`using`, non-`implicit`, non-`given`, non-`erased`,
   non-default input;
3. physical transitive descent of the input carrier from
   `highway.config.Projection.Byte.Substrate.Value`;
4. explicit URN identity evidence on that physical primordial carrier;
5. an explicit result type whose physical terminal path is
   `Frame/Value.scala`, with the same byte-descent and URN-identity proof;
6. exactly two explicitly typed frame coordinates: one `val output: X` and
   exactly one `val error: Y` or `val effect: Y`;
7. physical byte descent and URN identity for both `X` and `Y`;
8. exactly one physical body line containing exactly one top-level expression;
   an absent body, local declaration sequence, multiline expression,
   multi-statement block, or explicit `return` in Scala rejects;
9. that expression performs exactly one atomic semantic operation or one typed
   delegation. Compressing several comparisons, calls, decision matches,
   planner stages, or state transitions onto one physical line still rejects;
10. no overload identity and no explicit `throw` or Java `throws` effect.

## Explicit binding and observation law

The callable law is language-neutral. Scala and Java name the current scanner
surface; they are not a scope ceiling or an ontology. Each Haskell, Elixir,
Scala, Java, BEAM, native, script, generated, or later language frontend must
project its syntax through a registered ContractGate observation into the same
typed physical evidence. A language that lacks a current frontend remains
unobserved and red; it is never silently outside the law.

The same audit root enforces three additional rules without a file, path,
adapter, language, generated-source, launcher, test, or build exemption:

11. no glob or wildcard import is admissible. Scala/Java `*`, legacy Scala `_`,
    wildcard selectors, and equivalent language forms reject. Every imported
    coordinate is named explicitly or the binding does not exist;
12. explicit spelling alone is not external-dependency admission. Every host,
    JDK, runtime, native, filesystem, descriptor, process, network, clock,
    digest, compiler, or library symbol must cross its registered typed
    ContractGate boundary. Placement below `adapters/jvm` or an exact
    `java.nio.file.Files`-style import grants nothing;
13. file extension, file type, path prefix, language identity, declaration
    kind, annotation, generated status, and naming convention are observations,
    not definitions. A rule such as “this file type in this language with this
    declaration means X” rejects unless a physical typed identity and behavior
    contract independently proves X.

A Markov chain may model ordered process state and transition probability. A
gateway, bridge, tunnel, frontend, adapter, or parser may transport and observe
that process. Neither defines the carrier, identity, callable effect, or
semantic operation it observes. Those remain separately URN-addressed physical
coordinates with exact lineage and byte-frame evidence.

The required terminal finding families are drilled, not fused:

- `Import.Binding.Wildcard.Present.Value`;
- `Import.Binding.Explicit.Absent.Value`;
- `External.Binding.Contract.Gate.Absent.Value`;
- `Definition.Authority.Inferred.Value`, whose evidence retains separate
  File, File-Type, Language, Declaration, and Path coordinates.

Those carriers and language-neutral frontend evidence do not yet exist in the
Gate. Their absence is an enforcement failure, not an exemption or reason to
weaken the law.

The exact `2026-07-15` read finds zero implementation or specification files
naming any of those four families. The current Source Discipline enforcement
frontier also violates the binding law it must enforce: two wildcard imports
remain in
`modules/config/src/main/scala/highway/config/gates/Source/Discipline/Gate.scala`
and one remains in
`modules/config/src/main/scala/highway/config/primordial/gates/Source/Gate/Finding/Entry.scala`.
These are ordinary red findings. Neither self-hosting nor bootstrap status
grants an exception.

Physical line count is therefore necessary but not sufficient. A long nested
expression is not a subatomic callable merely because formatting places it on
one line. Multi-stage work is represented by typed stage state and a unary
scheduler step whose output is `Continue(nextState)` or `Complete(result)`;
each scheduler invocation performs one transition only.

There is no callable constructor exemption and no constructor-method fixed
point. Primary data-constructor syntax is a separate syntax category. It is
admitted only within a lexically drilled config behavior whose innermost
callable already satisfies the complete law above. The callable's declared
physical Frame result derives the only construction closure:

```text
{ declared Frame, Frame.output carrier, Frame.error|effect carrier }
```

The closure is resolved from physical primordial types and has exactly three
identified byte-descendant carrier coordinates. A fourth carrier, a malformed
Frame, a non-Frame result, a non-lawful enclosing callable, or construction
outside config behavior rejects. Scala and Java use the same derivation.
Neither a path spelling nor a `Construct/Apply.scala` suffix authorizes a
callable or carrier.

This is not a prefix rule, name list, adapter privilege, compatibility alias,
ignore, greylist, baseline, or waiver. `audit(root)` and `files(root, files)`
always apply the callable law. The focused-file entrance also computes global
case-fold namespace collisions, so it cannot hide a conflict with an
unchanged path.

## Physical Proof

The Gate-owned typed frontier observes the audited root's physical
`modules/config/src/main/scala/highway/config/primordial/**/Value.scala`
files through registered atomic external probes. No adapter recursively walks
the repository. The Gate then:

- derives carrier identities from declared package plus terminal `Value`;
- resolves `extends`/`with` edges through the existing import and package
  binding model;
- computes the byte-substrate descendant closure to a fixed point;
- requires `Type` or `dtype` plus a URN coordinate or `Lineage.of` identity
  reference in each admitted carrier definition;
- resolves frame coordinate types back to that same physical carrier catalog.

A spelling containing `Byte`, `Frame`, `Value`, or `Urn` is therefore
insufficient. A fake byte-named carrier, a disconnected transitive tower, and
a byte descendant without direct identity evidence all reject.

Repository coordinates are also indexed independently from per-file lexical
inspection. Physical directory coordinates and declared package coordinates
are case-folded, grouped, and reduced to the shallowest conflicting semantic
coordinate. Every member of a collision is a finding. This rejects
`adapters/Jvm` beside canonical `adapters/jvm` and the same class of conflict
for `Execution/execution`, `Knowledge/knowledge`, `Lexical/lexical`,
`Runtime/runtime`, `Semantic/semantic`, `Viewer/viewer`, `Corpus/corpus`, and
`Ossie/ossie`. There is no accepted-case table.

The low-level two-argument `inspect(path, source)` is a legacy violation, not an
isolated-probe exemption. It must be replaced by an exact one-input physical
Frame entrance and then removed. The same rule applies to its internal parser,
scanner, repository-observation, and finding-construction call graph: a public
or private spelling does not change the required `T -> Frame(X, Y)` shape.
Until that decomposition is complete, neither `audit(root)` nor the
changed-file hook is a conforming enforcement entrance, even when its observed
findings are otherwise useful.

## Rule 9 semantic-atomicity gap

Rule 9 is specified but not enforced. The live `singleExpression` predicate at
`Gate.scala:1684` proves only one nonempty physical body line, one top-level
statement, no local declaration, and no Scala `return`. The callable audit at
line 1178 uses that predicate for `Body.Expression.Cardinality`. The
`codomainConstruction` path at line 2116 reuses the same predicate before
granting construction closure, so compressed multistage work can also receive
constructor admission. `frameCodomain` at line 2182 then reduces Frame,
output, and error/effect identities to `Set[String]`, erasing role and
multiplicity after cardinality inspection.

The focused specification is intentionally red for this gap. Its one-line
conditional and nested-call fixtures begin at `Spec.scala:2975`, with direct
`Body.Expression.Cardinality` assertions at line 3014. The positive primary
data-constructor fixture at line 3167 remains a separate syntax category; it
does not authorize a callable or prove semantic atomicity.

Line counts, token counts, regexes, and raw invocation counts cannot close this
law. Rule 9 requires a compiler-resolved term graph bound to the physical
source span. An operation-free coordinate has the form:

```text
Coordinate(input, field_1 ... field_n)
```

Every segment must resolve to a physical typed immutable carrier coordinate.
A zero-argument method, extension, implicit conversion, dynamic selection, or
unresolved symbol is not a coordinate. Exactly two body proofs are admissible:

```text
Delegate(callee, Coordinate(input, ...))
```

This contains exactly one invocation. The callee is a separately audited unary
physical-Frame arrow, the argument is operation-free, and the callee result is
exactly the caller's declared Frame. No constructor, operator, control node,
assignment, lambda, or nested invocation is present.

```text
ConstructClosure(
  frame = F,
  output = X(Atomic(operation, Coordinate(input, ...))),
  error|effect = Y(Coordinate(input, ...))
)
```

The atomic operation has one exact physical identity and proof; its operands
are operation-free coordinates. The closure retains the roles and
multiplicities of exactly one F, one X, and one Y. It is never represented as a
set, admits no fourth carrier, and contains no nested semantic operation. A
constructor-only morphism is this same form with the proven codomain
construction as its atomic operation. Constructor syntax never proves its own
admission.

The judge rejects every branch, `if`, `match`, `try`, loop, guard, conditional,
nested invocation, chained comparison/boolean expression, comparison-plus-
transition, assignment, mutation, local declaration, lambda, `return`,
`throw`, unresolved call, or body containing more than one resolved semantic
operation identity. A comparison is atomic only when its resolved operator has
a physical operation contract. A scheduler leaf may construct one
`Continue(nextState)` or one `Complete(result)` only after the decision is
already carried by its typed input state; deciding and constructing are two
transitions.

This is proof-derived, not a spelling whitelist. Each operation contract binds
the language frontend, compiler-resolved symbol or instruction, T/X/Y/Frame
identities, refinement semantics, revision, and either a pure primitive proof
or an exact ContractGate registration. Missing proof fails closed.

The enforcement dependency DAG is:

```text
R9-0 physical callable occurrence + carrier/inheritance/identity catalogs
 -> R9-1 Scala and Java ContractGate probes emit resolved typed body graphs
 -> R9-2 operation-free coordinate proof
 -> R9-3 role-preserving F/X/Y closure derivation
 -> R9-4a atomic operation identity/refinement proof
 -> R9-4b exact unary typed-delegation proof
 -> R9-5 judge accepts exactly one of R9-4a or R9-4b
 -> R9-6 distinct Rule-8 and Rule-9 finding projection
 -> R9-7 codomain construction consumes that same accepted verdict
 -> R9-8 state-specific Continue/Complete scheduler decomposition
 -> R9-9 Gate orchestration migration
 -> R9-10 self-audit plus Scala/Java adversarial fixtures
```

`R9-4a` and `R9-4b` are mutually exclusive. At minimum the finding algebra
must gain separate terminal carriers for
`Callable.Body.Semantic.Operation.Cardinality.Value` and
`Callable.Body.Operation.Identity.Proof.Absent.Value`; overloading
`Body.Expression.Cardinality` would collapse Rule 8 physical shape into Rule 9
semantic proof. These carriers and the resolved-body frontier do not yet
exist, so this section is an exact red continuation rather than an acceptance
claim.

## Finding Algebra

Fifteen new terminal finding-code carriers were added under
`highway.config.gates.Source.Gate.Finding.Code.Callable`:

- `Input.Cardinality.Value`
- `Input.Explicit.Absent.Value`
- `Input.Primordial.Byte.Descendant.Value`
- `Identity.Overload.Value`
- `Result.Declaration.Absent.Value`
- `Result.Primordial.Byte.Descendant.Value`
- `Frame.Coordinate.Cardinality.Value`
- `Frame.Output.Coordinate.Absent.Value`
- `Frame.Output.Coordinate.Cardinality.Value`
- `Frame.Output.Coordinate.Primordial.Byte.Descendant.Value`
- `Frame.Error.Effect.Coordinate.Absent.Value`
- `Frame.Error.Effect.Coordinate.Cardinality.Value`
- `Frame.Error.Effect.Coordinate.Primordial.Byte.Descendant.Value`
- `Body.Expression.Cardinality.Value`
- `Effect.Typed.Result.Absent.Value`

The sixteenth new code is the repository-topography finding:

- `Case.Fold.Coordinate.Collision.Value`

Each semantic word is a separate package coordinate and every terminal is a
`Value.scala` carrier. The shared finding-code carrier now descends from the
physical byte substrate and projects the typed `dtype` coordinate from each
value's typed `Type` coordinate. `Type`, `dtype`, and `render` are `val`
coordinates; the shared carrier and all sixteen new terminals contain zero
`def` declarations. Each of the sixteen values overrides that Type with its
own terminal
`.../Type/Urn/Value.scala` identity and has an explicit lineage edge to the
normalized finding-code parent.

The identity count is intentionally seventeen, not sixteen:

```text
1 normalized Finding.Code parent Type URN
+ 16 distinct finding-value Type URNs
= 17 Type/Urn/Value.scala constants
```

Twenty-six new terminal Source Discipline segment values construct those URNs
without fused semantic words. The legacy shared
`constants.Source.Discipline.Types.Finding.Code.Urn` remains only as the
default identity debt for preexisting flat finding values; none of the sixteen
new values uses it as its own Type. No conjoined compatibility spelling was
introduced.

## Adversarial Fixtures

The synthetic-repository matrix in the focused Source Discipline specification
now covers:

- a valid transitive byte descendant and a valid output/effect frame;
- zero, plural, contextual, anonymous-context, implicit, defaulted, and
  multiple-clause inputs;
- absent result declaration, tuple, `Either`, `Try`, `Future`, and a raw
  non-frame result carrier;
- fake byte spelling, a disconnected transitive ancestry, and byte descent
  without URN identity;
- absent and multi-expression bodies, explicit `throw`, and overloads;
- one-physical-line conditional compression and nested-call compression,
  proving that formatting several operations onto one line is not atomic;
- absent, duplicate, raw, and extra output/error/effect coordinates;
- a valid extension receiver and a typed callable-valued binding;
- invalid extension arity, inferred extension input, tuple/curried callable
  values, inferred lambdas, and explicitly typed lambdas without a declared
  result;
- a Java unary frame, explicit Java constructors, Java lambda/SAM syntax,
  Java overload, plural input, absent body, `throws`, and `throw`;
- Scala and Java positive codomain-derived construction of exactly Frame,
  output, and effect;
- rejection of a foreign fourth carrier, construction outside config behavior,
  and construction inside a plural-input behavior;
- primary data-constructor declarations remaining distinct from construction
  expressions;
- deterministic physical and declared-package case-fold collisions, including
  `Jvm`/`jvm`, through both full-audit and focused-file entrances.
- rejection of the operator's fused `DocumentInventory`, `UrnRawAdapter`,
  `KleinTransition`, and misspelled `KlienTransition` examples while the
  drilled `Document.Inventory`, `Urn.Raw.Adapter`, and `Klein.Transition`
  physical/package coordinates remain clean;
- preservation of `RDF`, `23`, and `Atlas` as separate acronym, digit-run, and
  word coordinates in both the fused negative fixture and drilled positive
  topology.

Every callable finding code and the case-fold collision code has a direct
assertion in that matrix.
The fixture sources are data supplied to a temporary physical repository; no
production carrier whitelist is involved.

The explicit-binding and observation additions are a separate, still-red
fixture obligation. Before those finding families can be claimed as enforced,
the focused matrix must also prove:

- rejection of Scala `*`, legacy Scala `_`, Java `*`, selector wildcards, and
  every registered frontend's equivalent unbounded binding form;
- rejection of an exactly named external import when no typed ContractGate
  admission exists, including `java.nio.file.Files` below `adapters/jvm`;
- positive admission only when one explicitly named coordinate crosses its
  registered unary ContractGate observation and returns a physical Frame;
- identical semantic classification for identical physical evidence presented
  under different suffixes, file types, paths, language labels, declaration
  kinds, annotations, and generated-source labels;
- a typed red gap when a Haskell, Elixir, Scala, Java, BEAM, native, script, or
  generated frontend is absent, rather than silent exclusion from inventory;
- separation of a Markov process observation from the gateway, bridge, tunnel,
  adapter, parser, or frontend that carries it.

None of those fixtures or finding carriers is presently claimed as authored,
executed, or green. Their absence keeps both full-audit and focused-file
entrances nonconforming.

## Operator TODO Correlation

The `2026-07-15T12:25:46-05:00` coordinated application-source census records
`78` active files, `204` matching lines, and `431` exact
`#@TODO`/`//@TODO` occurrences after fixture payload text is separated from
live operator comments. The new occurrence is the runtime lambda-invocation
parameter decoder's time/space-complexity marker; it is a red process surface,
not a scope extension or an admitted implementation. Earlier same-turn reads
were smaller because the operator was actively adding the new hammer blocks.
The latest complete read repeats the `12:19:33` state exactly. It is a volatile
last-seen observation, not an allowance or frozen baseline.

The same snapshot includes `39` files and `143` lines naming the no-glob law,
and `52` files and `156` lines binding this universal receipt. Independent of
marker placement, the live Scala/Java tree contains `1,478` files and `1,563`
physical wildcard-import lines; `23` marker-bearing files intersect that
wildcard surface. A marked exact import remains red when its
dependency lacks a registered typed ContractGate; the rule is not limited to
the lines that happen to contain `*`.

Markers remain present until the underlying structures are migrated; the gate
correlates violations and does not delete, hide, or accept them.

The repeatable marker command is preserved in
`docs/campaigns/operator-todo-current-census.md`.

## Static Surface Census

The scanner covers Scala definitions, extension receivers, callable-valued
bindings, exposed lambdas, Java methods, explicit Java constructors, abstract
or interface declarations, and Java lambda/SAM arrows. Physical primary data
constructors are inventoried separately from callable declarations. No stale
repository-wide finding total is claimed while the shared source tree is
changing.

## Self-Hosting Red Receipt

`Gate.scala` receives no implementation, launcher, scanner, or bootstrapping
exemption from the law it enforces. The current source is therefore explicitly
**red**, not structurally complete. The exact `2026-07-14` static snapshot is:

```text
3,813 physical lines
163 def declaration starts
152 private def declaration starts
11 non-private member/local def declaration starts
98 declaration starts whose signature reaches = on the same line
65 declaration starts whose signature continues across lines
0 def declaration lines containing a Frame result
```

Those figures remain the exact `2026-07-14` observation, not a mutable claim
about later bytes. The `2026-07-15` S1Δ binding in
`source-discipline-root-takeover-2026-07-14.md` records the live Gate as 3,850
lines, 167 `def` starts, and still zero physical Frame-result defs. Root's
`2026-07-15T10:51` replay resolves those declarations as 156 private or
scoped-private plus 11 non-private starts; 97 reach `=` on the declaration
line and 70 continue across lines. The live source SHA-256 is
`f6bafbe34ec41f6a2755def4133d6e3f9abbff177b73584a12690f7d4c7f69b1`.
It still contains one `Host.walk` call, so neither the Gate-owned observation
frontier nor self-hosting callable shape is green.

The counts come from anchored declaration scans over the one physical file,
not from a stale repository baseline. The ten-input private `inspect` arrow and
the raw `project(source: String): Source.Lexical.Projection` arrow are direct
counterexamples independent of any aggregate count. The source also contains
raw Scala/JDK carriers, tuple mechanics, local helper declarations, and
multi-line bodies. Enforcement exists, but the implementation does not yet
satisfy its own callable shape.

An exact new-law finding total is deliberately not invented: producing that
receipt requires a fresh integrated config compile, then running this gate
against its own physical source with the new carrier graph. The currently
shared target predates concurrent config inputs needed by `Gate.scala`.

The continuation is a dependency DAG, not a one-file rewrite:

```text
S0 Gate.scala + launchers physical snapshot
 -> S1 lexical inventory of every callable and raw mechanic
 -> S2 one primordial input carrier per callable
 -> S3 one primordial output carrier + one error/effect carrier per callable
 -> S4 one physical Frame carrier per callable codomain
 -> S5 external/JDK mechanics moved behind config adapter ports
 -> S6 each pure mechanic moved to one config behavior leaf with one body line
 -> S7 Gate orchestration rendered as unary Frame arrows over those leaves
 -> S8 Gate self-audit + launcher self-audit
 -> S9 focused fixtures, full Source Discipline audit, and red/green receipt
```

`S2` and `S3` may fan out after `S1`; `S4` depends on both. `S5` and `S6` may
fan out after carrier identities exist; `S7` joins them. `S8` and `S9` remain
strict joins. No node permits a compatibility alias, accepted violation,
greylist, baseline, or path exemption.

## Files

The current owned set has `63` files:

- `2` enforcement files: `Gate.scala` and its focused `Spec.scala`;
- `1` shared finding-code carrier updated with byte-substrate `dtype`
  projection;
- `16` drilled finding `Value.scala` carriers: fifteen Callable codes plus
  Case/Fold/Coordinate/Collision;
- `17` drilled Type/Urn `Value.scala` constants: one normalized parent plus
  one identity for every new finding value;
- `26` drilled Source Discipline segment `Value.scala` constants used by
  those identities;
- `1` campaign receipt, this file.

The exact lane-added flat file
`modules/config/src/main/scala/highway/config/primordial/gates/Source/Gate/Finding/Code/Case/Fold/Coordinate/Collision.scala`
was replaced by the drilled `Collision/Value.scala` carrier after all
references moved to `.Collision.Value`; it is the only authorized deletion in
this lane.

No RDF, planner, Telephone, CPG, URN, Atlas/Graph RGB, native, viewer,
generated-service, build, `_specspec`, `_golden`, corpus, or promotion file was
edited by this lane.

## Verification

- Scala CLI `3.8.4`, offline, `-Ystop-after:parser`, with workspace/cache state
  redirected to `/tmp`: passed for `Gate.scala`, `Spec.scala`, the shared
  finding carrier, all sixteen new finding carriers, all seventeen Type URN
  constants, and all twenty-six new segment constants.
- Root repeated the offline Scala CLI `3.8.4` parser pass for the current
  3,850-line Gate source at SHA-256
  `f6bafbe34ec41f6a2755def4133d6e3f9abbff177b73584a12690f7d4c7f69b1`,
  with server disabled and all writable state under `/tmp`. This is syntax
  evidence only; it does not satisfy the unary callable law.
- A scoped static scan proves zero `def` tokens across the shared finding-code
  carrier plus all sixteen new terminal finding carriers.
- An earlier private semantic probe over the fifteen Callable identities was
  superseded by the final val-only shared-carrier correction. It is not claimed
  as a pass for the final files. The Case/Fold identity also requires a fresh
  integrated target because the current target still contains the superseded
  flat collision class.
- Focused behavioral fixtures: authored but not executed. SBT was not invoked
  while concurrent writers were active.
- The `2026-07-15` Rule-9 fixture addition parses under Scala CLI `3.8.4`,
  offline, with `-Ystop-after:parser`. Its behavioral assertions are
  intentionally red against the current `singleExpression` implementation,
  which still counts physical lines/statements but not semantic operations.
- A targeted IDEA `get_file_problems` request for the focused specification
  returned no payload within the local fifteen-second bound and was
  terminated. It is typed-unavailable IDE evidence, not an inspection pass.
- A separate IDEA error inspection of the current Gate source likewise
  returned no payload within sixty seconds and was terminated. It is not a
  semantic inspection pass and does not supersede physical/hash evidence.
- A private integrated semantic compile was attempted offline against the
  existing config target. It stopped before owned typechecking because that
  target predates the concurrent physical-anchor, gate-contract, and adapter
  sources now referenced by the live `Gate.scala`. No current semantic compile
  or behavioral test pass is claimed.
- Scoped whitespace/diff validation is recorded after the final source freeze.

## Open Dependencies

The byte root currently obtains its identity through the legacy constant
`modules/config/src/main/scala/highway/config/constants/Projection/Types/Byte/Substrate/Urn.scala`.
That file remains an explicit open normalization dependency. This lane neither
renamed it nor treated it as an exception.

The exact `2026-07-15` S2 Source-specific closure is separately sealed in
`source-discipline-s2-source-byte-closure-red.md`. All 180 apparent physical
Source byte descendants are current Gate false positives: zero are
coordinate-complete and zero own the required physical Type/URN terminal.
Accordingly no isolated T/X/Y/Frame enforcement leaf can be added without
inheriting fixed-U8/Sorted identity or constructing another forbidden
Node/eigenvalue fallback. The constructor-free physical identity authority and
the coherent carrier-kind normalization wave precede S2; this is a dependency,
not an exemption from auditing the current Gate.

The authority proof is sealed in
`constructor-free-type-urn-authority-red.md`. All 185 physical primordial
Type/URN leaves extend `Urn.Node.Value` and use the eigenvalue metatype. The
eigenvalue's `Type = dtype = coordinate = this` is the required `E = E*`
terminal fixed point, while ordinary identities remain distinct by coordinate.
The open batch-zero work is not choosing a second root: it is removing
constructor-bearing Node ancestry, separating Urn/Node/Functional contracts,
and proving root plus ordinary-coordinate readback without an exemption.

The enforcement is a lexical/physical source proof, not yet compiler/TASTy or
JVM-signature proof. Compiler-expanded effects, inherited Java signatures, and
callables synthesized outside source require later compiled-evidence closure.
The full repository is expected to be red under the new law until its thousands
of callable declarations are migrated; that debt is not a waiver and is not a
reason to weaken the gate.
