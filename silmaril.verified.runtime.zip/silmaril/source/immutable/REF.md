1) you violated style/standards and actively undermined literally all components 2)
Every unique artifact, sense, glossary, taxon, flow, and projection receives a stable URN and an independent AOB:

### What this means in practice

1. **No inline numeric literals in scripts/ code.** Not `64`, not `1024`, not `5`, not `0`, not `1`, not `-1`. If a number appears in code, it MUST be sourced from a `SIL_*` env var, a `scripts/config/` file, `make/volumes.mk`, or a `src/silmaril_specs/data/` YAML. The only exception is a structurally obvious arity/index (@IGNORE:NO EXCEPTIONS:function argument count, tuple element index in a pattern match, list base in `Enum.reduce(items, 0, ...)` where 0 is the identity element of addition — but per NO EXCEPTIONS, even 0 must be a named constant).

2. **No inline string literals for paths, event names, socket paths, timeouts, or field names in scripts/.** These live in the `SIL_*` env block or `scripts/config/`. The only string literals allowed in code are(@IGNORE:NO EXCEPTIONS::
   - (@IGNORE:NO EXCEPTIONS:Error messages in `{:error, {:reason_atom, "descriptive message"}}` tuples (the message is diagnostic, not a magic sentinel)
   - (@IGNORE:NO EXCEPTIONS:Comment strings
   - (@IGNORE:NO EXCEPTIONS:Test fixture strings (in test fixtures only)

3. **No inline timeout values.** Not `5_000`, not `30_000`, not `1_000`. All timeouts come from `SIL_*` env or `scripts/config/`.

4. **No inline interval values.** Not `30_000` (archive), not `45_000` (cat), not `500` (spool). These already live in the `SIL_*` env block or config/constants/numeric/interval/*** or equivalent. Any NEW interval must go there too.

5. **No inline capacity values.** Not `64` (ring), not `512` (batch), not `4096` (lag_max), not `2048`. These live in `SIL_*` env or `scripts/config/`. The ring capacity change (64→1024) and batch size change (512→2048) are config edits, not code edits @TODO: Rings are just circles that stack- this allow us to leverage the polar and differential geometery operations.

6. **No inline path strings.** Not `"logs/hooks"`, not `"logs/hooks/*.avro"`, not `"archive"`, not `"cache/telephone/l2/hot.arrow"`, not `"build/"`, not `"cannon/"`. These live in `SIL_*` env (`SIL_HOOKS_DIR`, `SIL_ARCHIVE_DIR`, `SIL_CANNON_DIR`, etc.) or `scripts/config/`. Reference via env vars or config/constants/path/file/****.

7. **No inline event-name strings.** Not `"hook_agent_text"`, not `"hook_l1_commit_receipt"`, not `"hook_render_progress"`. These live in `or config/constants/event/****/` .

8. **No inline socket path strings.** Not `"logs/.telephone.sock"`. This lives in `SIL_TELEPHONE_SOCK` or config/constants/path/instance/file/socket/****/`.

# 18. Per-atom geometric projection packet

Each applicable atom-of-being should carry projections such as:


Each projection should carry a complete mathematical contract:

[
\boxed{
\Pi_\alpha
==========

\left\langle
D_\alpha,
C_\alpha,
A_\alpha,
U_\alpha,
\phi_\alpha,
\psi_\alpha,
D\phi_\alpha,
G_\alpha,
\mathcal J_\alpha,
\mathcal A_\alpha,
S_\alpha,
F_\alpha,
\varepsilon_\alpha,
\rho_\alpha
\right\rangle
}
]

where:

| Field                | Meaning                                                      |
| -------------------- | ------------------------------------------------------------ |
| (D_\alpha,C_\alpha)  | Domain and codomain types.                                   |
| (A_\alpha)           | Ordered axis URNs.                                           |
| (U_\alpha)           | Units, scales, base years, and transformations.              |
| (\phi_\alpha)        | Forward chart or projection.                                 |
| (\psi_\alpha)        | Inverse, adjoint, backprojection, or compatibility relation. |
| (D\phi_\alpha)       | Jacobian, linearization, or discrete transport operator.     |
| (G_\alpha)           | Metric tensor or distance contract.                          |
| (\mathcal J_\alpha)  | Optional complex structure.                                  |
| (\mathcal A_\alpha)  | Optional typed antipode.                                     |
| (S_\alpha)           | Singular set and boundary conditions.                        |
| (F_\alpha)           | Fidelity class.                                              |
| (\varepsilon_\alpha) | Round-trip and distortion tolerances.                        |
| (\rho_\alpha)        | Provenance and validation evidence.                          |

This belongs in the per-URN AOB and `atom.spec.yaml` projection suite.

```
#@todo: THERE IS ALSO THE REQUIREMENT OF PROCESSES THAT ARE INTERFACED WITH TO BE FULLY SPECIFIEID AND REALIZED IN FULL RENDER (INCLUDING DOCSITE,MAN,OPENAPI,MCP!)
#@TODO: The core idea is the atom.spec.yaml is a master yaml for the aob bundle wherein <ENCODED-URN>.AOB.DIR/***/*.yaml can be understood to be the "expanded"/subatomic form wherein we properly allow validation/task melt (aka. Full atom.spec.yaml taks-> subtasks per subatom (proper/stricter adherence and build on citations/grouding), and the projections are all required to be generated   
<encoded-urn>/
├── atom.spec.yaml
├── <ENCODED-URN>.AOB.DIR/
├── ├── source/
├── │   ├── path.receipt.yaml
├── │   ├── content.digest
├── │   └── evidence.yaml
├── ├── taxonomy/
├── ├── ├── ranks.yaml
│   ├── ├── memberships.yaml
│   ├── └── mappings.yaml
├── ├── polysemy/
│   ├── ├── lexeme.yaml
│   ├── ├── senses.yaml
│   ├── └── collisions.yaml
├── ├── flows/
│   ├── ├── incoming.yaml
│   ├── ├── outgoing.yaml
│   ├── └── evidence.yaml
│   ├── atlas
│   │   └── rows
│   │       └── part-001.yaml
│   ├── context
│   │   └── dewey.yml
│   ├── identity
│   │   └── node.yml
│   ├── lineage
│   │   └── heritage.yml
│   └── relation
│       ├── inbound.yml
│       ├── outbound.yml
│       └── relation.yml
├── .projections/
│   ├── self/
│   ├── grammar/
│   ├── glyph/
│   ├── linkml/
│   ├── shacl/
│   ├── rdf-turtle/
│   ├── sparql/
│   ├── geosparql/
│   ├── ossie/
│   ├── atlas/
│   ├── graphml/
│   ├── dot/
│   ├── uml/
│   ├── xyz/
│   └── yggdrasil/
├── receipts/
└── gaps/

```text
Canonical semantic element
  ├── AOB atom specification
  ├── self projection
  ├── grammar projection
  ├── glyph projection
  ├── LinkML schema and instance
  ├── SHACL data and shapes
  ├── RDF/Turtle representation
  ├── SPARQL query representation
  ├── GeoSPARQL data, profile, and receipt
  ├── OSSIE model and receipt
  ├── Atlas term and coordinate representation
  ├── GraphML
  ├── DOT
  ├── UML
  ├── XYZ chart
  └── Yggdrasil profile
```

EXAMPLES OF GRANULARITY for URNS/AOBS!
1. /instance/specification/local/path/file/project/external/core/lang/logic/<lang>                         ← base AOB (language/spec/version)
          └ /chapter/<n>/<anchor>                                                  ← chapter
                └ /section/<sub-nums>/<anchor>                                      ← section/subsection
                      └ /component/{examples|artifacts|algebra|productions|terms}/<id>   ← component
2./instance/local/instance/file/path/file/project/**/format/markdown/
/instance/local/instance/file/path/file/project/**/format/markdown/{meta/**,components/H0,H1,H2/{tblXXX,PARAGRAPHXXX}}
4.ENSURE FULL COMPLIANCE/PROPER for The BFO/CCO/CPO ANCHOR REQUIREMENT+PROPER TAXONOMICAL LINEAGE/GOVERNANCE (proper specification gate for atom.spec.yaml) and all generator types!
5.ENSURE FULL COMPLIANCE/PROPER for all fields in a given atlas glossary (proper specification gate for atom.spec.yaml) (ensure proper build out of multiple UDPS (user defined properties!), and full buisness metadata components!) !
6. FULL/complaince to ossie
6.ENSURE FULL COMPLIANCE/PROPER full suite generation for all available linkml fields (proper specification gate for atom.spec.yaml) and all generator types!

    Models
        Model-level metadata and directives
        Classes
        Slots
        Types
        Enums
        Subsets
        Metamodel
    Schema Element Metadata
        Providing descriptions
        Providing aliases
        Structured aliases
        Deprecating elements
        Specifying units
        Other metadata slots
    Inheritance
        Linking classes and slots with is_a
        Abstract classes and slots
        Mixin classes and slots
        Materializing inherited slots
    Slots
        ranges
        slot_usage
        Keys & Identifiers
        Type designator
        Cardinality
        inverse
        default values
        logical characteristics
    Arrays
        Types
        NDArrays
        Generators
        See Also
        References
    URIs and Mappings
        background: URIs, IRIs, and CURIEs
        URI Prefixes
        class uri and slot uri
        Enumerations and the meaning slot
        Relationship to ISO-11179-3
        mappings
        id_prefixes
        See Also
    Semantic Enumerations
        Basic Enums
        Mapping Permissible Values to Ontologies
        Working with Enums in Python
        Dynamic Enums
        Tooling to support dynamic enums
    Inlining objects
        Example
        No inlining, reference by key
        Inlining as a list
        Inlining as a dictionary
        Inlining a single-valued object
        Inlining as simple dictionaries
        Inlining with non-JSON serializations
        When should inlining be used?
    Adding constraints and rules
        Unique Keys
        String serialization
        Patterns
        Structured patterns
        Minimum and Maximum values
        Expressions and other advanced features
    Type designators
    Subsets
    Imports
        Importing external schemas
        Local imports
        Making merged files for distribution
    Advanced features
        LinkML Any type
        Boolean constraints
        Rules
        Defining slots
        equals_expression
        URI or CURIE as a range
    Mapping schemas to other frameworks
    Schema Linter
        Introduction
        Configuration
        Rules
        Reports
        Exit Codes
        API Docs
    Derived models
        Asserted vs Derived Models/Schemas
        Materializing a derived model
        Programmatically inferring models
        Specification
    Annotations
        Background
        Adding your own annotations
        Annotation validation
        Validation of annotations
        Other uses of instantiates
    The metamodel
        Metamodel Versioning scheme
        Release Candidates
        Metamodel Release Notes
    Expression Language
        Syntax
        Limitations
        Examples
Generators

A LinkML generator is code that transforms a linkml schema into a datamodel expressed using another framework, or into some other artefact, such as JSON-Schema, or markdown documentation.

Generators allow you to tap into the rich tooling offered in other technical stacks. The philosophy of LinkML is to embrace and reuse these existing frameworks, rather than serve as an alternative.
Schema Frameworks

These generators translate from a LinkML model to commonly used web standards for structuring data such as JSON-Schema, Protocol Buffers (ProtoBuf), and GraphQL.

Contents:

    JSON Schema
    ProtoBuf
    GraphQL
    OpenAPI

Linked Data Standards

Linked Data is a broad term encompassing frameworks based on RDF and URIs/IRIs. LinkML schemas, can be translated directly into RDF, or they can be mapped to OWL, or translated to shape languages such as ShEx and SHACL.

Contents:

    JSON-LD Contexts
    JSON-LD
    RDF
    SPARQL
    ShEx
    SHACL
    OWL
    YARRRML

Documentation Generation

These generators will translate LinkML models into documentation, including UML class diagrams and markdown websites that can be easily published on static hosting sites.

Contents:

    Documentation
    ER Diagrams
    PlantUML Diagram Generator
    Project Generator

Language Specific

These will generate object models that are particular to specific languages such as Python, Javascript, or Java.

Contents:

    Python
    Pydantic
    Java
    Typescript
    Rust

Database

Generators specific to database frameworks, including SQL and graph databases.

Contents:

    SQL DDL
    SQL Alchemy
    SQL Validation
    BigQuery DDL
    TypeDB / TypeQL

Others

Contents:

    LinkML Generators
    Prefix Generator
    SSSOM
    TerminusDB
    Excel Spreadsheet
    CSV
    Yaml
    Pandera

Feature Dashboard

See which metamodel features each generator supports at a glance.

    Generator Feature Dashboard

Common

Classes and utilities used by all generators

Common:

    Common
        Build
            BuildResult
            ClassResult
            EnumResult
            RangeResult
            SchemaResult
            SlotResult
            TypeResult
        Lifecycle
            LifecycleMixin
        Type Designators
            get_accepted_type_designator_values()
            get_type_designator_value()

@@@FULL OSSIE SPEC
<!--
  Licensed to the Apache Software Foundation (ASF) under one
  or more contributor license agreements.  See the NOTICE file
  distributed with this work for additional information
  regarding copyright ownership.  The ASF licenses this file
  to you under the Apache License, Version 2.0 (the
  "License"); you may not use this file except in compliance
  with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing,
  software distributed under the License is distributed on an
  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, either express or implied.  See the License for the
  specific language governing permissions and limitations
  under the License.
-->

# Apache Ossie - Core Metadata Specification

> **DRAFT version** — in development, schema may change before 0.2.0 is released.

**Version:** 0.2.0.dev0

## Goals

- **Standardization**: Establish uniform language and structure for semantic model definitions, ensuring consistency and ease of interpretation across various tools and systems.
- **Extensibility**: Support domain-specific extensions while maintaining core compatibility.
- **Interoperability**: Enable exchange and reuse across different AI and BI applications.

## Table of Contents

1. [Enumerations](#enumerations)
2. [Semantic Model](#semantic-model)
3. [Datasets](#datasets)
4. [Relationships](#relationships)
5. [Fields](#fields)
6. [Metrics](#metrics)
7. [Examples](#examples)

---

## Enumerations

Standard enumeration values used throughout the specification.

### Dialects

Supported SQL and expression language dialects for metrics and field definitions.

| Dialect | Description |
|---------|-------------|
| `ANSI_SQL` | Standard SQL dialect |
| `SNOWFLAKE` | Snowflake SQL |
| `MDX` | Multi-Dimensional Expressions |
| `TABLEAU` | Tableau calculations |
| `DATABRICKS` | Databricks SQL |
| `MAQL` | GoodData MAQL (Metric Analysis and Query Language) |
| `BIGQUERY` | Google BigQuery (GoogleSQL) |

### Data types

`DataType` declares the logical value type of a field or metric independently
of its role and physical representation. The shared names align with the
ontology specification's built-in value types; `Time`, `DateTimeTz`, and
`Opaque` are additional core data types.

| DataType | Description |
|----------|-------------|
| `String` | Variable-length Unicode character data; length and collation are unspecified. |
| `Integer` | Exact integral number; width and signedness are unspecified. |
| `Decimal` | Exact base-10 number; precision and scale are unspecified. |
| `Float` | Approximate floating-point number. |
| `Boolean` | Logical two-valued truth type. |
| `Date` | Calendar date with no time-of-day component. |
| `Time` | Time-of-day with no date or timezone. |
| `DateTime` | Local/civil date and time with no timezone or offset. |
| `DateTimeTz` | Date and time with sufficient offset or timezone context to identify an instant. Preservation of a named timezone identifier is not guaranteed. |
| `Opaque` | Known type outside the portable vocabulary; use `custom_extensions` for vendor-specific refinement. Omit `datatype` when the type is unknown or unspecified. |

## Semantic Model

The top-level container that represents a complete semantic model, including datasets, relationships, and  metrics.

### Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Unique identifier for the semantic model |
| `description` | string | No | Human-readable description |
| `ai_context` | string/object | No | Additional context for AI tools (e.g., custom instructions) |
| `datasets` | array | Yes | Collection of logical datasets (fact and dimension tables) |
| `relationships` | array | No | Defines how logical datasets are connected |
| `metrics` | array | No | Quantifiable measures defined as aggregate expressions on fields from logical datasets |
| `custom_extensions` | array | No | Vendor-specific attributes for extensibility |

### Example

```yaml
semantic_model:
  - name: sales_analytics
    description: Sales and customer analytics model
    ai_context:
      instructions: "Use this model for sales analysis and customer insights"
    datasets:
      - name: orders
        source: sales.public.orders
    relationships: []
    metrics: []
    custom_extensions:
      - vendor_name: DBT
        data: '{"project_name": "tpcds_analytics", "models_path": "models/semantic"}'
```

---

## Datasets

Logical datasets represent business entities or concepts (fact and dimension tables). They contain fields and define the structure of the data.

### Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Unique identifier for the dataset |
| `source` | string | Yes | Reference to underlying physical table/view (e.g., `database.schema.table`) or query |
| `primary_key` | array | No | Primary key columns that uniquely identify rows (single or composite) |
| `unique_keys` | array of arrays | No | Array of unique key definitions (each can be single or composite) |
| `description` | string | No | Human-readable description |
| `ai_context` | string/object | No | Additional context for AI tools (e.g., synonyms, common terms) |
| `fields` | array | No | Row-level attributes for grouping, filtering, and metric expressions |
| `custom_extensions` | array | No | Vendor-specific attributes |

### Primary Key Examples

```yaml
# Simple primary key
primary_key: [customer_id]

# Composite primary key
primary_key: [order_id, line_number]
```

### Unique Keys Examples

```yaml
# Multiple unique keys (each can be simple or composite)
unique_keys:
  - [email]                    # Simple unique key
  - [first_name, last_name]    # Composite unique key
```

### Example

```yaml
datasets:
  - name: orders
    source: sales.public.orders
    primary_key: [order_id]
    unique_keys:
      - [order_id]
      - [order_number]
    description: Order transactions
    ai_context:
      synonyms:
        - "purchases"
        - "sales"
    fields: []
    custom_extensions:
      - vendor_name: DBT
        data: '{"materialized": "table"}'
```

---

## Relationships

Relationships define how logical datasets are connected through foreign key constraints. They support both simple and composite keys.

### Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Unique identifier for the relationship |
| `from` | string | Yes | The logical dataset on the many side of the relationship |
| `to` | string | Yes | The logical dataset on the one side of the relationship |
| `from_columns` | array | Yes | Array of column names in the "from" dataset (foreign key columns) |
| `to_columns` | array | Yes | Array of column names in the "to" dataset (primary or unique key columns) |
| `ai_context` | string/object | No | Additional context for AI tools |
| `custom_extensions` | array | No | Vendor-specific attributes |

### Important Notes

- The order of columns in `from_columns` must correspond to the order in `to_columns`
- Both arrays must have the same number of columns
- For simple relationships, use a single column: `[column1]`
- For composite relationships, use multiple columns: `[column1, column2]`

### Examples

**Simple Relationship:**

```yaml
- name: orders_to_customers
  from: orders
  to: customers
  from_columns: [customer_id]
  to_columns: [id]
```

**Composite Relationship:**

```yaml
# order_lines.product_id = products.id AND order_lines.variant_id = products.variant_id
- name: order_lines_to_products
  from: order_lines
  to: products
  from_columns: [product_id, variant_id]
  to_columns: [id, variant_id]
```

---

## Fields

Fields represent row-level attributes that can be used for grouping, filtering, and in metric expressions. They can be simple column references or computed expressions.

### Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Unique identifier for the field within the dataset |
| `expression` | object | Yes | Expression definition with dialect support |
| `dimension` | object | No | Dimension metadata (e.g., `is_time` flag) |
| `label` | string | No | Label for categorization |
| `description` | string | No | Human-readable description |
| `datatype` | string (enum) | No | Logical data type for this field. See [Data types](#data-types). |
| `ai_context` | string/object | No | Additional context for AI tools (e.g., synonyms) |
| `custom_extensions` | array | No | Vendor-specific attributes |

### Expression Object

The expression object supports multiple SQL dialects for cross-platform compatibility. Each field can define expressions in different dialects.

**Structure:**

```yaml
expression:
  dialects:
    - dialect: ANSI_SQL  # Must be one of the dialects enum values
      expression: "customer_id"  # Scalar SQL expression
```

**Key Points:**

- Use scalar SQL expressions (no aggregations)
- Can be simple column references (e.g., `customer_id`) or computed expressions (e.g., `first_name || ' ' || last_name`)
- Multiple dialect versions can be provided for the same field

### Dimension Object

| Field | Type | Description |
|-------|------|-------------|
| `is_time` | boolean | Temporal-role marker. When `true`, consumers that distinguish time dimensions (e.g. for time-series analysis or temporal filtering) should treat this field as a time dimension. This is a *role* flag, independent of the field's data type. See [DataType and `is_time`: type vs. role](#datatype-and-is_time-type-vs-role). |

### Examples

**Simple Column Reference for a Dimension:**

```yaml
- name: customer_id
  expression:
    dialects:
      - dialect: ANSI_SQL
        expression: customer_id
  description: Customer identifier
  dimension:
    is_time: false
```

**Computed Field:**

```yaml
- name: full_name
  expression:
    dialects:
      - dialect: ANSI_SQL
        expression: first_name || ' ' || last_name
  description: Customer full name
  ai_context:
    synonyms:
      - "name"
      - "customer name"
```

**Time Dimension:**

```yaml
- name: order_date
  expression:
    dialects:
      - dialect: ANSI_SQL
        expression: order_date
  datatype: Date
  dimension:
    is_time: true
  description: Date when order was placed
  ai_context:
    synonyms:
      - "purchase date"
      - "transaction date"
```

**Multi-Dialect Field:**

```yaml
- name: email_normalized
  expression:
    dialects:
      - dialect: ANSI_SQL
        expression: LOWER(email)
      - dialect: SNOWFLAKE
        expression: LOWER(email)::VARCHAR
      - dialect: BIGQUERY
        expression: SAFE_CAST(LOWER(email) AS STRING)
  description: Normalized email address
```

### DataType and `is_time`: type vs. role

`datatype` and `dimension.is_time` are independent properties that answer different questions:

- **`datatype`** describes the *data type* of the field (e.g. `Date`, `Integer`, `String`, `DateTimeTz`): what kind of values the field holds.
- **`dimension.is_time`** is a *temporal-role marker*: whether the field should be treated as a time dimension for time-series analysis or temporal filtering, regardless of its data type.

**Default for `is_time`.** When `is_time` is not set explicitly, it defaults to `true` if `datatype` is one of `Date`, `Time`, `DateTime`, `DateTimeTz`, and `false` otherwise. Explicit `is_time` always wins. Set `is_time: false` on a temporal-typed column (e.g. an audit `created_at` you don't want on the time axis) to opt out of the default.

Common combinations:

| Column example | `datatype` | `is_time` | Effective role | Why |
|---|---|---|---|---|
| `d_date` (calendar date) | `Date` | omitted | time dimension | Temporal `datatype`; `is_time` defaults to `true`. |
| `order_timestamp` | `DateTimeTz` | omitted | time dimension | Same. |
| `created_at` (audit timestamp) | `DateTime` | `false` | regular dimension | Explicit opt-out of the temporal default. |
| `d_year` (integer year grain) | `Integer` | `true` | time dimension | Non-temporal `datatype`; `is_time: true` makes the role explicit. |
| `d_quarter_name` (e.g. `"Q1"`) | `String` | `true` | time dimension | String-valued temporal grain. |
| `customer_id` | `Integer` | omitted | regular dimension | Non-temporal `datatype`; `is_time` defaults to `false`. |

> **Precedent.** This type/role separation mirrors [Snowflake Semantic Views' YAML authoring form](https://docs.snowflake.com/en/user-guide/views-semantic/semantic-view-yaml-spec), which has a structural `time_dimensions:` collection whose entries can carry any `data_type`. The published example annotates `order_year` with `data_type: NUMBER`. LookML supports a similar split via its [`dimension_group`](https://cloud.google.com/looker/docs/reference/param-field-dimension-group), whose `datatype` enum covers `date`, `datetime`, `timestamp`, plus the integer-encoded forms `epoch` and `yyyymmdd`.

**Consumer guidance.**

- For *data-type* questions (casting, serialization, downstream type inference): prefer `datatype` when present. If only `is_time: true` is set, do not infer a specific scalar type from it.
- For *role* questions (classifying time dimensions in a query UI, generating time-series output sections, choosing time-aware aggregations): treat the field as a time dimension when `is_time` resolves to `true`, whether explicitly set or defaulted from a temporal `datatype`.

---

## Metrics

Quantitative measures defined on business data, representing key calculations like sums, averages, ratios, etc. Metrics are defined at the semantic model level and can  span multiple datasets.

### Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Unique identifier for the metric |
| `expression` | object | Yes | Expression definition with dialect support |
| `description` | string | No | Human-readable description of what the metric measures |
| `datatype` | string (enum) | No | Logical data type for this metric. See [Data types](#data-types). |
| `ai_context` | string/object | No | Additional context for AI tools (e.g., synonyms) |
| `custom_extensions` | array | No | Vendor-specific attributes |

### Expression Object

The expression object supports multiple dialects

```yaml
expression:
  dialects:
  - dialect: ANSI_SQL  # Default
    expression: "SUM(order.sales) / COUNT(DISTINCT order.customer_id)"
```

### Examples

**Simple Aggregation:**

```yaml
- name: total_revenue
  expression:
    dialects:
      - dialect: ANSI_SQL
        expression: SUM(orders.amount)
  description: Total revenue across all orders
  datatype: Decimal
  ai_context:
    synonyms:
      - "total sales"
      - "revenue"
```

**Cross-Dataset Metric:**

```yaml
- name: avg_orders
  expression:
    dialects:
      - dialect: ANSI_SQL
        expression: SUM(orders.amount) / COUNT(DISTINCT customers.id)
  description: Average orders
  datatype: Decimal
  ai_context:
    synonyms:
      - "Order Average by customer"
```

---

## Custom Extensions

Custom extensions allow vendors to add platform-specific metadata without breaking core compatibility. Each extension includes a vendor name and arbitrary JSON data.

### Schema

```yaml
custom_extensions:
  - vendor_name: string  # Free-form string identifying the vendor
    data: string         # JSON string containing vendor-specific data
```

### Vendor Names

The `vendor_name` field is a free-form string, allowing any vendor or organization to
define custom extensions without requiring changes to the core specification.

The following are well-known examples:

| Vendor | Description |
|--------|-------------|
| `COMMON` | Common/standard extensions |
| `SNOWFLAKE` | Snowflake-specific attributes |
| `SALESFORCE` | Salesforce/Tableau-specific attributes |
| `DBT` | dbt-specific attributes |
| `DATABRICKS` | Databricks-specific attributes |
| `GOODDATA` | GoodData-specific attributes |
| `HONEYDEW` | Honeydew-specific attributes |
| `WISDOM` | WisdomAI-specific attributes |

### Examples

**Snowflake Extension:**

```yaml
- vendor_name: SNOWFLAKE
  data: '{
    "warehouse": "ANALYTICS_WH",
    "database": "PROD",
    "schema": "PUBLIC"
  }'
```

**Salesforce Extension:**

```yaml
- vendor_name: SALESFORCE
  data: '{
    "tableau_workbook_id": "sales_dashboard",
    "einstein_enabled": true,
    "crm_sync": {
      "enabled": true,
      "sync_frequency": "daily"
    }
  }'
```

**DBT Extension:**

```yaml
- vendor_name: DBT
  data: '{
    "project_name": "analytics",
    "materialized": "table",
    "tags": ["daily", "core"]
  }'
```

**Databricks Extension:**

```yaml
- vendor_name: Databricks
  data: '{
    "default_catalog": "finance",
    "default_schema": "gold"
  }'
```

---

## Complete Example

Here's a complete semantic model example showing all components working together:

```yaml
version: 0.2.0.dev0
semantic_model:
  - name: ecommerce_analytics
    description: E-commerce sales and customer analytics
    ai_context:
      instructions: "Use this model for analyzing sales trends, customer behavior, and product performance"

    datasets:
      - name: orders
        source: sales.public.orders
        primary_key: [order_id]
        description: Customer orders
        fields:
          - name: order_id
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: order_id
            description: Order identifier

          - name: customer_id
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: customer_id
            description: Customer identifier

          - name: order_date
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: order_date
            datatype: Date
            dimension:
              is_time: true
            description: Order date

          - name: amount
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: amount
            description: Order amount

      - name: customers
        source: sales.public.customers
        primary_key: [id]
        description: Customer information
        fields:
          - name: id
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: id
            description: Customer identifier

          - name: email
            expression:
              dialects:
                - dialect: ANSI_SQL
                  expression: email
            description: Customer email

    relationships:
      - name: orders_to_customers
        from: orders
        to: customers
        from_columns: [customer_id]
        to_columns: [id]

    metrics:
      - name: total_revenue
        expression:
          dialects:
            - dialect: ANSI_SQL
              expression: SUM(orders.amount)
        description: Total revenue from all orders
        ai_context:
          synonyms:
            - "total sales"
            - "revenue"

      - name: customer_count
        expression:
          dialects:
            - dialect: ANSI_SQL
              expression: COUNT(DISTINCT customers.id)
        description: Total number of customers
        ai_context:
          synonyms:
            - "total customers"
            - "customer base"

    custom_extensions:
      - vendor_name: SNOWFLAKE
        data: '{"warehouse": "ANALYTICS_WH"}'
```

---

## AI Context Structure

The `ai_context` field can be either a simple string or a structured object with specific keys:

**Simple String:**

```yaml
ai_context: "orders, purchases, sales"
```

**Structured Object:**

```yaml
ai_context:
  instructions: "Use this for sales analysis"
  synonyms:
    - "orders"
    - "purchases"
    - "sales"
  examples:
    - "Show total sales last month"
    - "What's the revenue by region?"
```

### Recommended AI Context Fields

| Field | Type | Description |
|-------|------|-------------|
| `instructions` | string | Instructions for AI on how to use this entity |
| `synonyms` | array | Alternative names and terms |
| `examples` | array | Sample questions or use cases |

---

## Version History

- **0.2.0.dev0** (Unreleased): In-development next minor release. Schema is mutable; do not depend on this version in production.
- **0.1.1** (2025-12-11): Initial release
  - Core semantic model structure
  - Support for datasets, relationships, fields, and metrics
  - Multi-dialect metric expressions
  - Vendor extensibility framework
  - Context for agents

---

## License

See LICENSE file for details.
## The hierarchy spine

```text
Domain
  └── Realm
      └── Subdomain
          └── Kingdom
              └── Phylum
                  └── Class
                      └── Order
                          └── Family
                              └── Genus
                                  └── Species
                                      └── Component
                                          └── Instance
```

Path depth does not determine rank. A path segment supplies lexical evidence. Rules assign rank.

Ranks may be skipped when no defensible intermediate taxon exists. Artificial padding is forbidden.

## Seven independent hierarchy systems

| Hierarchy                | Relation                           | Shape                  |
| ------------------------ | ---------------------------------- | ---------------------- |
| Filesystem containment   | `locatedWithin`                    | Tree                   |
| Ontological type         | `subClassOf`, `instanceOf`         | Polyhierarchical DAG   |
| Mereological composition | `partOf`, `hasPart`                | DAG                    |
| Glossary semantics       | `broader`, `narrower`, `related`   | Lattice                |
| Process flow             | `precedes`, `consumes`, `produces` | Directed graph         |
| Provenance               | `derivedFrom`, `attestedBy`        | Directed acyclic graph |
| Projection               | `projectsTo`, `preserves`, `drops` | Typed multigraph       |

Only filesystem containment requires one parent. All other hierarchies may have multiple parents.

## Twenty seed kingdoms

Kingdom URNs use:

```text
urn:silmaril:ga:kingdom:{full-lexical-key}
```

### Realm I: Economic observation

| ID  | Kingdom                                                        |
| --- | -------------------------------------------------------------- |
| K01 | Official Economic Statistics                                   |
| K02 | Bureau of Labor Statistics Products and Programs               |
| K03 | Statistical Observations, Measures, Estimates, and Uncertainty |
| K04 | Populations, Geographies, Periods, Units, and Price Bases      |

### Realm II: Artifact substrate

| ID  | Kingdom                                                |
| --- | ------------------------------------------------------ |
| K05 | Corpus, Repository, Revision, and Snapshot             |
| K06 | Filesystem and Kernel Objects                          |
| K07 | Artifact, Path, Content, Module, and Semantic Identity |
| K08 | Package, Namespace, Import, and Entrypoint             |

### Realm III: Execution algebra

| ID  | Kingdom                                                  |
| --- | -------------------------------------------------------- |
| K09 | Configuration, Constants, Commands, and Environments     |
| K10 | Dependencies, Capabilities, and External Gates           |
| K11 | Contracts, Schemas, Constraints, and Validation          |
| K12 | Unary Processes, Inputs, Outputs, Frames, and Effects    |
| K13 | Lambda, Bit, Byte, Cipher, and Digest                    |
| K14 | Morphisms, Categories, Grammars, Operators, and Rewrites |

### Realm IV: Knowledge transformation

| ID  | Kingdom                                             |
| --- | --------------------------------------------------- |
| K15 | Codebase Volume, Inventory, Catalog, and Manifest   |
| K16 | Atlas, Glossary, Term, Axis, and Semantic Topology  |
| K17 | Tables, Documents, Headers, Rows, Cells, and Fields |

### Realm V: Production and assurance

| ID  | Kingdom                                                    |
| --- | ---------------------------------------------------------- |
| K18 | Build, Make, Render, Interface, and Deployment             |
| K19 | Tests, Fixtures, Quality, Conformance, and Benchmarks      |
| K20 | Provenance, Evidence, Receipts, Gaps, Trust, and Authority |

## Example ranked classification

For the row canonical-order command constant:

| Rank      | Assignment                                                    |
| --------- | ------------------------------------------------------------- |
| Domain    | Computational Economics Research Infrastructure               |
| Realm     | Knowledge Transformation                                      |
| Subdomain | Official-Statistics Software Analysis                         |
| Kingdom   | Atlas, Glossary, Term, Axis, and Semantic Topology            |
| Phylum    | Glossary Aggregation                                          |
| Class     | Tabular Transformation                                        |
| Order     | Row Normalization                                             |
| Family    | Canonical Ordering                                            |
| Genus     | Projection Process Configuration                              |
| Species   | Python Command Constant Module                                |
| Component | `value.py` module                                             |
| Instance  | Exact path occurrence plus corpus snapshot and content digest |

Additional kingdom memberships:

```text
K07 Artifact Identity
K09 Configuration and Command
K12 Unary Process
K14 Morphism and Projection
K17 Table and Row
```

One home kingdom supports packaging. Multiple semantic memberships preserve reality.

---

# 9. Flow model

## Flow A: Corpus ingestion

```text
Shard capture
 /instance/spec/local/external/core/lang/logic/<lang>                         ← base AOB (language/spec/version)
          └ /chapter/<n>/<anchor>                                                  ← chapter
                └ /section/<sub-nums>/<anchor>                                      ← section/subsection
                      └ /component/{examples|artifacts|algebra|productions|terms}/<id>   ← component
  → shard ordering
  → concatenation digest
  → tree parsing
  → path-occurrence identity
  → artifact-kind classification
  → lexical atomization
  → glossary binding
  → sense resolution
  → taxonomy assignment
  → flow inference
  → constraint validation
  → projection fan-out
  → receipt and gap reconciliation
  → operator review
  → seal
```

Every transition produces a receipt. An error produces a typed effect and explicit gap, not silent omission.

## Flow B: Subatomic semantic construction

```text
bit
  → byte
  → encoded code unit
  → Unicode scalar
  → grapheme
  → lexeme
  → literal word
  → syntax node
  → semantic sense
  → typed relation
  → taxonomic membership
  → projection
```

This prevents the system from jumping directly from a pathname string to an ontology assertion.

## Flow C: Unary executable law

```text
Input
  → Process
  → Frame(
       Output,
       Effect
     )
```

Supporting edges:

```text
Configuration Value ─────► Process
Dependency Library ──────► Process
Contract ─────────────────► Input
Schema Constraint ────────► Output
Receipt ◄────────────────── Validation
```



## Core ontology classes

```text
StateSpace
StratifiedStateSpace
CoordinateReferenceSystem
CoordinateAxis
CoordinateChart
ChartTransition
CartesianCoordinateSpace
PolarCoordinateSpace
ComplexCoordinateSpace
RiemannianManifold
StatisticalManifold
ProbabilitySimplex
CotangentPhaseSpace
ComplexStructure
AlmostComplexStructure
SymplecticForm
RiemannSphere
ComplexProjectiveSpace
MetricTensor
Connection
Geodesic
VectorField
CovectorField
Projection
Embedding
QuotientMap
ParallelTransport
AntipodalInvolution
SemanticDualityInvolution
InformationLossEstimate
ProjectionDistortionEstimate
CommutativityDefect
NavigationReceipt
```

## Important properties

```text
hasDomainSpace
hasCodomainSpace
hasDeclaredDimension
hasOrderedAxis
hasCoordinateUnit
hasCoordinateScale
hasMetricTensor
hasConnection
hasComplexStructure
hasAntipodalInvolution
hasInverseTransformation
hasSingularSet
preservesIdentity
preservesMetric
preservesOrientation
isLossless
hasInformationLossEstimate
hasProjectionDistortionEstimate
hasRoundTripTolerance
hasBaseYear
hasPriceDeflator
hasSurveyWeight
hasReplicateWeightDesign
hasGeographicVintage
hasUncertaintyEstimate
derivedFromObservation
generatedByMorphism
```
The numerical processes should extend the existing unary byte-frame pattern documented by the repository. ([GitHub][7])

```text
morphism/
├── geometry/
│   ├── coordinate/cartesian/to/polar/
│   ├── coordinate/polar/to/cartesian/
│   ├── coordinate/complex/to/stereographic/
│   ├── coordinate/stereographic/to/complex/
│   ├── chart/transition/validation/
│   ├── metric/tensor/derivation/
│   ├── connection/coefficient/derivation/
│   ├── antipodal/involution/application/
│   └── antipodal/involution/validation/
├── information/
│   ├── fisher/metric/derivation/
│   ├── divergence/local/expansion/
│   ├── projection/loss/estimation/
│   └── projection/distortion/estimation/
├── navigation/
│   ├── query/covector/derivation/
│   ├── natural/gradient/derivation/
│   ├── geodesic/path/solution/
│   ├── hamiltonian/path/integration/
│   └── parallel/covector/transport/
└── diagram/
    ├── commutativity/defect/measurement/
    └── closed/path/holonomy/measurement/
```

Each process emits:

```text
output
effect
status
domain-space
codomain-space
input-digest
output-digest
metric-identity
chart-identity
tolerance
uncertainty
information-loss
provenance
```

## Mandatory invariants

1. **Dimension law**

[
\text{coordinate count}
=======================

\text{declared coordinate-reference-system dimension}.
]

2. **Axis law**

Every axis has order, unit, datatype, transformation, and domain.

3. **Economic-unit law**

Nominal monetary values require currency and period. Real values additionally require base year and deflator.

4. **Chart-transition law**

A chart transition declares its inverse or explicitly declares why it is only locally invertible.

5. **Round-trip law**

[
d(x,T^{-1}(T(x)))\leq\epsilon.
]

6. **Complex-structure law**

[
J(J(v))=-v
]

on the declared subbundle.

7. **Antipodal law**

[
\tau(\tau(x))=x.
]

8. **Metric law**

The metric is symmetric and positive-definite on the active stratum, or its null space and quotient interpretation are declared.

9. **Probability law**

Probability coordinates are normalized and their zero-support policy is explicit.

10. **Projection law**

Every lossy projection declares preserved targets and an information-loss estimate or estimation status.

11. **Infinity law**

Missing, undefined, censored, and infinite cannot share the same representation.

12. **Geographic separation law**

Physical geographic coordinates cannot be placed in an abstract information coordinate reference system.

13. **Survey-design law**

ACS/PUMS estimates declare weight type, product, geography vintage, and variance method.

14. **Commutativity law**

A diagram expected to commute must declare a numerical defect tolerance.

15. **Causal-claim law**

A causal result requires treatment, outcome, counterfactual, identification strategy, confounder assumptions, selection process, and threats to identification.

# 1. The formal object

Define the Silmaril Antipodal Information Atlas as

[
\boxed{
\mathfrak S
===========

\left\langle
B,\mathcal C,\mathscr X,\pi,\Phi,
G,\nabla,\mathcal J,\omega,
\mathfrak A,\mathcal M,\mathcal R
\right\rangle
}
]

where:

| Symbol                | Meaning                                                                                                                                             |
| --------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| (B)                   | Canonical semantic base: URNs, typed identities, ontology assertions, and provenance anchors.                                                       |
| (\mathcal C)          | Category or partially ordered family of contexts: glossaries, verticals, datasets, geographic levels, periods, roles, models, and policy scenarios. |
| (\mathscr X)          | A sheaf of local, stratified state spaces over contexts.                                                                                            |
| (\pi:\mathscr X\to B) | The map from any representation back to canonical identity.                                                                                         |
| (\Phi={\phi_\alpha})  | The atlas of Cartesian, polar, complex, simplex, spherical, projective, and other charts.                                                           |
| (G)                   | A family of economic, statistical, geographic, semantic, temporal, and provenance metrics.                                                          |
| (\nabla)              | A connection for transporting coordinate frames, units, uncertainty, and interpretation along paths.                                                |
| (\mathcal J)          | A complex structure on compatible even-dimensional strata, satisfying (\mathcal J^2=-I).                                                            |
| (\omega)              | A symplectic form pairing primal states and dual sensitivities.                                                                                     |
| (\mathfrak A)         | A typed family of partial antipodal involutions.                                                                                                    |
| (\mathcal M)          | Typed unary morphisms and their transition, pushforward, pullback, and adjoint operations.                                                          |
| (\mathcal R)          | Provenance, uncertainty, fidelity, singularity, validation, and information-loss receipts.                                                          |

# 2. Plural topology through a sheaf of contexts

The same node may legitimately belong to:

* an economic-subject hierarchy,
* a data-provenance hierarchy,
* a geographic hierarchy,
* an empirical-workflow DAG,
* a BFO or CCO grounding,
* a statistical-family chart,
* a policy scenario,
* and a software-artifact taxonomy.

Those are contexts, not mutually exclusive parent trees.

Let (U,V\in\mathcal C) be two contexts. A local representation is

[
s_U\in\mathscr X(U).
]

The restriction map

[
\rho_{U,V}:\mathscr X(U)\rightarrow\mathscr X(V),
\qquad V\preceq U,
]

translates a state into a narrower or overlapping context.

Two local states are compatible when

[
\rho_{U,U\cap V}(s_U)
=====================

\rho_{V,U\cap V}(s_V).
]

When all overlaps agree, the states glue into a global section (s). When they do not, Silmaril emits a **gluing obstruction**, rather than silently choosing one hierarchy as truth.

A numerical diagnostic is

[
\epsilon_{\mathrm{glue}}(U,V)
=============================

d_{U\cap V}
\left(
\rho_{U,U\cap V}(s_U),
\rho_{V,U\cap V}(s_V)
\right).
]

This directly solves the node-map problem:

[
\boxed{\text{one canonical node} + \text{many contextual sections} \neq \text{many unrelated nodes}}
]

Sheaf-based models are useful precisely because local computations or representations can be checked for the existence of a globally consistent section, while cohomological obstructions characterize failures of global agreement. ([arXiv][2])

---

# 3. The chart system

A chart is not an identity. It is a reversible or explicitly lossy representation:

[
\phi_\alpha:
U_\alpha\subset X_\sigma
\longrightarrow
V_\alpha.
]

The codomain may be

[
V_\alpha
\subset
\mathbb R^n,;
\mathbb C^k,;
\Delta^{m-1},;
S^{n-1},;
\mathbb{RP}^{n-1},;
\mathbb{CP}^{k-1},
]

or a typed discrete complex.

## Cartesian chart

[
x=(x^1,\ldots,x^n)\in\mathbb R^n.
]

Use it for:

* regression and estimation,
* additive decompositions,
* linear constraints,
* tensor and matrix operations,
* direct storage of quantities with explicit units.

Cartesian coordinates are the workbench. They should not be mistaken for the entire workshop.

## Polar or spherical chart

For a reference state (x_0),

[
x-x_0=r,u,
\qquad
r\geq0,\quad u\in S^{n-1}.
]

With metric (G),

[
r_G(x;x_0)
==========

\sqrt{(x-x_0)^\top G(x_0)(x-x_0)}.
]

The direction is

[
u_G=
\frac{x-x_0}{r_G}.
]

This separates:

* **magnitude**, how far the state is from a benchmark;
* **direction**, which combination of economic dimensions produces the deviation;
* **orientation**, whether a process moves toward or away from a constraint;
* **winding**, whether repeated transformations circulate around a reference state.

In two dimensions,

[
z=x+iy=re^{i\theta}.
]

Polar and Cartesian coordinates are therefore two charts on the same real or complex plane, not rival ontologies.

## Simplex chart

Probability distributions and mixed strategies live naturally in

[
\Delta^{m-1}
============

\left{
p\in\mathbb R^m:
p_i\geq0,;
\sum_i p_i=1
\right}.
]

Use this for:

* employment-state probabilities,
* housing-tenure distributions,
* model posterior weights,
* mixed strategies,
* transition probabilities.

The boundary must be explicit because zero support often makes information metrics singular.

## Riemannian structure

“Riemannian” is not another coordinate format. It is a metric tensor

[
G_x:T_xX\times T_xX\rightarrow\mathbb R
]

that defines local lengths, angles, geodesics, volumes, and curvature.

A coordinate change may alter the matrix representing (G), but not the underlying geometric distance. This gives Silmaril a formal test for whether two projections preserve the same economic relation.

---

# 4. Complex numbers as primal-dual economic coordinates

The imaginary component must not mean “unobserved vibes,” LLM narrative, or speculative sentiment.

It should encode a typed, measured, estimated, or formally derived **dual quantity**.

For a primal state (q\in M), let

[
p\in T_q^*M
]

be a cotangent variable such as:

* a likelihood score,
* an objective gradient,
* a shadow price,
* a Lagrange multiplier,
* a marginal welfare weight,
* a downstream requirement,
* a regret vector,
* or a sensitivity of an estimand.

After unit normalization,

[
\boxed{
z^i
===

\frac{q^i-q_0^i}{s_{q,i}}
+
i\frac{p_i-p_{0,i}}{s_{p,i}}
}
]

The real and imaginary components are dimensionless only after the scales (s_q,s_p) are declared.

This gives a precise interpretation:

[
\Re z = \text{forward or primal economic state},
]

[
\Im z = \text{backward or dual sensitivity state}.
]

Multiplication by (i) becomes a quarter-turn between primal and dual directions:

[
\mathcal J
\begin{pmatrix}
\delta q\
\delta p
\end{pmatrix}
=============

\begin{pmatrix}
-\delta p\
\delta q
\end{pmatrix},
\qquad
\mathcal J^2=-I.
]

On a compatible cotangent stratum,

[
\omega
======

\sum_i dq^i\wedge dp_i
]

is the symplectic form. When (G,\mathcal J,\omega) satisfy

[
\omega(u,v)=G(\mathcal Ju,v),
]

the stratum is Kähler-compatible and admits a Hermitian tensor

[
h(u,v)=G(u,v)+i\omega(u,v).
]

This should be a **declared capability of particular strata**, not a universal ontology axiom.

---

# 5. The central process law: produce forward, consume backward

This is the strongest mathematical interpretation of the requested producer-consumer antipode.

Let

[
f:X\rightarrow Y
]

be a process.

The forward channel transports the primal state:

[
q_Y=f(q_X).
]

A tangent perturbation moves forward as

[
v_Y=Df_{q_X}v_X.
]

A downstream requirement, score, loss gradient, or shadow value moves backward through the cotangent pullback:

[
\boxed{
p_X
===

Df_{q_X}^{\top}p_Y
}
]

Therefore:

* **produce** is forward state transport;
* **consume** is backward requirement or sensitivity transport;
* the two are dual, but not generally inverse.

Package both channels into the unary frame law:

[
\boxed{
\operatorname{apply}*f:
\operatorname{Frame}(q_X,p_Y,\rho*{\mathrm{in}})
\longrightarrow
\operatorname{Frame}(q_Y,p_X,\rho_{\mathrm{out}},\ell_f)
}
]

with

[
q_Y=f(q_X),
\qquad
p_X=Df^\top p_Y.
]

Here (\rho) is provenance and (\ell_f) is the declared loss or residue.

This aligns cleanly with Silmaril’s unary byte-frame architecture. The ontology-level operation can be named `apply`, while the generated executable adapter can retain the repository’s one-function `MAIN()` entrypoint. The existing engine already requires one input, one frame result, explicit effects, and atomic Make envelopes. ([GitHub][3])

For nondifferentiable transforms, (Df) may be replaced by a declared:

* discrete incidence operator,
* relational adjoint,
* generalized derivative,
* subgradient,
* finite-difference linearization,
* or transpose of a stochastic kernel.

When none exists, Silmaril must not fabricate a consumer antipode.

---

# 6. Typed antipodal geometry

There should not be one magical antipode applied indiscriminately. Define a family

[
\mathfrak A={\mathcal A_\tau}_{\tau\in\mathcal T}
]

indexed by the type of space or morphism.

Each valid antipode satisfies

[
\mathcal A_\tau^2=I
]

on its declared domain.

## Direction antipode

On a tangent sphere,

[
\mathcal A_T(v)=-v.
]

This represents opposite local movement.

## Role antipode

[
\mathcal A_R(\text{producer})=\text{consumer},
\qquad
\mathcal A_R(\text{consumer})=\text{producer},
]

but only when a `DualityContract` validates compatible types, units, and effects.

## Morphism antipode

[
\mathcal A_M(f)=f^\dagger,
]

where (f^\dagger) is an adjoint or typed dual.

Three distinct cases must remain separate:

### Reversible transformation

[
f^\dagger=f^{-1}.
]

A full state may be recovered.

### Lossy but differentiable projection

[
f^\dagger\neq f^{-1}.
]

The backward operation transports sensitivities or produces a compatible equivalence class, not the original state.

For a linear map,

[
R_f=I-f^\dagger f
]

is a round-trip residue operator.

### Irreversible operation

No antipode is asserted. The operation emits a boundary or loss certificate.

Aggregation, hashing, top-coding, disclosure avoidance, lossy dimensionality reduction, and deletion generally belong here unless sufficient retained state supports a qualified backprojection.

## Orientation-preserving and orientation-free views

When orientation is irrelevant, identify antipodal directions:

[
S^{n-1}/(v\sim -v)=\mathbb{RP}^{n-1}.
]

When producer and consumer roles matter, keep the oriented double cover:

[
S^{n-1}\longrightarrow\mathbb{RP}^{n-1}.
]

The two lifts ({v,-v}) represent the same projective direction but different role orientations.

That gives Silmaril a precise switch:

* projective view for role-neutral classification;
* lifted spherical view for directional processing.

---

# 7. The Riemann sphere

For a one-complex-dimensional chart,

[
\widehat{\mathbb C}
===================

\mathbb C\cup{\infty}
\cong
S^2
\cong
\mathbb{CP}^1.
]

The inverse stereographic map is

[
\operatorname{stereo}^{-1}(z)
=============================

\frac{1}{1+|z|^2}
\left(
2\Re z,;
2\Im z,;
|z|^2-1
\right).
]

The spherical antipode becomes

[
\boxed{
\mathcal A_{\widehat{\mathbb C}}(z)
===================================

-\frac{1}{\overline z}
}
]

with

[
0\leftrightarrow\infty.
]

In polar form,

[
z=re^{i\theta}
\quad\Longrightarrow\quad
\mathcal A(z)
=============

r^{-1}e^{i(\theta+\pi)}.
]

It simultaneously:

* reverses orientation,
* moves to the opposite hemisphere,
* and exchanges local and reciprocal scale.

This is useful for normalized ratio states, reciprocal constraints, bidirectional navigation, and “near versus far” chart switching.

But (\infty) must mean **outside the current finite chart or a declared singular limit**. It must never be silently reused for missing observations, suppressed values, undefined ratios, or unknown sentiment.

Möbius transformations

[
T(z)=\frac{az+b}{cz+d},
\qquad ad-bc\neq0,
]

can provide conformal navigation within eligible one-complex-dimensional charts. They should not be forced onto arbitrary economic transformations.

---

# 8. Information geometry

For a regular statistical family

[
\mathcal P={p_\theta:\theta\in\Theta},
]

define the score

[
s_i(x;\theta)
=============

\frac{\partial}{\partial\theta^i}\log p_\theta(x)
]

and Fisher information metric

[
\boxed{
G^{F}_{ij}(\theta)
==================

\mathbb E_\theta[s_i s_j]
}
]

The local Kullback-Leibler divergence satisfies

[
D_{\mathrm{KL}}
\left(
p_\theta\Vert p_{\theta+d\theta}
\right)
=======

\frac12
d\theta^\top G^F(\theta)d\theta
+
O(|d\theta|^3).
]

Thus Fisher distance measures local statistical distinguishability, rather than raw Euclidean parameter displacement.

Use the (\alpha)-connections

[
\nabla^{(\alpha)}
]

to distinguish mixture, exponential, and intermediate geometries. A projection packet must declare whether it uses an exponential projection, mixture projection, orthogonal metric projection, or another divergence minimization. Smooth probability families, information metrics, and (\alpha)-connections form the standard differential-geometric substrate of information geometry. ([Springer Nature Link][4])

For an objective (L(\theta)), the natural-gradient direction is

[
\boxed{
\widetilde{\nabla}L
===================

(G^F)^{-1}\nabla L
}
]

on a regular stratum. Unlike the ordinary coordinate gradient, it respects reparameterization of the statistical model. ([MIT Direct][5])

## Survey-weighted empirical geometry

For survey observations (h), weights (w_h), and scores (s_h), a proposed empirical metric is

[
\widehat G_w
============

\frac{1}{W}
\sum_h w_hs_hs_h^\top,
\qquad
W=\sum_h w_h.
]

This is a weighted local geometry, not automatically a complete design-based variance estimator.

Silmaril must separately preserve:

* person or housing-unit weight semantics,
* replicate-weight estimates where applicable,
* missingness and imputation flags,
* top and bottom coding,
* geography comparability,
* margins of error,
* and validation against official aggregates.

At zero-support boundaries or rank-deficient points, use a restricted tangent space, regularized metric, or declared pseudoinverse. The rank and regularization must be emitted in the receipt. Blindly inverting Fisher information would convert a warning light into a confetti cannon.

---

# 9. Chart transition laws

For overlapping charts (\alpha) and (\beta),

[
T_{\beta\alpha}
===============

\phi_\beta\circ\phi_\alpha^{-1}.
]

If

[
x_\beta=T_{\beta\alpha}(x_\alpha),
\qquad
J_{\beta\alpha}=DT_{\beta\alpha},
]

then tangent vectors, covectors, covariance, and metrics transform as

[
v_\beta=J_{\beta\alpha}v_\alpha,
]

[
p_\alpha=J_{\beta\alpha}^{\top}p_\beta,
]

[
\Sigma_\beta
============

J_{\beta\alpha}\Sigma_\alpha J_{\beta\alpha}^{\top},
]

[
G_\alpha
========

J_{\beta\alpha}^{\top}
G_\beta
J_{\beta\alpha}.
]

The atlas cocycle law requires

[
T_{\gamma\alpha}
================

T_{\gamma\beta}\circ T_{\beta\alpha}
]

on triple overlaps.

A violation here is not interesting curvature. It is an invalid atlas or an implementation defect.

For approximate or lossy transitions, replace equality by a declared tolerance and record:

[
\epsilon_{\beta\alpha}(x)
=========================

d
\left(
x,
\psi_{\alpha\beta}T_{\beta\alpha}(x)
\right),
]

where (\psi_{\alpha\beta}) is the backprojection or reconstruction relation.

Carry forward the fidelity classes:

1. exact,
2. structural,
3. approximated,
4. externalized,
5. dropped.

Every chart transition must say which class applies.

---

# 10. Navigation as hybrid geodesic planning

A Silmaril route crosses:

* continuous regions within a stratum,
* discrete morphism edges,
* chart overlaps,
* context restrictions,
* aggregation boundaries,
* and provenance gates.

For a path (\gamma), define

[
\begin{aligned}
\mathcal C(\gamma)
={}&
\int_{\gamma_{\mathrm{continuous}}}
\sqrt{
\dot\gamma(t)^\top
G(\gamma(t))
\dot\gamma(t)
},dt\
&+
\lambda_L\sum_{e\in\gamma}\ell_e
+
\lambda_U\sum_{e\in\gamma}u_e
+
\lambda_P\sum_{e\in\gamma}r_e
+
\lambda_C\sum_{e\in\gamma}c_e.
\end{aligned}
]

Here:

* (\ell_e) is information or semantic loss;
* (u_e) is uncertainty inflation;
* (r_e) is provenance or validation risk;
* (c_e) is computational cost.

Contract violations receive infinite cost.

The route is

[
\gamma^*
========

\arg\min_{\gamma:s\leadsto t}\mathcal C(\gamma).
]

Within continuous strata, query-directed navigation can use

[
\dot\gamma
==========

-G^\dagger\nabla\Psi_Q,
]

where (\Psi_Q) is a query or research objective and (G^\dagger) is used only with an explicit singularity receipt.

Across discrete chart or morphism boundaries, use graph search over validated edges. The resulting planner is a **geodesic-DAG navigator**:

1. resolve canonical start and goal identities;
2. enumerate valid contexts and charts;
3. compute local geodesic segments;
4. cross only declared chart overlaps or morphisms;
5. transport uncertainty, units, weights, and cotangents;
6. minimize total economic and informational cost;
7. emit a complete route receipt.

---

# 11. Connections, curvature, and transformation-order effects

A connection (\nabla) transports local frames, units, sensitivities, and interpretive bases along a path.

For two transformation routes with the same source and destination,

[
X
\xrightarrow{f}
Y
\xrightarrow{h}
Z
]

and

[
X
\xrightarrow{g}
W
\xrightarrow{k}
Z,
]

define the discrete commuting-diamond residual

[
\boxed{
\kappa(f,h;g,k;x)
=================

d_Z
\left(
h(f(x)),
k(g(x))
\right)
}
]

If (\kappa=0), the diagram commutes at (x).

If (\kappa>0), the order of operations matters. This is the operational analogue of curvature.

Economically meaningful examples include:

* deflating monetary values before versus after aggregation when price indices vary across observations;
* applying equivalence scales before versus after household aggregation;
* handling top-coded income before versus after nonlinear transformations;
* translating geography before versus after pooling overlapping survey products;
* conditioning a model before versus after dimensionality reduction.

Some noncommutation is a bug. Some is genuine path dependence. The receipt must distinguish them.

For a continuous connection (\Gamma), curvature is

[
F=d\Gamma+\Gamma\wedge\Gamma.
]

Parallel transport around a closed loop produces holonomy

[
H_\gamma.
]

Three diagnostics must remain separate:

1. **Atlas cocycle error**, which should be zero for exact chart changes.
2. **Process-order residual**, which measures noncommuting transformations.
3. **Geometric holonomy**, which may be nontrivial because the underlying connection is curved.+++++# URNARY-LAW.md (v6, 14 facets)

The sparky lambda functor canon at
`scripts/python/pylib/reference/pylib/src/silmaril/sparky/lambda/functor/**`
IS the ground truth: a tree of one-function-per-file Python modules.
Every field accessor lives in its own directory with one `apply.py`
containing one `def apply(payload: Bytes) -> Bytes:` and one `return`.
Every runtime functor lives in its own file with one
`def NAME(frame): return frame.NAME(frame)`. That shape IS the urnary law.

The codebase IS on the frame-circle manifold. Every file has θ (the
directory path) and r (the body). Two files at the same θ have byte-identical
r modulo their constant imports. The pole is the origin. Antipodes are dual.
Scenes are windings. This IS the coordinate system.

---

## Facet 0 — The canon (the 9-point pattern, from the sparky lambda functor tree)

**The law.** The sparky lambda functor tree IS the canon — working code that
embodies the urnary law verbatim. The pattern, confirmed across 30+ files:

1. Every function is named `apply`.
2. Every function takes exactly ONE typed input (`payload: Bytes`).
3. Every function is exactly two lines: `def apply(...): return ...`.
4. Each function lives in its own file in its own directory (the path
   encodes the type).
5. The directory structure encodes the type — `frame/current`,
   `frame/next`, `frame/previous`, `effect/ok`, `effect/error`,
   `effect/left`, `effect/right`, `audience`, etc. — each is its own
   directory with `apply.py` + `__init__.py`.
6. Type dispatch happens by directory path, NOT `isinstance`. There's one
   `apply.py` per type. To get the "current frame" you import from
   `.../frame/current/apply.py`; to get the "next frame" you import from
   `.../frame/next/apply.py`. The type IS the path.
7. The single ternary `return TRUE if payload.count(SEPARATOR) == Int(EXPECTED) else FALSE`
   is one expression — urnary.
8. No exceptions. No `try/except` anywhere.
9. Polar functions: produce/consume (Facet 3 — the antipodal map on the
   frame circle).

---

## Facet 1 — F(x)->Y

One function. One typed input. One output. One expression returned.

The input is one typed record — a dataclass with defined inheritance. If a
function needs multiple pieces of data, they are fields of one record,
accessed by attribute (`req.name`, `req.doc`), not by tuple unpacking, not
by dict-destructuring, not by multiple positional args.

The output is one typed value.

The body is one expression — a single `return`. A single ternary
`return X if cond else Y` is one expression. A chain
`A if c1 else (B if c2 else C)` is N expressions — multi-branch dispatch —
and is absent from the law.

One function per file. The file name IS the function name. The function
name is `apply` (for value-level functors) or the verb itself (for runtime
functors). There is no second parameter, no helper, no nested def. The
return is a single expression — not a block, not a statement sequence.

**Canon.** `pylib/src/silmaril/sparky/lambda/functor/bit/encode/apply.py`:

```python
from config.gate.external.python.base.builtins.bytes.value import VALUE as Bytes
from config.gate.external.python.base.builtins.format.value import VALUE as Format
from config.gate.value.protocol.byte.empty.value import VALUE as EMPTY
from config.gate.value.protocol.format.binary_08.value import VALUE as FORMAT_SPEC
def apply(payload: Bytes) -> Bytes: return EMPTY.join(Format(byte, FORMAT_SPEC.decode()).encode() for byte in payload)
```

One file. One function. One typed input (`payload: Bytes`). One return. The
imports are the closed environment; the body is one expression.

---

## Facet 2 — For-loops are combinators (one function per file)

`map`, `filter`, `reduce`, `fold` are each their own function in their own
file, applied as a separate urnary step. A `"\n".join(map(f, xs))` hides a
for-loop inside an expression — it fuses two functions (the map and the
join) into one. The per-element function is one file; the join/fold is a
different file; you apply them in sequence, each as its own urnary call.

**Canon.** `fold` and `reduce` are separate files in the graph functor tree:

```python
# graph/fold.py
def fold(frame): return frame.fold(frame)
```
```python
# graph/reduce.py
def reduce(frame): return frame.reduce(frame)
```

The per-element transform lives in its own field accessor, e.g.
`packet/field/atlas/r/apply.py`:

```python
def apply(payload: Bytes) -> Bytes: return payload.split(SEPARATOR)[Int(INDEX)]
```

Each is urnary. The combinator is a named function in a named file, not an
inline lambda inside a string join.

---

## Facet 3 — Polar functions = differential geometry on the frame circle

A polar function is r = f(θ): one distinguished origin (the pole), one
angular input, one radial output. That IS the urnary law stated
geometrically — a curve swept by a single parameter.

**The topology over discrete scenes:**

- A scene is one full sweep of the frame ring — one revolution of θ.
- The scene sequence is the winding number: the timeline is the universal
  cover (ℤ covering ℤ/n, exactly as ℝ covers S¹). "Which scene am I in" is
  a deck transformation count — it cannot be recovered from inside any
  single frame chart, which is the topological reason there is no global
  "current" you can carry around a whole revolution. H¹(S¹) = ℤ: the
  scene counter is that cohomology class made operational. This is the
  same obstruction that forces sectioning over covers in the event-sheaf
  picture — the frame tree is its discretization.
- Discrete curvature concentrates at the vertices (the exterior angles at
  each frame step), and the discrete Gauss–Bonnet identity — exterior
  angles summing to 2π per revolution — is the invariant "every scene
  closes." Total turning = 2π × number of scenes. A frame walk that doesn't
  close isn't a scene yet; it's an open arc, an atom-in-flight.
- The polar line element ds² = dr² + r²·dθ² gives the cost geometry:
  change within a frame is the dr term; frame succession is the dθ term
  weighted by r — stepping the ring costs more the bigger the payload
  you're carrying. That's a metric statement, and it's the geometric
  justification for keeping r-computations (the two-line bodies) minimal:
  the sweep, not the radius, should carry the structure.

**The pole and the chart:**

- The pole is `frame/current`. Everything is measured radially from the
  payload you are holding now. The pole is the one point the polar chart
  cannot describe (r=0 is a coordinate singularity) — which is why
  `frame/current/apply.py` doesn't compute its position; it simply IS the
  origin the others are measured from.
- θ is NOT runtime data — it is the directory path. `frame/previous`,
  `frame/current`, `frame/next` are discrete angular positions: θ lives
  on a finite cyclic group ℤ/n (the frame ring), not the continuous circle
  S¹. Frame succession is rotation by the generator. The path pins θ
  before evaluation; the two-line `apply` computes only r. ONE input,
  because the angle was already spent choosing the file.

**Polarity is antipodality:**

On a circle every direction has an antipode, θ and θ+π. The dual pairs in
the tree are exactly antipodal chart points:

- `effect/ok` ↔ `effect/error`
- `effect/left` ↔ `effect/right`
- `storage/write` ↔ `storage/read`
- `runtime/observe` ↔ `runtime/seal`
- produce ↔ consume: consume(θ) = produce(θ+π)

Produce/consume is NOT a separate categorical duality bolted on — it IS
the antipodal map on the frame circle. That's what "polar" buys you:
polarity is a geometric involution, and every dual directory pair in the
tree is one orbit of it. No mutation of an outer variable. No
`x.append(y)`; `return frame.emit(frame)`. Pushforward/pullback, not
assignment.

**Canon.** The storage pair — `storage/write.py` and `storage/read.py`:

```python
# storage/write.py — produce (pushforward)
def write(frame): return frame.write(frame)
```
```python
# storage/read.py — consume (pullback, antipodal to write)
def read(frame): return frame.read(frame)
```

The duality is in the verb, not in a side-effect. `write` produces (the
frame returns its written self); `read` consumes (the frame returns its
readback). No global, no `nonlocal`, no mutation of a captured variable.
Pushforward/pullback, not assignment.

**Position-assignment table (BLS subtrees → angular roles):**

| BLS subtree | Angular role | Sparky analogue |
|---|---|---|
| `config/` (226 value.py) | The pole (frame/current) — frozen constants, the origin | `frame/current` |
| `types/` (24 value.py + 16 apply.py) | The coordinate chart — 18 typed fibers over the frame circle | the field-accessor sheaf |
| `types/catch/try_/apply.py` | The singular verdict — the ONE try/except site carrying both poles | `effect/outcome/{ok,error}` fused |
| `build/` (251 apply.py) | The effect half — the verb-tree, the winding engine | `packet/field/*` + `projection/*` |
| `synth/` (56 value.py + 29 apply.py) | The synthesizer — atom/avro factory with explicit verdict axis | `profile/*` + `effect/*` |
| `util/` (26 apply.py + 9 process.py) | The process hub — orchestration entry points, the frame-advance drivers | `runtime/*` |
| `render/` (10 value.py, 0 apply.py) | The render atlas — pure records, passive lookup | the passive coordinate sheaf |

**Already-encoded geometry (formalized, not invented):**

- `config/constants/dag/exit/codes/exit/` — the 13-group verdict circle (1
  success + 12 error groups + telephone block) = the antipodal outcome manifold
- `config/constants/workflows/{default,dev,master,prod,test}/` — the 5-point
  branch-policy frame-circle
- `build/render/dag/executor/{advance,rollback}` — the frame-succession
  algebra (advance = next, rollback = previous, flip = rotation, swap =
  transposition)
- `synth/avro/render/{success,failure,happy}` — the (value, error) 2-tuple
  verdict with TRUE/FALSE-gated branching
- `types/set/{union,intersect,difference,filter,of}` — the set-algebra
  quadrant
- `types/tuple/{first,second,of,swap}` — the tuple coordinate with swap as
  half-turn
- `types/bytes/{from_,to}` — the directional conversion diameter

**Deeper topology (connection, holonomy, sheaf cohomology):**

- **Connection / parallel transport along the frame ring:** the frame ring
  is a discrete circle ℤ/n. A connection on this ring assigns a transport
  map between adjacent frames — the "advance one step" operator
  (`build/render/dag/executor/advance/one/step/apply.py`). Parallel transport
  around a full revolution returns the frame to its start, possibly
  transformed — the holonomy. For a flat connection (zero curvature), the
  holonomy is trivial. For the DAG executor, the holonomy is the rollback
  stack: compensators pushed during a failed advance are popped during
  rollback — the holonomy IS the compensator composition. If the holonomy
  is identity (empty rollback stack), the scene closed cleanly.

- **Holonomy as scene closure:** a scene is one full sweep (one revolution
  of θ). The discrete Gauss–Bonnet identity says exterior angles sum to 2π
  per revolution — every scene closes. Holonomy is the obstruction to
  closure: if the holonomy is non-trivial (rollback stack non-empty), the
  scene didn't close — it's an open arc, an atom-in-flight. The DAG
  executor's "advance one step" + rollback stack IS the connection +
  holonomy structure made operational.

- **Curvature as exterior-angle concentration:** discrete curvature lives
  at the vertices (the frame steps). The exterior angle at each step is the
  "turn" — the change in direction. For the DAG executor, the exterior
  angle is the fail-mode dispatch: a successful step has zero exterior angle
  (straight ahead), a failed step has non-zero exterior angle (a turn —
  dispatch rollback). Total turning = 2π × number of scenes = the sum of
  all exterior angles. A DAG run that completes with zero failures has zero
  total turning — a flat scene. A DAG run with failures has non-zero total
  turning — a curved scene.

- **Sheaf cohomology H¹ made operational:** H¹(S¹) = ℤ — the first
  cohomology of the circle is the integers. The scene counter IS this
  cohomology class made operational: "which scene am I in" is a deck
  transformation count. The winding number is the scene index. The frame
  tree IS the discretization of the event-sheaf's sectioning obstruction:
  the sheaf has no global section over the circle (you can't carry a
  "current" around a whole revolution), so you section over the cover
  (one chart per frame). The frame tree is that cover.

---

## Facet 4 — One expression (no nested ternary chains)

A single `return X if c else Y` is one expression (urnary). A chain
`A if c1 else (B if c2 else C)` is an if/elif ladder written sideways — it
is multi-branch dispatch. The law requires one expression, and a chain is
structurally N expressions nested. Multi-branch is handled by having
**one function per branch** — the type lives in the input record, and the
right function is selected by application, not by a nested ternary.

**Canon.** The `effect` family is five separate files — `effect/ok`,
`effect/error`, `effect/left`, `effect/right`, `effect/name`. Each is its
own directory with its own `apply.py`:

```python
# packet/field/effect/ok/apply.py
from config.gate.value.protocol.field.index.effect.ok.value import VALUE as INDEX
def apply(payload: Bytes) -> Bytes: return payload.split(SEPARATOR)[Int(INDEX)]
```
```python
# packet/field/effect/error/apply.py
from config.gate.value.protocol.field.index.effect.error.value import VALUE as INDEX
def apply(payload: Bytes) -> Bytes: return payload.split(SEPARATOR)[Int(INDEX)]
```

The forbidden form would be a single file with
`return ok_val if kind == 'ok' else (err_val if kind == 'error' else ...)`.
That is a five-way dispatch written sideways. The canon instead has five
files, each urnary. The caller applies the right one; it does not branch.
The same pattern holds for `frame/current`, `frame/next`, `frame/previous`
(three files, not one ternary) and for `atlas/r`, `atlas/g`, `atlas/b`
(three files, not one ternary over a color channel).

---

## Facet 5 — Type dispatch by path (no isinstance)

`isinstance(x, T)` is runtime type checking, not function application. Type
dispatch is done by having one function per type — the type is carried in
the input record (as a field, as the path that selected the functor, as the
frame's own method set), and the right function is selected by application,
not by an `isinstance` branch. The sparky code never inspects the type of
its input at runtime. It imports a typed alias (`VALUE as Bytes`,
`VALUE as Int`, `VALUE as SEPARATOR`) and applies. The type is in the
import, not in a runtime check.

**Canon.** Every field accessor imports its index constant and applies it,
with no type inspection:

```python
# packet/field/atlas/r/apply.py
from config.gate.external.python.base.builtins.bytes.value import VALUE as Bytes
from config.gate.external.python.base.builtins.int.value import VALUE as Int
from config.gate.value.protocol.packet.unit_separator.value import VALUE as SEPARATOR
from config.gate.value.protocol.field.index.atlas.r.value import VALUE as INDEX
def apply(payload: Bytes) -> Bytes: return payload.split(SEPARATOR)[Int(INDEX)]
```

`atlas/g/apply.py` and `atlas/b/apply.py` are byte-identical except for the
`INDEX` import. There is no `if isinstance(payload, AtlasRFrame): ...`. The
"type" is the directory path you walked to find the functor (`atlas/r` vs
`atlas/g` vs `atlas/b`). The frame carries its own methods (`frame.observe`,
`frame.seal`, `frame.step`), and the runtime functor just applies the
matching one — again no `isinstance(frame, ObservableFrame)`.

---

## Facet 6 — No exceptions (error handling is a typed effect field)

`try/except` is a statement, not an expression, so it is not urnary. Error
handling is done by routing through typed effect fields (`effect/ok`,
`effect/error`, `effect/left`, `effect/right`) — each its own functor. An
error is a value in a field, read by a field accessor, not a raised
exception caught by a handler. The `valid` functor
(`packet/valid/apply.py`) is a gate returning a typed boolean.

**Canon.** The sparky `effect/error/apply.py` extracts the error field from
the record via `payload.split(SEPARATOR)[Int(INDEX)]`. There is no `try:`,
no `CatchReq`, no `on_failure` lambda. The error was placed in the field
upstream by the producer; the consumer just reads it.

---

## Facet 7 — The functorial forms (the canon's five body shapes)

Every urnary function is ONE expression returned. The closed environment
is the imports. The body is one expression — no `importlib.import_module`
inside the body (that is a second function fused in), no f-string
interpolation that fuses string-building with function application, no
inline second function call. The string interpolation that builds any path
is itself a function — it lives in its own `apply.py` behind its own gate,
not inline in the body.

The canon instantiates five body shapes. Each IS the urnary form for its
angular position θ. The shape IS determined by θ — two files at the same θ
have byte-identical bodies modulo their constant imports (Facet 13).

**Shape 1 — Field extractor** (the path selects the INDEX; the body is
split+index):

```python
from config.gate.external.python.base.builtins.bytes.value import VALUE as Bytes
from config.gate.external.python.base.builtins.int.value import VALUE as Int
from config.gate.value.protocol.packet.unit_separator.value import VALUE as SEPARATOR
from config.gate.value.protocol.field.index.<path>.value import VALUE as INDEX
def apply(payload: Bytes) -> Bytes: return payload.split(SEPARATOR)[Int(INDEX)]
```

Two files at the same θ (e.g. `frame/current` and `frame/next`) have
byte-identical bodies — only the INDEX import differs. That IS the byte
anchor (Facet 13). Canon: every `packet/field/*/apply.py` (40 files).

**Shape 2 — Gated delegation** (the path selects the PROJECT gate; the
body is one application of the gated functor to the typed input):

```python
from config.gate.external.python.<path>.library import DEPENDENCY as PROJECT
from <type-input>.value import VALUE as Input
from <type-frame>.value import VALUE as Frame

def apply(value: Input) -> Frame: return PROJECT(value)
```

The functor (PROJECT) is the gated library dependency — the closed
environment. The input and output types are URN-tree value.py records with
defined inheritance. The body is one application. Canon: every
`silmaril/sparky/morphism/**/apply.py` and `silmaril/sparky/lambda_/**/
apply.py`.

The `FUNCTOR(**,...)` form IS a specialization of Shape 2 for the case
where the gated functor accepts the typed record's fields as kwargs via
the `**` spread. `**` = universal path component AND Python abstract kwargs
(spreads typed record fields as kwargs to the functor) AND pointer
semantics. All three meanings hold simultaneously:

```python
from config.gate.external.python.stdlib.importlib.import.kind.module.library import DEPENDENCY as FUNCTOR
from config.gate.external.python.stdlib.importlib.import.kind.module.functor.error.library import DEPENDENCY as ERROR
from <type-X>.value import VALUE as INPUT_VAL
from <type-Y>.value import VALUE as OUTPUT_VAL

def apply(input_val: INPUT_VAL) -> OUTPUT_VAL:
    return FUNCTOR(**, input_val, OUTPUT_VAL, ERROR)
```

`FUNCTOR` is the gated library dependency. `ERROR` is the gated error
channel from the SAME library submodule. `INPUT_VAL` is the typed input
(one record, with defined inheritance). `OUTPUT_VAL` is the typed output.
The body is ONE application. This form applies where the functor's
signature accepts the spread record fields — it is not a universal
template that replaces Shape 2; it IS Shape 2 with kwargs-spread.

**Shape 3 — Ternary over composition** (the body is a single ternary
`X if cond else Y` where X and Y are composed applications of gated
functors — one expression, urnary):

```python
def apply(payload: Bytes) -> Bytes: return Ok(Render(payload)) if Valid(payload) == TRUE else ERROR
```

The ternary IS one expression (Facet 4 allows a single ternary). The
composed applications (`Ok(Render(payload))`, `Valid(payload)`) are
function applications of gated functors — each lives behind its own gate.
The body is one expression. Canon: every `api/project/*/apply.py`.

**Shape 4 — Constant concatenation** (the path selects the token set; the
body assembles pre-rendered byte fragments — one expression):

```python
def apply(payload: Bytes) -> Bytes: return T000 + T001 + ... + TNN
```

Each `TNN` is a gated `VALUE` constant imported from
`config.gate.value.render.token.*`. The body is one expression (a sum of
constants). Canon: every `projection/*/section/sNNNN/apply.py`.

**Shape 5 — Sum of applications** (the body is a composition of function
applications, each gated, summed into one expression):

```python
def apply(payload: Bytes) -> Bytes: return S0000(payload) + S0001(payload) + ...
```

Each `SNNNN` is a gated functor imported from a sibling `apply.py`. The
body is one expression (a sum of applications). Canon: the top-level
`projection/*/apply.py` assemblers.

---

**Args and kwargs are typed records with defined inheritance.** Every
function takes exactly ONE typed input. If a function needs multiple pieces
of data, they are FIELDS of ONE typed record (a dataclass with defined
inheritance), accessed by attribute (`req.index`, `req.entry`), not by
tuple unpacking (Facet 9) and not by multiple positional args (Facet 1).
The record's inheritance chain is defined in its `value.py` file.

The resolver functor, the error channel, the input type, and the output
type are ALL in the closed environment (imports). The body is one
expression. There is no `importlib.import_module` call inside the body —
that is a second function fused in. Canon: every `value.py` accessor in the
sparky tree imports its `INDEX` constant from a gate and applies it — the
path is fixed at import time, not computed at call time. There is no
`importlib.import_module` anywhere in the sparky canon.

---

## Facet 8 — The catch combinator is a disguised try/except

A `CatchReq(fn=lambda: ..., on_success=lambda: ..., on_failure=lambda: ...)`
record passed to a `try_/apply.py` that contains `try: ... except: ...` is a
RELABELING of try/except, not a removal of it. The lambdas are
multi-expression functions inlined into a record; the `try_/apply.py` site
still contains the `try:` statement.

The law (Facet 6) is explicit: error handling is via typed effect FIELDS
(`effect/ok`, `effect/error`, `effect/left`, `effect/right`), each its own
functor. An error is a VALUE in a field, read by a field accessor, not a
raised exception caught by a handler.

A single `try_/apply.py` allowlisted as "the ONE try/except site" is a
DOCUMENTED DEVIATION, not the law. Where the law applies (everywhere else),
the catch combinator pattern is absent — it is try/except with extra steps.

**Canon.** The sparky `effect/error/apply.py` extracts the error field from
the record via `payload.split(SEPARATOR)[Int(INDEX)]`. There is no `try:`,
no `CatchReq`, no `on_failure` lambda. The error was placed in the field
upstream by the producer; the consumer just reads it.

---

## Facet 9 — Tuple unpacking is multi-arg

`def apply(req: tuple) -> str: i, entry = req` is a two-argument function
wearing a tuple costume. The unpacking `i, entry = req` is a local
assignment that splits one input into two. The urnary law is ONE typed
input. If the function needs two pieces of data, they are TWO FIELDS of ONE
typed record, and the function reads them by attribute (`req.index`,
`req.entry`), not by tuple unpacking.

**Canon.** Every sparky `apply.py` takes `payload: Bytes` and returns one
expression. There is no `a, b = payload` anywhere. The frame carries its
own methods (`frame.observe`, `frame.seal`), accessed by attribute, not by
destructuring.

---

## Facet 10 — `if X else Y` chains are if/elif sideways

A two-branch `return A if cond else B` is one expression (urnary). A
`return (A if c1 else B) if c2 else C` or any nesting of ternaries is a
multi-branch dispatch — Facet 4. The "polar select" framing
(`X if exists(path) else None`) is still a ternary; if chained or nested it
violates Facet 4. Multi-branch is one file per branch (the path selects the
functor), not a nested ternary.

---

## Facet 11 — Type annotations are gated imports

Every dataclass field type is a gated import from
`config.gate.external.python.base.builtins.*` (for primitives) or from a
URN-tree `value.py` (for domain types like `WarehouseRef`). The type
annotation IS part of the closed environment — the type is in the import,
not in a bare builtin name.

A frozen dataclass field `path: str` is absent from the law. `str` is a
bare Python builtin, not imported from a gate. The field type IS a typed
value — inherited through the polar topology. A `WarehouseRef` field
`path: WAREHOUSE_PATH_TYPE` where `WAREHOUSE_PATH_TYPE` is imported from
`types/warehouse/path/type/value.py` IS the polar inheritance: the type is
a value in the tree, not a bare builtin.

**The form:**

```python
from config.gate.external.python.stdlib.dataclasses.dataclass.library import DEPENDENCY as dataclass
from config.gate.external.python.base.builtins.str.value import VALUE as STR_TYPE
from config.gate.external.python.base.builtins.object.value import VALUE as OBJECT_TYPE

@dataclass(frozen=True)
class FlagReq:
    name: STR_TYPE
    type: STR_TYPE
    default: OBJECT_TYPE
    doc: STR_TYPE
```

The builtin type gate tree (`config.gate.external.python.base.builtins.*`)
holds the gated aliases: `bytes`, `str`, `int`, `bool`, `list`, `tuple`,
`dict`, `object`, `float`, `set` — each in its own `value.py` as
`VALUE = <builtin>`. Every dataclass field type is imported from this tree
or from a domain-type URN-tree `value.py`.

---

## Facet 12 — No dict-dispatch (type dispatch by path)

`DISPATCH = {BOOL_TYPE: _bool_default}; DISPATCH.get(flag["type"], ...)(flag)`
is `isinstance` wearing a dict costume. The type is in the path that
selected the functor, not in a dict lookup on a type field.

If `flag.type == "bool"`, the caller imports from
`.../flag/default/bool/apply.py`; if not, from
`.../flag/default/nonbool/apply.py`. The selection is by application (which
file you import), not by a runtime dict lookup. The type IS the path.

The dispatch table lives in `value.py` (as a constant archetype) only when
the key is a static design-time list (Shape A — composition-as-dispatch, per
the type-dispatch pattern). When the key is runtime data, the dispatch is
the FUNCTOR's job — it lives behind a `library.py` gate, not in the `apply.py`
body. The `apply.py` body is one application: `return FUNCTOR(input)`. The
functor resolves the type and applies the right branch internally; the
`apply.py` does not contain the dispatch dict.

---

## Facet 13 — The byte anchor

Files at the same angular position have byte-identical bodies modulo their
constant imports. Two field-extractors at the same depth (e.g.
`frame/current/apply.py` and `frame/next/apply.py`) have byte-identical
bodies — only the INDEX import differs. That IS the byte anchor.

Conformance is verified by normalized AST hash: strip imports, strip
docstring, hash the remaining AST. Files at the same θ (same manifest
`byte_anchor_group`) must have the same normalized hash. If they diverge,
one of them is not at its canonical form for that angular position.

The manifest (`MANIFOLD.yaml`) assigns every file its θ, its body shape,
its canonical form, and its `byte_anchor_group`. The drift gate re-renders
the manifest and byte-diffs. A file that diverges from its manifest entry
fails the gate. The manifest IS the coordinate chart — the roadmap for the
entire codebase.

Conformance is positively framed: the gate asserts the canonical form for
each file's angular position. The gate reports `CONFORMS <path>` (compliant)
or `DIVERGES <path>: <reason>` (does not match canonical form). The law
states what IS; the gate verifies conformance to what IS.

---

## Facet 14 — Nomenclature / Lexical / Semantic (the lexical law)

Every identifier in the tree IS a proper English word. The path IS the
notation; the type name IS the path's head; the field name IS the path's
spine; the constant IS the path's crown. There are no abbreviations, no
acronyms, no compound tokens, no trailing underscores. The nth-degree
iteration of grammar/notation means: each path segment is ONE proper word,
and the FULL path IS the composed notation. A flat name like
`byte_anchor_group` is zero-degree — collapsed into a single compound
token — and IS absent from the law. The law requires nth-degree iteration:
one word per segment, meaning composed by the path.

The lexical law IS 11 rules:

1. **Directory paths ARE proper words.** Every path segment IS a single
   lowercase proper English word. No hyphens, no underscores in path
   segments, no acronyms, no abbreviations. `frame/current` IS the form;
   `frame_current` IS NOT. `byte/anchor/group` IS the form;
   `byte_anchor_group` IS NOT. `request` IS the form; `req` IS NOT.

2. **Type names ARE proper words.** Dataclass names ARE proper words, not
   abbreviations. `ThetaRequest` IS the form; `ThetaReq` IS NOT.
   `ParseError` IS the form; `ParseErr` IS NOT. `ParseOkay` IS the form;
   `ParseOk` IS NOT. `ByteAnchorGroup` IS the form; `Bag` IS NOT.

3. **Field names ARE proper words.** Dataclass field names ARE proper
   words. `byte_anchor_group` IS acceptable (Python convention: underscores
   BETWEEN proper words in field names); `bag` IS NOT (abbreviation); `req`
   IS NOT (the form IS `request`).

4. **Constants ARE UPPER_SNAKE with proper words.** Constants follow
   UPPER_SNAKE convention and MUST use proper words — no abbreviations.
   `INPUT_VALUE` IS the form; `INPUT_VAL` IS NOT. `OUTPUT_VALUE` IS the
   form; `OUTPUT_VAL` IS NOT. `BYTE_ANCHOR_GROUP` IS the form; `BAG` IS
   NOT. `SEPARATOR` IS a proper word. `INDEX` IS a proper word. `VALUE` IS
   a proper word. `DEPENDENCY` IS a proper word.

5. **No acronyms anywhere.** No acronyms in paths, type names, field
   names, or constants. `abstract/syntax/tree` IS the form; `AST` IS NOT.
   `input/output` IS the form; `IO` IS NOT. `data/definition/language` IS
   the form; `DDL` IS NOT. The path IS the expansion. `BLS` stays as the
   project name — it IS the product name, not an acronym in code paths.
   `python` IS the form; `PY` IS NOT. `shell` IS the form; `SH` IS NOT.

6. **No abbreviations anywhere.** No abbreviations in paths, type names,
   field names, or constants. `request` IS the form; `req` IS NOT.
   `error` IS the form; `err` IS NOT. `okay` IS the form; `ok` IS NOT
   (except in the canon `effect/ok`, which IS the established angular
   position). `value` IS the form; `val` IS NOT. `directory` IS the form;
   `dir` IS NOT. `definition` IS the form; `def` IS NOT. `initial` IS the
   form; `init` IS NOT (except `__init__.py` — rule 8). `directories` IS
   the form; `dirs` IS NOT. `specification` IS the form; `spec` IS NOT.
   `calculate` IS the form; `calc` IS NOT. `generator` IS the form; `gen`
   IS NOT. `maximum`/`minimum` ARE the forms; `max`/`min` ARE NOT. `number`
   IS the form; `num` IS NOT. `count` IS the form; `cnt` IS NOT. `length`
   IS the form; `len` IS NOT. `index` IS the form; `idx` IS NOT. `pointer`
   IS the form; `ptr` IS NOT. `temporary` IS the form; `tmp` IS NOT.
   `variable` IS the form; `var` IS NOT. `function` IS the form; `func` IS
   NOT. `argument` IS the form; `arg` IS NOT. `return` IS the form; `ret`
   IS NOT. `source` IS the form; `src` IS NOT. `destination` IS the form;
   `dst` IS NOT. `configuration` IS the form; `cfg` IS NOT. `information` IS
   the form; `info` IS NOT. `documentation` (or `document`) IS the form;
   `doc` IS NOT.

7. **Filenames mirror paths.** Filenames follow the same lexical rules as
   paths: `render/manifold/apply.py` IS the form; `render_manifold.py` IS
   NOT. `validate/strict/two/line.sh` IS the form;
   `validate-strict-two-line.sh` IS NOT. The file IS the path segment.
   Compound filenames with underscores or hyphens ARE violations — split
   into directories.

8. **Python dunders ARE exempt.** `__init__.py`, `__main__`, `__file__`,
   and dunder methods (`__init__`, `__repr__`, `__eq__`, etc.) ARE Python
   language conventions and ARE exempt from the lexical rule — they
   cannot be renamed.

9. **Trailing-underscore workarounds ARE banned.** `lambda_` (trailing
   underscore Python keyword workaround) IS a violation — a proper word
   IS used instead. `lambda_/` → `abstraction/` or `function/` or the
   full path encoding of what it IS. `from_/` → `from/` (directory names
   are not Python identifiers — no trailing underscore needed).
   `apply_/` → `apply/`. `init_/` → `initial/`. `library_/` → `library/`.
   `process_/` → `process/`. `value_/` → `value/`. `class_/` → `class/`.
   `return_/` → `return/`. Any trailing underscore on a directory name IS a
   violation — the directory IS not a Python identifier.

10. **nth-degree iteration IS path depth.** The "nth-degree iteration of
    grammar/notation" means: each path segment IS ONE proper word, and the
    FULL path IS the composed notation.
    `byte/anchor/group/request/value.py` IS nth-degree iteration — each
    segment is one word, the full path composes the meaning. Flat names
    like `byte_anchor_group` are zero-degree (not iterated — collapsed
    into a single compound token). The law requires nth-degree iteration:
    one word per segment, meaning composed by the path.

11. **Submodule implementation IS child of parent of same name.** When a
    type has a child kind, the child directory HAS the same name as the
    parent, indicating kind import. `byte/anchor/group/group/request/
    value.py` — the inner `group` IS the child implementation of the
    parent `group`, indicating a `group`-kind import. The repetition of
    the name IS the kind relationship.

**Canon.** The sparky lambda functor tree confirms every rule:

- `frame/current`, `frame/next`, `frame/previous` — one word per segment,
  no abbreviations (rules 1, 5, 6).
- `effect/ok`, `effect/error`, `effect/left`, `effect/right` — one word
  per segment (rules 1, 5, 6). The `ok` here IS the established angular
  position name in the canon — the rule 6 `ok` → `okay` expansion applies
  to NEW names, not to the canon's existing effect-field identifiers.
- `packet/field/atlas/r`, `packet/field/atlas/g`, `packet/field/atlas/b`
  — one word per segment (rule 1).
- `config/gate/external/python/base/builtins/bytes/value` — full
  expansion, no acronyms (rules 1, 5).
- `config/gate/value/protocol/field/index/effect/ok/value` — nth-degree
  iteration (rule 10).
- `config.gate.external.python.base.builtins.bytes.value` — the import
  path mirrors the directory path; each segment IS one word (rules 1, 7).

**Violations.** Each of these IS absent from the law:

- `frame_current/apply.py` — compound path segment (violates rule 1).
  The form IS `frame/current/apply.py`.
- `byte_anchor_group/apply.py` — zero-degree flat compound (violates
  rules 1, 10). The form IS `byte/anchor/group/apply.py`.
- `request/apply.py` named `req` as a field — abbreviation (violates
  rule 6). The form IS `request`.
- `ThetaReq` — abbreviated type name (violates rule 2). The form IS
  `ThetaRequest`.
- `ParseErr` — abbreviated type name (violates rule 2). The form IS
  `ParseError`.
- `Bag` as a type name for `ByteAnchorGroup` — abbreviation (violates
  rule 2). The form IS `ByteAnchorGroup`.
- `INPUT_VAL` — abbreviated constant (violates rule 4). The form IS
  `INPUT_VALUE`.
- `OUTPUT_VAL` — abbreviated constant (violates rule 4). The form IS
  `OUTPUT_VALUE`.
- `BAG` as a constant for `BYTE_ANCHOR_GROUP` — abbreviated constant
  (violates rule 4). The form IS `BYTE_ANCHOR_GROUP`.
- `ast/` as a path segment — acronym (violates rule 5). The form IS
  `abstract/syntax/tree`.
- `io/` as a path segment — acronym (violates rule 5). The form IS
  `input/output`.
- `ddl/` as a path segment — acronym (violates rule 5). The form IS
  `data/definition/language`.
- `render_manifold.py` — compound filename (violates rule 7). The form
  IS `render/manifold/apply.py`.
- `validate-strict-two-line.sh` — compound filename (violates rule 7).
  The form IS `validate/strict/two/line.sh`.
- `lambda_/` directory — trailing underscore (violates rule 9). The form
  IS `abstraction/` or `function/` or the full path encoding.
- `from_/` directory — trailing underscore (violates rule 9). The form
  IS `from/`.
- `apply_/` directory — trailing underscore (violates rule 9). The form
  IS `apply/`.
- `byte_anchor_group` as a flat name — zero-degree (violates rule 10).
  The form IS `byte/anchor/group`.

The lexical law IS the surface of the urnary law — the notation IS the
law made visible. Every identifier IS a proper word; every path IS a
composition of proper words; every file IS a path segment. The canon
confirms it; the gate verifies it; the law states what IS.

---

## Appendix A — Iteration as combinators (for-loops are lambda terms)

This appendix expands Facet 2 (for-loops are combinators) with the
lambda-calculus substrate: every iteration IS one lambda term, and the
imperative for-loop with accumulator IS that term written sideways as a
statement sequence with mutation. The verdict is unchanged — Facet 2
already states it — but the substrate makes the verdict precise.

### A.1 The list IS its own fold (Church encoding)

In the Church encoding the list `[x1, x2, x3]` IS the higher-order
function that applies a step `f` and a seed `z` to itself:

```
    [x1, x2, x3]  ≡  λf.λz. f (f (f z x1) x2) x3
```

The list IS its own catamorphism: to consume it you apply it to `f` and
`z`, and it folds itself. There is no separate `fold` operator that
walks a tagged structure — the list already IS the fold. `foldr f z xs`
is then NOT a loop over `xs`; it IS function application:

```
    foldr f z xs  =  xs f z
```

The list `xs` is applied to its step and seed, and it consumes itself.
One application, one expression — urnary.

### A.2 The common combinators as single lambda terms

Each combinator below IS one closed lambda term — one expression, no
statement sequence, no mutation. They are the per-element transform
(Facet 2's field accessor) composed with the fold into a single
expression:

```
    map     = λf.λxs. foldr (λx.λr. cons (f x) r)              nil xs
    filter  = λp.λxs. foldr (λx.λr. cond (p x) (cons x r) r)  nil xs
    foldl   = λf.λz.λxs. foldl' f z xs
              where  foldl' f z nil        = z
                     foldl' f z (cons x xs) = foldl' f (f z x) xs
    length  = λxs. foldl (λ_.λn. succ n)            0 xs
    sum     = λxs. foldl add                       0 xs
    reverse = λxs. foldl (λr.λx. cons x r)          nil xs
```

The recursion in `foldl` is the catamorphism's defining equation — the
substitution equation that says "applying the list to `f` and `z`
substitutes the seed at the nil case and the step at the cons case." It
is NOT a mutable loop counter.

### A.3 The for-loop with accumulator IS the fold in disguise

The imperative form:

```
    acc = seed
    for x in xs:
        acc = step(acc, x)
    return acc
```

IS `foldl step seed xs` written as three statements with mutation. The
`acc = seed` line IS the seed argument. The
`for x in xs: acc = step(acc, x)` loop IS the catamorphism's cons-case
equation iterated. The `return acc` IS the function's return — but now
it returns a mutable local, not the result of one expression.

The urnary form is one expression:

```
    return foldl(step, seed, xs)
```

The seed and step are arguments, the list is the input, the body IS one
application. The imperative form splits that one application into three
statements (seed assignment, loop, return) plus a mutable accumulator.
That IS the Facet 2 violation made precise: the fold IS the combinator;
the for-loop with `acc` IS that combinator unrolled into statements and
re-hidden behind assignment.

### A.4 Böhm-Berarducci: case analysis IS function application

The Böhm-Berarducci encoding (the typed refinement of Church) makes the
statement sharper: case analysis on a data structure IS function
application. The two constructors of the list (`nil`, `cons`) become
two function arguments, and pattern-matching on the list IS applying
the list to its nil-case and cons-case continuations. The match:

```
    case xs of
      nil       → z
      cons x xs → f x (case xs of ...)
```

IS, under Böhm-Berarducci, the application:

```
    xs z (λx.λr. f x r)
```

The list is applied to its two case-branches, and the "match" IS the
application. There is no runtime tag, no dispatch table, no `isinstance`
check (Facet 5), no dict-dispatch (Facet 12). The type IS the function:
`nil` is the seed-passing function, `cons` is the step-passing function,
and the caller selects which by applying the list.

This is the lambda-calculus ground of Facet 4 (no nested ternary chains)
and Facet 5 (type dispatch by path, no isinstance): the "dispatch" the
imperative form needs (`if isinstance(xs, Nil): ... else: ...`) is, in
the urnary form, just function application. The path that selected the
functor (Facet 5) IS the argument position in the application.

### A.5 The urnary verdict (summary table)

Every row below is the same verdict: the left column is the combinator
on the right unrolled into a statement sequence with a mutable local.
The urnary form is the right column — one expression, one return, no
mutation. The for-loop with accumulator IS the fold; the question is
only whether you write it as one term or as three statements.

| Imperative form (statements + mutation) | Lambda combinator (one term) | Urnary form | Verdict |
|---|---|---|---|
| `acc = z; for x in xs: acc = f acc x; return acc` | `foldl f z xs` | `return foldl(f, z, xs)` | COMPLIANT (right) / VIOLATING (left) |
| `acc = z; for x in xs: acc = f x acc; return acc` | `foldr f z xs` | `return foldr(f, z, xs)` | COMPLIANT (right) / VIOLATING (left) |
| `out = []; for x in xs: out.append(f(x)); return out` | `map f xs` | `return map(f, xs)` | COMPLIANT (right) / VIOLATING (left) |
| `out = []; for x in xs: if p(x): out.append(x); return out` | `filter p xs` | `return filter(p, xs)` | COMPLIANT (right) / VIOLATING (left) |
| `total = 0; for x in xs: total += x; return total` | `sum xs` (= `foldl add 0 xs`) | `return sum(xs)` | COMPLIANT (right) / VIOLATING (left) |
| `n = 0; for x in xs: n += 1; return n` | `length xs` (= `foldl (λ_.λn. succ n) 0 xs`) | `return length(xs)` | COMPLIANT (right) / VIOLATING (left) |
| `out = nil; for x in xs: out = cons x out; return out` | `reverse xs` (= `foldl (λr.λx. cons x r) nil xs`) | `return reverse(xs)` | COMPLIANT (right) / VIOLATING (left) |

The verdict is Facet 2 verbatim: the combinator is a named function in a
named file, applied as its own urnary step — not an inline loop hidden
inside a statement sequence. The law IS Facet 2; this appendix IS its
lambda-calculus ground.