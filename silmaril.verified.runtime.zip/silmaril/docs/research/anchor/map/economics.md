# Economic research designs and observation boundaries

## Housing affordability option

The ACS/PUMS question now points to an actual proposed descriptive option: weighted housing-cost-burden distributions and threshold shares by tenure, income group and comparable geography. The intended unit is a household or housing record in the selected release's eligible occupied-housing universe. A release, target geography and period have not been supplied as selections. They remain launch parameters, not fabricated observed coordinates.

The option requires housing weights, replicate-weight uncertainty, release-specific variable definitions, universe and missingness checks, nominal versus real price treatment, geographic/PUMA comparability and validation against appropriate official aggregates. It does not claim causality, an affordability estimate or observed sentiment.

## Alternating-offer proposal

The repaired design is a proposal, not an executed model experiment. The primary analysis unit is a full two-player match, with decisions nested within it. The target population is a finite roster of local model/version/prompt/sampling configurations that must be sealed before launch. It is not a human sample and has no economic geographic sampling frame. Four offers define the within-match period; actual execution dates will be recorded when trials occur.

The economic question is how proposed agents' offers and acceptance choices deviate from a specified equilibrium benchmark and how those deviations vary across models, player order and framing. Candidate mechanisms include bounded reasoning, fairness preferences and prompt-induced conventions. Verbal explanations do not establish which mechanism operated.

The benchmark has two players, a pie of 1000 integer tokens, at most four alternating offers, player one proposing first, common discount factor 9/10, zero terminal disagreement payoff and acceptance at indifference. Both players observe the full history. At the last round player two offers zero to player one; backward induction then gives allocations to player one of 100 at round three, 90 at round two, and 181 at round one. The first-round split is therefore 181/819. This is a derived finite-game benchmark, not the infinite-horizon bargaining formula and not an observed agent outcome.

Planned outcomes include agreement rates, offer shares, agreement round, discounted payoffs, invalid actions and strategy deviations at reached subgames. Uncertainty must respect independent matches and sessions. Model artifacts, versions, exact prompts, sampling parameters, seeds, player order and every failed/partial trial require logs. Randomized framing and order would support designated causal contrasts only with a prespecified identification contract.

The local-model roster and trial roster are explicitly pending. No behavioral count or effect size is invented. Policy and mechanism-design relevance is conditional on measured robustness and external-validity limits, not inferred from this unrun proposal.
