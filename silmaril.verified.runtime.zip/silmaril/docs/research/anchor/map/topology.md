# Executable topology and scheduling

## Research capability

This analysis is descriptive infrastructure verification. The unit is a finite declared graph or chain complex. Its target population is the supplied finite fixture or admitted plan, not a sample of households or agents. Geometry and calendar survey periods do not apply. The decision is whether an execution plan can be scheduled safely and whether an explicitly declared algebraic model is internally consistent.

## Directed order is not undirected homology

A diamond with arcs a to b, a to c, b to d and c to d is a directed acyclic graph. Its underlying one-complex has four vertices, four edges and one connected component, hence beta one equals one. It must be accepted by the scheduling gate. Removing a directed cycle remains the job of the Kahn criterion, not the assertion beta one equals zero.

The repaired Kahn implementation chooses the earliest declared currently ready node after each removal. The counterexample has declared order a,b,c,d and a dependency b to a. The correct priority order is b,a,c,d. The predecessor FIFO queue produced b,c,d,a. Both are topological orders, but only the former satisfies the declared tie policy.

For a finite graph, beta zero is the number of weak components and beta one is edges minus vertices plus components. These are diagnostic invariants, not a complete structural fingerprint. Independent graph components can still compete for undeclared external resources; topology alone does not prove resource isolation.

## Chain-complex calculation

`homology::compute` validates every declared differential over the selected prime field and checks consecutive matrix products are zero. It computes ranks, Betti dimensions and Euler equality. Coefficient fields are explicit and validated. The current finite profile bounds the prime by 32749, each module rank by 64, and degree by 16. Integer entries must be canonical signed decimal values within the declared bound; shell arithmetic expressions are rejected as data.

The actual source engagement example is a cellular bigon, not an assumed simplicial triangle. Its cells are a,b,f,g,alpha, with both one-cells running from a to b and alpha spanning f and g. Module ranks are 2,2,1; d1 has rows (-1,-1),(1,1), and d2 has entries (-1,1). The recorded field-two computation has Betti vector (1,0,0) and Euler characteristic one. `evidence/repair/boundary.sh` reruns this calculation; its retained log is a fresh measurement, not a historical claim.

Higher-degree, invalid-composition, prime-characteristic, arithmetic-injection and scope-limit controls appear in `tests/homology.sh`. This implementation computes field homology, not integral Smith normal form or torsion. Laplacian eigenvalues are not generally integers and Smith diagonal entries are not eigenvalues. Equal spectra do not imply graph isomorphism. A finite state machine does not become a differentiable manifold by assigning numeric state codes.

The critical-path result is a longest directed path measured in unit edges. It is not a measured elapsed-time makespan or a geodesic certificate. Cost estimation, continuous relaxations and spectral solvers would require separately specified models and validation.
