# Consolidated OWL, XSD and categorical mapping

## Actual artifacts

The active logical artifact is `ontology/consolidated.ttl`. It includes the local ontology, its source-derived class hierarchy, coherent pinned external ontology axioms, the 428-occurrence semantic crosswalk, and the companion executable SHACL constraints. `ontology/consolidated.shacl.ttl` is the extracted shapes leg; it is not a second logical authority. Original source files remain under `source/` and the identifier bridge and change records are under `evidence/repair/`.

Six foundational law families, the Yoneda/full-faithfulness/density theorem records, and four construction records remain separate. The source crosswalk is not a machine-checked certificate that every semantic-profile assignment forms the proposed global functor. `proofs.md` gives general arguments with explicit variance and smallness assumptions.

## Semantic boundaries

OWL class expressions denote subsets of an interpretation domain. Intersection, union, complement, enumerations and cardinalities operate on interpreted occupants. An asserted syntax count is not a semantic cardinality, different names do not automatically denote different individuals, and open-world entailment is not closed-world validation.

OWL object and data properties are distinct typed relations. `owl:hasKey` uses its named-instance/shared-value semantics. Total single-valued observation maps are an additional specialization under which joint monicity is meaningful, not an automatic translation of every OWL key. A key does not require the data to explicitly contain a key value.

XSD records retain lexical space, value space, lexical interpretation, canonical representation and facets. Context-dependent interpretation and overlapping union membership remain explicit. List tokenization is not the same thing as the list value space, and restricted list types need not be closed under concatenation. Include, import, redefine and override remain distinct schema-module transformations. No general XSD validation engine is claimed.

A physical octet, an arbitrary registered-width byte schema, `xsd:unsignedByte`, and the residue ring modulo 256 are not identified merely because some carriers have the same cardinality.

## Pair and occurrence semantics

A Pair is an ordered product of key and value. A BindingOccurrence adds subject, carrier, position and provenance. The added OWL cardinality restrictions, pair key, disjointness axiom and two SHACL shapes exercise this distinction on explicitly synthetic controls. The native parser also maintains the distinction for its admitted reference-valued YAML profile.

This is not a universal claim that every transported metadata binding and every historical AOB has recursively acquired complete independent grounding. The old padded accounts are quarantined in a separate shard, not imported into the active head.

## Validation

`reports/independent/` contains actual Apache Jena SHACL results and mutation controls. `reports/structure.md` separately counts declarations, property-assertion kinds, class/individual overlap and named-subclass depth. Nine source shapes have no production focus node in this snapshot; their empty targets are reported rather than interpreted as passing measurements. No complete OWL 2 DL reasoner or proof-assistant kernel ran.

Standards: W3C OWL 2 Structural Specification and Direct Semantics; W3C SHACL; W3C XML Schema 1.1 Parts 1 and 2. Their unchanged source IRIs and citations are retained in the graph. Upper ontology editions are byte-pinned, not silently upgraded.
