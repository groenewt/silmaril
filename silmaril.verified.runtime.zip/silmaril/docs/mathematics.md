# Algebraic and categorical closure: construction, proof and executable scope

## 1. Pair and binding

The primordial product is `Pair = Key × Value`. Its left and right projections obey the product equations. It is not an assertion until it is placed in a subject context and given a carrier, occurrence position and provenance:

\[
B=S\times(K\times V)\times C\times P\times E.
\]

The assertion projection is `(s,(k,v),c,p,e) ↦ (s,k,v)`. Forgetting occurrence coordinates is a projection, not an equality of the records. Two physical bindings may share a semantic pair and subject while differing in their carriers. No digest participates in the definition of semantic identity.

The kernel stores the key/value pair and the binding in separate arrays and emits separate RDF resources. The containing map determines the subject. Every additional YAML mapping depth introduces a named map and a new binding coordinate. This does not identify YAML containment with programming inheritance, set membership, or ontological subclassing.

Keys denote typed relation positions. A general relation must be represented by a span `S ← E → V`; it cannot be silently used as a single-valued function `S → V`. The context of a binding supplies the subject, while the key identifies the relation and the right coordinate supplies its occupant. Olog aspects that really are functions have their totality and uniqueness obligations separately checked.

## 2. Presented category

A typed graph G has objects, directed generating arrows, and source/target maps. Its free path category includes the empty path at each object. Given parallel path equations E, let ≡E be the least congruence containing them and closed under compatible composition. Then

\[
\mathcal C_{seed}=\operatorname{Path}(G_{seed})/\equiv_{E_{seed}}.
\]

The executable profile accepts a complete finite category table. It does not claim that an arbitrary finite graph with a few equations presents exactly that table. A separately supplied equation is checked for satisfaction in the table; that is a model-satisfaction result.

For an exact presentation of the table itself, take every table arrow as a generator. Add the identity equations and one equation `[g,f] = [g∘f]` for every composable pair. Reduce every nonempty composable path by table composition and remove identity generators. Each reduction shortens the path. Ambiguities on three consecutive arrows join because the table's associativity has been checked; unit ambiguities join by the checked identity laws. Thus the table gives an exact normal-form presentation under these full equations. This argument does not establish decidability or completeness for arbitrary user presentations.

The six foundational families are category identity, category associativity, functor identity, functor composition, naturality, and sketch-equation satisfaction. Naturality constrains a declared transformation. It is not an assumption that every family of functions is natural. The structured expression records retain constructors, argument positions, variables, left and right sides. The executable checker interprets the admitted finite tables, not arbitrary shell expressions embedded in these records.

## 3. Functor and category of elements

A covariant functor `M:C→Set` assigns a carrier M(a) to each object and a total map M(f) to each arrow. Its identity and composition equations are checked pointwise on the admitted finite carriers.

For covariant M, the category of elements has objects `(a,x)` with `x∈M(a)`. A morphism `(a,x)→(b,y)` is an arrow `f:a→b` for which `M(f)(x)=y`. The identity is the lift of `id(a)`. The composite of lifts of f and g is the lift of `g∘f`, because

\[
M(g\circ f)(x)=M(g)(M(f)(x)).
\]

This is the precise meaning of `SeedCarrier=∫Mseed`: a category over C, not an untyped union of payload strings. The implementation constructs the lifted arrows and checks their sources, targets, identities, composition and associativity. The projection back to C is recorded separately from the element value.

## 4. Yoneda is a theorem

For a locally small C and covariant `M:C→Set`, define

\[
\Phi:\operatorname{Nat}(\operatorname{Hom}(a,-),M)\to M(a),\qquad
\Phi(\eta)=\eta_a(1_a).
\]

For `x∈M(a)`, define `Ψ(x)_b(f)=M(f)(x)`. Functoriality makes this family natural: for `g:b→c`,

\[
M(g)(\Psi(x)_b(f))=M(g\circ f)(x)=\Psi(x)_c(g\circ f).
\]

The unit law gives `Φ(Ψ(x))=x`. Naturality of η, applied to `f:a→b` and `1_a`, gives `η_b(f)=M(f)(η_a(1_a))`, so `Ψ(Φ(η))=η`. The two maps are inverse. No seventh axiom has been inserted.

The executable finite check enumerates candidate component families, retains the natural ones, and checks this evaluation/reconstruction bijection. Its candidate ceiling is explicit. Exhaustive finite evidence is not a machine-checked proof of the general statement above.

For the standard embedding `y:C→[C^op,Set]`, `y(a)=Hom(-,a)`. Applying the preceding argument in the opposite category gives

\[
\operatorname{Nat}(y(a),y(b))\cong\operatorname{Hom}_C(a,b),
\]

which is full faithfulness. The implementation deliberately constructs the opposite-category view, rather than changing variance in prose while keeping a covariant table.

## 5. Co-Yoneda and the quotient

For covariant M and fixed c, take all pairs `(x,f)` with `x∈M(d)` and `f:d→c`. Impose the generating relation

\[
(M(g)(x),h)\sim(x,h\circ g)
\]

for `g:d→e` and `h:e→c`. Evaluation `[x,f]↦M(f)(x)` is well-defined by functoriality. It is surjective because `y∈M(c)` is the evaluation of `[y,1_c]`. Every class satisfies `[x,f]=[M(f)(x),1_c]`, by taking g=f and h=1c. Equal evaluations therefore give the same class, proving injectivity. Consequently

\[
M(c)\cong\int^d M(d)\times\operatorname{Hom}(d,c).
\]

The finite implementation materializes these generators, computes their equivalence classes, and checks that evaluation is constant on each class and bijective. On the two-element group-action fixture, four candidate pairs quotient to two classes.

## 6. Topology, geometry, groups and classes

A one-object category whose arrows all have two-sided inverses is a group. The group checker verifies category laws first, then an inverse witness for each arrow. Commutativity is a separate check; it is not inherited from being a group.

A finite topology is a family of subsets containing the empty and full sets and closed under binary union and intersection. Since the family is finite, arbitrary unions of members reduce to finite unions. The implementation uses bounded bitsets as a physical representation of subsets, not as their semantic identity.

A finite integer-valued metric is checked for totality, nonnegativity, zero exactly on the diagonal, symmetry and triangle inequalities. The topology and metric checks do not assert that every geometric object is a group, or that every topological space has the supplied metric. The inherited ontology keeps sets, class descriptions, groups, categories, topological spaces and geometric spaces distinct.

A proper class is not materialized as a finite set merely because a registry can list class descriptions. Quantification over all sets or all categories needs the declared foundational size convention; the executable profile is finite.

## 7. Corrections to the inherited lambda and polar text

The displayed Church list `λf.λz.f(f(f z x1)x2)x3` has left-fold order with step type `Accumulator→Element→Accumulator`. It is not the usual right-fold encoding used by the subsequent map/filter equations. The left-fold length step is `λn.λx.succ(n)`, not `λ_.λn.succ(n)`. These conventions must not be mixed.

A Bash loop can implement a fold via an explicit loop invariant, but that does not turn mutable Bash source into a pure lambda term. This runtime uses Bash mutation as its physical implementation of declared contracts. It does not claim that all helper bodies satisfy a literal one-expression lambda-source rule.

A finite cyclic set with its discrete topology is not a circle and does not acquire the circle's first cohomology. A cycle graph's geometric realization is a circle. The map from integers modulo n is a useful quotient of groups; a topological universal-cover statement requires the relevant spaces and topology. An antipodal involution on n equally spaced discrete positions exists by half-turn only for even n. Read and write are not inverses merely because directories are paired. Cost interpretations of `dr²+r²dθ²` are proposed models, not measured runtime costs.

## 8. OWL and XSD boundaries

OWL class predicates are interpreted inside a model. Object and data properties are relations; property functionality requires its own constraints. Cardinality is fiber cardinality over distinct interpreted values. `oneOf` is finite enumeration without a unique-name assumption. `hasKey` uses shared witnesses on named individuals, with the named-filler condition for object keys. Joint monicity requires a restricted functional observation setting and does not replace the general rule.

XSD accounts retain `D=(L,V,ell,c,F)`. The broad lexical mapping can be relational: `anySimpleType` and `anyAtomicType` demonstrate why a universal function assumption would be wrong. A list's tokenization is lexical processing; its values are sequences. Union members can overlap without value tags, while validation retains member-selection behavior. Include/import/redefine/override are versioned schema-component transformations, not arbitrary text rewrites.

The current unsigned-byte checker implements decimal lexical normalization and integer range validation. It does not implement an XML Schema processor. An octet in the machine carrier, an unsigned-byte datatype value and an element of the modular ring are separately typed accounts.

## Sources

Primary specifications used: W3C OWL 2 Direct Semantics, especially Table 9; W3C XML Schema 1.1 Part 2, sections on value/lexical spaces, lists and unions; RFC 8141, RFC 3986 and RFC 8089; GNU Bash Reference Manual; BFO 2020 core. Source identifiers and access scope are in docs/grounding.md and docs/sources.md. The Yoneda and coend arguments above are supplied mathematical derivations; executable scope is explicitly finite.
