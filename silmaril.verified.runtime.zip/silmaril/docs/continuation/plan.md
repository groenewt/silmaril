# Verified continuation implementation plan

Goal: retain the repaired executor and close reproducible occurrence-identity and validation-coverage defects.
Architecture: one Bash execution kernel, immutable input witnesses, distinct host-side ontology verification.
Basis: the user-approved Pair/BindingOccurrence construction, immutable source rule, and requested OWL/SHACL validation continuation.

Research classification: normative computational-economics research infrastructure. Unit: a binding occurrence, source carrier, or validation fixture. Population, geography, and economic estimand: not applicable to these synthetic mechanical tests. Mechanism: stable observations and exact input pins prevent cross-session identity drift and evidence substitution. Decision: whether isolated research workflow tests may consume the successor; not production or empirical-result approval.

Global constraints: Bash builtins only inside execution; no Git commit or push; no original-source modification; no digest as semantic identity; strict archive bound less than 50000000 bytes; unavailable evidence cannot become an accepted gate.

## Task 1: Stable native capture
- [x] Reproduce absence of a replayable capture interface.
- [x] Add transactional observation-scoped capture with independent SHA256 input pin.
- [x] Serialize reference-valued binding/position/provenance accounts deterministically.
- [x] Re-admit by recomputing source meaning and comparing the complete receipt, without evaluating receipt content.
- [x] Test cross-process identity, changed snapshot/path/source, altered receipt, invalid pins, and rollback.
- [x] Refresh exact source projections and callable registry; run every native suite.

## Task 2: Nominal artifact identity
- [x] Demonstrate the inherited digest key rejects distinct byte-identical artifacts.
- [x] Replace that key with explicit nominal artifact identifier, and the corresponding SHACL uniqueness rule.
- [x] Preserve the original ontology and exact withdrawal/addition evidence.
- [x] Test shared-digest acceptance, duplicate-nominal rejection, and missing-nominal rejection.

## Task 3: Shape coverage and logical boundary
- [x] Measure all original target populations with Apache Jena.
- [x] Add labeled synthetic fixtures for absent target populations, never production data.
- [x] Exercise positive and hostile controls against actual declared targets.
- [x] Rerun inherited hostile controls and structural OWL checks on the complete successor.
- [x] Record complete-DL tool acquisition outcomes without relabeling partial inference.

## Task 4: Delivery evidence

The final archive, clean-extraction replay, byte manifest and process-image trace are bound in the separately published verification report. This planning document is not a self-certifying archive seal. The remaining whole-corpus obligations are listed in remaining.md and retain their blocked status.
