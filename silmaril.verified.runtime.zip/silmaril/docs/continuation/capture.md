# Observation-scoped native key/value capture

## Research use

This is normative computational-economics research infrastructure. The question is whether a workflow can reproduce its exact source bindings without confusing equal bytes with equal artifact identity. The unit is a source binding occurrence. The controls are synthetic; they have no empirical population, geography, income outcome, price basis or causal estimand. The capability supports auditable transformation provenance, not survey-design or policy-effect validation.

## Native interface

The existing engine is retained. Capture, replay, hashing and reference-valued YAML rendering use Bash builtins and Bash language constructs. No Python, Java or external executable is invoked by the native engine.

`kv::capture SOURCE OBSERVATION PIN` admits an absolute source path, a ranked observation URN and an independently supplied lowercase SHA-256 pin. It hashes the exact admitted byte buffer and returns a capture token only after successful validation. `kv::capture::emit` emits the reference-valued account. `kv::capture::verify SOURCE OBSERVATION PIN RECEIPT` reconstructs and compares the complete receipt bytes. Surplus arguments, an empty receipt argument, NUL, truncation, changed source bytes, changed receipt bytes and incompatible observation identity reject.

A trusted local invocation, using already existing private directories:

```bash
source /absolute/path/to/silmaril/engine.sh
kv::capture "$SOURCE" "$OBSERVATION" "$EXPECTED_SHA256" || exit 1
(set -C; kv::capture::emit > "$RECEIPT") || exit 1
kv::capture::verify "$SOURCE" "$OBSERVATION" "$EXPECTED_SHA256" "$RECEIPT" || exit 1
```

Do not obtain the expected pin from an untrusted receipt under test. The pin is content evidence, not an artifact identity or a signature.

The unary entrance remains `engine::apply REQUEST` or `engine.sh apply REQUEST`. Two new operation references end in `:capture` and `:capture:verify`. A capture request contains IDENTITY, TYPE, OPERATION, INPUT, RECEIPT, OBSERVATION/IDENTITY and DIGEST. INPUT and RECEIPT are typed path references. DIGEST is a counted vector of exactly 32 referenced octets in the existing decimal-ordinal trie format. OUTPUT is optional for the result Frame. POLICY, CHECKPOINT and SNAPSHOT are not capture fields. Conversely, a non-capture operation rejects capture-only fields instead of silently ignoring them. The executable constructor example in tests/captureinterface.sh demonstrates the exact native serialization.

Creation uses noclobber publication in a pre-existing private directory. Existing matching accounts are verified without rewriting and have effect NONE; creation records the existing audit effect. A differing existing account rejects without replacement. A receipt may not overlap the request, input or Frame output; existing hardlink aliases are checked. Frame output for capture must be new.

## Identity and transaction rules

Pair identity depends on the typed key and typed value. A binding occurrence separately records subject, pair, source carrier, exact position and provenance. Observation and path coordinates are length-framed into carrier/occurrence identities; hashes are not injected into those identities. Named key/value references preserve Pair identity across independent observations and source locations. Source-owned description witnesses remain contextual, rather than being silently interned as context-free semantic values.

The receipt records line, byte offset and byte length for each binding. Failed admission restores the previous committed pair state and clears capture result coordinates. Any subsequent generic parse invalidates the old capture token. A process-local pin registry prevents rebinding one observed carrier identity to different bytes. Cold-process replay instead requires the independently retained observation, pin and exact receipt.

The profile admits at most 1,024 bindings and 16,777,216 rendered receipt bytes. This is not a general YAML implementation, a public namespace registry, global observation-uniqueness service, recursive AOB closure, hostile-filesystem sandbox, durable transaction protocol or power-loss guarantee. Raw installed Bash remains trusted code.

## Verification

The native capture suite has 19 named controls; the unary request suite has eight. The source catalog suite checks equality with every sealed source registration, not only a hard-coded count. The companion verification archive records fresh full-suite replay, cold capture replay, native-to-typed RDF coordinate comparisons and independent Jena SHACL checks. Synthetic targets are explicitly separated from the delivered data graph.
