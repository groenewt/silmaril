# Ontology and shape corrections

The successor retains the predecessor's class vocabulary and changes a specific identity axiom: InformationBearingArtifactEntity is keyed by artifact:identifier, not artifact:digest. The new datatype property has that artifact class as its domain. It is not substituted with the specification identifier property, which would introduce an unwanted specification classification. The existing bargaining-prompt artifact receives its already assigned subject IRI as a nominal identifier. Different artifact identifiers may have equal bytes and equal digests. Duplicate identifiers and a missing identifier reject through SHACL.

The old digest-key constraint and exact predecessor bytes remain in the verification before-images. They are not simultaneously retained as active constraints. A new version IRI ends in :capture:one, with owl:priorVersion retaining the predecessor version. Open the consolidated entry point alone in a fresh ontology manager.

A second correction concerns controlled zero measurements. The old SPARQL triple pattern matched the RDF term 0, missing zeros carried with a different numeric datatype or lexical representation. The repaired query binds the count and tests numeric equality using FILTER(?count = 0). Missing positive control evidence now rejects for the original nonnegative-integer zero, an integer zero and a lexical 00 zero.

The host Turtle serializer writes explicit blank-node references. An initial ordinary pretty serialization duplicated a shared RDF-list tail. The final serializer does not abbreviate blank-node lists or collapse their sharing. This is a representation repair, not an additional mathematical axiom.

The independent shape exercise uses all 52 declared node shapes. Existing data and separately labeled synthetic fixtures are counted separately. Each shape has a negative control that must produce a result for its specified focus and the corresponding shape or property shape. A failure on an unrelated shape does not satisfy that control.

SHACL conformance is not OWL 2 DL satisfiability, a proof of every categorical theorem, justified applicability of each imported class, empirical evidence, or full corpus admission. The full reasoner and historical-source obligations remain in remaining.md. The pure Bash runtime does not invoke Jena or the host validation tools.
