# Historical baseline assessment

The following is the unchanged assessment of the previous delivery. It is not the current revision status. See gates.md and changes.md for this revision.

# Acceptance-gate assessment

## Release decision

**Executable profile: tested. Whole-corpus acceptance: not sealed.**

These statements are different. A passing finite-model check does not discharge all 34 corpus requirements. A named grounding profile is not an imported ontology closure. A reference present in the compiled registry is not necessarily a fully defined and separately persisted specimen. This assessment supersedes any earlier blanket “FINAL / PASS” prose in the conversation.

“Local” means the admitted mapping/finite-runtime profile exercised by the included tests. “Partial” means that part is implemented but the user's universal requirement remains unsatisfied. “Blocked” means this package does not supply the required artifact or verification. “Delivery” is a directly checked packaging/source-operation fact, not an ontology claim.

## All 34 acceptance criteria

| No. | Requirement | Assessment and exact boundary |
|---|---|---|
| 1 | Pair carrier for every law family | Partial. Active mapping entries use pairs; every historical law family has not been converted. |
| 2 | Every visible binding has independent occurrence identity | Local. Parser creates a pair and physical binding for every admitted mapping entry. Persisted whole-corpus AOB coverage is incomplete. |
| 3 | Left/relation/right/coordinate/state/local metadata | Partial. Typed predicate, value, subject and physical coordinates are explicit; recursively expanded local metadata/state for every generated occurrence is incomplete. |
| 4 | Deep nesting is pair composition | Local structural descent. Nested subjects and positions are explicit. Arbitrary nested assertions are not automatically composable category arrows. |
| 5 | No anonymous/primitive/flow/alias/null shortcuts | Local syntax/profile rejection. Physical Bash counters, buffers, arrays and compiled prelude remain the implementation substrate, not recursively expanded public AOBs. |
| 6 | Exact substrate chain for every specimen | Partial. Octet/UTF-8/position operations exist. Register, instruction, kernel and physical realization proofs for every semantic specimen are not present. |
| 7 | Explicit ontology-grounding profile everywhere | Partial. Two exact BFO named-chain profiles are checked. Full BFO restrictions/import closure and class-specific CCO/CPO grounding remain blocked. |
| 8 | Distinct grounding/taxonomy/inheritance/containment/realization/denotation/location/resolution | Local records distinguish these; whole legacy inventory has not been reconciled. |
| 9 | Meaningful complete ranked lineage | Partial. Rooted names and rank-marker checks exist. Independent domain/kingdom/phylum differentia and admissibility proofs for every taxon do not. |
| 10 | Concrete Instance and positioned Occurrence | Partial. Runtime objects and occurrences are distinguished, but not every compiled record has all independently materialized rank nodes. |
| 11 | Every rank edge has differentia, authority, provenance, state, receipt | Blocked as a universal claim. Declared references and descriptions are not that complete edge estate. |
| 12 | No skipped/fused/padded/misplaced ranks | Partial. Known fused local URI atoms were migrated and selected rank errors checked. Complete semantic padding/fusion detection is not implemented. |
| 13 | Exactly one primary rendering lineage | Partial. Deterministic local construction, not a global proof over all source archives. |
| 14 | Secondary classifications share identity without duplicate AOB | Blocked for full corpus. Secondary-classification reconciliation is not complete. |
| 15 | Standard URN envelope and fixed payload order | Partial. The stricter assigned-name subset is admitted. Full RFC 8141 parsing with all components is not implemented. |
| 16 | Namespace state explicit | Documented. No public registration claim for `silmaril`; IANA was read on 2026-09-04. |
| 17 | Optional components have protocol-only roles | Local rejection of optional components in canonical names. General component parser absent. |
| 18 | URN delimiters distinct from language operators | Local canonical profile separates them. All graded URNARY operator modes/parser/seals are not implemented. |
| 19 | Lowercase expanded canonical names, no fused forms | Partial. Known source tokens were migrated; all Bash ABI function names and code symbols are not projected through independently defined notation specimens. |
| 20 | URN/URI/filesystem/taxonomic/locator/endpoint species distinct | Modeled. Executable general URI, file locator and endpoint parsers remain incomplete. |
| 21 | Every path has full root/segments/parent/layer/depth/ordinal/kind/notation/provenance | Partial. Reversible absolute path and binding byte positions exist. Complete filesystem account and sibling ordinals do not. |
| 22 | Taxonomic path reverses to exact lineage | Partial. Foundation paths are deterministic renderings; complete rank-segment grammar and relocation receipts are not globally checked. |
| 23 | Every file URI round-trips to admitted occurrence | Blocked. Typed physical path encoding is not a file-URI parser. |
| 24 | Every endpoint separates service/protocol/version/operation/locator/security/policy | Modeled contracts only. Live endpoint parsing and security-policy execution are not claimed. |
| 25 | Every directory ring accounts for every child and closes | Blocked. No complete governed-filesystem inventory or ring proof. |
| 26 | Hash/device/host/port do not replace semantic identity | Local design and source manifest keep digest evidence separate. Physical locator bytes remain occurrence coordinates. Full historical corpus compliance is not asserted. |
| 27 | Grammar/operators/fixtures/gaps/adjudications/taxa/paths/endpoints/receipts all pairs | Partial. Included canonical registries/receipts are mapping projections; complete historical grammar and operator corpus not migrated. |
| 28 | One semantic AOB for every identity | Blocked. Fourteen new foundation AOBs are materialized; the entire compiled and dynamic identity universe is not. |
| 29 | One occurrence AOB for every physical manifestation | Blocked. Runtime occurrence records exist but are not all independent persistent AOB directories with complete local metadata. |
| 30 | Nucleus/grounding/rank/address registries self-validate and all projections round-trip | Partial. Parser, selected profiles and exact pair N-Triples checks pass. Full self-hosting and all-projection equivalence not demonstrated. |
| 31 | Generated head covers complete admitted graph, no law inline | Partial. The included pointer index covers 14 foundation records; it is not the whole admitted corpus head. |
| 32 | Every violation reconciled before DAG resumes | Not satisfied globally. Local fixtures run under their tested profile; unresolved corpus gates remain explicit. Production admission must not mistake this for a whole-corpus seal. |
| 33 | Every shard below strict byte bound | Delivery. Actual archive size and integrity are reported in the delivery receipt. |
| 34 | No Git commit without confirmation | Delivery. No Git mutation was performed. |

## Required error registry

The 23 requested leaf coordinates are separately registered. The complete current registry contains 48 coordinates. Runtime errors can be looked up without collapsing families; `registry/errors.yaml` carries their identities and record definitions.

| Family | Distinct required leaves | Current emission/verification boundary |
|---|---|---|
| GROUNDING | MISSING, CONTRADICTORY | Exact-profile absence, version/ancestry conflict tested. Full imported-ontology inconsistency is not decided. |
| RANK | MISSING, MISPLACED, SKIPPED, PADDED, FUSED | Separate identities exist. Some structural checks use legacy typed errors. Exhaustive semantic rank diagnosis is not implemented. |
| RESOURCE / UNIFORM / NAME | SYNTAX, NAMESPACE, EQUIVALENCE, DELIMITER | Strict canonical name syntax/namespace admission exists. General RFC equivalence is not implemented. |
| PATH | ROOT, PARENT, DEPTH, ORDINAL, SEGMENT, ROUND / TRIP | Lexical/symlink/round-trip tests cover part of the profile. Global sibling and directory-ring assertions are absent. |
| PROTOCOL | IDENTITY, LOCATOR, OPERATION, ENDPOINT, SECURITY | Local builtin protocol and operation admission tested. Live locator, endpoint and security processing is absent. |
| PROJECTION | FIDELITY | Exact generated N-Triples comparison and worker-envelope rejection implemented. General schema/OWL projection fidelity is not proved. |

Registration is not emission coverage. Naming an error cannot serve as evidence that the corresponding failure is detected.

## Finite closure versus general proof

The category identity, associativity, functor identity, functor composition, naturality and sketch-equation records are six axiom families. Naturality is a condition on a specified transformation, not an axiom required merely to form a category. The three Yoneda/full-faithfulness/density records are theorems with proof-target references. `docs/mathematics.md` supplies the mathematical arguments; finite exhaustive checks supply execution evidence for the fixtures. No proof-assistant kernel has checked the universal proofs.

The OWL/SHACL file is an explicit projection. Delivery-time RDF syntax checking is not satisfiability checking, complete SHACL validation or an OWL 2 DL profile proof. The runtime's exact generated N-Triples verifier intentionally does not advertise those capabilities.

## Quarantine and unresolved evidence

The three original source ZIPs and legacy consolidated seed Turtle were not modified. They remain source evidence outside the active runtime package. Legacy permissive YAML, old URIs, source JSON/TSV/TOML, executable hooks and incompatible service scripts are not copied into active admission merely to claim parity. The source inventory preserves locations; it does not fabricate full semantic and occurrence AOBs for every quarantined source member.
