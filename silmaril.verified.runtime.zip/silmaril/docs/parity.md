# Current functional reconciliation

The three immutable source archives and their 361 function occurrences remain inventoried in registry/reconciliation.yaml and docs/sourcecounts.md. An occurrence inventory does not imply behavioral equivalence. The earlier compact type/object/C3/polymorphism and byte/DAG regressions remain in the suite with explicit canonical-name/YAML migrations.

| Capability | Current treatment |
|---|---|
| Type/field/abstract/C3/next-method contracts | Retained and regression tested. |
| Permissive YAML/raw scalar/sequence surface | Replaced by strict reference-only mapping and typed-vector projection. Old formats are deliberately rejected. |
| Pair identity/binding occurrence | Corrected to key/value product identity with separate observation, carrier, subject, position and provenance; transactional failure and export checked. |
| Stable graph ordering and native workers | Retained native scheduler; predeclared immutable parent-visible output profile. |
| Retry/deadline/abort/continue/skip/dependencies | Native Bash implementation and regression fixtures retained. No hard real-time guarantee. |
| Reverse compensation/checkpoint/resume | Implemented profile retained; serializers repaired beyond ten nodes. Not a general side-effect inverse or atomic persistence guarantee. |
| Octet/UTF-8/binary I/O | All-byte and invalid encoding fixtures retained. Width-through-128 schemas added without implicit padding. |
| SHA-256 and integrity manifest | Native Bash implementation added; self-excluded manifest uses typed digest octets, exact extents and complete file membership. |
| URI/URN/file-locator parsing | Native bounded profile added; no substitution of locator for resource identity. |
| RDF and SHACL | Native bounded reader, semantic pair projection comparison, constraint execution and standard validation report added. Unsupported features reject. |
| External import/class-chain evidence | Pinned user-artifact-derived projection and actual declared import closure checked. Not full upstream verification or OWL consistency. |
| Function/file accounts | Every active sealed function has a checked source view; quiescent file inventory covers parents, layers, depths, ordinals and child counts. Not universal recursive AOB closure. |
| Finite category/functor/Yoneda/coend/algebra | Executable finite checks retained, logical theorem/axiom separation retained. |
| External Java/Fuseki/curl/installation/executable hooks | Rejected by the active no-external policy, not called compatible. |
| mkdir/unlink/rename/fsync/kernel locks | No external helper fallback. Existing parents, single writer and completion/snapshot checks remain required. |
| Full grammar/graphemes/all projections/general XSD/OWL | Not supplied as universal implementations; unsupported scope remains explicit in gates.md. |

The absolute no-external execution rule conflicts with historical instructions to launch Java, curl or external filesystem utilities. This revision resolves the execution choice in favor of the user's active prohibition. It does not claim observational equivalence to those prohibited external side effects.

No remote repository mutation was performed. This is a downloadable local successor, not a claimed commit to groenewt/silmaril.
