# Grounding and external provenance

Ontology grounding, programming inheritance, taxonomy, realization, denotation and location remain different relations. A successful C3 order is not an ontology-grounding proof. A protocol specification, its implementation, an endpoint and a process occurrence are not interchangeable.

## Preserved external projection

ontology/external/imports.ttl is an extraction of 14,690 triples from the unchanged Library source preserved at evidence/external/source.ttl. Named external subjects in the BFO, CCO and CPO namespaces and their connected blank-node descriptions were selected. evidence/external/provenance.md gives source and projection digests and extraction scope. This is not presented as an upstream byte-for-byte distribution or a proof of consistency.

The graph declares these exact version identities:

- BFO: http://purl.obolibrary.org/obo/bfo/2020/bfo-core.ttl
- CCO: https://www.commoncoreontologies.org/2024-11-06/CommonCoreOntologiesMerged
- CPO: http://www.ontologyrepository.com/CommonCoreOntologies/Domain/2025-04-25/CognitiveProcessOntology

The baseline selected BFO named-chain profiles use a bfo-core.owl version identifier. The .owl and .ttl identifiers are not silently equated. The new import loader validates the supplied graph's actual declarations independently.

import::loadPinned reads, hashes and parses one snapshot, checks the exact ontology/version pair and leaves the previous accepted graph intact on replacement failure. import::closure resolves all declared imports against ontology/version identities in that graph, rejects missing/conflicting declarations and permits cyclic imports. import::chain checks actual declared class and immediate named-superclass edges, not invented ancestry.

The information-content chain through CCO InformationContentEntity and BFO generically dependent continuant differs from the process chain. The CPO CognitiveProcess chain passes through RepresentationalMentalProcess, MentalProcess and BodilyProcess. A Bash process is not automatically a member of that cognitive chain. Appropriate individual mapping decisions remain explicit research/modeling obligations.

Preserved external labels, IRIs and literals retain their original notation. They are evidence behind the import boundary, not exceptions allowing arbitrary scalar authority in canonical Silmaril YAML. License/attribution metadata present in the source is preserved. No upstream license or provenance audit is claimed beyond those notices and the recorded source identity.
