# Source inventory

silmarilbashdag.zip: 14 files, 127 function occurrences, 43806 bytes. SHA-256 `a360b59ec81eb954ebd8ee193f015815446d811c8875b9c684d653f5d406cf15`.

silmaril-type-dag-engine-final.zip: 4043 files, 148 function occurrences, 17929104 bytes. SHA-256 `c245de9947286735eba54d10a76c409cdca912301d2a91a4f397a97c4030338d`.

silmaril-type-dag-engine-final-2026-08-16.zip: 19866 files, 86 function occurrences, 19877293 bytes. SHA-256 `9cb4a0a78ce2ee4a9928af2b1069e63bb1d9df734b9487f84dca1227ab0edeca`.

