# Sources, observations and attribution

Observation date: 2026-09-04. URLs are evidence locators, not canonical Silmaril semantic identities.

## Primary external specifications

- W3C, *OWL 2 Web Ontology Language Direct Semantics*, Second Edition, Recommendation 11 December 2012. https://www.w3.org/TR/owl2-direct-semantics/ . Sections 2.2.1 and 2.2.3 ground relational properties and class restrictions; Table 9 gives the named-individual/shared-value key condition. The implementation checks a finite key antecedent, not the entire OWL semantics.
- W3C, *XML Schema Definition Language 1.1 Part 2: Datatypes*, Recommendation 5 April 2012. https://www.w3.org/TR/xmlschema11-2/ . Datatype fundamentals, lists, unions, anySimpleType/anyAtomicType lexical relations and unsignedByte. The five-coordinate local account is a modeling contract, not a replacement definition of the standard.
- W3C, *XML Schema Definition Language 1.1 Part 1: Structures*. https://www.w3.org/TR/xmlschema11-1/ . Schema composition, inclusion, import, redefinition and overriding. No general schema-module processor is implemented here.
- IETF, RFC 8141, *Uniform Resource Names (URNs)*. https://www.rfc-editor.org/rfc/rfc8141 . Standard assigned-name envelope and optional components; canonical local names use a narrower subset.
- IETF, RFC 3986, *Uniform Resource Identifier (URI): Generic Syntax*. https://www.rfc-editor.org/rfc/rfc3986 . Component boundaries remain distinct from the local categorical/operator language.
- IETF, RFC 8089, *The file URI Scheme*. https://www.rfc-editor.org/rfc/rfc8089 . A typed local physical path is not by itself an implementation of this scheme.
- IANA, *Uniform Resource Names Namespaces*. https://www.iana.org/assignments/urn-namespaces . Read on the observation date; no public `silmaril` registration asserted.
- GNU, *Bash Reference Manual*. https://www.gnu.org/software/bash/manual/ . Builtin read/printf, parameter expansion, process substitution, arrays and DEBUG/extdebug behavior. The installed interpreter is the tested execution authority; no new Bash binary is distributed.

## Mathematical primary sources and proof scope

David I. Spivak and Robert E. Kent, *Ologs: A Categorical Framework for Knowledge Representation*. https://arxiv.org/abs/1102.1889 . Presented schemas, functorial instances and commuting facts motivate the finite fixture representation. The category-of-elements, Yoneda and coend arguments in `mathematics.md` state their own maps and equations and are not claims that this engine has formalized the entire paper.

## Ontology excerpt

BFO 2020 source: https://raw.githubusercontent.com/BFO-ontology/BFO-2020/master/21838-2/owl/bfo-core.owl . Version IRI `http://purl.obolibrary.org/obo/bfo/2020/bfo-core.owl`. Attribution: BFO-ontology/BFO-2020 contributors; source declares Creative Commons Attribution 4.0, https://creativecommons.org/licenses/by/4.0/ . This package adapts only selected named-superclass edges and two profile tables. It does not redistribute or certify a complete BFO import closure. No unverified CCO/CPO imported IRI is invented.

## Project and source archives

Public repository page: https://github.com/groenewt/silmaril . Read-only page inspection, not a source-complete clone or a write. Source hashes, member totals and function totals for the three available archives are in `sourcecounts.md`. The original named `REF.md`, `REFTWO.md` and `READING_00.md` were not edited; no claim is made that every section was reviewed or converted in this consolidation.

Legacy seed inventory obtained from Library: `anchor_map_full_consolidated.ttl`, 10,044,752 bytes. The original remains unchanged as external evidence. Its broad inventory is not silently promoted into an active, completely imported or logically validated ontology.
