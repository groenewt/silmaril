# Implemented repair record

The previous delivery archive was recovered from its actual bytes. Earlier interrupted repair directories were absent. This revision was rebuilt from that preserved baseline; handoff assertions were not substituted for code.

## Identity, transactions and serialization

A primordial pair identity now encodes its key and value references reversibly with explicit length framing. It does not include subject, document path or content digest. Equal key/value products share identity; changing the value changes identity. A separate binding occurrence carries the subject, pair, observed carrier, source position and provenance. Observation counters are session-local, not a globally unique persistence service.

Canonical parsing stages a candidate graph. Syntax, UTF-8 and reference failures restore the previous graph, source bytes and dynamically admitted references. Only coordinates actually constructed by an accepted parse are published. Binding exports retain carrier, position and provenance rather than silently dropping those coordinates.

Decimal ordinal tries now render depth-first. Numeric-order iteration incorrectly reopened digit keys at ordinal ten. The generic vector renderer, function index, binding account, checkpoint, graph receipt, file inventory and manifest have explicit regressions for this case. An empty vector has a typed empty member, not a null or anonymous map. Vector admission walks only its own ordinal trie and rejects unrelated registered keys hidden beneath MEMBER; payload subgraphs are not miscounted as ordinal structure.

## Failure propagation

The top-level test runner and both case harnesses call each test normally inside a strict Bash subshell and collect its status with builtin wait. Tests are not executed as the condition of an if statement. Deliberately failing probes prove that a successful trailing command does not hide failure. Their expected diagnostics are isolated in evidence/expectedcasefailure.log and evidence/expectedparityfailure.log.

The runtime command policy saves and restores the caller's errexit setting and exact ERR action while its own Frame contract controls method status. A skipped external command still rejects the operation. This is an in-process policy, not a hostile-code sandbox or an arbitrary debugger compatibility promise.

## Native functionality added

SHA-256 uses builtin arithmetic and bounded binary reads. It hashes empty, multiblock, NUL-containing and high-byte data. Optional extent output counts original bytes before padding. The manifest contains a vector of 32 referenced octet values, never a raw digest scalar or digest-based resource identity. Native verification checks algorithm, size, hash, membership, relocation, duplicate and surplus files before tests create scratch outputs.

URI parsing separates scheme, authority, path, query and fragment. Relative resolution and URN assigned-name equivalence have executable fixtures. The local file-locator profile supports empty or localhost authority and rejects remote authorities, encoded slash/NUL and path escape. Decoding a historical path reference checks lexical validity without requiring its old directories to exist. Live readability and no-link checks occur only at the relocated destination. A manifest regression uses a deliberately absent original root. These parsers do not perform network exchange, authentication or authorization.

The native RDF reader supports the delivered Turtle profile, scoped blank nodes, lists, literals, datatype/language terms, relative IRIs and triple-set storage. Failed append restores the prior graph. Semantic RDF projection comparison distinguishes graph equality from byte equality. Invalid UTF-8, prohibited prefixed-name punctuation, control IRIs and escaped-terminal-dot cases have regressions.

The executable SHACL profile includes targets, cardinality, simple/inverse paths, type/class, selected datatypes, lists, logical combinations and closed shapes. Unsupported constraints, duplicate singleton parameters and recursion fail explicitly. Standard validation reports are emitted only after evaluation; graph changes invalidate a previous report. Node constraints aggregate child nonconformance into one parent NodeConstraintComponent result per value. Target and class superclass traversal stays inside the selected data graph; superclass triples in a shapes or unrelated graph cannot silently enlarge data-graph membership. This is not a claim to implement all SHACL Core, SPARQL, RDF entailment or OWL reasoning.

Pinned import loading hashes and parses the same snapshot, verifies ontology/version identity, resolves the actual declared imports and checks named class chains. Rejected replacement restores the accepted import graph. The delivered external projection comes from a preserved user artifact, not a verified current upstream download.

Registered byte schemas distinguish width, bit order, octet order and encoding. Bitstring carriers support widths through 128 without host-integer truncation. Non-octet-aligned widths do not acquire implicit padding. Existing machine-octet, unsigned-byte datatype and residue-ring semantics remain different.

Every active function has an exact Bash-rendered source view and a canonical lexical identity. Source-view checks include path reversal, missing/altered bodies and unknown functions. This establishes source equivalence, not universal behavior or recursive ontology closure.

The filesystem inventory includes hidden entries and empty directories, parent links, relative layers, absolute depths, sibling ordinals and child counts. It rejects links and unsupported special files and restores glob options. It is a bounded observation of a quiescent tree, not an atomic filesystem snapshot.

## Retained behavior

C3 inheritance, typed field contracts, abstract-type rejection, polymorphic dispatch and next-method behavior remain. Stable DAG ordering, bounded native workers, retry, timeout, failure disposition, dependency-success gating, reverse compensation and checkpoint/resume remain. The public semantic interface stays one request carrier to one Frame; internal Bash helper calling conventions are not claimed to be literal lambda terms.

Finite category, functor, naturality, category-of-elements, Yoneda/full-faithfulness and coend checks remain. Six axiom-family records and three theorem records retain their distinct logical roles. Written general arguments are separate from finite execution certificates.
