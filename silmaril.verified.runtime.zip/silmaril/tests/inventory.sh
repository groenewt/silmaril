#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
complete() { inventory::scan "$ROOT/tests/tree"; [[ ${#inventoryPath[@]} == 6 ]]; inventory::check; }
corruptdepth() { inventory::scan "$ROOT/tests/tree"; inventoryDepth[2]=999; if inventory::check; then return 1; fi; [[ $engineError == "${errorRegistry[PATH/DEPTH]}" ]]; }
corruptordinal() { inventory::scan "$ROOT/tests/tree"; inventoryOrdinal[2]=inventoryOrdinal[1]; if inventory::check; then return 1; fi; [[ $engineError == "${errorRegistry[PATH/ORDINAL]}" ]]; }
options() { shopt -u nullglob dotglob; inventory::scan "$ROOT/tests/tree"; if shopt -q nullglob || shopt -q dotglob; then return 1; fi; }
bounded() { inventoryMaximumEntries=2; if inventory::scan "$ROOT/tests/tree"; then return 1; fi; [[ $engineError == "${errorRegistry[PAIR/LIMIT]}" ]]; }
serialization() { inventory::scan "$ROOT/tests/tree"; inventory::emit > "$ROOT/evidence/tree.yaml"; kv::parse "$ROOT/evidence/tree.yaml"; kv::check; }
check completefilesystemring complete
check incorrectdepthrejected corruptdepth
check repeatedordinalrejected corruptordinal
check globoptionsrestored options
check boundedfilesystemscan bounded
check referenceonlypathaccount serialization
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
