#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
passed=0 failed=0
readypriority() {
  graphNodes=(a b c d); graphEdges=(ba); graphEdgeTarget=([ba]=a); graphEdgeSource=([ba]=b)
  graphAdjacency=([b$SILMARILUS'a']=1); graphIdentity=fixture
  graph::topological
  [[ ${graphOrder[*]} == 'b a c d' ]]
}
cyclepriority() {
  graphNodes=(a b c); graphEdges=(ab ba); graphEdgeTarget=([ab]=b [ba]=a); graphEdgeSource=([ab]=a [ba]=b)
  graphAdjacency=([a$SILMARILUS'b']=1 [b$SILMARILUS'a']=1); graphIdentity=fixture
  ! graph::topological && [[ ${graphOrder[*]} == c ]]
}
check earliestdeclarednewlyreadynode readypriority
check cyclicresidualnotaccepted cyclepriority
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
