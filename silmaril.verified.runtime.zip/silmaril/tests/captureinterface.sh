#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
path::absolute "$ROOT" ROOT
source "$ROOT/tests/assert.sh"
passed=0 failed=0
inputfile=$ROOT/evidence/captureinterfaceinput.yaml
requestfile=$ROOT/evidence/captureinterfacerequest.yaml
obs=$SILMARILTYPEGRAPH:component:interface:instance:observation
prepare() {
  local operation=$1 output=$2 inref outref
  printf 'IDENTITY: %s\nTYPE: %s\n' "$SILMARILTYPEGRAPH:component:interface:instance:document" "$SILMARILTYPEGRAPH" > "$inputfile"
  hash::file "$inputfile" meCurrentDigest
  path::identify "$inputfile" inref; path::identify "$output" outref
  {
    printf 'IDENTITY: %s\nTYPE: %s\nOPERATION: %s\nINPUT: %s\nRECEIPT: %s\nOBSERVATION:\n  IDENTITY: %s\nDIGEST:\n' "$REQUESTTYPE:component:interface:instance:$operation" "$REQUESTTYPE" "$REQUESTOPERATION:$operation" "$inref" "$outref" "$obs"
    publication::vector 32 2 manifest::digestItem
  } > "$requestfile"
}
creation() {
  local receipt=$ROOT/evidence/captureinterfacecreation$BASHPID.yaml
  prepare capture "$receipt"
  engine::apply "$requestfile" && [[ -s $receipt && ${frameStatus[$engineResult]} == "$SILMARILSTATUSSUCCESS" && $kvCaptureVerified == 1 && ${frameEffect[$engineResult]} == "$SILMARILEFFECTAUDIT" ]]
}
replay() {
  local receipt=$ROOT/evidence/captureinterfacereplay$BASHPID.yaml
  prepare capture "$receipt"; engine::apply "$requestfile" || return
  prepare capture:verify "$receipt"; engine::apply "$requestfile" && [[ $kvCaptureVerified == 1 && ${frameEffect[$engineResult]} == "$SILMARILEFFECTNONE" ]]
}
idempotent() {
  local receipt=$ROOT/evidence/captureinterfaceidempotent$BASHPID.yaml before after
  prepare capture "$receipt"; engine::apply "$requestfile" || return
  hash::file "$receipt" before
  engine::apply "$requestfile" || return
  hash::file "$receipt" after
  [[ $before == "$after" && ${frameEffect[$engineResult]} == "$SILMARILEFFECTNONE" ]]
}
altered() {
  local receipt=$ROOT/evidence/captureinterfacealtered$BASHPID.yaml before after
  prepare capture "$receipt"; engine::apply "$requestfile" || return
  printf '# tamper\n' >> "$receipt"; hash::file "$receipt" before
  prepare capture:verify "$receipt"
  if engine::apply "$requestfile"; then return 1; fi
  hash::file "$receipt" after
  [[ $before == "$after" && ${frameStatus[$engineResult]} == "$SILMARILSTATUSFAILURE" && $kvCaptureVerified == 0 ]]
}
overlap() {
  local before after
  prepare capture "$inputfile"; hash::file "$inputfile" before
  if engine::apply "$requestfile"; then return 1; fi
  hash::file "$inputfile" after
  [[ $before == "$after" && ${frameStatus[$engineResult]} == "$SILMARILSTATUSFAILURE" ]]
}
irrelevant() {
  local receipt=$ROOT/evidence/captureinterfaceirrelevant$BASHPID.yaml
  prepare pairs "$receipt"
  ! engine::apply "$requestfile" && [[ ${frameStatus[$engineResult]} == "$SILMARILSTATUSFAILURE" ]]
}
missing() {
  local receipt=$ROOT/evidence/captureinterfacemissing$BASHPID.yaml
  prepare capture:verify "$receipt"
  ! engine::apply "$requestfile" && [[ ! -e $receipt && ${frameStatus[$engineResult]} == "$SILMARILSTATUSFAILURE" ]]
}
frameoverlap() {
  local receipt=$ROOT/evidence/captureinterfaceframe$BASHPID.yaml ref
  prepare capture "$receipt"; path::identify "$receipt" ref; printf 'OUTPUT: %s\n' "$ref" >> "$requestfile"
  ! engine::apply "$requestfile" && [[ ! -e $receipt && ${frameStatus[$engineResult]} == "$SILMARILSTATUSFAILURE" ]]
}
check unarycapturewritesaccount creation
check unarycapturereplaysaccount replay
check repeatedcapturedoesnotrewrite idempotent
check alteredaccountnotrewritten altered
check captureinputoverlaprejected overlap
check capturefieldsnotignored irrelevant
check verifymissingreceiptrejected missing
check captureframeoverlaprejected frameoverlap
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
