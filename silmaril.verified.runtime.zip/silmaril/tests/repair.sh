#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
path::absolute "$ROOT" ROOT
engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" || exit 1
passed=0 failed=0
source "$ROOT/tests/assert.sh"
DOC=$SILMARILTYPEGRAPH:component:repair:instance:one
TEMP=$ROOT/evidence/repair.yaml
fixture() { printf 'IDENTITY: %s\nVALUE: %s\n' "$DOC" "$1" > "$TEMP"; }
changedvalue() {
  fixture "$SILMARILTRUE"; kv::parse "$TEMP"; local before=${kvPair[ROOT/VALUE]}
  fixture "$SILMARILFALSE"; kv::parse "$TEMP"
  [[ $before != "${kvPair[ROOT/VALUE]}" ]]
}
sameproduct() {
  fixture "$SILMARILTRUE"; kv::parse "$TEMP"; local before=${kvPair[ROOT/VALUE]}
  printf 'IDENTITY: %s\nVALUE: %s\n' "$DOC:component:second" "$SILMARILTRUE" > "$TEMP"
  kv::parse "$TEMP"; [[ $before == "${kvPair[ROOT/VALUE]}" ]]
}
rollback() {
  fixture "$SILMARILTRUE"; kv::parse "$TEMP"; local before=${kvPair[ROOT/VALUE]} raw=$kvRaw
  printf 'IDENTITY: %s\nVALUE: %s\nVALUE: %s\n' "$DOC" "$SILMARILTRUE" "$SILMARILFALSE" > "$TEMP"
  if kv::parse "$TEMP"; then return 1; fi
  [[ $kvRaw == "$raw" && ${kvPair[ROOT/VALUE]-} == "$before" ]]
}
observation() {
  fixture "$SILMARILTRUE"; kv::parse "$TEMP"; local before=${kvBinding[ROOT/VALUE]}
  fixture "$SILMARILFALSE"; kv::parse "$TEMP"
  [[ $before != "${kvBinding[ROOT/VALUE]}" ]]
}
check productchangeswithvalue changedvalue
check productsindependentofsubject sameproduct
check failedparsepreservescommittedgraph rollback
check editedcarrierhasnewobservation observation
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
