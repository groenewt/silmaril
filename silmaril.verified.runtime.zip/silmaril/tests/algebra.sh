#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
passed=0 failed=0
source "$ROOT/tests/assert.sh"
groupvalid() { finite::load "$ROOT/examples/category.yaml" && algebra::group && algebra::commutative; }
topologyvalid() { topologyCarrier=2; topologyOpen=(0 1 3); topology::check; }
topologyinvalid() { topologyCarrier=3; topologyOpen=(0 1 2 7); ! topology::check; }
metricvalid() { metricSize=3; metricValue=([0,0]=0 [0,1]=1 [0,2]=2 [1,0]=1 [1,1]=0 [1,2]=1 [2,0]=2 [2,1]=1 [2,2]=0); geometry::metric; }
metricinvalid() { metricvalid || return; metricValue[0,2]=3; metricValue[2,0]=3; ! geometry::metric; }
check finitegroup groupvalid
check finitetopology topologyvalid
check unionclosureviolation topologyinvalid
check finitemetric metricvalid
check triangleviolation metricinvalid
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
