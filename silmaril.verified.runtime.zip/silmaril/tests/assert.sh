#!/bin/bash
# Failure-sensitive case harness. A case is never invoked as an if predicate.
check() {
  local assertionLabel=$1 assertionWorker assertionStatus; shift
  (
    set -Eeuo pipefail
    trap 'assertionStatus=$?; printf "CASE ERROR status=%s source=%q line=%s\n" "$assertionStatus" "${BASH_SOURCE[0]}" "$LINENO" >&2; exit "$assertionStatus"' ERR
    "$@"
  ) &
  assertionWorker=$!
  if wait "$assertionWorker"; then
    printf 'PASS %s\n' "$assertionLabel"; ((passed+=1))
  else
    assertionStatus=$?
    printf 'FAIL %s status=%s\n' "$assertionLabel" "$assertionStatus" >&2; ((failed+=1))
  fi
  return 0
}
