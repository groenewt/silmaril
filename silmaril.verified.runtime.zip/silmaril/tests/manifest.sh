#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
package=$ROOT/tests/package
manifest=$package/manifest.yaml
build() {
 printf 'a\000b' > "$package/content"
 manifest::emit "$package" "$manifest" > "$manifest"
 if (($#)); then local raw=; IFS= read -r -d '' raw < "$manifest" || :; raw=${raw//"$MANIFESTALGORITHM"/"$1"}; printf '%s' "$raw" > "$manifest"; fi
}

valid() { build; manifest::verify "$package" "$manifest"; [[ $manifestVerified == 1 && $manifestCheckedBytes == 3 ]]; }
changed() { build; printf 'b\000a' > "$package/content"; if manifest::verify "$package" "$manifest"; then return 1; fi; [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]; }
size() { build; printf 'longer' > "$package/content"; if manifest::verify "$package" "$manifest"; then return 1; fi; [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]; }
unknown() { build "$SILMARILTYPEGRAPH"; if manifest::verify "$package" "$manifest"; then return 1; fi; }
relocated() {
  build
  local original replacement=$PATHNOTATIONBASE raw= word n c i source=/silmarilarchiveabsent/source/tree
  path::identify "$package" original
  [[ ! -e /silmarilarchiveabsent ]]
  for ((i=0;i<${#source};i+=1)); do
    c=${source:i:1}; printf -v n '%03d' "'$c"
    replacement+=:octet:${lexicalDigits[${n:0:1}]}:${lexicalDigits[${n:1:1}]}:${lexicalDigits[${n:2:1}]}
  done
  IFS= read -r -d '' raw < "$manifest" || :
  raw=${raw//"$original"/"$replacement"}; printf '%s' "$raw" > "$manifest"
  manifest::verify "$package" "$manifest"
  [[ $manifestVerified == 1 ]]
}
check relocateswithoutoriginalfilesystem relocated
check nativemanifestandsize valid
check alteredcontentrejected changed
check alteredextentrejected size
check incorrectdigestalgorithmrejected unknown
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
