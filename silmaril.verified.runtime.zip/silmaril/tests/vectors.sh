#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
fixture=$ROOT/evidence/vectorinput.yaml
result=$ROOT/evidence/vectoroutput.yaml
registry() { kv::parse "$ROOT/registry/functions.yaml"; }
bindings() {
  printf 'IDENTITY: %s\n' "$SILMARILTYPEGRAPH:component:fixture:instance:vector" > "$fixture"
  local k
  for k in VALUE TYPE SOURCE TARGET OUTPUT INPUT EFFECT ERROR STATUS STATE IDENTITY PAIR KEY; do
    [[ $k == IDENTITY ]] && continue
    printf '%s: %s\n' "$k" "$SILMARILTRUE" >> "$fixture"
  done
  kv::parse "$fixture"
  local count=${#kvPaths[@]}
  ((count>10))
  kv::emitBindings > "$result"
  yaml::parse "$result"
  local p n
  yaml::requiredSequence ROOT BINDING p n
  ((n==count))
}
setupnodes() {
  graphIdentity=$SILMARILTYPEGRAPH:component:fixture:instance:vector
  kvKnown[$graphIdentity]=1; graphNodes=(); nodeFrame=(); nodeOutput=()
  local i w id
  for ((i=0;i<15;i+=1)); do
    name::number "$i" w
    id=$graphIdentity:component:node:instance:$w
    graphNodes+=("$id"); kvKnown[$id]=1
    schedulerState[$id]=pending; schedulerAttempts[$id]=0
  done
}
checkpoint() { setupnodes; checkpoint::emit "$SILMARILTRUE" > "$result"; yaml::parse "$result"; local p n; yaml::requiredSequence ROOT NODES p n; ((n==15)); }
receipts() { setupnodes; graph::emitReceipts > "$result"; yaml::parse "$result"; local p n; yaml::requiredSequence ROOT NODES p n; ((n==15)); }
orphanmember() {
  local count
  number::reference 1 count
  printf 'IDENTITY: %s\nVALUE:\n  VECTOR: %s\n  COUNT: %s\n  MEMBER:\n    ZERO:\n      ITEM: %s\n    VALUE: %s\n' \
    "$SILMARILTYPEGRAPH:component:fixture:instance:vector" "$KVTYPEVECTOR" "$count" "$SILMARILTRUE" "$SILMARILTRUE" > "$fixture"
  if yaml::parse "$fixture"; then return 1; fi
}
check sourceindexordinaltrie registry
check largebindingvector bindings
check largecheckpointvector checkpoint
check largereceiptvector receipts
check unindexedmemberrejected orphanmember
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
