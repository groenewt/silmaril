#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
source "$ROOT/tests/parity.sh"
passed=0 failed=0
strict() { test::firewall; [[ $- == *e* ]]; }
restored() {
 local before after
 trap 'printf "quote '\'' preserved\\n" >&2' ERR
 before=$(trap -p ERR)
 test::sensitiveGate
 after=$(trap -p ERR)
 [[ $before == "$after" && $- == *e* ]]
}
sealed() { [[ $(declare -p -F rdf::load) == *'-fr '* ]] || [[ $(declare -p -F rdf::load) == *'-frt '* ]]; }
check stricterrexternaldispatchrejected strict
check errortrapandoptionsrestored restored
check parserfunctionssealed sealed
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
