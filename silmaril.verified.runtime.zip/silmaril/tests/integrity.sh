#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
empty() { local v; hash::text '' v; [[ $v == e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 ]]; }
abc() { local v; hash::text abc v; [[ $v == ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad ]]; }
longvector() { local v; hash::text abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq v; [[ $v == 248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1 ]]; }
binary() { local v; hash::file "$ROOT/examples/bytestream.bin" v; [[ $v == 9357c7b3dd71adecdc73f2611b8268272c1df1e7afae842212c9828582ddc777 ]]; }
limited() { local v=unchanged; hashMaximumBytes=2; if hash::text abc v; then return 1; fi; [[ $v == unchanged && $engineError == "${errorRegistry[PAIR/LIMIT]}" ]]; }
check emptysha256 empty
check abcsha256 abc
check multiblocksha256 longvector
check nulandhighbytessha256 binary
check boundedhash limited
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
