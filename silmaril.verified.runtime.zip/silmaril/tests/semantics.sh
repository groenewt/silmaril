#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
passed=0 failed=0
source "$ROOT/tests/assert.sh"
shared() { keyNamed=([a]=1 [b]=1 [u]=1 [v]=1); keyClass=([a]=1 [b]=1); keyObjectProperties=(p); keyDataProperties=(); keyValues=([a,p]='u v' [b,p]='u'); semantics::keyMatch a b; }
unnamed() { shared || return; keyNamed[u]=0; ! semantics::keyMatch a b; }
missing() { shared || return; keyValues[b,p]=; ! semantics::keyMatch a b; }
unsigned() { schema::unsignedByte ' +0255 ' && [[ $schemaValue == 255 && $schemaCanonical == 255 ]]; }
overflow() { ! schema::unsignedByte 256 && ! schema::unsignedByte 99999999999999999999999; }
zeronegative() { schema::unsignedByte '-000' && [[ $schemaValue == 0 ]]; }
check relationalsharedkey shared
check namedobjectfillercondition unnamed
check absentkeynotunique missing
check unsignedbytelexicalmapping unsigned
check unsignedbytenotmodular overflow
check unsignedbytenegativezero zeronegative
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
