#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
fixture=$ROOT/evidence/parser.ttl
basic() {
  printf '%s\n' '@prefix e: <http://example.org/> .' 'e:s e:p e:o, e:o ; e:q "hello"@EN .' > "$fixture"
  rdf::load "$fixture" data
  [[ ${#rdfSubject[@]} == 2 ]]
}
collections() {
  printf '%s\n' '@prefix e: <http://example.org/> .' 'e:s e:p (e:a e:b) ; e:q [ e:r true ] .' > "$fixture"
  rdf::load "$fixture" data
  [[ ${#rdfSubject[@]} == 7 ]]
}
base() {
  printf '%s\n' '@base <http://example.org/a/> .' '<../s> <p> <#o> .' > "$fixture"
  rdf::load "$fixture" data
  [[ ${rdfTerm[${rdfSubject[0]}]} == 'http://example.org/s' && ${rdfTerm[${rdfObject[0]}]} == 'http://example.org/a/#o' ]]
}
literals() {
  printf '%s\n' '@prefix e: <http://example.org/> .' 'e:s e:p "\u0041", "A", "\u0000", "\\u0000", 12, 1.2, 1E2 .' > "$fixture"
  rdf::load "$fixture" data
  [[ ${#rdfSubject[@]} == 6 ]]
}
longliteral() {
  printf '%s\n' '@prefix e: <http://example.org/> .' 'e:s e:p """line one' 'line two""" .' > "$fixture"
  rdf::load "$fixture" data
  [[ ${rdfLexical[${rdfObject[0]}]} == 'line one\nline two' ]]
}
invalid() {
  printf '%s\n' '@prefix e: <http://example.org/> .' 'e:s e:p [ e:q e:o .' > "$fixture"
  if rdf::load "$fixture" data; then return 1; fi
  [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]
}
closure() { rdf::load "$ROOT/ontology/closure.ttl" data; ((${#rdfSubject[@]}>=368)); }
check rdfdedupandlanguage basic
check rdfcollectionandblanknodes collections
check relativeiribase base
check lexicalliteralidentity literals
check longquotedliteral longliteral
check malformedturtlerejected invalid
check deliveredontologyparsedbybash closure
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
