#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
passed=0 failed=0
source "$ROOT/tests/assert.sh"
record() { grounding::check "$GROUNDINGRECORD" && [[ ${groundingImported[$GROUNDINGRECORD]} == http://purl.obolibrary.org/obo/BFO_0000031 ]]; }
process() { grounding::check "$GROUNDINGPROCESS"; }
unknown() { ! grounding::check "$SILMARILROOT:ontology:process:cognitive" && [[ $engineError == "${errorRegistry[GROUNDING/MISSING]}" ]]; }
contradictory() { groundingParent[http://purl.obolibrary.org/obo/BFO_0000031]=http://purl.obolibrary.org/obo/BFO_0000015; ! grounding::check "$GROUNDINGRECORD" && [[ $engineError == "${errorRegistry[GROUNDING/CONTRADICTORY]}" ]]; }
check exactrecordclasschain record
check exactprocessclasschain process
check unpinnedanchorblocked unknown
check contradictoryclasschain contradictory
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
