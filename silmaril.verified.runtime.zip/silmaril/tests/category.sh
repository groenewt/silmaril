#!/bin/bash
set -u
set -o pipefail
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
passed=0 failed=0
source "$ROOT/tests/assert.sh"
fixture() { finite::load "$ROOT/examples/category.yaml"; }
categorygood() { fixture && category::check && [[ ${#categoryArrows[@]} == 2 ]]; }
categoryidentity() { fixture || return; categoryIdentity[${categoryObjects[0]}]=${categoryArrows[1]}; ! category::check && [[ $engineError == "${errorRegistry[CATEGORY/IDENTITY]}" ]]; }
categorymissing() { fixture || return; unset 'categoryComposite[${categoryArrows[1]}$SILMARILUS${categoryArrows[1]}]'; ! category::check && [[ $engineError == "${errorRegistry[CATEGORY/COMPOSITION]}" ]]; }
modelgood() { fixture && model::check "${modelNames[0]}"; }
modelbad() { fixture || return; local m=${modelNames[0]} a=${categoryArrows[1]} o=${categoryObjects[0]} x y; read -r x y <<< "${modelElements[$m$SILMARILUS$o]}"; modelAction[$m$SILMARILUS$a$SILMARILUS$x]=$x; ! model::check "$m" && [[ $engineError == "${errorRegistry[FUNCTOR/COMPOSITION]}" ]]; }
naturalgood() { fixture && natural::check "${naturalNames[0]}"; }
naturalbad() { fixture || return; local n=${naturalNames[0]} m=${modelNames[0]} o=${categoryObjects[0]} x y; read -r x y <<< "${modelElements[$m$SILMARILUS$o]}"; naturalComponent[$n$SILMARILUS$o$SILMARILUS$x]=$x; ! natural::check "$n" && [[ $engineError == "${errorRegistry[NATURALITY/SQUARE]}" ]]; }
elementsgood() { fixture && elements::build "${modelNames[0]}" && elements::check && [[ ${#elementObjects[@]} == 2 && ${#elementArrows[@]} == 4 ]]; }
coendgood() { fixture && coend::check "${modelNames[0]}" "${categoryObjects[0]}" && [[ $coendClassCount == 2 && ${#coendStates[@]} == 4 ]]; }
equationbad() { fixture || return; equationRight[${equationNames[0]}]="${categoryArrows[1]} "; ! category::check && [[ $engineError == "${errorRegistry[CATEGORY/EQUATION]}" ]]; }
yonedagood() { fixture && yoneda::check "${modelNames[0]}" "${categoryObjects[0]}" && [[ $yonedaCount == 2 && $yonedaCandidateCount == 4 ]]; }
fullyfaithful() { fixture && yoneda::fullyFaithful && [[ $yonedaPairCount == 1 ]]; }
normalform() { fixture || return; local p; presentation::normalize "${categoryObjects[0]}" "${categoryArrows[1]} ${categoryArrows[1]} " p && [[ $p == "${categoryArrows[0]}" ]]; }
nonassociative() {
  fixture || return; local e=${categoryArrows[0]} a=${categoryArrows[1]} b=${categoryArrows[1]}:component:extra o=${categoryObjects[0]} f g
  categoryArrows+=("$b"); categorySource[$b]=$o; categoryTarget[$b]=$o
  categoryComposite[$b$SILMARILUS$e]=$b; categoryComposite[$e$SILMARILUS$b]=$b
  categoryComposite[$a$SILMARILUS$a]=$b; categoryComposite[$a$SILMARILUS$b]=$e
  categoryComposite[$b$SILMARILUS$a]=$a; categoryComposite[$b$SILMARILUS$b]=$b
  ! category::check && [[ $engineError == "${errorRegistry[CATEGORY/ASSOCIATIVITY]}" ]]
}
check covariantyonedabijection yonedagood
check yonedafullfaithfulness fullyfaithful
check presentedcategorynormalform normalform
check nonassociativetablerejected nonassociative
check categoryidentitiesandassociativity categorygood
check wrongidentityrejected categoryidentity
check missingcompositerejected categorymissing
check functoridentitycomposition modelgood
check wrongfunctoractionrejected modelbad
check naturalitysquares naturalgood
check nonnaturalfamilyrejected naturalbad
check categoryofelements elementsgood
check coendquotientbijection coendgood
check sketchequationrejected equationbad
walking() { finite::certify "$ROOT/examples/walking.yaml" && [[ ${#categoryObjects[@]} == 2 && $yonedaPairCount == 4 ]]; }
walkingcoend() { finite::load "$ROOT/examples/walking.yaml" && coend::check "${modelNames[0]}" "${categoryObjects[1]}" && [[ $coendClassCount == 2 && ${#coendStates[@]} == 3 ]]; }
check nonendomorphiccategory walking
check multicarriercoend walkingcoend
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
