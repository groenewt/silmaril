#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
base='@prefix e: <http://example.org/> . @prefix sh: <http://www.w3.org/ns/shacl#> . @prefix xsd: <http://www.w3.org/2001/XMLSchema#> .'
prepare() {
 printf '%s\n' "$base" "$1" > "$ROOT/evidence/data.ttl"
 printf '%s\n' "$base" "$2" > "$ROOT/evidence/shapes.ttl"
 rdf::load "$ROOT/evidence/data.ttl" data
 rdf::append "$ROOT/evidence/shapes.ttl" shapes
}
conforming() { prepare 'e:s e:p e:o .' 'e:S a sh:NodeShape; sh:targetNode e:s; sh:property [sh:path e:p; sh:minCount 1; sh:maxCount 1; sh:nodeKind sh:IRI] .'; shape::validate; [[ $shapeFocusCount == 1 && ${#shapeResultFocus[@]} == 0 ]]; }
missing() { prepare 'e:s e:q e:o .' 'e:S sh:targetNode e:s; sh:property [sh:path e:p; sh:minCount 1] .'; if shape::validate; then return 1; fi; [[ $shapeFailure == 0 && ${#shapeResultFocus[@]} == 1 ]]; }
closed() { prepare 'e:s e:q e:o .' 'e:S sh:targetNode e:s; sh:closed true; sh:property [sh:path e:p] .'; if shape::validate; then return 1; fi; [[ ${#shapeResultFocus[@]} == 1 ]]; }
classclosure() { prepare 'e:s a e:Child . e:Child <http://www.w3.org/2000/01/rdf-schema#subClassOf> e:Parent .' 'e:S sh:targetClass e:Parent; sh:class e:Parent .'; shape::validate; [[ $shapeFocusCount == 1 ]]; }
logic() { prepare 'e:s e:p e:o .' 'e:S sh:targetNode e:s; sh:or ([sh:nodeKind sh:Literal] [sh:nodeKind sh:IRI]); sh:not [sh:nodeKind sh:BlankNode] .'; shape::validate; }
unknown() { prepare 'e:s e:p e:o .' 'e:S sh:targetNode e:s; sh:sparql [sh:select "SELECT ?this WHERE {}"] .'; if shape::validate; then return 1; fi; [[ $shapeFailure == 1 ]]; }
recursive() { prepare 'e:s e:p e:o .' 'e:S sh:targetNode e:s; sh:node e:S .'; if shape::validate; then return 1; fi; [[ $shapeFailure == 1 ]]; }
datatype() { prepare 'e:s e:p "abc"^^xsd:integer .' 'e:S sh:targetNode e:s; sh:property [sh:path e:p; sh:datatype xsd:integer] .'; if shape::validate; then return 1; fi; [[ $shapeFailure == 0 && ${#shapeResultFocus[@]} == 1 ]]; }
inverse() { prepare 'e:s e:p e:o .' 'e:S sh:targetNode e:o; sh:property [sh:path [sh:inversePath e:p]; sh:hasValue e:s; sh:minCount 1] .'; shape::validate; }
closure() { rdf::load "$ROOT/ontology/closure.ttl" data; rdf::append "$ROOT/ontology/closure.ttl" shapes; shape::validate; ((shapeFocusCount>0)); }
nodereport() {
  prepare 'e:s e:p "abc" .' 'e:S sh:targetNode e:s; sh:property e:P . e:P sh:path e:p; sh:node [sh:datatype xsd:integer; sh:nodeKind sh:IRI] .'
  local status=0
  shape::validate || status=$?
  [[ $status == 1 && $shapeFailure == 0 && ${#shapeResultFocus[@]} == 1 ]]
  [[ ${shapeResultConstraint[0]} == node ]]
  [[ ${rdfTerm[${shapeResultFocus[0]}]} == http://example.org/s ]]
  [[ ${rdfTerm[${shapeResultShape[0]}]} == http://example.org/P ]]
  [[ ${rdfTerm[${shapeResultPath[0]}]} == http://example.org/p ]]
  [[ ${rdfTerm[${shapeResultValue[0]}]} == abc ]]
}
foreignsuperclasstarget() {
  prepare 'e:s a e:Child .' 'e:Child <http://www.w3.org/2000/01/rdf-schema#subClassOf> e:Parent . e:S sh:targetClass e:Parent; sh:class e:Parent .'
  shape::validate
  [[ $shapeFocusCount == 0 && ${#shapeResultFocus[@]} == 0 ]]
}
foreignsuperclassconstraint() {
  prepare 'e:s a e:Child .' 'e:Child <http://www.w3.org/2000/01/rdf-schema#subClassOf> e:Parent . e:S sh:targetNode e:s; sh:class e:Parent .'
  local status=0
  shape::validate || status=$?
  [[ $status == 1 && $shapeFailure == 0 && ${#shapeResultFocus[@]} == 1 ]]
  [[ ${shapeResultConstraint[0]} == class ]]
}
check conformingnode conforming
check missingrequiredproperty missing
check closedshape closed
check subclassbasedtarget classclosure
check logicalconstraints logic
check unsupportedconstraintfails unknown
check recursiveshapefails recursive
check illtypeddatatyperejected datatype
check inversepropertypath inverse
check deliveredshapesnonvacuous closure
check nodeconstraintreportaggregation nodereport
check targetclassgraphisolation foreignsuperclasstarget
check classconstraintgraphisolation foreignsuperclassconstraint
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
