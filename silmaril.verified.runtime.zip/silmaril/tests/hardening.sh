#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
fixture=$ROOT/evidence/hardening.ttl
pairdecode() { local id; pair::identity "$SILMARILTYPEPAIR" "$SILMARILTRUE" id; pair::decompose "$id"; [[ $pairKeyResult == "$SILMARILTYPEPAIR" && $pairValueResult == "$SILMARILTRUE" ]]; if pair::decompose "$id:trailing"; then return 1; fi; }
transaction() { rdf::content '<http://e/s> <http://e/p> <http://e/o> .' data 'http://e/'; local old=${rdfTerm[${rdfObject[0]}]}; printf '%s\n' '<http://e/a> <http://e/p> <http://e/b> .' '<http://e/broken>' > "$fixture"; if rdf::append "$fixture" data; then return 1; fi; [[ ${#rdfSubject[@]} == 1 && ${rdfTerm[${rdfObject[0]}]} == "$old" ]]; }
keyword() { printf '%s\n' '<http://e/s> <http://e/p> a .' > "$fixture"; if rdf::load "$fixture"; then return 1; fi; }
localname() { printf '%s\n' '@prefix e: <http://e/> .' 'e:s e:p e:bad{ .' > "$fixture"; if rdf::load "$fixture"; then return 1; fi; }
percent() { printf '%s\n' '@prefix e: <http://e/> .' 'e:s e:p e:bad%2 .' > "$fixture"; if rdf::load "$fixture"; then return 1; fi; }
utf() { printf '<http://e/s> <http://e/p> "\300\257" .\n' > "$fixture"; if rdf::load "$fixture"; then return 1; fi; }
unusedconstraint() { rdf::content '@prefix sh: <http://www.w3.org/ns/shacl#> . <http://e/S> a sh:NodeShape; sh:qualifiedValueShape [] .' shapes 'http://e/'; if shape::validate; then return 1; fi; [[ $shapeFailure == 1 ]]; }
duplicateparameter() { rdf::content '@prefix sh: <http://www.w3.org/ns/shacl#> . <http://e/S> sh:targetNode <http://e/s>; sh:property [sh:path <http://e/p>; sh:minCount 0, 1] .' shapes 'http://e/'; if shape::validate; then return 1; fi; [[ $shapeFailure == 1 ]]; }
check productconstructorinverse pairdecode
check rdfappendtransaction transaction
check keywordonlyinpredicate keyword
check illegalprefixedname localname
check malformedpercent percent
check malformedutfencoding utf
check unsupportedunfocusedshape unusedconstraint
check duplicateconstraintparameter duplicateparameter
prefixedplus() { printf '%s\n' '@prefix e: <http://example.org/> . e:a e:p e:bad+ .' > "$fixture"; if rdf::load "$fixture" data; then return 1; fi; }
escapeddot() { printf '%s\n' '@prefix e: <http://example.org/> . e:a e:p e:good\. .' > "$fixture"; rdf::load "$fixture" data; [[ ${rdfTerm[${rdfObject[0]}]} == http://example.org/good. ]]; }
controliri() { printf '%s\n' '<http://example.org/a> <http://example.org/p> <http://example.org/\u0001> .' > "$fixture"; if rdf::load "$fixture" data; then return 1; fi; }
check unescapedplusrejected prefixedplus
check escapedterminaldotretained escapeddot
check controliriinvalid controliri
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
