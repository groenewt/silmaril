#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
path::absolute "$ROOT" ROOT
source "$ROOT/tests/assert.sh"
passed=0 failed=0
available() { declare -F homology::compute >/dev/null && declare -F analysis::graph >/dev/null; }
check homologypublicimplementation available
if ((failed)); then printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"; exit 1; fi
unfilled() { homologyDimension=(3 3); homologyBoundary=([1,0,0]=-1 [1,1,0]=1 [1,1,1]=-1 [1,2,1]=1 [1,0,2]=-1 [1,2,2]=1); homologyPrime=2; homology::compute && [[ ${homologyBetti[*]} == '1 1' && $homologyEuler == 0 ]]; }
filled() { unfilled || return; homologyDimension+=(1); homologyBoundary[2,0,0]=1; homologyBoundary[2,1,0]=1; homologyBoundary[2,2,0]=-1; homologyPrime=3; homology::compute && [[ ${homologyBetti[*]} == '1 0 0' && $homologyEuler == 1 ]]; }
sphere() { homologyDimension=(1 0 1); homologyBoundary=(); homologyPrime=5; homology::compute && [[ ${homologyBetti[*]} == '1 0 1' && $homologyEuler == 2 ]]; }
invalidboundary() { filled || return; homologyBoundary[2,0,0]=0; ! homology::compute && [[ $homologyVerified == 0 && ${#homologyBetti[@]} == 0 ]]; }
composite() { unfilled || return; homologyPrime=4; ! homology::compute && [[ $homologyVerified == 0 ]]; }
characteristic() { homologyDimension=(1 1); homologyBoundary=([1,0,0]=2); homologyPrime=2; homology::compute && [[ ${homologyBetti[*]} == '1 1' ]] || return; homologyPrime=3; homology::compute && [[ ${homologyBetti[*]} == '0 0' ]]; }
injection() { homologyDimension=(1 1); homologyBoundary=([1,0,0]='1+1'); homologyPrime=2; ! homology::compute && [[ $homologyVerified == 0 ]]; }
surplus() { unfilled || return; homologyBoundary[2,0,0]=1; ! homology::compute; }
diamond() { graphNodes=(a b c d); graphAdjacency=([a$SILMARILUS'b']=1 [a$SILMARILUS'c']=1 [b$SILMARILUS'd']=1 [c$SILMARILUS'd']=1); analysis::graph && [[ $analysisAcyclic == 1 && $analysisComponents == 1 && $analysisCycles == 1 && $analysisEuler == 0 && $analysisCriticalEdges == 2 ]]; }
cycle() { graphNodes=(a b c); graphAdjacency=([a$SILMARILUS'b']=1 [b$SILMARILUS'c']=1 [c$SILMARILUS'a']=1); analysis::graph && [[ $analysisAcyclic == 0 && $analysisCycles == 1 && $analysisCriticalEdges == -1 ]]; }
isolated() { graphNodes=(a b c); graphAdjacency=(); analysis::graph && [[ $analysisAcyclic == 1 && $analysisComponents == 3 && $analysisCycles == 0 && $analysisEuler == 3 ]]; }
foreign() { graphNodes=(a b); graphAdjacency=([a$SILMARILUS'absent']=1); ! analysis::graph && [[ $analysisVerified == 0 ]]; }
check unfilledtrianglehasfirsthomology unfilled
check filledtriangleboundarycomposition filled
check higherdegreehomology sphere
check nonchaincomplexrejected invalidboundary
check nonfieldrejected composite
check coefficientfieldmatters characteristic
check arithmeticexpressionrejected injection
check outofdomaincoefficientrejected surplus
check directeddiamondhasfirsthomology diamond
check directedcycleisindependenttest cycle
check independentcomponents isolated
check foreignedgerejected foreign
strictzero() { homologyDimension=(1 0 1); homologyBoundary=(); homologyPrime=5; homology::compute; [[ $homologyVerified == 1 ]]; }
wire() { engine::reset; engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml"; graph::load "$ROOT/examples/polymorphic.yaml"; graph::validate; analysis::graph; analysis::emit > "$ROOT/evidence/analysis.yaml"; kv::parse "$ROOT/evidence/analysis.yaml"; }
check strictzeroarithmetic strictzero
check referenceonlyanalysis wire
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
