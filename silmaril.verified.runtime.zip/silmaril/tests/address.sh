#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
pieces() { uri::parse 'https://user@example.org:443/a%20b?x=1#f'; [[ ${uri[SCHEME]} == https && ${uri[USER]} == user && ${uri[HOST]} == example.org && ${uri[PORT]} == 443 && ${uri[PATH]} == /a%20b && ${uri[QUERY]} == x=1 && ${uri[FRAGMENT]} == f ]]; }
roundtrip() { local rendered; uri::parse 'HTTPS://Example.org/a?#'; uri::render rendered; [[ $rendered == 'HTTPS://Example.org/a?#' ]]; }
percentbad() { if uri::parse 'http://example/a%2'; then return 1; fi; [[ $engineError == "${errorRegistry[PROTOCOL/LOCATOR]}" ]]; }
ipv6good() { uri::parse 'https://[2001:db8::1]:443/'; [[ ${uri[HOST]} == '[2001:db8::1]' ]]; }
ipv6bad() { ! uri::parse 'http://[1::2::3]/'; }
urnparts() { urn::parse 'URN:EXAMPLE:a%2fb?+resolver?=query#fragment'; [[ ${urn[NAMESPACE]} == example && ${urn[RESOLUTION]} == resolver && ${urn[QUERY]} == query && ${urn[FRAGMENT]} == fragment ]]; }
equivalence() { urn::equivalent 'URN:EXAMPLE:a%2fb?+one#x' 'urn:example:a%2Fb?=two#y'; ! urn::equivalent 'urn:example:a%2Fb' 'urn:example:a/b'; ! urn::equivalent 'urn:example:a' 'urn:example:A'; }
fileuri() { local uriText result; path::toFileUri "$ROOT/evidence/a space%name" uriText; path::fromFileUri "$uriText" result; [[ $result == "$ROOT/evidence/a space%name" ]]; }
filebad() { ! path::fromFileUri 'file:///tmp/%2Fetc' result; ! path::fromFileUri 'file:///tmp/%2e%2e/secret' result; ! path::fromFileUri 'file://remote/tmp/a' result; ! path::fromFileUri 'file:///tmp/a%00b' result; }
resolvecase() { local result; uri::resolve 'http://a/b/c/d;p?q' "$1" result; [[ $result == "$2" ]] || { printf 'got %q expected %q\n' "$result" "$2" >&2; return 1; }; }
check uricomponents pieces
check uribyteroundtrip roundtrip
check malformedpercent percentbad
check ipv6literal ipv6good
check malformedipv6 ipv6bad
check urncomponents urnparts
check urnequivalence equivalence
check localfileuriroundtrip fileuri
check fileuritypesafety filebad
while IFS='|' read -r input expected; do check "resolve:$input" resolvecase "$input" "$expected"; done <<'CASES'
g:h|g:h
g|http://a/b/c/g
./g|http://a/b/c/g
g/|http://a/b/c/g/
/g|http://a/g
//g|http://g
?y|http://a/b/c/d;p?y
g?y|http://a/b/c/g?y
#s|http://a/b/c/d;p?q#s
g#s|http://a/b/c/g#s
g?y#s|http://a/b/c/g?y#s
;x|http://a/b/c/;x
g;x|http://a/b/c/g;x
g;x?y#s|http://a/b/c/g;x?y#s
|http://a/b/c/d;p?q
.|http://a/b/c/
./|http://a/b/c/
..|http://a/b/
../|http://a/b/
../g|http://a/b/g
../..|http://a/
../../|http://a/
../../g|http://a/g
../../../g|http://a/g
../../../../g|http://a/g
/./g|http://a/g
/../g|http://a/g
g.|http://a/b/c/g.
.g|http://a/b/c/.g
g..|http://a/b/c/g..
..g|http://a/b/c/..g
./../g|http://a/b/g
./g/.|http://a/b/c/g/
g/./h|http://a/b/c/g/h
g/../h|http://a/b/c/h
g;x=1/./y|http://a/b/c/g;x=1/y
g;x=1/../y|http://a/b/c/y
g?y/./x|http://a/b/c/g?y/./x
g?y/../x|http://a/b/c/g?y/../x
g#s/./x|http://a/b/c/g#s/./x
g#s/../x|http://a/b/c/g#s/../x
http:g|http:g
CASES
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
