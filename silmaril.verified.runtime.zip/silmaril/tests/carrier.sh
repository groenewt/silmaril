#!/bin/bash
set -u
set -o pipefail
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" || exit 1
passed=0 failed=0
source "$ROOT/tests/assert.sh"
STREAM=$SILMARILTYPEBYTESTREAM:component:fixture:instance:exhaustive
allbytes() { local i v; byte::readFile "$ROOT/examples/octets.bin" "$STREAM" || return; [[ ${byteStreamCount[$STREAM]} == 517 ]] || return; for ((i=0;i<512;i++)); do byte::at "$STREAM" "$i" v || return; [[ $v == $((i%256)) ]] || return 1; done; }
writebytes() { allbytes || return; byte::writeFile "$STREAM" "$ROOT/evidence/carrier.bin" || return; local copy=$STREAM:component:copy; byte::readFile "$ROOT/evidence/carrier.bin" "$copy" || return; local i; for ((i=0;i<517;i++)); do [[ ${byteStreamValue[$STREAM$SILMARILUS$i]} == "${byteStreamValue[$copy$SILMARILUS$i]}" ]] || return 1; done; }
chunkboundary() { byteChunkSize=3; allbytes; }
bytelimit() { byteMaximumLength=4; ! byte::readFile "$ROOT/examples/octets.bin" "$STREAM" && [[ ! ${byteStreamDefined[$STREAM]+present} ]]; }
unicodegood() { byte::readFile "$ROOT/examples/unicode.bin" "$STREAM" && unicode::decode "$STREAM" && [[ ${unicodeValues[*]} == '65 233 8364 128512 0' ]]; }
unicodebad() { byte::readFile "$ROOT/examples/surrogate.bin" "$STREAM" || return; ! unicode::decode "$STREAM" && [[ $engineError == "${errorRegistry[ENCODING/INVALID]}" ]]; }
pathroundtrip() { local id result; path::identify "$ROOT/examples/octets.bin" id && path::decode "$id" result && [[ $result == "$ROOT/examples/octets.bin" ]]; }
check exhaustiveoctets allbytes
check binaryroundtrip writebytes
check chunkboundaries chunkboundary
check boundedtransaction bytelimit
check unicodescalars unicodegood
check surrogaterejection unicodebad
check reversiblepathcoordinate pathroundtrip
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
