#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" || exit 1
passed=0 failed=0
source "$ROOT/tests/assert.sh"
DOC=$SILMARILTYPEGRAPH:component:test:instance:pair
TEMP=$ROOT/evidence/pair.yaml
fixture() { printf 'IDENTITY: %s\n%s\n' "$DOC" "$1" > "$TEMP"; }
rawreject() { fixture 'COUNT: 3'; ! kv::parse "$TEMP"; }
keyreject() { fixture "UNDECLARED: $SILMARILTRUE"; ! kv::parse "$TEMP" && [[ $engineError == "${errorRegistry[PAIR/KEY]}" ]]; }
duplicatereject() { fixture "TYPE: $SILMARILTYPEGRAPH"$'\n'"TYPE: $SILMARILTYPEGRAPH"; ! kv::parse "$TEMP" && [[ $engineError == "${errorRegistry[PAIR/DUPLICATE]}" ]]; }
subject() { fixture "VALUE:"$'\n'"  TYPE: $SILMARILTYPEGRAPH"; kv::parse "$TEMP" && [[ ${kvSubject[ROOT/VALUE/TYPE]} == "${kvMap[ROOT/VALUE]}" && ${kvSubject[ROOT/VALUE/TYPE]} != "$DOC" ]]; }
physicaloccurrence() { fixture "TYPE: $SILMARILTYPEGRAPH"; kv::parse "$TEMP" || return; local before=${kvBinding[ROOT/TYPE]} pair=${kvPair[ROOT/TYPE]}; printf '%s' "$kvRaw" > "$ROOT/evidence/second.yaml"; kv::parse "$ROOT/evidence/second.yaml" && [[ $before != "${kvBinding[ROOT/TYPE]}" && $pair == "${kvPair[ROOT/TYPE]}" ]]; }
carrierspan() { fixture "TYPE: $SILMARILTYPEGRAPH"; kv::parse "$TEMP" && [[ -n ${kvCarrier[ROOT/TYPE]-} && -n ${kvPosition[ROOT/TYPE]-} && -n ${kvProvenance[ROOT/TYPE]-} && ${kvOffset[ROOT/TYPE]} -gt 0 ]]; }
quotereject() { fixture 'METADATA:'$'\n''  SHORT:'$'\n''    DESCRIPTION: "bad"quote"'; ! kv::parse "$TEMP"; }
textroundtrip() { fixture 'METADATA:'$'\n''  LONG:'$'\n''    DESCRIPTION: "literal \\ and escaped \" quote"'; kv::parse "$TEMP" || return; local text=${kvValue[ROOT/METADATA/LONG/DESCRIPTION]}; kv::emit > "$ROOT/evidence/second.yaml"; kv::parse "$ROOT/evidence/second.yaml" && [[ ${kvValue[ROOT/METADATA/LONG/DESCRIPTION]} == "$text" ]]; }
bytelimit() { fixture "TYPE: $SILMARILTYPEGRAPH"; local before=$kvRaw; kvMaximumBytes=16; ! kv::parse "$TEMP" && [[ $engineError == "${errorRegistry[PAIR/LIMIT]}" && $kvRaw == "$before" ]]; }
namereject() { ! identity::requireRankedUrn "$SILMARILROOT:domain:knowledge:kingdom:law"; }
vectorreject() { fixture "NODES:"$'\n'"  VECTOR: $KVTYPEVECTOR"$'\n'"  COUNT: $KVEMPTYVECTOR"$'\n'"  MEMBER: $KVEMPTYVECTOR"; ! yaml::parse "$TEMP" && [[ $engineError == "${errorRegistry[VECTOR/CARDINALITY]}" ]]; }
check rawscalarrejected rawreject
check closedkeyregistry keyreject
check duplicatekeyrejected duplicatereject
check nestedsubject subject
check distinctphysicalbinding physicaloccurrence
check explicitcarrierspan carrierspan
check malformedquoterejected quotereject
check proseroundtrip textroundtrip
check textboundedbeforeread bytelimit
check missinggroundingrejected namereject
check vectorcardinalityrejected vectorreject
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
