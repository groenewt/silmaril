#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
passed=0 failed=0
source "$ROOT/tests/assert.sh"
clockcheck() { local start= end=; scheduler::clock start && scheduler::clock end && [[ $start =~ ^[0-9]{16}$ ]] && ((end>=start)); }
constructor() { request::write validate "$ROOT/examples/polymorphic.yaml" "$ROOT/evidence/constructed.yaml" && engine::apply "$ROOT/evidence/constructed.yaml" && [[ ${frameStatus[$engineResult]} == "$SILMARILSTATUSSUCCESS" ]]; }
projectiongood() { engine::reset; engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" || return; printf 'IDENTITY: %s\nVALUE: %s\n' "$REQUESTTYPE:component:projection:instance:fixture" "$SILMARILTRUE" > "$ROOT/evidence/projection.yaml"; kv::parse "$ROOT/evidence/projection.yaml" && kv::turtle > "$ROOT/evidence/projection.ttl" && projection::verify "$ROOT/evidence/projection.ttl"; }
projectionbad() { projectiongood || return; printf '\n' >> "$ROOT/evidence/projection.ttl"; ! projection::verify "$ROOT/evidence/projection.ttl" && [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]; }
check wallclockconversion clockcheck
check requestconstructor constructor
check pairprojection projectiongood
check alteredprojectionrejected projectionbad
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
