#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
fixture=$ROOT/evidence/importfixture.ttl
header='@prefix owl: <http://www.w3.org/2002/07/owl#> . @prefix e: <http://example.org/> .'
complete() { printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av; owl:imports e:bv . e:b a owl:Ontology; owl:versionIRI e:bv .' > "$fixture"; rdf::load "$fixture" imports; import::closure; [[ ${#importVersion[@]} == 2 ]]; }
missing() { printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av; owl:imports e:bv .' > "$fixture"; rdf::load "$fixture" imports; if import::closure; then return 1; fi; [[ $engineError == "${errorRegistry[GROUNDING/MISSING]}" ]]; }
conflict() { printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av, e:avtwo .' > "$fixture"; rdf::load "$fixture" imports; if import::closure; then return 1; fi; [[ $engineError == "${errorRegistry[GROUNDING/CONTRADICTORY]}" ]]; }
cycle() { printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av; owl:imports e:bv . e:b a owl:Ontology; owl:versionIRI e:bv; owl:imports e:av .' > "$fixture"; rdf::load "$fixture" imports; import::closure; }
external() {
 rdf::load "$ROOT/ontology/external/imports.ttl" imports
 import::closure
 [[ ${#importVersion[@]} == 3 && ${#rdfSubject[@]} == 14690 ]]
 import::chain 'http://www.ontologyrepository.com/CommonCoreOntologies/CognitiveProcess' 'http://www.ontologyrepository.com/CommonCoreOntologies/RepresentationalMentalProcess' 'http://www.ontologyrepository.com/CommonCoreOntologies/MentalProcess' 'http://www.ontologyrepository.com/CommonCoreOntologies/BodilyProcess' 'http://purl.obolibrary.org/obo/BFO_0000015' 'http://purl.obolibrary.org/obo/BFO_0000003' 'http://purl.obolibrary.org/obo/BFO_0000001'
 import::chain 'https://www.commoncoreontologies.org/ont00000958' 'http://purl.obolibrary.org/obo/BFO_0000031' 'http://purl.obolibrary.org/obo/BFO_0000002' 'http://purl.obolibrary.org/obo/BFO_0000001'
 [[ ${importVersion[http://www.ontologyrepository.com/CommonCoreOntologies/Domain/CognitiveProcessOntology]} == http://www.ontologyrepository.com/CommonCoreOntologies/Domain/2025-04-25/CognitiveProcessOntology ]]
}
pinvalid() { local bytes digest; printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av .' > "$fixture"; hash::file "$fixture" digest; import::loadPinned "$fixture" "$digest" http://example.org/a http://example.org/av; [[ $importDigest == "$digest" ]]; }
pininvalid() { local digest; printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av .' > "$fixture"; printf -v digest '%064d' 0; if import::loadPinned "$fixture" "$digest" http://example.org/a http://example.org/av; then return 1; fi; [[ $engineError == "${errorRegistry[GROUNDING/CONTRADICTORY]}" ]]; }
pinversion() { local digest; printf '%s\n' "$header" 'e:a a owl:Ontology; owl:versionIRI e:av .' > "$fixture"; hash::file "$fixture" digest; if import::loadPinned "$fixture" "$digest" http://example.org/a http://example.org/wrong; then return 1; fi; [[ $engineError == "${errorRegistry[GROUNDING/CONTRADICTORY]}" ]]; }
check pinsamesnapshot pinvalid
check wrongpinrejected pininvalid
check wrongpinnedversionrejected pinversion
check importclosurecomplete complete
check missingimportrejected missing
check conflictingversionrejected conflict
check cyclicimportsallowed cycle
check preservedexternalclosureandclasschains external
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
