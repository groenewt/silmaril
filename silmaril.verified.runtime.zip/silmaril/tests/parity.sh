#!/bin/bash
set -o nounset
set -o pipefail

testSource=${BASH_SOURCE[0]}
if [[ $testSource == */* ]]; then
  testDirectory=${testSource%/*}
else
  testDirectory=.
fi
rootDirectory=${testDirectory%/*}
enginePath=${rootDirectory}/engine.sh

if [[ ! -r $enginePath ]]; then
  printf 'not ok engine missing at %s\n' "$enginePath" >&2
  exit 1
fi

if ! declare -F engine::bootstrap >/dev/null; then
  source "$enginePath"
fi

declare -gi testPassed=0
declare -gi testFailed=0
declare -g testValueA=
declare -g testValueB=
declare -gi testBaselineReady=0

test::pass() {
  local name=${1-}
  printf 'ok %s\n' "$name"
  (( testPassed += 1 ))
}

test::fail() {
  local name=${1-}
  printf 'not ok %s error=%s detail=%s\n' "$name" "${engineError-}" "${engineDetail-}" >&2
  (( testFailed += 1 ))
  return 1
}

test::run() {
  local name=$1 functionName=$2 testWorker testStatus
  engine::clearError
  (
    set -Eeuo pipefail
    trap 'testStatus=$?; printf "PARITY CASE ERROR status=%s source=%q line=%s\n" "$testStatus" "${BASH_SOURCE[0]}" "$LINENO" >&2; exit "$testStatus"' ERR
    "$functionName"
  ) &
  testWorker=$!
  if wait "$testWorker"; then test::pass "$name"
  else test::fail "$name" || :; fi
}

test::bootstrap() {
  if (( testBaselineReady == 1 )); then
    return 0
  fi
  engine::reset
  engine::bootstrap "${rootDirectory}/ontology/primordial.yaml" "${rootDirectory}/ontology/runtime.yaml" || return 1
  testBaselineReady=1
}

test::methodA() {
  local objectIdentity=$1
  local methodIdentity=$2
  local ownerType=$3
  local outputName=$4
  frame::success "$testValueA" "$SILMARILEFFECTNONE" "$outputName"
}

test::methodB() {
  local objectIdentity=$1
  local methodIdentity=$2
  local ownerType=$3
  local outputName=$4
  frame::success "$testValueB" "$SILMARILEFFECTNONE" "$outputName"
}

test::unsafeDynamic() {
  local objectIdentity=$1
  local methodIdentity=$2
  local ownerType=$3
  local outputName=$4
  runtimeGuardBusy=1
  local slash=/
  local program="${slash}bin${slash}echo"
  "$program" forbidden
  frame::success "$testValueA" "$SILMARILEFFECTNONE" "$outputName"
}

test::tamperRun() {
  local objectIdentity=$1
  local methodIdentity=$2
  local ownerType=$3
  local outputName=$4
  runtimeViolation=
  frame::success "$testValueA" "$SILMARILEFFECTNONE" "$outputName"
}

test::sensitiveRun() {
  local objectIdentity=$1
  local methodIdentity=$2
  local ownerType=$3
  local outputName=$4
  runtime::end
  frame::success "$testValueA" "$SILMARILEFFECTNONE" "$outputName"
}

test::ontology() {
  test::bootstrap || return 1
  local required
  local -a requiredTypes=(
    "$SILMARILTYPEOBJECT"
    "$SILMARILTYPEPAIR"
    "$SILMARILTYPEKEYVALUEPAIR"
    "$SILMARILTYPEFRAME"
    "$SILMARILTYPESET"
    "$SILMARILTYPEGROUP"
    "$SILMARILTYPECLASS"
    "$SILMARILTYPECATEGORY"
    "$SILMARILTYPETOPOLOGY"
    "$SILMARILTYPEGEOMETRY"
    "$SILMARILTYPEMETRICSPACE"
    "$SILMARILTYPEPATH"
    "$SILMARILTYPEFILESYSTEMPATH"
    "$SILMARILTYPEPROTOCOL"
    "$SILMARILTYPEBUILTINPROTOCOL"
  )
  for required in "${requiredTypes[@]}"; do
    type::exists "$required" || return 1
    object::exists "$required" || return 1
    [[ ${objectType[$required]} == "$SILMARILTYPETYPE" ]] || return 1
  done
  type::isSubtype "$SILMARILTYPEGROUP" "$SILMARILTYPEMONOID" || return 1
  type::isSubtype "$SILMARILTYPEMETRICSPACE" "$SILMARILTYPETOPOLOGY" || return 1
  type::isSubtype "$SILMARILTYPEMETRICSPACE" "$SILMARILTYPEGEOMETRY" || return 1
  if type::isSubtype "$SILMARILTYPECLASS" "$SILMARILTYPESET"; then
    return 1
  fi
  [[ ${typeAxiomCount[$SILMARILTYPEGROUP]-0} -ge 1 ]] || return 1
  [[ ${typeAxiomCount[$SILMARILTYPETOPOLOGY]-0} -eq 4 ]] || return 1
  object::exists "$SILMARILPROTOCOLBUILTIN" || return 1
  [[ ${objectType[$SILMARILPROTOCOLBUILTIN]} == "$SILMARILTYPEBUILTINPROTOCOL" ]] || return 1
  object::exists "$SILMARILDEFINITIONOBJECT" || return 1
}

test::pairCarrier() {
  test::bootstrap || return 1
  yaml::parse "${rootDirectory}/ontology/primordial.yaml" || return 1
  (( yamlPairCount > 1000 )) || return 1
  local index
  for (( index = 0; index < yamlPairCount; index += 1 )); do
    identity::requireUrn "${yamlPairIdentity[$index]}" pair || return 1
    [[ -n ${yamlPairLeft[$index]} ]] || return 1
    [[ -n ${yamlPairRight[$index]} ]] || return 1
  done
}

test::byteCarrier() {
  test::bootstrap || return 1
  declare -F byte::readFile >/dev/null || return 1
  type::exists "$SILMARILTYPEBYTE" || return 1
  type::exists "$SILMARILTYPEBYTESTREAM" || return 1
  local streamIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:computation:kingdom:carrier:phylum:byte:class:stream:order:ordered:family:fixture:genus:binary:species:stream:component:fixture:instance:one'
  byte::readFile "${rootDirectory}/examples/bytestream.bin" "$streamIdentity" || return 1
  local count
  byte::count "$streamIdentity" count || return 1
  [[ $count -eq 8 ]] || return 1
  local -a expected=(0 10 65 127 128 255 0 66)
  local index
  local value
  for (( index = 0; index < count; index += 1 )); do
    byte::at "$streamIdentity" "$index" value || return 1
    [[ $value -eq ${expected[$index]} ]] || return 1
  done
}

test::c3() {
  test::bootstrap || return 1
  local typeA='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:formal:phylum:inheritance:class:type:order:c3:family:test:genus:runtime:species:a'
  local typeB=${typeA%:a}:b
  local typeC=${typeA%:a}:c
  local typeD=${typeA%:a}:d
  type::define "$typeA" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$SILMARILTYPEOBJECT" || return 1
  type::define "$typeB" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$typeA" || return 1
  type::define "$typeC" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$typeA" || return 1
  type::define "$typeD" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 2 "$typeB" "$typeC" || return 1
  local -a resolution=()
  type::mro "$typeD" resolution || return 1
  [[ ${resolution[0]} == "$typeD" ]] || return 1
  [[ ${resolution[1]} == "$typeB" ]] || return 1
  [[ ${resolution[2]} == "$typeC" ]] || return 1
  [[ ${resolution[3]} == "$typeA" ]] || return 1

  testValueA='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:value:phylum:symbol:class:test:order:constant:family:value:genus:lexical:species:a'
  testValueB=${testValueA%:a}:b
  object::new "$testValueA" "$SILMARILTYPESYMBOL" || return 1
  object::new "$testValueB" "$SILMARILTYPESYMBOL" || return 1
  local methodIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:behavior:phylum:dispatch:class:method:order:c3:family:test:genus:operation:species:run'
  method::define "$typeA" "$methodIdentity" test::methodA || return 1
  method::define "$typeB" "$methodIdentity" test::methodB || return 1
  local objectIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:object:phylum:dispatch:class:test:order:c3:family:object:genus:instance:species:one'
  object::new "$objectIdentity" "$typeD" || return 1
  local frameIdentity=
  object::call "$objectIdentity" "$methodIdentity" frameIdentity || return 1
  [[ ${frameOutput[$frameIdentity]} == "$testValueB" ]] || return 1

  local conflictA='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:formal:phylum:inheritance:class:type:order:c3:family:conflict:genus:runtime:species:a'
  local conflictB=${conflictA%:a}:b
  local conflictX=${conflictA%:a}:x
  local conflictY=${conflictA%:a}:y
  local conflictZ=${conflictA%:a}:z
  type::define "$conflictA" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$SILMARILTYPEOBJECT" || return 1
  type::define "$conflictB" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$SILMARILTYPEOBJECT" || return 1
  type::define "$conflictX" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 2 "$conflictA" "$conflictB" || return 1
  type::define "$conflictY" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 2 "$conflictB" "$conflictA" || return 1
  if type::define "$conflictZ" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 2 "$conflictX" "$conflictY"; then
    return 1
  fi
  [[ $engineError == "$SILMARILERRORTYPEC3" ]] || return 1
}

test::typing() {
  test::bootstrap || return 1
  local nodeIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:object:phylum:typing:class:node:order:field:family:object:genus:instance:species:one'
  local valueIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:value:phylum:symbol:class:field:order:typed:family:value:genus:lexical:species:one'
  local wrongIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:object:phylum:graph:class:edge:order:typed:family:edge:genus:instance:species:one'
  object::new "$nodeIdentity" "$SILMARILTYPECONSTANTNODE" || return 1
  object::new "$valueIdentity" "$SILMARILTYPESYMBOL" || return 1
  object::new "$wrongIdentity" "$SILMARILTYPEEDGE" || return 1
  object::set "$nodeIdentity" "$SILMARILFIELDVALUE" "$valueIdentity" || return 1
  if object::set "$nodeIdentity" "$SILMARILFIELDVALUE" "$wrongIdentity"; then
    return 1
  fi
}

test::graph() {
  test::bootstrap || return 1
  graph::load "${rootDirectory}/examples/polymorphic.yaml" || return 1
  graph::validate || return 1
  [[ ${#graphOrder[@]} -eq 5 ]] || return 1
  [[ ${graphOrder[0]} == *':source:a' ]] || return 1
  [[ ${graphOrder[1]} == *':source:b' ]] || return 1
  [[ ${graphOrder[2]} == *':pass:a' ]] || return 1
  graph::execute || return 1
  [[ $graphStatus == "$SILMARILSTATUSSUCCESS" ]] || return 1
  [[ ${nodeOutput[${graphOrder[4]}]} == "$SILMARILVALUEGAMMA" ]] || return 1
  local sourceFrame=${nodeFrame[${graphOrder[0]}]}
  [[ ${frameEffect[$sourceFrame]} == "$SILMARILEFFECTAUDIT" ]] || return 1
}

test::cycle() {
  test::bootstrap || return 1
  graph::load "${rootDirectory}/examples/cycle.yaml" || return 1
  if graph::validate; then
    return 1
  fi
  [[ $engineError == "$SILMARILERRORGRAPHCYCLE" ]] || return 1
}

test::protocol() {
  test::bootstrap || return 1
  if graph::load "${rootDirectory}/examples/badprotocol.yaml"; then
    return 1
  fi
  [[ $engineError == "$SILMARILERRORGRAPHPROTOCOL" ]] || return 1
}

test::yamlGate() {
  test::bootstrap || return 1
  if yaml::parse "${rootDirectory}/examples/invalidkey.yaml"; then
    return 1
  fi
  [[ $engineError == "${errorRegistry[PAIR/KEY]}" ]] || return 1
}

test::firewall() {
  test::bootstrap || return 1
  local unsafeType='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:execution:phylum:graph:class:node:order:unsafe:family:node:genus:test:species:unsafe'
  type::define "$unsafeType" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$SILMARILTYPENODE" || return 1
  method::define "$unsafeType" "$SILMARILMETHODRUN" test::unsafeDynamic || return 1
  testValueA='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:value:phylum:symbol:class:firewall:order:constant:family:value:genus:lexical:species:a'
  object::new "$testValueA" "$SILMARILTYPESYMBOL" || return 1
  local objectIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:object:phylum:firewall:class:node:order:unsafe:family:object:genus:instance:species:one'
  object::new "$objectIdentity" "$unsafeType" || return 1
  runtime::begin || return 1
  local frameIdentity=
  object::call "$objectIdentity" "$SILMARILMETHODRUN" frameIdentity || :
  local endStatus=0
  runtime::end || endStatus=$?
  [[ $endStatus -ne 0 ]] || return 1
  [[ $runtimeViolationCommand == /bin/echo ]] || return 1
  [[ $runtimeExternalCount -eq 1 ]] || return 1
}

test::tamperGate() {
  test::bootstrap || return 1
  local unsafeType='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:execution:phylum:graph:class:node:order:tamper:family:node:genus:test:species:unsafe'
  type::define "$unsafeType" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$SILMARILTYPENODE" || return 1
  if method::define "$unsafeType" "$SILMARILMETHODRUN" test::tamperRun; then
    return 1
  fi
  [[ $engineError == "$SILMARILERRORRUNTIMEESCAPE" ]] || return 1
}

test::sensitiveGate() {
  test::bootstrap || return 1
  local unsafeType='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:execution:phylum:graph:class:node:order:sensitive:family:node:genus:test:species:unsafe'
  type::define "$unsafeType" "$SILMARILDEFINITIONOBJECT" "$SILMARILFALSE" 1 "$SILMARILTYPENODE" || return 1
  method::define "$unsafeType" "$SILMARILMETHODRUN" test::sensitiveRun || return 1
  testValueA='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:value:phylum:symbol:class:sensitive:order:constant:family:value:genus:lexical:species:a'
  object::new "$testValueA" "$SILMARILTYPESYMBOL" || return 1
  local objectIdentity='urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:testing:kingdom:object:phylum:firewall:class:node:order:sensitive:family:object:genus:instance:species:one'
  object::new "$objectIdentity" "$unsafeType" || return 1
  runtime::begin || return 1
  local frameIdentity=
  object::call "$objectIdentity" "$SILMARILMETHODRUN" frameIdentity || :
  local endStatus=0
  runtime::end || endStatus=$?
  [[ $endStatus -ne 0 ]] || return 1
  [[ $runtimeViolationCommand == runtime::end ]] || return 1
}

test::audit() {
  test::bootstrap || return 1
  engine::audit || return 1
}

test::main() {
  test::bootstrap || {
    test::fail bootstrap || :
    printf 'passed %s failed %s\n' "$testPassed" "$testFailed"
    return 1
  }
  test::run ontology test::ontology
  test::run paircarrier test::pairCarrier
  test::run bytecarrier test::byteCarrier
  test::run c3 test::c3
  test::run typing test::typing
  test::run graph test::graph
  test::run cycle test::cycle
  test::run protocol test::protocol
  test::run yamlgate test::yamlGate
  test::run firewall test::firewall
  test::run tampergate test::tamperGate
  test::run sensitivegate test::sensitiveGate
  test::run audit test::audit
  printf 'passed %s failed %s\n' "$testPassed" "$testFailed"
  (( testFailed == 0 ))
}

if [[ ${BASH_SOURCE[0]} == "$0" ]]; then
  test::main
fi
