#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
prepare() { engine::reset; engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml"; wide::initialize "$ROOT/ontology/physical.yaml"; }
schemaid=$SILMARILROOT:grounding:ontology:basic:formal:domain:computation:kingdom:carrier:phylum:byte:class:schema:order:registered:family:bit:genus:vector:species:schema:component:test:instance:one
valueid=$SILMARILROOT:grounding:ontology:basic:formal:domain:computation:kingdom:carrier:phylum:byte:class:value:order:registered:family:bit:genus:vector:species:byte:component:test:instance:one
validwidth() { local bits; printf -v bits '%*s' 128 ''; bits=${bits// /1}; wide::schema "$schemaid" 128 "$WIDEMOST" "$WIDEFORWARD" "$WIDERAW"; wide::new "$valueid" "$schemaid" "$bits"; type::isSubtype "${objectType[$valueid]}" "$WIDETYPEVECTOR"; [[ ${#wideBits[$valueid]} == 128 ]]; }
widthreject() { if wide::schema "$schemaid" 129 "$WIDEMOST" "$WIDEFORWARD" "$WIDERAW"; then return 1; fi; [[ $engineError == "${errorRegistry[BYTE/RANGE]}" ]]; }
undeclared() { if wide::new "$valueid" "$schemaid" 111; then return 1; fi; [[ $engineError == "${errorRegistry[GROUNDING/MISSING]}" ]]; }
wrongextent() { wide::schema "$schemaid" 3 "$WIDEMOST" "$WIDEFORWARD" "$WIDERAW"; if wide::new "$valueid" "$schemaid" 1111; then return 1; fi; [[ ! ${objectDefined[$valueid]+yes} ]]; }
invalidbit() { wide::schema "$schemaid" 3 "$WIDEMOST" "$WIDEFORWARD" "$WIDERAW"; if wide::new "$valueid" "$schemaid" 10x; then return 1; fi; [[ $engineError == "${errorRegistry[ENCODING/INVALID]}" ]]; }
roundtrip() { wide::schema "$schemaid" 16 "$WIDELEAST" "$WIDEREVERSE" "$WIDERAW"; wide::new "$valueid" "$schemaid" 1000000011111111; wide::octets "$valueid"; [[ ${wideOctets[*]} == '1 255' ]]; wide::fromOctets "$valueid:occurrence:second" "$schemaid" "${wideOctets[@]}"; [[ ${wideBits[$valueid:occurrence:second]} == "${wideBits[$valueid]}" ]]; }
partial() { wide::schema "$schemaid" 3 "$WIDEMOST" "$WIDEFORWARD" "$WIDERAW"; wide::new "$valueid" "$schemaid" 101; if wide::octets "$valueid"; then return 1; fi; [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]; }
stalereset() { wide::schema "$schemaid" 8 "$WIDEMOST" "$WIDEFORWARD" "$WIDERAW"; wide::new "$valueid" "$schemaid" 10101010; engine::reset; if wide::octets "$valueid"; then return 1; fi; [[ $engineError == "${errorRegistry[GROUNDING/MISSING]}" ]]; }
prepare
check resetinvalidatescarrier stalereset
check wideonehundredtwentyeight validwidth
check widthboundreject widthreject
check unregisteredwidthschema undeclared
check exactbitextent wrongextent
check nonbinaryrejection invalidbit
check independentbitandbyteorder roundtrip
check nonoctetalprojectionrejectsimplicitpadding partial
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
