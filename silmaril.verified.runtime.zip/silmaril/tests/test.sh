#!/bin/bash
# Compatibility entry point; parity.sh is the single test implementation.
source "${BASH_SOURCE[0]%/*}/parity.sh"
if [[ ${BASH_SOURCE[0]} == "$0" ]]; then test::main "$@"; fi
