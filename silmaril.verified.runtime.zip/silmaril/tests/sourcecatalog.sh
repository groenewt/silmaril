#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
path::absolute "$ROOT" ROOT
source "$ROOT/tests/assert.sh"
passed=0 failed=0
catalog() {
  local list count index item identity function
  local -A identities=()
  yaml::parse "$ROOT/registry/functions.yaml" || return
  yaml::requiredSequence "$SILMARILYAMLROOT" SOURCE list count || return
  ((count==${#runtimeTrusted[@]})) || return 1
  for ((index=0;index<count;index+=1)); do
    yaml::sequenceMap "$list" "$index" item || return
    yaml::requiredScalar "$item" IDENTITY identity || return
    [[ ! ${identities[$identity]+present} ]] || return 1
    identities[$identity]=1
  done
  for function in "${!runtimeTrusted[@]}"; do [[ ${identities[${sourceIdentity[$function]}]-} == 1 ]] || return 1; done
}
check fullsourcecatalogmatchessealedregistry catalog
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
