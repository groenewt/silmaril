#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/tests/assert.sh"
passed=0 failed=0
probe() { false; printf '%s\n' UNREACHABLE; }
caseproof() { local passed=0 failed=0; check deliberatefailure probe > "$ROOT/evidence/expectedcasefailure.log" 2>&1; [[ $passed == 0 && $failed == 1 ]]; }
parityproof() { source "$ROOT/tests/parity.sh"; testPassed=0 testFailed=0; test::run deliberateparityfailure probe > "$ROOT/evidence/expectedparityfailure.log" 2>&1; [[ $testFailed == 1 && $testPassed == 0 ]]; }
check casesdonotmaskfailure caseproof
check paritycasesdonotmaskfailure parityproof
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
