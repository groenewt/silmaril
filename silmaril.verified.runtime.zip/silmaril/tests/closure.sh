#!/bin/bash
set -u
set -o pipefail
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
passed=0
failed=0
source "$ROOT/tests/assert.sh"
exist() { declare -F "$1" >/dev/null; }
check canonicalpairparser exist kv::parse
check finitemodelchecker exist category::check
check functorchecker exist model::check
check naturalitychecker exist natural::check
check elementconstruction exist elements::build
check coendchecker exist coend::check
check errorregistry exist error::lookup
check unaryinterface exist engine::apply
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
