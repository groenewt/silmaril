#!/bin/bash
set -u
allDirectory=${BASH_SOURCE[0]%/*}
allFailed=0 allSuites=0
for allSuite in parity pair category carrier scheduler checkpoint algebra interface grounding semantics closure final repair assertion integrity address rdf shapes policy wide imports hardening source projection inventory transactions manifest vectors order homology capture sourcecatalog captureinterface; do
  printf 'SUITE %s\n' "$allSuite"
  (
    set -Eeuo pipefail
    trap 's=$?; printf "SUITE ERROR status=%s source=%q line=%s\n" "$s" "${BASH_SOURCE[0]}" "$LINENO" >&2; exit "$s"' ERR
    source "$allDirectory/$allSuite.sh"
    if [[ $allSuite == parity ]]; then test::main; fi
  ) &
  allWorker=$!
  if wait "$allWorker"; then printf 'SUITEPASS %s\n' "$allSuite"
  else printf 'SUITEFAIL %s\n' "$allSuite" >&2; ((allFailed+=1)); fi
  ((allSuites+=1))
done
printf 'SUITES passed=%s failed=%s\n' "$((allSuites-allFailed))" "$allFailed"
((allFailed==0))
