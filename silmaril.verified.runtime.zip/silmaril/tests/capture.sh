#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
path::absolute "$ROOT" ROOT
source "$ROOT/tests/assert.sh"
passed=0 failed=0
available() { declare -F kv::capture >/dev/null && declare -F kv::capture::verify >/dev/null; }
check replayablecaptureavailable available
if ((failed)); then printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"; exit 1; fi
captureSource=$ROOT/evidence/capturesource.yaml
captureReceipt=$ROOT/evidence/capturereceipt.yaml
captureObservation=$SILMARILTYPEGRAPH:component:capture:instance:observation
captureOther=$SILMARILTYPEGRAPH:component:capture:instance:other
setupcapture() {
 printf 'IDENTITY: %s\nVALUE:\n  TYPE: %s\nMETADATA:\n  SHORT:\n    DESCRIPTION: "captured source"\n' "$SILMARILTYPEGRAPH:component:capture:instance:document" "$SILMARILTYPEGRAPH" > "$captureSource"
 hash::file "$captureSource" capturePin
 kv::capture "$captureSource" "$captureObservation" "$capturePin"
}
stable() { setupcapture || return; local before=$kvCaptureReceipt bind=${kvBinding[ROOT/VALUE/TYPE]}; kv::parse "$captureSource"; kv::parse "$captureSource"; kv::capture "$captureSource" "$captureObservation" "$capturePin" && [[ $before == "$kvCaptureReceipt" && $bind == "${kvBinding[ROOT/VALUE/TYPE]}" ]]; }
newobservation() { setupcapture || return; local pair=${kvPair[ROOT/VALUE/TYPE]} bind=${kvBinding[ROOT/VALUE/TYPE]}; kv::capture "$captureSource" "$captureOther" "$capturePin" && [[ $bind != "${kvBinding[ROOT/VALUE/TYPE]}" && $pair == "${kvPair[ROOT/VALUE/TYPE]}" ]]; }
newpath() { setupcapture || return; local pair=${kvPair[ROOT/VALUE/TYPE]} bind=${kvBinding[ROOT/VALUE/TYPE]}; printf '%s' "$kvRaw" > "$ROOT/evidence/captureother.yaml"; kv::capture "$ROOT/evidence/captureother.yaml" "$captureObservation" "$capturePin" && [[ $bind != "${kvBinding[ROOT/VALUE/TYPE]}" && $pair == "${kvPair[ROOT/VALUE/TYPE]}" ]]; }
readmission() { setupcapture || return; kv::capture::emit > "$captureReceipt"; kv::capture::verify "$captureSource" "$captureObservation" "$capturePin" "$captureReceipt" && [[ $kvCaptureVerified == 1 ]]; }
alteredreceipt() { readmission || return; local before=$kvRaw beforePair=${kvPair[ROOT/VALUE/TYPE]} beforeKnown=${#kvKnown[@]}; printf '# unauthorized addition\n' >> "$captureReceipt"; ! kv::capture::verify "$captureSource" "$captureOther" "$capturePin" "$captureReceipt" && [[ $kvCaptureVerified == 0 && -z $kvCaptureReceipt && $kvRaw == "$before" && ${kvPair[ROOT/VALUE/TYPE]} == "$beforePair" && ${#kvKnown[@]} == "$beforeKnown" ]]; }
badpin() { setupcapture || return; local before=$kvRaw beforeKnown=${#kvKnown[@]}; ! kv::capture "$captureSource" "$captureObservation" notasha && [[ $kvRaw == "$before" && ${#kvKnown[@]} == "$beforeKnown" && $kvCaptureVerified == 0 ]]; }
changedsource() { readmission || return; local before=$kvRaw; printf '# changed bytes\n' >> "$captureSource"; ! kv::capture::verify "$captureSource" "$captureObservation" "$capturePin" "$captureReceipt" && [[ $kvRaw == "$before" && $kvCaptureVerified == 0 ]]; }
newpin() { readmission || return; printf '# changed bytes\n' >> "$captureSource"; hash::file "$captureSource" capturePin; ! kv::capture::verify "$captureSource" "$captureObservation" "$capturePin" "$captureReceipt" && [[ $kvCaptureVerified == 0 ]]; }
invalidobservation() { setupcapture || return; ! kv::capture "$captureSource" urn:wrong:snapshot "$capturePin" && [[ $kvCaptureVerified == 0 ]]; }
emptyreceipt() { setupcapture || return; printf '' > "$captureReceipt"; ! kv::capture::verify "$captureSource" "$captureObservation" "$capturePin" "$captureReceipt"; }
nulreceipt() { setupcapture || return; printf '%s\000' "$kvCaptureReceipt" > "$captureReceipt"; ! kv::capture::verify "$captureSource" "$captureObservation" "$capturePin" "$captureReceipt"; }
clearedoutput() { setupcapture || return; if kv::capture "$captureSource" "$captureObservation" bad; then return 1; fi; if kv::capture::emit > "$captureReceipt"; then return 1; fi; [[ ! -s $captureReceipt ]]; }
spancheck() { setupcapture || return; [[ ${kvOffset[ROOT/IDENTITY]} == 0 && ${kvLine[ROOT/VALUE/TYPE]} == 3 && ${kvSubject[ROOT/VALUE/TYPE]} == "${kvMap[ROOT/VALUE]}" && $kvCaptureCount == ${#kvPaths[@]} ]]; }
check stableacrossparsehistory stable
check newsnapshotpreservespair newobservation
check newlocationpreservespair newpath
check exactreceiptreplay readmission
check alteredreceipttransaction alteredreceipt
check invalidpintransaction badpin
check changedsourceoldpin changedsource
check changedsourceupdatedpinoldreceipt newpin
check invalidsnapshotrejected invalidobservation
check emptyreceiptrejected emptyreceipt
check nulreceiptrejected nulreceipt
check failedcaptureclearsresult clearedoutput
check positionandinheritedsubject spancheck
surplusarguments() { readmission || return; ! kv::capture "$captureSource" "$captureObservation" "$capturePin" "$captureReceipt" surplus && [[ $kvCaptureVerified == 0 ]]; }
emptyfourthargument() { setupcapture || return; ! kv::capture "$captureSource" "$captureObservation" "$capturePin" '' && [[ $kvCaptureVerified == 0 ]]; }
failedverifyclearsall() { setupcapture || return; if kv::capture::verify "$captureSource" "$captureObservation" "$capturePin" ''; then return 1; fi; [[ $kvCaptureCount == 0 && -z $kvCaptureDigest && -z $kvCaptureSource && -z $kvCaptureObservation ]]; }
parseinvalidatescapture() { setupcapture || return; kv::parse "$captureSource"; ! kv::capture::emit > "$captureReceipt" && [[ ! -s $captureReceipt && $kvCaptureVerified == 0 ]]; }
immutablecapture() { setupcapture || return; printf '# different carrier\n' >> "$captureSource"; hash::file "$captureSource" capturePin; ! kv::capture "$captureSource" "$captureObservation" "$capturePin" && [[ $kvCaptureVerified == 0 ]]; }
check surpluscaptureargumentsrejected surplusarguments
check emptyreceiptargumentrejected emptyfourthargument
check failedverifyclearsallcoordinates failedverifyclearsall
check laterparseinvalidatescapture parseinvalidatescapture
check observedcarriernameimmutable immutablecapture
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
