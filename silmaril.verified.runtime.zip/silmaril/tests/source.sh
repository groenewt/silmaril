#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
allviews() { source::verify "$ROOT"; ((sourceVerified>200)); }
missingview() { if source::verifyFile 'pair::identity' "$ROOT/evidence/absentfunction.sh"; then return 1; fi; }
changedview() { printf '%s\n' 'pair::identity () { :; }' > "$ROOT/evidence/changedfunction.sh"; if source::verifyFile pair::identity "$ROOT/evidence/changedfunction.sh"; then return 1; fi; [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]; }
unknownfunction() { if source::verifyFile external::unknown "$ROOT/engine.sh"; then return 1; fi; }
relocatedview() { local f=pair::identity; declare -f "$f" > "$ROOT/evidence/copiedfunction.sh"; sourcePath[$f]=evidence/copiedfunction.sh; if source::verify "$ROOT"; then return 1; fi; [[ $engineError == "${errorRegistry[PATH/ROUND/TRIP]}" ]]; }
check movedviewneedsdeclaredprojection relocatedview
check everyfunctionview allviews
check missingfunctionview missingview
check changedfunctionview changedview
check unregisteredfunctionview unknownfunction
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
