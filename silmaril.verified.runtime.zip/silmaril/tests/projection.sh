#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
fixture=$ROOT/evidence/projectionfixture.ttl
output=$ROOT/evidence/projectionoutput.ttl
report=$ROOT/evidence/shapereport.ttl
roundtrip() {
 printf '%s\n' '@prefix e: <http://example.org/> . e:s e:p ("A" "\u0000" "\\u0000"), "hello"@EN .' > "$fixture"
 rdf::load "$fixture" data
 local count=${#rdfSubject[@]}
 rdf::emit data > "$output"
 rdf::load "$output" data
 [[ ${#rdfSubject[@]} == "$count" ]]
 local seen=0 t
 for t in "${!rdfTerm[@]}"; do [[ ${rdfKind[t]} != literal ]] || ((seen+=1)); done
 [[ $seen == 4 ]]
}
semantic() {
 kv::parse "$ROOT/examples/polymorphic.yaml"
 kv::turtle > "$output"
 printf '\n# Different whitespace does not change an RDF graph.\n' >> "$output"
 projection::semanticVerify "$output"
 if projection::verify "$output"; then return 1; fi
}
extra() {
 kv::parse "$ROOT/examples/polymorphic.yaml"
 kv::turtle > "$output"
 printf '%s\n' '<http://example.org/a> <http://example.org/b> <http://example.org/c> .' >> "$output"
 if projection::semanticVerify "$output"; then return 1; fi
 [[ $engineError == "${errorRegistry[PROJECTION/FIDELITY]}" ]]
}
shapereport() {
 printf '%s\n' '@prefix sh: <http://www.w3.org/ns/shacl#> . @prefix e: <http://example.org/> . e:s sh:targetNode e:a; sh:property [ sh:path e:p; sh:minCount 1 ] .' > "$fixture"
 rdf::load "$fixture" shapes
 if shape::validate; then return 1; fi
 shape::emitReport > "$report"
 rdf::load "$report" report
 local t found=0
 for t in "${!rdfTerm[@]}"; do [[ ${rdfKind[t]} != literal || ${rdfTerm[t]} != false ]] || found=1; done
 ((found))
}
noinvalidreport() { shapeFailure=1; if shape::emitReport > "$report"; then return 1; fi; [[ ! -s $report ]]; }
check rdfprojectionroundtrip roundtrip
check equivalentgraphdifferentbytes semantic
check extratriplerejected extra
check shapereportparsedbybash shapereport
check evaluationfailureisnotconformance noinvalidreport
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
