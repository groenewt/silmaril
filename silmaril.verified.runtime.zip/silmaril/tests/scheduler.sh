#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
passed=0 failed=0
source "$ROOT/tests/assert.sh"
setup() { engine::reset; engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" && graph::load "$ROOT/examples/polymorphic.yaml" && graph::validate; }
# These implementations are admitted trusted-program fixtures, not sourced plan text.
node::fixture::timeout() { while :; do :; done; }
node::fixture::retry() { if ((schedulerAttempt<2)); then frame::failure "$SILMARILERRORGRAPHNODE" "$4"; return 1; else local v; object::get "$1" "$SILMARILFIELDVALUE" v || return; frame::success "$v" "$SILMARILEFFECTNONE" "$4"; fi; }
node::fixture::failure() { frame::failure "$SILMARILERRORGRAPHNODE" "$4"; return 1; }
node::fixture::child() { if [[ $BASHPID == "$schedulerParent" ]]; then frame::failure "$SILMARILERRORGRAPHNODE" "$4"; return 1; else local v; object::get "$1" "$SILMARILFIELDVALUE" v || return; frame::success "$v" "$SILMARILEFFECTNONE" "$4"; fi; }
node::fixture::rollback() { frame::success "$SILMARILVALUENONE" "$SILMARILEFFECTAUDIT" "$4"; }
parallelrun() { setup || return; scheduler::defaults; schedulerParallel=2; methodImplementation[$SILMARILTYPECONSTANTNODE$SILMARILUS$SILMARILMETHODRUN]=node::fixture::child; scheduler::run || return; [[ $graphStatus == "$SILMARILSTATUSSUCCESS" && ${#schedulerCommit[@]} == 5 && ${nodeOutput[${graphOrder[4]}]} == "$SILMARILVALUEGAMMA" ]]; }
timeoutrun() { setup || return; scheduler::defaults; schedulerTimeout=60000; methodImplementation[$SILMARILTYPECONSTANTNODE$SILMARILUS$SILMARILMETHODRUN]=node::fixture::timeout; ! scheduler::run && [[ $engineError == "${errorRegistry[EXECUTION/TIMEOUT]}" ]]; }
retryrun() { setup || return; scheduler::defaults; schedulerRetry=1; methodImplementation[$SILMARILTYPECONSTANTNODE$SILMARILUS$SILMARILMETHODRUN]=node::fixture::retry; scheduler::run && [[ ${schedulerAttempts[${graphNodes[1]}]} == 2 ]]; }
continuerun() { setup || return; scheduler::defaults; schedulerDisposition=continue; methodImplementation[$SILMARILTYPEAUDITEDCONSTANTNODE$SILMARILUS$SILMARILMETHODRUN]=node::fixture::failure; ! scheduler::run && [[ ${schedulerState[${graphNodes[1]}]} == success && ${schedulerState[${graphNodes[2]}]} == blocked ]]; }
rollbackrun() { setup || return; scheduler::defaults; schedulerRollback=1; methodImplementation[$SILMARILTYPEJOINNODE$SILMARILUS$SILMARILMETHODRUN]=node::fixture::failure; local t; for t in "$SILMARILTYPECONSTANTNODE" "$SILMARILTYPEIDENTITYNODE"; do methodImplementation[$t$SILMARILUS$SCHEDULERMETHODROLLBACK]=node::fixture::rollback; methodDefined[$t$SILMARILUS$SCHEDULERMETHODROLLBACK]=1; done; ! scheduler::run && [[ ${#schedulerRolled[@]} == 3 && ${schedulerRolled[0]} == "${graphNodes[2]}" && ${schedulerRolled[2]} == "${graphNodes[0]}" ]]; }
limits() { setup || return; scheduler::defaults; schedulerParallel=0; ! scheduler::run; }
check boundedparallelworkers parallelrun
check nativetimeout timeoutrun
check boundedretry retryrun
check dependencyblockingandcontinue continuerun
check reversecommitrollback rollbackrun
check schedulercapacity limits
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
