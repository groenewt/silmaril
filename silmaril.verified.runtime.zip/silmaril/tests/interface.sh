#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
passed=0 failed=0
source "$ROOT/tests/assert.sh"
requestfile() { local op=$1 input=$2 out=$3 inref outref; path::identify "$input" inref; path::identify "$out" outref; printf 'IDENTITY: %s\nTYPE: %s\nOPERATION: %s\nINPUT: %s\nOUTPUT: %s\n' "$REQUESTTYPE:component:fixture:instance:$op" "$REQUESTTYPE" "$REQUESTOPERATION:$op" "$inref" "$outref" > "$ROOT/evidence/request.yaml"; }
validate() { requestfile validate "$ROOT/examples/polymorphic.yaml" "$ROOT/evidence/result.yaml"; engine::apply "$ROOT/evidence/request.yaml" && [[ ${frameStatus[$engineResult]} == "$SILMARILSTATUSSUCCESS" ]] && kv::parse "$ROOT/evidence/result.yaml"; }
invalid() { requestfile validate "$ROOT/examples/cycle.yaml" "$ROOT/evidence/result.yaml"; ! engine::apply "$ROOT/evidence/request.yaml" && [[ ${frameStatus[$engineResult]} == "$SILMARILSTATUSFAILURE" ]]; }
arity() { ! engine::apply a b; }
certificate() { requestfile certify "$ROOT/examples/category.yaml" "$ROOT/evidence/result.yaml"; engine::apply "$ROOT/evidence/request.yaml" && [[ ${frameStatus[$engineResult]} == "$SILMARILSTATUSSUCCESS" ]]; }
receipt() { engine::reset; engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" && graph::load "$ROOT/examples/polymorphic.yaml" && graph::validate && graph::execute || return; graph::emitReceipts > "$ROOT/evidence/graph.yaml"; yaml::parse "$ROOT/evidence/graph.yaml"; }
check unarytypedrequest validate
check rejectionframe invalid
check unaryarity arity
check finitecertificate certificate
check referenceonlyreceipt receipt
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
