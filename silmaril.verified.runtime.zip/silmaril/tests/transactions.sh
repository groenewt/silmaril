#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
source "$ROOT/engine.sh"
source "$ROOT/tests/assert.sh"
path::absolute "$ROOT" ROOT
passed=0 failed=0
fixture=$ROOT/evidence/transactionfixture.yaml
importfile=$ROOT/evidence/transactionimport.ttl
kvencoding() {
 printf 'IDENTITY: %s\nTYPE: %s\n' "$SILMARILTYPEGRAPH:component:test:instance:encoding" "$SILMARILTYPEGRAPH" > "$fixture"
 kv::parse "$fixture"; local before=$kvRaw
 printf 'IDENTITY: %s\nMETADATA:\n  SHORT:\n    DESCRIPTION: "\300\257"\n' "$SILMARILTYPEGRAPH:component:test:instance:encoding" > "$fixture"
 if kv::parse "$fixture"; then return 1; fi
 [[ $kvRaw == "$before" && $engineError == "${errorRegistry[ENCODING/INVALID]}" ]]
}
importrollback() {
 local digest before beforeterm
 printf '%s\n' '@prefix owl: <http://www.w3.org/2002/07/owl#> . <urn:test:original> a owl:Ontology; owl:versionIRI <urn:test:original:version> .' > "$importfile"
 hash::file "$importfile" digest
 import::loadPinned "$importfile" "$digest" urn:test:original urn:test:original:version
 before=$importDigest; beforeterm=${rdfTerm[0]}
 printf '%s\n' '@prefix owl: <http://www.w3.org/2002/07/owl#> . <urn:test:replacement> a owl:Ontology; owl:versionIRI <urn:test:replacement:version> .' > "$importfile"
 hash::file "$importfile" digest
 if import::loadPinned "$importfile" "$digest" urn:test:replacement urn:test:incorrect; then return 1; fi
 [[ ${importVersion[urn:test:original]-} == urn:test:original:version && $importDigest == "$before" && ${rdfTerm[0]} == "$beforeterm" ]]
}
stalereport() {
 rdf::reset
 rdf::content '@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:test:shape> sh:targetNode <urn:test:node> .' shapes ''
 shape::validate
 rdf::content '<urn:test:node> <urn:test:predicate> <urn:test:value> .' data ''
 if shape::emitReport > "$ROOT/evidence/stalereport.ttl"; then return 1; fi
 [[ ! -s $ROOT/evidence/stalereport.ttl ]]
}
check canonicaltextutfencodingtransaction kvencoding
check pinnedimportrejectionpreservescommit importrollback
check datachangeinvalidatesvalidation stalereport
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
