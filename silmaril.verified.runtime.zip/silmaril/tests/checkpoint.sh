#!/bin/bash
set -u
ROOT=${BASH_SOURCE[0]%/*}/..
if ! declare -F engine::bootstrap >/dev/null; then source "$ROOT/engine.sh"; fi
path::absolute "$ROOT" ROOT
passed=0 failed=0
source "$ROOT/tests/assert.sh"
setup() { engine::reset; engine::bootstrap "$ROOT/ontology/primordial.yaml" "$ROOT/ontology/runtime.yaml" && graph::load "$ROOT/examples/polymorphic.yaml" && graph::validate; }
CP=$ROOT/evidence/checkpoint.yaml
SN=$ROOT/evidence/snapshot.yaml
save() { setup || return; scheduler::defaults; graph::execute || return; local n; for n in "${graphNodes[@]}"; do schedulerState[$n]=success; schedulerAttempts[$n]=1; done; checkpoint::write "$CP" "$SN"; }
restore() { save || return; setup || return; scheduler::defaults; checkpoint::load "$CP" "$SN" || return; scheduler::run && [[ ${#schedulerCommit[@]} == 5 && ${schedulerAttempts[${graphNodes[0]}]} == 0 ]]; }
mutation() { save || return; printf '#changed\n' >> "$SN"; ! checkpoint::load "$CP" "$SN" && [[ $engineError == "${errorRegistry[EXECUTION/RESUME]}" ]]; }
partial() { save || return; local text= line; while IFS= read -r line; do [[ $line == COMPLETE:* ]] || text+=$line$'\n'; done < "$CP"; printf '%s' "$text" > "$CP"; ! checkpoint::load "$CP" "$SN"; }
check persistentresume restore
check snapshotmutationrejected mutation
check incompletecheckpointrejected partial
printf 'SUMMARY passed=%s failed=%s\n' "$passed" "$failed"
((failed==0))
