wide::new () 
{ 
    local wnId=$1 wnSchema=$2 wnBits=$3;
    [[ -n ${wideSchemaWidth[$wnSchema]+yes} && ${objectType[$wnSchema]-} == "$WIDETYPESCHEMA" ]] || { 
        error::raise GROUNDING/MISSING 'unregistered byte schema';
        return 1
    };
    [[ -n $wnBits && $wnBits != *[!01]* ]] || { 
        error::raise ENCODING/INVALID 'bit alphabet';
        return 1
    };
    ((${#wnBits}==wideSchemaWidth[$wnSchema])) || { 
        error::raise BYTE/RANGE 'bit extent disagrees with schema';
        return 1
    };
    object::new "$wnId" "$WIDETYPEBYTE" || return 1;
    wideSchema[$wnId]=$wnSchema;
    wideBits[$wnId]=$wnBits;
    kvKnown[$wnId]=1
}
