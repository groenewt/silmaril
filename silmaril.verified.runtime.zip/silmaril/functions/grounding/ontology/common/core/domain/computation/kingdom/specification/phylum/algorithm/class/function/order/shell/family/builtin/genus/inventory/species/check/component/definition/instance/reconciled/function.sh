inventory::check () 
{ 
    local ivIndex ivParent ivPath ivPrevious ivRest LC_ALL=C;
    local -A ivCounts=() ivLast=() ivUnique=();
    ((${#inventoryPath[@]}>0)) || { 
        error::raise PATH/ROOT 'empty inventory';
        return 1
    };
    for ivIndex in "${!inventoryPath[@]}";
    do
        ivPath=${inventoryPath[ivIndex]};
        ivParent=${inventoryParent[ivIndex]};
        path::lexical "$ivPath" || { 
            error::raise PATH/SEGMENT 'inventory path';
            return 1
        };
        [[ ! -n ${ivUnique[$ivPath]+yes} ]] || { 
            error::raise PATH/ORDINAL 'duplicate path occurrence';
            return 1
        };
        ivUnique[$ivPath]=1;
        [[ ${inventoryKind[ivIndex]} == directory || ${inventoryKind[ivIndex]} == file ]] || { 
            error::raise PATH/SEGMENT 'unknown entry kind';
            return 1
        };
        if ((ivIndex==0)); then
            ((ivParent==-1 && inventoryDepth[ivIndex]==0 && inventoryOrdinal[ivIndex]==0)) || { 
                error::raise PATH/ROOT 'root coordinate';
                return 1
            };
            continue;
        fi;
        ((ivParent>=0 && ivParent<ivIndex)) && [[ ${inventoryKind[ivParent]} == directory ]] || { 
            error::raise PATH/PARENT 'invalid parent index';
            return 1
        };
        [[ $ivPath == "${inventoryPath[ivParent]%/}/"* ]] || { 
            error::raise PATH/PARENT 'parent lexical prefix';
            return 1
        };
        ivRest=${ivPath#"${inventoryPath[ivParent]%/}/"};
        [[ -n $ivRest && $ivRest != */* ]] || { 
            error::raise PATH/PARENT 'not an immediate child';
            return 1
        };
        ((inventoryDepth[ivIndex]==inventoryDepth[ivParent]+1)) || { 
            error::raise PATH/DEPTH 'relative layer disagreement';
            return 1
        };
        ((inventoryOrdinal[ivIndex]==${ivCounts[$ivParent]:-0})) || { 
            error::raise PATH/ORDINAL 'sibling ordinal disagreement';
            return 1
        };
        if [[ -n ${ivLast[$ivParent]+yes} ]]; then
            [[ ${ivLast[$ivParent]} < $ivPath ]] || { 
                error::raise PATH/ORDINAL 'lexical sibling order';
                return 1
            };
        fi;
        ivCounts[$ivParent]=$((${ivCounts[$ivParent]:-0}+1));
        ivLast[$ivParent]=$ivPath;
    done;
    for ivIndex in "${!inventoryPath[@]}";
    do
        ((inventoryChildren[ivIndex]==${ivCounts[$ivIndex]:-0})) || { 
            error::raise PATH/ORDINAL 'directory ring child cardinality';
            return 1
        };
    done
}
