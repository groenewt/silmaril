text::utfEight () 
{ 
    local utText=$1 utChunk utOffset utIndex utByte utChar utNeed=0 utLow=128 utHigh=191 LC_ALL=C;
    for ((utOffset=0; utOffset<${#utText}; utOffset+=4096))
    do
        utChunk=${utText:utOffset:4096};
        if ((utNeed==0)) && [[ $utChunk != *['�'-'�']* ]]; then
            continue;
        fi;
        for ((utIndex=0; utIndex<${#utChunk}; utIndex+=1))
        do
            utChar=${utChunk:utIndex:1};
            printf -v utByte '%d' "'$utChar";
            if ((utNeed)); then
                ((utByte>=utLow && utByte<=utHigh)) || { 
                    error::raise ENCODING/INVALID 'invalid UTF8 continuation';
                    return 1
                };
                ((utNeed-=1));
                utLow=128 utHigh=191;
                continue;
            fi;
            if ((utByte<128)); then
                continue;
            else
                if ((utByte>=194 && utByte<=223)); then
                    utNeed=1;
                else
                    if ((utByte>=224 && utByte<=239)); then
                        utNeed=2;
                        if ((utByte==224)); then
                            utLow=160;
                        else
                            if ((utByte==237)); then
                                utHigh=159;
                            fi;
                        fi;
                    else
                        if ((utByte>=240 && utByte<=244)); then
                            utNeed=3;
                            if ((utByte==240)); then
                                utLow=144;
                            else
                                if ((utByte==244)); then
                                    utHigh=143;
                                fi;
                            fi;
                        else
                            error::raise ENCODING/INVALID 'invalid UTF8 leading octet';
                            return 1;
                        fi;
                    fi;
                fi;
            fi;
        done;
    done;
    ((utNeed==0)) || { 
        error::raise ENCODING/INVALID 'incomplete UTF8 scalar';
        return 1
    }
}
