byte::objectAt () 
{ 
    local streamIdentity=$1;
    local index=$2;
    local outputName=$3;
    local count=${byteStreamCount[$streamIdentity]:-$SILMARILZERO};
    [[ $index =~ ^[0-9]+$ ]] && (( index >= SILMARILZERO && index < count )) || { 
        engine::raise "$SILMARILERROROBJECT" 'byte object index';
        return "$SILMARILFAILURE"
    };
    local -n outputReference=$outputName;
    outputReference=${byteStreamObject[${streamIdentity}${SILMARILUS}${index}]}
}
