yaml::record () 
{ 
    local path=$1;
    local kind=$2;
    local value=${3-};
    local lineNumber=${4-};
    local key=${5-member};
    local parent=${6-$SILMARILYAMLROOT};
    local depth=${7-$SILMARILZERO};
    [[ ! -n ${yamlKind[$path]+present} ]] || { 
        engine::raise "$SILMARILERRORYAMLDUPLICATE" "$path";
        return "$SILMARILFAILURE"
    };
    yamlKind[$path]=$kind;
    yamlValue[$path]=$value;
    yamlLine[$path]=$lineNumber;
    yamlPaths+=("$path");
    local pairIdentity="urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:knowledge:kingdom:representation:phylum:yet:another:markup:language:class:pair:order:parse:family:key:value:genus:occurrence:species:pair:component:pair:instance:count${yamlPairCount}";
    local keyIdentity;
    yaml::keySpecimen "$key" keyIdentity;
    local rightIdentity=$value;
    if [[ -z $rightIdentity || ! $rightIdentity =~ ^urn:silmaril: ]]; then
        rightIdentity="urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:knowledge:kingdom:representation:phylum:yet:another:markup:language:class:value:order:parse:family:scalar:genus:occurrence:species:value:component:scalar:instance:count${yamlPairCount}";
    fi;
    yamlPairIdentity[$yamlPairCount]=$pairIdentity;
    yamlPairLeft[$yamlPairCount]=$keyIdentity;
    yamlPairRight[$yamlPairCount]=$rightIdentity;
    yamlPairParent[$yamlPairCount]=${yamlPathPair[$parent]-$SILMARILPAIRROOT};
    yamlPairDepth[$yamlPairCount]=$depth;
    yamlPathPair[$path]=$pairIdentity;
    (( yamlPairCount += SILMARILONE ))
}
