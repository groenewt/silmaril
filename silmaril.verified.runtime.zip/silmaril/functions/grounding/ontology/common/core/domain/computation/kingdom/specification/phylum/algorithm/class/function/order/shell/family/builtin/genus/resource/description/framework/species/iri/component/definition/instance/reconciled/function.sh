rdf::iri () 
{ 
    local rrString= rrChar rrClosed=0 rdfCharacter= rdfNull=0 rrResolved;
    ((rdfCursor+=1));
    while ((rdfCursor<${#rdfText})); do
        rrChar=${rdfText:rdfCursor:1};
        ((rdfCursor+=1));
        if [[ $rrChar == '>' ]]; then
            rrClosed=1;
            break;
        fi;
        if [[ $rrChar == '\' ]]; then
            [[ ${rdfText:rdfCursor:1} == [uU] ]] || { 
                rdf::error 'IRI escape';
                return 1
            };
            rdf::escape || return 1;
            ((rdfNull==0)) || { 
                rdf::error 'NUL in IRI';
                return 1
            };
            rrChar=$rdfCharacter;
        fi;
        [[ $rrChar != [\<\>\"\{\}\|\^\`\\] && $rrChar != [[:space:][:cntrl:]] ]] || { 
            rdf::error 'illegal IRI character';
            return 1
        };
        rrString+=$rrChar;
    done;
    ((rrClosed)) || { 
        rdf::error 'unterminated IRI';
        return 1
    };
    if [[ $rrString =~ ^[A-Za-z][A-Za-z0-9+.-]*: ]]; then
        rrResolved=$rrString;
    else
        [[ -n $rdfBase ]] || { 
            rdf::error 'relative IRI without base';
            return 1
        };
        uri::resolve "$rdfBase" "$rrString" rrResolved || return 1;
    fi;
    rdf::intern iri "$rrResolved"
}
