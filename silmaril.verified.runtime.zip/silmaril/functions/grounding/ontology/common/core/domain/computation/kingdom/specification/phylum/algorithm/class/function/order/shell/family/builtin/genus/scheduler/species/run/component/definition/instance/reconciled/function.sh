scheduler::run () 
{ 
    ((graphValidated==1)) || { 
        error::raise EXECUTION/DEPENDENCY 'unvalidated graph';
        return 1
    };
    [[ $schedulerParallel =~ ^(0|[1-9][0-9]{0,9})$ && $schedulerRetry =~ ^(0|[1-9][0-9]{0,9})$ && $schedulerTimeout =~ ^(0|[1-9][0-9]{0,9})$ ]] || return 1;
    ((schedulerParallel>=1 && schedulerParallel<=64 && schedulerRetry<=16 && schedulerTimeout<=3600000000)) || { 
        error::raise EXECUTION/CAPABILITY 'scheduler limit';
        return 1
    };
    [[ $schedulerDisposition == abort || $schedulerDisposition == continue || $schedulerDisposition == skip ]] || return 1;
    [[ $schedulerRollback == 0 || $schedulerRollback == 1 ]] || return 1;
    schedulerParent=$BASHPID;
    schedulerCommit=();
    schedulerRolled=();
    schedulerState=();
    schedulerAttempts=();
    schedulerDepth=();
    nodeOutput=();
    nodeFrame=();
    nodeInput=();
    nodeInputCount=();
    graphFailureFrame=;
    graphStatus=$SILMARILSTATUSSUCCESS;
    local sxNode sxPred sxLevel=0 sxMax=0 sxD sxI sxJ sxFrame= sxFailed=0 sxAbort=0 sxAttempt sxFd sxPid sxStart sxErr=;
    local -a sxReady=() sxFds=() sxPids=() sxStarts=();
    for sxNode in "${graphOrder[@]}";
    do
        sxD=0;
        for sxPred in "${graphNodes[@]}";
        do
            [[ -n ${graphAdjacency[$sxPred$SILMARILUS$sxNode]+present} ]] || continue;
            (( ${schedulerDepth[$sxPred]:-0}+1 <= sxD )) || sxD=$((${schedulerDepth[$sxPred]:-0}+1));
        done;
        schedulerDepth[$sxNode]=$sxD;
        ((sxD<=sxMax)) || sxMax=$sxD;
        schedulerState[$sxNode]=pending;
        schedulerAttempts[$sxNode]=0;
        if [[ -n ${schedulerRestored[$sxNode]-} ]]; then
            nodeOutput[$sxNode]=${schedulerRestored[$sxNode]};
            schedulerState[$sxNode]=success;
            schedulerCommit+=("$sxNode");
        fi;
    done;
    for ((sxLevel=0; sxLevel<=sxMax; sxLevel++))
    do
        ((sxAbort==0)) || break;
        sxReady=();
        for sxNode in "${graphOrder[@]}";
        do
            [[ ${schedulerState[$sxNode]} == pending && ${schedulerDepth[$sxNode]} == "$sxLevel" ]] || continue;
            if scheduler::inputs "$sxNode"; then
                sxReady+=("$sxNode");
            else
                schedulerState[$sxNode]=blocked;
                sxFailed=1;
            fi;
        done;
        for ((sxI=0; sxI<${#sxReady[@]}; sxI+=schedulerParallel))
        do
            ((sxAbort==0)) || break;
            sxFds=();
            sxPids=();
            sxStarts=();
            for ((sxJ=sxI; sxJ<${#sxReady[@]} && sxJ<sxI+schedulerParallel; sxJ++))
            do
                sxNode=${sxReady[$sxJ]};
                schedulerState[$sxNode]=running;
                schedulerAttempts[$sxNode]=1;
                scheduler::clock sxStart || return 1;
                scheduler::launch "$sxNode" "$SILMARILMETHODRUN" 1 sxFd sxPid || return 1;
                sxFds+=("$sxFd");
                sxPids+=("$sxPid");
                sxStarts+=("$sxStart");
            done;
            for ((sxJ=0; sxJ<${#sxFds[@]}; sxJ++))
            do
                sxNode=${sxReady[$((sxI+sxJ))]};
                sxAttempt=1;
                sxFrame=;
                while ! scheduler::receive "${sxFds[$sxJ]}" "${sxPids[$sxJ]}" "${sxStarts[$sxJ]}" sxFrame; do
                    ((sxAttempt<=schedulerRetry)) || break;
                    ((sxAttempt+=1));
                    schedulerAttempts[$sxNode]=$sxAttempt;
                    scheduler::clock sxStart || return 1;
                    scheduler::launch "$sxNode" "$SILMARILMETHODRUN" "$sxAttempt" sxFd sxPid || return 1;
                    sxFds[$sxJ]=$sxFd;
                    sxPids[$sxJ]=$sxPid;
                    sxStarts[$sxJ]=$sxStart;
                done;
                nodeFrame[$sxNode]=$sxFrame;
                if [[ -n $sxFrame && ${frameStatus[$sxFrame]-} == "$SILMARILSTATUSSUCCESS" ]]; then
                    nodeOutput[$sxNode]=${frameOutput[$sxFrame]};
                    schedulerState[$sxNode]=success;
                    schedulerCommit+=("$sxNode");
                else
                    schedulerState[$sxNode]=failure;
                    sxFailed=1;
                    sxErr=$engineError;
                    graphFailureFrame=$sxFrame;
                    [[ $schedulerDisposition != abort ]] || sxAbort=1;
                fi;
            done;
        done;
    done;
    for sxNode in "${graphNodes[@]}";
    do
        [[ ${schedulerState[$sxNode]} != pending ]] || schedulerState[$sxNode]=blocked;
    done;
    if ((sxFailed)); then
        graphStatus=$SILMARILSTATUSFAILURE;
        if ((schedulerRollback)); then
            scheduler::compensate || return 1;
        fi;
        engineError=${sxErr:-${errorRegistry[EXECUTION/DEPENDENCY]}};
        return 1;
    fi;
    graphStatus=$SILMARILSTATUSSUCCESS;
    engine::clearError
}
