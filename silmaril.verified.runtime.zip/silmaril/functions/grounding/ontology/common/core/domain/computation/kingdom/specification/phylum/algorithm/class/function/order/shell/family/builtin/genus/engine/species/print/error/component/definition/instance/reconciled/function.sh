engine::printError () 
{ 
    [[ -z $engineError ]] || printf 'ERROR: %s\nDETAIL: %s\n' "$engineError" "$engineDetail" 1>&2
}
