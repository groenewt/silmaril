object::set () 
{ 
    local identity=$1;
    local field=$2;
    local value=$3;
    object::exists "$identity" && object::exists "$value" || { 
        engine::raise "$SILMARILERROROBJECT" "$identity or $value";
        return "$SILMARILFAILURE"
    };
    [[ ${fieldDefined[$field]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERRORFIELD" "$field";
        return "$SILMARILFAILURE"
    };
    local identityType=${objectType[$identity]};
    local owner=${fieldOwner[$field]};
    local expected=${fieldValueType[$field]};
    local valueType=${objectType[$value]};
    type::isSubtype "$identityType" "$owner" || { 
        engine::raise "$SILMARILERRORFIELD" 'owner type';
        return "$SILMARILFAILURE"
    };
    type::isSubtype "$valueType" "$expected" || { 
        engine::raise "$SILMARILERRORFIELD" 'value type';
        return "$SILMARILFAILURE"
    };
    local key="${identity}${SILMARILUS}${field}";
    local count=${objectFieldCount[$key]:-$SILMARILZERO};
    local cardinality=${fieldCardinality[$field]};
    if [[ $cardinality != "$SILMARILCARDINALITYMANY" && $count -ge $SILMARILONE ]]; then
        engine::raise "$SILMARILERRORFIELD" 'cardinality exceeded';
        return "$SILMARILFAILURE";
    fi;
    objectFieldValue[${key}${SILMARILUS}${count}]=$value;
    objectFieldCount[$key]=$(( count + SILMARILONE ))
}
