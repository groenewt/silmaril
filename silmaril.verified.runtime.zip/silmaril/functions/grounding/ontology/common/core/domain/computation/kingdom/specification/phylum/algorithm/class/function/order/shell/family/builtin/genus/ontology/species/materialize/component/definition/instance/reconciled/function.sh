ontology::materialize () 
{ 
    local identity;
    for identity in "${typeOrder[@]}";
    do
        object::new "$identity" "$SILMARILTYPETYPE" || return "$SILMARILFAILURE";
    done;
    for identity in "${definitionOrder[@]}";
    do
        object::new "$identity" "$SILMARILTYPEDEFINITION" || return "$SILMARILFAILURE";
    done;
    for identity in "${axiomOrder[@]}";
    do
        object::new "$identity" "$SILMARILTYPEAXIOM" || return "$SILMARILFAILURE";
    done;
    local count;
    local index;
    local value;
    for identity in "${typeOrder[@]}";
    do
        object::set "$identity" "$SILMARILFIELDDEFINITION" "${typeDefinition[$identity]}" || return "$SILMARILFAILURE";
        count=${typeParentCount[$identity]:-$SILMARILZERO};
        for ((index = SILMARILZERO; index < count; index += SILMARILONE ))
        do
            value=${typeParent[${identity}${SILMARILUS}${index}]};
            object::set "$identity" "$SILMARILFIELDPARENT" "$value" || return "$SILMARILFAILURE";
        done;
        count=${typeAxiomCount[$identity]:-$SILMARILZERO};
        for ((index = SILMARILZERO; index < count; index += SILMARILONE ))
        do
            value=${typeAxiom[${identity}${SILMARILUS}${index}]};
            object::set "$identity" "$SILMARILFIELDAXIOM" "$value" || return "$SILMARILFAILURE";
        done;
    done;
    for identity in "${axiomOrder[@]}";
    do
        object::set "$identity" "$SILMARILFIELDDOMAIN" "${axiomDomain[$identity]}" || return "$SILMARILFAILURE";
    done
}
