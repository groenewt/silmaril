engine::sealDefinitions () 
{ 
    local functionNames;
    functionNames=$(compgen -A function);
    local functionName;
    while IFS= read -r functionName; do
        case $functionName in 
            homology::* | analysis::* | manifest::* | inventory::* | source::* | text::* | import::* | wide::* | shape::* | rdf::* | uri::* | urn::* | hash::* | pair::* | semantics::* | projection::* | grounding::* | algebra::* | topology::* | geometry::* | reference::* | checkpoint::* | scheduler::* | unicode::* | yoneda::* | presentation::* | kv::* | name::* | number::* | error::* | category::* | model::* | natural::* | elements::* | coend::* | finite::* | request::* | publication::* | schema::* | authority::* | byte::* | dispatch::* | engine::* | field::* | frame::* | graph::* | identity::* | method::* | node::* | object::* | ontology::* | path::* | receipt::* | runtime::* | runtimeconfig::* | string::* | type::* | value::* | yaml::*)
                runtimeTrusted[$functionName]=$SILMARILONE;
                readonly -f "$functionName"
            ;;
        esac;
    done <<< "$functionNames";
    runtimeCallable[object::get]=$SILMARILONE;
    runtimeCallable[object::getCount]=$SILMARILONE;
    runtimeCallable[object::getAt]=$SILMARILONE;
    runtimeCallable[object::call]=$SILMARILONE;
    runtimeCallable[object::callNext]=$SILMARILONE;
    runtimeCallable[type::isSubtype]=$SILMARILONE;
    runtimeCallable[frame::success]=$SILMARILONE;
    runtimeCallable[frame::failure]=$SILMARILONE;
    runtimeCallable[frame::forward]=$SILMARILONE;
    runtimeCallable[value::ensureSymbol]=$SILMARILONE;
    runtimeCallable[byte::count]=$SILMARILONE;
    runtimeCallable[byte::at]=$SILMARILONE;
    runtimeCallable[byte::objectAt]=$SILMARILONE
}
