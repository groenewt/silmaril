shape::error () 
{ 
    shapeFailure=1;
    shapeDetail=$*;
    error::raise PROJECTION/FIDELITY "SHACL profile failure: $*";
    return 2
}
