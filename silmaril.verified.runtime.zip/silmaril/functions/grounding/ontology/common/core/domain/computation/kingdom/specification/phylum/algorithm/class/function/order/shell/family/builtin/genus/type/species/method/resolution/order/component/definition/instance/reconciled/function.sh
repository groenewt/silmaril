type::mro () 
{ 
    local identity=$1;
    local outputName=$2;
    local -n outputReference=$outputName;
    type::exists "$identity" || { 
        engine::raise "$SILMARILERRORTYPE" "$identity";
        return "$SILMARILFAILURE"
    };
    outputReference=();
    local remaining=${typeMro[$identity]};
    local token;
    while [[ -n $remaining ]]; do
        type::sequenceHead "$remaining" token;
        outputReference+=("$token");
        type::sequenceTail "$remaining" remaining;
    done
}
