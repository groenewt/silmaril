import::chain () 
{ 
    local ipPrevious= ipCurrent ipExpected ipFound ipParent ipType;
    local -A ipSeen=();
    (($#>0)) || { 
        error::raise GROUNDING/MISSING 'empty imported chain';
        return 1
    };
    for ipExpected in "$@";
    do
        [[ ! -n ${ipSeen[$ipExpected]+yes} ]] || { 
            error::raise GROUNDING/CONTRADICTORY 'repeated imported class';
            return 1
        };
        ipSeen[$ipExpected]=1;
        import::term "$ipExpected" || return 1;
        ipCurrent=$importTerm;
        rdf::objects "$ipCurrent" "${RDFNS}type" "$importGraph";
        ipFound=0;
        for ipType in "${rdfValues[@]}";
        do
            [[ ${rdfTerm[ipType]} != http://www.w3.org/2002/07/owl#Class ]] || ipFound=1;
        done;
        ((ipFound)) || { 
            error::raise GROUNDING/MISSING "class declaration absent: $ipExpected";
            return 1
        };
        if [[ -n $ipPrevious ]]; then
            rdf::objects "$ipPrevious" "${RDFSNS}subClassOf" "$importGraph";
            ipFound=0;
            for ipParent in "${rdfValues[@]}";
            do
                [[ $ipParent != "$ipCurrent" ]] || ipFound=1;
            done;
            ((ipFound)) || { 
                error::raise GROUNDING/CONTRADICTORY "missing named superclass edge: $ipExpected";
                return 1
            };
        fi;
        ipPrevious=$ipCurrent;
    done
}
