shape::node () 
{ 
    local snFocus=$1 snShape=$2 snPath= snParameter snConstraint snValue snIndex snCheck snType snActive="$1,$2" snStart=${#shapeResultFocus[@]} snItem snList snCount snMatched snStatus snBefore;
    local -a snValues=() snParameters=() snShapes=() snMembers=() snOther=();
    local -A snAllowed=() snLanguages=();
    ((shapeDepth+=1));
    ((shapeDepth<=shapeMaximumDepth)) || { 
        shape::error 'shape nesting capacity';
        return 2
    };
    [[ ! -n ${shapeActive[$snActive]+yes} ]] || { 
        shape::error 'recursive shape not in admitted profile';
        return 2
    };
    shapeActive[$snActive]=1;
    shape::single "$snShape" deactivated || return 2;
    if [[ -n $shapeParameter ]]; then
        [[ ${rdfDatatype[shapeParameter]} == "${XSDNS}boolean" && ${rdfTerm[shapeParameter]} =~ ^(true|false|0|1)$ ]] || { 
            shape::error 'deactivated boolean';
            return 2
        };
        if [[ ${rdfTerm[shapeParameter]} == true || ${rdfTerm[shapeParameter]} == 1 ]]; then
            unset 'shapeActive[$snActive]';
            ((shapeDepth-=1));
            return 0;
        fi;
    fi;
    shape::single "$snShape" path || return 2;
    snPath=$shapeParameter;
    if [[ -n $snPath ]]; then
        shape::path "$snFocus" "$snPath" || return 2;
        snValues=("${shapePathValues[@]}");
    else
        snValues=("$snFocus");
    fi;
    for snIndex in "${!rdfSubject[@]}";
    do
        [[ ${rdfGraph[snIndex]} == "$shapeShapesGraph" && ${rdfSubject[snIndex]} == "$snShape" ]] || continue;
        snConstraint=${rdfTerm[${rdfPredicate[snIndex]}]};
        snParameter=${rdfObject[snIndex]};
        [[ $snConstraint == "$SHNS"* ]] || continue;
        snConstraint=${snConstraint#"$SHNS"};
        case $snConstraint in 
            path | deactivated | targetNode | targetClass | targetSubjectsOf | targetObjectsOf | name | description | message | severity | order | group | ignoredProperties)
                continue
            ;;
            minCount | maxCount)
                [[ -n $snPath ]] || { 
                    shape::error 'count constraint on node shape';
                    return 2
                };
                shape::number "$snParameter" || return 2;
                if { 
                    [[ $snConstraint == minCount ]] && ((${#snValues[@]}<shapeNumber))
                } || { 
                    [[ $snConstraint == maxCount ]] && ((${#snValues[@]}>shapeNumber))
                }; then
                    shape::result "$snFocus" "$snShape" "$snPath" "$snConstraint";
                fi
            ;;
            property)
                for snValue in "${snValues[@]}";
                do
                    shape::single "$snParameter" path || return 2;
                    [[ -n $shapeParameter ]] || { 
                        shape::error 'property shape without path';
                        return 2
                    };
                    shape::node "$snValue" "$snParameter" || { 
                        snStatus=$?;
                        ((snStatus==1)) || return 2
                    };
                done
            ;;
            node | not)
                for snValue in "${snValues[@]}";
                do
                    snBefore=${#shapeResultFocus[@]};
                    snStatus=0;
                    shape::node "$snValue" "$snParameter" || snStatus=$?;
                    ((snStatus!=2)) || return 2;
                    shapeResultFocus=("${shapeResultFocus[@]:0:snBefore}");
                    shapeResultShape=("${shapeResultShape[@]:0:snBefore}");
                    shapeResultPath=("${shapeResultPath[@]:0:snBefore}");
                    shapeResultConstraint=("${shapeResultConstraint[@]:0:snBefore}");
                    shapeResultValue=("${shapeResultValue[@]:0:snBefore}");
                    if [[ $snConstraint == not ]]; then
                        ((snStatus!=0)) || shape::result "$snFocus" "$snShape" "$snPath" not "$snValue";
                    else
                        ((snStatus!=1)) || shape::result "$snFocus" "$snShape" "$snPath" node "$snValue";
                    fi;
                done
            ;;
            and | or | xone)
                shape::list "$snParameter" || return 2;
                snShapes=("${shapeList[@]}");
                for snValue in "${snValues[@]}";
                do
                    snMatched=0;
                    for snItem in "${snShapes[@]}";
                    do
                        snBefore=${#shapeResultFocus[@]};
                        snStatus=0;
                        shape::node "$snValue" "$snItem" || snStatus=$?;
                        ((snStatus!=2)) || return 2;
                        ((snStatus!=0)) || ((snMatched+=1));
                        shapeResultFocus=("${shapeResultFocus[@]:0:snBefore}");
                        shapeResultShape=("${shapeResultShape[@]:0:snBefore}");
                        shapeResultPath=("${shapeResultPath[@]:0:snBefore}");
                        shapeResultConstraint=("${shapeResultConstraint[@]:0:snBefore}");
                        shapeResultValue=("${shapeResultValue[@]:0:snBefore}");
                    done;
                    snCheck=0;
                    case $snConstraint in 
                        and)
                            ((snMatched==${#snShapes[@]})) && snCheck=1
                        ;;
                        or)
                            ((snMatched>0)) && snCheck=1
                        ;;
                        xone)
                            ((snMatched==1)) && snCheck=1
                        ;;
                    esac;
                    ((snCheck)) || shape::result "$snFocus" "$snShape" "$snPath" "$snConstraint" "$snValue";
                done
            ;;
            hasValue)
                snMatched=0;
                for snValue in "${snValues[@]}";
                do
                    [[ $snValue != "$snParameter" ]] || snMatched=1;
                done;
                ((snMatched)) || shape::result "$snFocus" "$snShape" "$snPath" hasValue "$snParameter"
            ;;
            in)
                shape::list "$snParameter" || return 2;
                snMembers=("${shapeList[@]}");
                for snValue in "${snValues[@]}";
                do
                    snMatched=0;
                    for snItem in "${snMembers[@]}";
                    do
                        [[ $snValue != "$snItem" ]] || snMatched=1;
                    done;
                    ((snMatched)) || shape::result "$snFocus" "$snShape" "$snPath" in "$snValue";
                done
            ;;
            nodeKind | class | datatype)
                for snValue in "${snValues[@]}";
                do
                    snStatus=0;
                    case $snConstraint in 
                        nodeKind)
                            shape::kind "$snValue" "$snParameter" || snStatus=$?
                        ;;
                        class)
                            shape::instance "$snValue" "$snParameter" || snStatus=$?
                        ;;
                        datatype)
                            shape::datatype "$snValue" "$snParameter" || snStatus=$?
                        ;;
                    esac;
                    ((snStatus!=2)) || return 2;
                    ((snStatus==0)) || shape::result "$snFocus" "$snShape" "$snPath" "$snConstraint" "$snValue";
                done
            ;;
            closed)
                [[ ${rdfDatatype[snParameter]} == "${XSDNS}boolean" && ${rdfTerm[snParameter]} =~ ^(true|false|0|1)$ ]] || { 
                    shape::error 'closed boolean';
                    return 2
                };
                [[ ${rdfTerm[snParameter]} == true || ${rdfTerm[snParameter]} == 1 ]] || continue;
                snAllowed=();
                shape::property "$snShape" property;
                snShapes=("${rdfValues[@]}");
                for snItem in "${snShapes[@]}";
                do
                    shape::single "$snItem" path || return 2;
                    if [[ -n $shapeParameter && ${rdfKind[shapeParameter]} == iri ]]; then
                        snAllowed[$shapeParameter]=1;
                    fi;
                done;
                shape::single "$snShape" ignoredProperties || return 2;
                if [[ -n $shapeParameter ]]; then
                    shape::list "$shapeParameter" || return 2;
                    for snItem in "${shapeList[@]}";
                    do
                        snAllowed[$snItem]=1;
                    done;
                fi;
                for snValue in "${snValues[@]}";
                do
                    for snItem in "${!rdfSubject[@]}";
                    do
                        if [[ ${rdfGraph[snItem]} == "$shapeDataGraph" && ${rdfSubject[snItem]} == "$snValue" && ! -n ${snAllowed[${rdfPredicate[snItem]}]+yes} ]]; then
                            shape::result "$snValue" "$snShape" "${rdfPredicate[snItem]}" closed "${rdfObject[snItem]}";
                        fi;
                    done;
                done
            ;;
            equals | disjoint)
                [[ ${rdfKind[snParameter]} == iri ]] || { 
                    shape::error 'comparison path not IRI';
                    return 2
                };
                rdf::objects "$snFocus" "${rdfTerm[snParameter]}" "$shapeDataGraph";
                snOther=("${rdfValues[@]}");
                for snValue in "${snValues[@]}";
                do
                    snMatched=0;
                    for snItem in "${snOther[@]}";
                    do
                        [[ $snValue != "$snItem" ]] || snMatched=1;
                    done;
                    if { 
                        [[ $snConstraint == equals ]] && ((snMatched==0))
                    } || { 
                        [[ $snConstraint == disjoint ]] && ((snMatched))
                    }; then
                        shape::result "$snFocus" "$snShape" "$snPath" "$snConstraint" "$snValue";
                    fi;
                done;
                if [[ $snConstraint == equals ]]; then
                    for snValue in "${snOther[@]}";
                    do
                        snMatched=0;
                        for snItem in "${snValues[@]}";
                        do
                            [[ $snValue != "$snItem" ]] || snMatched=1;
                        done;
                        ((snMatched)) || shape::result "$snFocus" "$snShape" "$snPath" equals "$snValue";
                    done;
                fi
            ;;
            *)
                shape::error "unsupported constraint $snConstraint";
                return 2
            ;;
        esac;
    done;
    unset 'shapeActive[$snActive]';
    ((shapeDepth-=1));
    ((${#shapeResultFocus[@]}==snStart))
}
