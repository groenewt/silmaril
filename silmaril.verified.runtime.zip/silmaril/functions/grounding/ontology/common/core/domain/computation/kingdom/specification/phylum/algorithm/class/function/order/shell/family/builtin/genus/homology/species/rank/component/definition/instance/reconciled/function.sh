homology::rank () 
{ 
    local hrRows=$1 hrColumns=$2 hrInput=$3 hrPrime=$4 hrOutput=$5;
    local -n hrValues=$hrInput;
    local -a hrWork=("${hrValues[@]}");
    local hrRank=$SILANALYSISZERO hrColumn hrPivot hrRow hrIndex hrTemporary hrInverse hrFactor;
    for ((hrColumn=SILANALYSISZERO; hrColumn<hrColumns && hrRank<hrRows; hrColumn+=SILANALYSISONE))
    do
        hrPivot=$hrRank;
        while ((hrPivot<hrRows)) && ((hrWork[hrPivot*hrColumns+hrColumn]==SILANALYSISZERO)); do
            ((hrPivot+=SILANALYSISONE));
        done;
        ((hrPivot<hrRows)) || continue;
        for ((hrIndex=SILANALYSISZERO; hrIndex<hrColumns; hrIndex+=SILANALYSISONE))
        do
            hrTemporary=${hrWork[hrRank*hrColumns+hrIndex]};
            hrWork[hrRank*hrColumns+hrIndex]=${hrWork[hrPivot*hrColumns+hrIndex]};
            hrWork[hrPivot*hrColumns+hrIndex]=$hrTemporary;
        done;
        homology::inverse "${hrWork[hrRank*hrColumns+hrColumn]}" "$hrPrime" hrInverse;
        for ((hrIndex=hrColumn; hrIndex<hrColumns; hrIndex+=SILANALYSISONE))
        do
            hrWork[hrRank*hrColumns+hrIndex]=$((hrWork[hrRank*hrColumns+hrIndex]*hrInverse%hrPrime));
        done;
        for ((hrRow=hrRank+SILANALYSISONE; hrRow<hrRows; hrRow+=SILANALYSISONE))
        do
            hrFactor=${hrWork[hrRow*hrColumns+hrColumn]};
            for ((hrIndex=hrColumn; hrIndex<hrColumns; hrIndex+=SILANALYSISONE))
            do
                hrWork[hrRow*hrColumns+hrIndex]=$(((hrWork[hrRow*hrColumns+hrIndex]-hrFactor*hrWork[hrRank*hrColumns+hrIndex])%hrPrime));
                ((hrWork[hrRow*hrColumns+hrIndex]>=SILANALYSISZERO)) || ((hrWork[hrRow*hrColumns+hrIndex]+=hrPrime));
            done;
        done;
        ((hrRank+=SILANALYSISONE));
    done;
    printf -v "$hrOutput" '%s' "$hrRank"
}
