rdf::escape () 
{ 
    local reCode=${rdfText:rdfCursor:1} reWidth reDigits reNumber reEscape;
    ((rdfCursor+=1));
    rdfCharacter= rdfNull=0;
    case $reCode in 
        t)
            rdfCharacter='	'
        ;;
        b)
            rdfCharacter=''
        ;;
        n)
            rdfCharacter='
'
        ;;
        r)
            rdfCharacter=''
        ;;
        f)
            rdfCharacter=''
        ;;
        '"' | "'" | '\')
            rdfCharacter=$reCode
        ;;
        u | U)
            reWidth=4;
            [[ $reCode != U ]] || reWidth=8;
            reDigits=${rdfText:rdfCursor:reWidth};
            [[ ${#reDigits} == "$reWidth" && $reDigits != *[!0123456789abcdefABCDEF]* ]] || { 
                rdf::error 'malformed Unicode escape';
                return 1
            };
            reNumber=$((16#$reDigits));
            ((rdfCursor+=reWidth));
            ((reNumber<=1114111 && (reNumber<55296 || reNumber>57343))) || { 
                rdf::error 'non scalar Unicode escape';
                return 1
            };
            if ((reNumber==0)); then
                rdfNull=1;
            else
                printf -v reEscape '\\U%08x' "$reNumber";
                printf -v rdfCharacter '%b' "$reEscape";
            fi
        ;;
        *)
            rdf::error 'unknown character escape';
            return 1
        ;;
    esac
}
