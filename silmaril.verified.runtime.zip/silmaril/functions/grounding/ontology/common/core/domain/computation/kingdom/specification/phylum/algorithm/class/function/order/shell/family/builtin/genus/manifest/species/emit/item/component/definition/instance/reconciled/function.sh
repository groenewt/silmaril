manifest::emitItem () 
{ 
    local miIndex=$1 miIndent=$2 miPath miCount meCurrentDigest=${meDigests[$1]};
    path::identify "${mePaths[miIndex]}" miPath || return 1;
    number::reference "${meSizes[miIndex]}" miCount;
    printf '%*sITEM:\n' "$miIndent" '';
    ((miIndent+=2));
    printf '%*sIDENTITY: %s\n%*sSOURCE: %s\n%*sCOUNT: %s\n%*sDIGEST:\n' "$miIndent" '' "$miPath" "$miIndent" '' "$miPath" "$miIndent" '' "$miCount" "$miIndent" '';
    publication::vector 32 "$((miIndent+2))" manifest::digestItem
}
