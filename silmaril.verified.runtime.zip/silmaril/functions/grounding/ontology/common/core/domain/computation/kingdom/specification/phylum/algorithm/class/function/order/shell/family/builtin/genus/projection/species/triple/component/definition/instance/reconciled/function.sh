projection::triple () 
{ 
    printf '<%s> <%s> <%s> .\n' "$1" "$2" "$3"
}
