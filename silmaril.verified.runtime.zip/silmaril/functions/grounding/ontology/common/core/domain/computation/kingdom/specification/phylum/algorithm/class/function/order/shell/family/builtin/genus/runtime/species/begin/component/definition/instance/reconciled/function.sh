runtime::begin () 
{ 
    (( runtimeActive == SILMARILZERO )) || { 
        engine::raise "$SILMARILERRORRUNTIMEESCAPE" 'guard already active';
        return "$SILMARILFAILURE"
    };
    runtimeHadErrexit=0;
    [[ $- != *e* ]] || runtimeHadErrexit=1;
    runtimeSavedErrAction=$(trap -p ERR);
    runtimeErrWasSet=0;
    if [[ -n $runtimeSavedErrAction ]]; then
        runtimeErrWasSet=1;
        local trapPrefix="trap -- '" trapSuffix="' ERR" trapQuote="'\\''";
        [[ $runtimeSavedErrAction == "$trapPrefix"*"$trapSuffix" ]] || { 
            engine::raise "$SILMARILERRORRUNTIMEESCAPE" 'unexpected ERR representation';
            return 1
        };
        runtimeSavedErrAction=${runtimeSavedErrAction#"$trapPrefix"};
        runtimeSavedErrAction=${runtimeSavedErrAction%"$trapSuffix"};
        runtimeSavedErrAction=${runtimeSavedErrAction//"$trapQuote"/"'"};
    fi;
    trap - ERR;
    set +e;
    runtimeViolation=;
    runtimeViolationCommand=;
    runtimeOwner=${FUNCNAME[1]-main};
    if shopt -q extdebug; then
        runtimeHadExtdebug=$SILMARILONE;
    else
        runtimeHadExtdebug=$SILMARILZERO;
    fi;
    if [[ $- == *T* ]]; then
        runtimeHadFunctrace=$SILMARILONE;
    else
        runtimeHadFunctrace=$SILMARILZERO;
    fi;
    shopt -s extdebug;
    set -T;
    trap 'runtime::debug' DEBUG;
    runtimeActive=$SILMARILONE
}
