manifest::digestItem () 
{ 
    local mdIndex=$1 mdIndent=$2 mdByte mdRef;
    mdByte=$((16#${meCurrentDigest:mdIndex*2:2}));
    number::reference "$mdByte" mdRef;
    printf '%*sITEM: %s\n' "$mdIndent" '' "$mdRef"
}
