kv::check () 
{ 
    local kcPath kcParent;
    for kcPath in "${kvPaths[@]}";
    do
        kcParent=${kcPath%/*};
        [[ -n ${kvPair[$kcPath]-} && -n ${kvBinding[$kcPath]-} && -n ${kvSubject[$kcPath]-} && -n ${kvPredicate[$kcPath]-} && -n ${kvRight[$kcPath]-} ]] || { 
            error::raise PAIR/SUBJECT "$kcPath";
            return 1
        };
        [[ ${kvSubject[$kcPath]} == "${kvMap[$kcParent]}" ]] || { 
            error::raise PAIR/SUBJECT "$kcPath";
            return 1
        };
    done
}
