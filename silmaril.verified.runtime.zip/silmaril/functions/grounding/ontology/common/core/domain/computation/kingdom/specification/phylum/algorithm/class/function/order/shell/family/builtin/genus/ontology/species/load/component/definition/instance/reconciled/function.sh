ontology::load () 
{ 
    local path=$1;
    yaml::parse "$path" || return "$SILMARILFAILURE";
    yaml::assertOnlyKeys "$SILMARILYAMLROOT" IDENTITY ANCHORS DEFINITIONS AXIOMS TYPES || return "$SILMARILFAILURE";
    yaml::requiredScalar "$SILMARILYAMLROOT" IDENTITY ontologyIdentity || return "$SILMARILFAILURE";
    identity::requireRankedUrn "$ontologyIdentity" ontology || return "$SILMARILFAILURE";
    ontology::loadAnchors || return "$SILMARILFAILURE";
    ontology::loadDefinitions || return "$SILMARILFAILURE";
    ontology::loadAxioms || return "$SILMARILFAILURE";
    ontology::loadTypes || return "$SILMARILFAILURE"
}
