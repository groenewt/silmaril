publication::frame () 
{ 
    local pfFrame=$1 pfIdentity=$2;
    printf 'IDENTITY: %s\nTYPE: %s\nSTATUS: %s\nOUTPUT: %s\nEFFECT: %s\nERROR: %s\n' "$pfIdentity" "$SILMARILTYPEFRAME" "${frameStatus[$pfFrame]}" "${frameOutput[$pfFrame]}" "${frameEffect[$pfFrame]}" "${frameError[$pfFrame]}"
}
