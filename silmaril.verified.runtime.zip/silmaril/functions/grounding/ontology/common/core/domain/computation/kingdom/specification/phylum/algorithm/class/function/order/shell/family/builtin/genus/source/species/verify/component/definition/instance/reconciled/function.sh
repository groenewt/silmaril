source::verify () 
{ 
    local saRoot=$1 saFunction saEntry saExpected saCount=0;
    sourceVerified=0;
    path::requireSafe "$saRoot" || return 1;
    [[ -d $saRoot ]] || { 
        error::raise PATH/ROOT 'source projection root';
        return 1
    };
    for saFunction in "${!runtimeTrusted[@]}";
    do
        [[ -n ${sourcePath[$saFunction]+yes} ]] || { 
            error::raise PROJECTION/FIDELITY "missing function registration: $saFunction";
            return 1
        };
        saExpected=${sourceIdentity[$saFunction]#"$SILMARILROOT:"};
        saExpected=functions/${saExpected//:/\/}/function.sh;
        [[ ${sourcePath[$saFunction]} == "$saExpected" ]] || { 
            error::raise PATH/ROUND/TRIP 'function identity and projection path disagree';
            return 1
        };
        source::verifyFile "$saFunction" "$saRoot/${sourcePath[$saFunction]}" || return 1;
        ((saCount+=1));
    done;
    ((${#sourcePath[@]}==saCount)) || { 
        error::raise PROJECTION/FIDELITY 'surplus function projection';
        return 1
    };
    sourceVerified=$saCount
}
