kv::capture::reset () 
{ 
    kvCaptureVerified=$SILCAPTUREZERO;
    kvCaptureCount=$SILCAPTUREZERO;
    kvCaptureReceipt=;
    kvCaptureObservation=;
    kvCaptureDigest=;
    kvCaptureSource=
}
