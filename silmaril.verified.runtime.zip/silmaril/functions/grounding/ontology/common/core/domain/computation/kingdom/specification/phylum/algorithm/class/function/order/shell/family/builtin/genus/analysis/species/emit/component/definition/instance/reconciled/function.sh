analysis::emit () 
{ 
    local aeVertices aeEdges aeComponents aeCycles aeLength aeState=$SILMARILFALSE;
    ((analysisVerified==SILANALYSISONE && analysisAcyclic==SILANALYSISONE)) || { 
        error::raise PROJECTION/FIDELITY 'DAG analysis certificate not established';
        return "$SILANALYSISONE"
    };
    number::reference "$analysisVertexCount" aeVertices;
    number::reference "$analysisEdgeCount" aeEdges;
    number::reference "$analysisComponents" aeComponents;
    number::reference "$analysisCycles" aeCycles;
    number::reference "$analysisCriticalEdges" aeLength;
    aeState=$SILMARILTRUE;
    printf 'IDENTITY: %s\nTYPE: %s\nGRAPH:\n  IDENTITY: %s\nACYCLIC: %s\nVERTICES:\n  COUNT: %s\nEDGES:\n  COUNT: %s\nCOMPONENTS:\n  COUNT: %s\nCYCLES:\n  COUNT: %s\nCRITICAL:\n  LENGTH: %s\nMETADATA:\n  SHORT:\n    DESCRIPTION: "Directed acyclicity, undirected first Betti number, and unit-edge critical length are separate measurements."\n' "$graphIdentity:component:structural:analysis:instance:current" "$SILANALYSISTYPE" "$graphIdentity" "$aeState" "$aeVertices" "$aeEdges" "$aeComponents" "$aeCycles" "$aeLength"
}
