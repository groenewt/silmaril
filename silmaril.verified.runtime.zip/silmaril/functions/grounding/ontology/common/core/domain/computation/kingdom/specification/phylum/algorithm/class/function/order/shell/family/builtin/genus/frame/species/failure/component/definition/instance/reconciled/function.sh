frame::failure () 
{ 
    local error=$1;
    local outputName=$2;
    frame::new "$SILMARILSTATUSFAILURE" "$SILMARILVALUENONE" "$SILMARILEFFECTNONE" "$error" "$outputName"
}
