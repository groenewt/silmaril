engine::main () 
{ 
    local emOp=${1-} emDir emInput emOutput= emRc=0 emId emN;
    engine::directory emDir;
    path::absolute "$emDir" emDir;
    case $emOp in 
        apply)
            [[ $# == 2 ]] || return 1;
            path::absolute "$2" emInput;
            engine::apply "$emInput" || emRc=$?;
            [[ -z $engineResult ]] || publication::frame "$engineResult" "$engineRequestIdentity:occurrence:result";
            return "$emRc"
        ;;
        selftest)
            source "$emDir/tests/test.sh";
            test::main;
            return $?
        ;;
    esac;
    engine::reset;
    engine::bootstrap "$emDir/ontology/primordial.yaml" "$emDir/ontology/runtime.yaml" || { 
        engine::printError;
        return 1
    };
    scheduler::defaults;
    case $emOp in 
        validate | order | run | analyze)
            [[ $# == 2 || ( $emOp == run && $# == 3 ) ]] || { 
                engine::usage;
                return 1
            };
            path::absolute "$2" emInput;
            graph::load "$emInput" && graph::validate || { 
                engine::printError;
                return 1
            };
            if [[ $emOp == analyze ]]; then
                analysis::graph && analysis::emit || emRc=$?;
            else
                if [[ $emOp == order ]]; then
                    for emId in "${graphOrder[@]}";
                    do
                        printf '%s\n' "$emId";
                    done;
                else
                    if [[ $emOp == run ]]; then
                        scheduler::run || emRc=$?;
                        if [[ $# == 3 ]]; then
                            path::absolute "$3" emOutput;
                            path::requireWritableTarget "$emOutput" && [[ $emOutput != "$emInput" ]] || return 1;
                            graph::emitReceipts > "$emOutput";
                        else
                            graph::emitReceipts;
                        fi;
                    fi;
                fi;
            fi
        ;;
        certify)
            [[ $# == 2 ]] || return 1;
            path::absolute "$2" emInput;
            finite::certify "$emInput" || emRc=$?;
            if ((emRc==0)); then
                frame::success "$SILMARILTRUE" "$SILMARILEFFECTNONE" engineResult;
            else
                frame::failure "$engineError" engineResult;
            fi;
            publication::frame "$engineResult" "${finiteDocument}:occurrence:certificate"
        ;;
        pairs)
            [[ $# == 2 ]] || return 1;
            path::absolute "$2" emInput;
            kv::parse "$emInput" && kv::emitBindings || emRc=$?
        ;;
        *)
            engine::usage;
            return 1
        ;;
    esac;
    ((emRc==0)) || engine::printError;
    return "$emRc"
}
