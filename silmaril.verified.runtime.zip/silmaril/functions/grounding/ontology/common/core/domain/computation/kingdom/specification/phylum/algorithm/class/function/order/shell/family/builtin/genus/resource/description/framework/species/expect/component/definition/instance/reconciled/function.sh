rdf::expect () 
{ 
    rdf::space;
    [[ ${rdfText:rdfCursor:${#1}} == "$1" ]] || { 
        rdf::error "expected $1";
        return 1
    };
    ((rdfCursor+=${#1}))
}
