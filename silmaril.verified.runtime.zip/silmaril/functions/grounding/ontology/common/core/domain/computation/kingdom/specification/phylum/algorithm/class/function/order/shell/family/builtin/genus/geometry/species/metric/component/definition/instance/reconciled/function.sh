geometry::metric () 
{ 
    local gmI gmJ gmK gmD gmBack gmSum;
    [[ $metricSize =~ ^(0|[1-9][0-9]?)$ ]] && ((metricSize<=64)) || { 
        error::raise PAIR/LIMIT 'finite metric carrier';
        return 1
    };
    ((${#metricValue[@]}==metricSize*metricSize)) || { 
        error::raise CATEGORY/EQUATION 'metric totality';
        return 1
    };
    for ((gmI=0; gmI<metricSize; gmI++))
    do
        for ((gmJ=0; gmJ<metricSize; gmJ++))
        do
            gmD=${metricValue[$gmI,$gmJ]-};
            [[ $gmD =~ ^(0|[1-9][0-9]{0,8})$ ]] || { 
                error::raise CATEGORY/EQUATION 'metric distance';
                return 1
            };
            if ((gmI==gmJ)); then
                ((gmD==0)) || { 
                    error::raise CATEGORY/EQUATION 'metric diagonal';
                    return 1
                };
            else
                ((gmD>0)) || { 
                    error::raise CATEGORY/EQUATION 'metric separation';
                    return 1
                };
            fi;
            [[ $gmD == "${metricValue[$gmJ,$gmI]-}" ]] || { 
                error::raise CATEGORY/EQUATION 'metric symmetry';
                return 1
            };
        done;
    done;
    for ((gmI=0; gmI<metricSize; gmI++))
    do
        for ((gmJ=0; gmJ<metricSize; gmJ++))
        do
            for ((gmK=0; gmK<metricSize; gmK++))
            do
                gmSum=$((${metricValue[$gmI,$gmK]}+${metricValue[$gmK,$gmJ]}));
                ((${metricValue[$gmI,$gmJ]}<=gmSum)) || { 
                    error::raise CATEGORY/EQUATION 'metric triangle';
                    return 1
                };
            done;
        done;
    done
}
