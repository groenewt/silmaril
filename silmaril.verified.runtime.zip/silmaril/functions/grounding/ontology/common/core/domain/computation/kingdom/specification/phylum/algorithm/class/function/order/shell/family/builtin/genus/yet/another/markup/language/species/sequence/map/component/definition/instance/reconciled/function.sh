yaml::sequenceMap () 
{ 
    local sequencePath=$1;
    local index=$2;
    local outputName=$3;
    local -n outputReference=$outputName;
    local resolvedPath;
    yaml::itemPath resolvedPath "$sequencePath" "$index";
    [[ ${yamlKind[$resolvedPath]-} == map ]] || { 
        engine::raise "$SILMARILERRORYAML" "sequence map $index";
        return "$SILMARILFAILURE"
    };
    outputReference=$resolvedPath
}
