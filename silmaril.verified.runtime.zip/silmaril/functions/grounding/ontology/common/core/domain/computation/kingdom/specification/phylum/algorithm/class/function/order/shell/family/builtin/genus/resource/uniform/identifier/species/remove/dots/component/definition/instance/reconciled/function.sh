uri::removeDots () 
{ 
    local rdInput=$1 rdOut=$2 rdOutput= rdPart rdTail;
    while [[ -n $rdInput ]]; do
        case $rdInput in 
            ../*)
                rdInput=${rdInput#../}
            ;;
            ./*)
                rdInput=${rdInput#./}
            ;;
            /./*)
                rdInput=/${rdInput#/./}
            ;;
            /.)
                rdInput=/
            ;;
            /../*)
                rdInput=/${rdInput#/../};
                if [[ $rdOutput == */* ]]; then
                    rdOutput=${rdOutput%/*};
                else
                    rdOutput=;
                fi
            ;;
            /..)
                rdInput=/;
                if [[ $rdOutput == */* ]]; then
                    rdOutput=${rdOutput%/*};
                else
                    rdOutput=;
                fi
            ;;
            . | ..)
                rdInput=
            ;;
            *)
                if [[ $rdInput == /* ]]; then
                    rdTail=${rdInput#/};
                    rdPart=/${rdTail%%/*};
                else
                    rdPart=${rdInput%%/*};
                fi;
                rdOutput+=$rdPart;
                rdInput=${rdInput:${#rdPart}}
            ;;
        esac;
    done;
    printf -v "$rdOut" '%s' "$rdOutput"
}
