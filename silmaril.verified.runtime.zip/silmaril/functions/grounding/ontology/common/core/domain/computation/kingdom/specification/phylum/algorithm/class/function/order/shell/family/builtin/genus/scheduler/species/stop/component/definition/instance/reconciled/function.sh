scheduler::stop () 
{ 
    local ssPid=$1;
    if kill -0 "$ssPid" 2> /dev/null; then
        kill -TERM "$ssPid" 2> /dev/null || :;
        kill -KILL "$ssPid" 2> /dev/null || :;
    fi;
    wait "$ssPid" 2> /dev/null || :
}
