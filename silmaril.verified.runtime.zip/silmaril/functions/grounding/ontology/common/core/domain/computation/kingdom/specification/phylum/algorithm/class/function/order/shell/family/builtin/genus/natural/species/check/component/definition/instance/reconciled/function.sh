natural::check () 
{ 
    local ncN=$1 ncM=${naturalSource[$1]-} ncP=${naturalTarget[$1]-} ncO ncX ncY ncF ncA ncB ncL ncR ncK ncExpected=0 ncActual=0;
    [[ -n $ncM && -n $ncP ]] || { 
        error::raise NATURALITY/SQUARE identity;
        return 1
    };
    model::check "$ncM" && model::check "$ncP" || return 1;
    for ncO in "${categoryObjects[@]}";
    do
        for ncX in ${modelElements[$ncM$SILMARILUS$ncO]};
        do
            ((ncExpected+=1));
            ncY=${naturalComponent[$ncN$SILMARILUS$ncO$SILMARILUS$ncX]-};
            [[ -n $ncY ]] && finite::contains "${modelElements[$ncP$SILMARILUS$ncO]}" "$ncY" || { 
                error::raise NATURALITY/SQUARE totality;
                return 1
            };
        done;
    done;
    for ncF in "${categoryArrows[@]}";
    do
        ncA=${categorySource[$ncF]};
        ncB=${categoryTarget[$ncF]};
        for ncX in ${modelElements[$ncM$SILMARILUS$ncA]};
        do
            ncY=${modelAction[$ncM$SILMARILUS$ncF$SILMARILUS$ncX]};
            ncL=${naturalComponent[$ncN$SILMARILUS$ncB$SILMARILUS$ncY]};
            ncY=${naturalComponent[$ncN$SILMARILUS$ncA$SILMARILUS$ncX]};
            ncR=${modelAction[$ncP$SILMARILUS$ncF$SILMARILUS$ncY]};
            [[ $ncL == "$ncR" ]] || { 
                error::raise NATURALITY/SQUARE "$ncF $ncX";
                return 1
            };
            ((finiteChecks+=1));
        done;
    done;
    for ncK in "${!naturalComponent[@]}";
    do
        [[ $ncK != "$ncN$SILMARILUS"* ]] || ((ncActual+=1));
    done;
    ((ncActual==ncExpected)) || { 
        error::raise NATURALITY/SQUARE surplus;
        return 1
    };
    return 0
}
