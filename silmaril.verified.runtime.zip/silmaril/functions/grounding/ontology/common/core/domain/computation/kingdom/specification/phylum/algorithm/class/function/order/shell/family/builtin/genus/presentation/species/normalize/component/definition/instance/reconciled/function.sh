presentation::normalize () 
{ 
    local pnObject=$1 pnWord=$2 pnOut=$3;
    category::check || return 1;
    category::path "$pnObject" "$pnWord" "$pnOut"
}
