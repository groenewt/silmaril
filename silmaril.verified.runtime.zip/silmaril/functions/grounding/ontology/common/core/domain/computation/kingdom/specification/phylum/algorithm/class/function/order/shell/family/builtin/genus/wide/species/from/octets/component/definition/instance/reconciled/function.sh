wide::fromOctets () 
{ 
    local wfId=$1 wfSchema=$2;
    shift 2;
    local -a wfOctets=("$@");
    local wfIndex wfPart wfValue wfBit wfBits=;
    [[ -n ${wideSchemaWidth[$wfSchema]+yes} && ${objectType[$wfSchema]-} == "$WIDETYPESCHEMA" ]] || { 
        error::raise GROUNDING/MISSING 'unknown schema';
        return 1
    };
    (($#*8==wideSchemaWidth[$wfSchema])) || { 
        error::raise BYTE/RANGE 'octet extent';
        return 1
    };
    for wfPart in "${wfOctets[@]}";
    do
        [[ $wfPart =~ ^(0|[1-9][0-9]{0,2})$ ]] && ((wfPart<=255)) || { 
            error::raise BYTE/RANGE 'octet range';
            return 1
        };
    done;
    for ((wfIndex=0; wfIndex<${#wfOctets[@]}; wfIndex+=1))
    do
        if [[ ${wideSchemaOctet[$wfSchema]} == "$WIDEREVERSE" ]]; then
            wfValue=${wfOctets[${#wfOctets[@]}-wfIndex-1]};
        else
            wfValue=${wfOctets[wfIndex]};
        fi;
        for ((wfBit=7; wfBit>=0; wfBit-=1))
        do
            wfBits+=$(((wfValue>>wfBit)&1));
        done;
    done;
    if [[ ${wideSchemaBit[$wfSchema]} == "$WIDELEAST" ]]; then
        wide::reverse "$wfBits" wfBits;
    fi;
    wide::new "$wfId" "$wfSchema" "$wfBits"
}
