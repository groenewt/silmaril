homology::prime () 
{ 
    local hpValue=$1 hpDivisor;
    homology::integer "$hpValue" "$SILANALYSISMAXPRIME" || return "$SILANALYSISONE";
    ((hpValue>=SILANALYSISTWO)) || return "$SILANALYSISONE";
    for ((hpDivisor=SILANALYSISTWO; hpDivisor*hpDivisor<=hpValue; hpDivisor+=SILANALYSISONE))
    do
        ((hpValue%hpDivisor)) || return "$SILANALYSISONE";
    done
}
