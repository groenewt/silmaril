urn::parse () 
{ 
    local unText=${1-} unWork unNid unNss unRest= unR= unQ= unF= unAssigned unCase unRP=0 unQP=0 unFP=0;
    urn=();
    ((${#unText}<=addressMaximumBytes)) || { 
        error::raise RESOURCE/UNIFORM/NAME/SYNTAX 'URN byte capacity';
        return 1
    };
    [[ ${unText:0:4}, == [uU][rR][nN]:, ]] || { 
        error::raise RESOURCE/UNIFORM/NAME/SYNTAX 'URN scheme';
        return 1
    };
    unWork=${unText:4};
    [[ $unWork == *:* ]] || { 
        error::raise RESOURCE/UNIFORM/NAME/SYNTAX namespace;
        return 1
    };
    unNid=${unWork%%:*};
    unWork=${unWork#*:};
    [[ $unNid =~ ^[a-zA-Z0-9][a-zA-Z0-9-]{0,30}[a-zA-Z0-9]$ ]] || { 
        error::raise RESOURCE/UNIFORM/NAME/NAMESPACE 'NID syntax';
        return 1
    };
    if [[ $unWork == *'#'* ]]; then
        unFP=1;
        unF=${unWork#*#};
        unWork=${unWork%%#*};
    fi;
    unNss=${unWork%%\?*};
    if [[ $unWork == *'?'* ]]; then
        unRest=?${unWork#*\?};
    fi;
    [[ -n $unNss && $unNss != /* ]] && uri::component "$unNss" path && uri::component "$unF" query || { 
        error::raise RESOURCE/UNIFORM/NAME/SYNTAX NSS;
        return 1
    };
    if [[ $unRest == '?+'* ]]; then
        unRP=1;
        unRest=${unRest:2};
        if [[ $unRest == *'?='* ]]; then
            unR=${unRest%%\?=*};
            unRest=?=${unRest#*\?=};
        else
            unR=$unRest;
            unRest=;
        fi;
        [[ -n $unR && $unR != [/?]* ]] && uri::component "$unR" query || { 
            error::raise RESOURCE/UNIFORM/NAME/DELIMITER resolution;
            return 1
        };
    fi;
    if [[ $unRest == '?='* ]]; then
        unQP=1;
        unQ=${unRest:2};
        unRest=;
        [[ -n $unQ && $unQ != [/?]* ]] && uri::component "$unQ" query || { 
            error::raise RESOURCE/UNIFORM/NAME/DELIMITER query;
            return 1
        };
    fi;
    [[ -z $unRest ]] || { 
        error::raise RESOURCE/UNIFORM/NAME/DELIMITER optional;
        return 1
    };
    uri::percentCase "$unNss" unCase || return 1;
    unAssigned=urn:${unNid,,}:$unCase;
    urn=([SCHEME]=urn [NAMESPACE]="${unNid,,}" [NSS]="$unNss" [ASSIGNED]="$unAssigned" [RESOLUTION]="$unR" [QUERY]="$unQ" [FRAGMENT]="$unF" [RESOLUTIONPRESENT]="$unRP" [QUERYPRESENT]="$unQP" [FRAGMENTPRESENT]="$unFP" [NOTATION]="$unText")
}
