shape::datatype () 
{ 
    local sdNode=$1 sdDatatype=$2 sdValue=${rdfLexical[$1]} sdType=${rdfTerm[$2]} sdInteger sdBound;
    [[ ${rdfKind[sdNode]} == literal && ${rdfDatatype[sdNode]} == "$sdType" ]] || return 1;
    case $sdType in 
        "${XSDNS}string" | "${RDFNS}langString")
            return 0
        ;;
        "${XSDNS}boolean")
            [[ $sdValue == true || $sdValue == false || $sdValue == 0 || $sdValue == 1 ]]
        ;;
        "${XSDNS}integer" | "${XSDNS}nonNegativeInteger" | "${XSDNS}positiveInteger" | "${XSDNS}unsignedByte")
            [[ $sdValue =~ ^[+-]?[0-9]+$ ]] || return 1;
            case $sdType in 
                *nonNegativeInteger)
                    [[ $sdValue != -* || $sdValue =~ ^-0+$ ]]
                ;;
                *positiveInteger)
                    [[ $sdValue != -* && ! $sdValue =~ ^\+?0+$ ]]
                ;;
                *unsignedByte)
                    schema::unsignedByte "$sdValue"
                ;;
                *)
                    return 0
                ;;
            esac
        ;;
        "${XSDNS}decimal")
            [[ $sdValue =~ ^[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)$ ]]
        ;;
        "${XSDNS}double" | "${XSDNS}float")
            [[ $sdValue =~ ^([+-]?INF|NaN|[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)([eE][+-]?[0-9]+)?)$ ]]
        ;;
        *)
            shape::error "unsupported datatype validation $sdType";
            return 2
        ;;
    esac
}
