rdf::reset () 
{ 
    shapeValidationComplete=0;
    rdfTerm=() rdfKind=() rdfLexical=() rdfDatatype=() rdfLanguage=() rdfSubject=() rdfPredicate=() rdfObject=() rdfGraph=();
    rdfIntern=() rdfTriples=() rdfPrefixes=() rdfBlankLabels=() rdfForward=() rdfParents=() rdfBlankCounter=0 rdfDocumentCounter=0 rdfTermResult= rdfErrorDetail=
}
