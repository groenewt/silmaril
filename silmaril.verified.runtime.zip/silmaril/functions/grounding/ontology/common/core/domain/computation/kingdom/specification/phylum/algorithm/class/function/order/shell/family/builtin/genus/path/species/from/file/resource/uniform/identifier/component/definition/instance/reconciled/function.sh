path::fromFileUri () 
{ 
    local ffInput=$1 ffOut=$2 ffText ffI ffC ffHex ffN ffOct ffResult=;
    uri::parse "$ffInput" || return 1;
    [[ ${uri[SCHEME],,} == file && ${uri[QUERYPRESENT]} == 0 && ${uri[FRAGMENTPRESENT]} == 0 && ${uri[USERPRESENT]} == 0 && ${uri[PORTPRESENT]} == 0 ]] || { 
        error::raise PROTOCOL/LOCATOR 'local file URI profile';
        return 1
    };
    [[ -z ${uri[HOST]} || ${uri[HOST],,} == localhost ]] || { 
        error::raise PROTOCOL/SECURITY 'remote file authority not admitted';
        return 1
    };
    ffText=${uri[PATH]};
    for ((ffI=0; ffI<${#ffText}; ffI++))
    do
        ffC=${ffText:ffI:1};
        if [[ $ffC == % ]]; then
            ffHex=${ffText:ffI+1:2};
            ffN=$((16#$ffHex));
            ((ffI+=2));
            ((ffN!=0 && ffN!=47)) || { 
                error::raise PATH/SEGMENT 'encoded separator or NUL';
                return 1
            };
            printf -v ffOct '\\%03o' "$ffN";
            printf -v ffC '%b' "$ffOct";
        fi;
        ffResult+=$ffC;
    done;
    path::lexical "$ffResult" || { 
        error::raise PATH/SEGMENT 'decoded path is not canonical';
        return 1
    };
    printf -v "$ffOut" '%s' "$ffResult"
}
