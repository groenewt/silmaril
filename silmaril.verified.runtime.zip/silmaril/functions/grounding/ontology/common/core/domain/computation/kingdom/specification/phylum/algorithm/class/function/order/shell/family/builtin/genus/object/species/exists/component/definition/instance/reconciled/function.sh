object::exists () 
{ 
    local identity=$1;
    [[ ${objectDefined[$identity]-} == "$SILMARILONE" ]]
}
