scheduler::launch () 
{ 
    local slNode=$1 slMethod=$2 slAttempt=$3 slFdOut=$4 slPidOut=$5 slFd slPid;
    exec {slFd}< <(scheduler::worker "$slNode" "$slMethod" "$slAttempt");
    slPid=$!;
    printf -v "$slFdOut" '%s' "$slFd";
    printf -v "$slPidOut" '%s' "$slPid"
}
