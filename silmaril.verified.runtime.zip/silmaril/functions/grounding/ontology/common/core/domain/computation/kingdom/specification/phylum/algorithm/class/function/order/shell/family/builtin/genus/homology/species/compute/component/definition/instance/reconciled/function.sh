homology::compute () 
{ 
    homologyVerified=$SILANALYSISZERO;
    homologyBetti=();
    homologyRank=();
    homologyEuler=$SILANALYSISZERO;
    local hcDegree hcRow hcColumn hcMiddle hcSum hcValue hcKey hcTail hcRank hcEuler=$SILANALYSISZERO hcBettiEuler=$SILANALYSISZERO hcSign=$SILANALYSISONE;
    local hcCount=${#homologyDimension[@]};
    local -a hcRanks=() hcBetti=() hcMatrix=();
    ((hcCount>=SILANALYSISONE && hcCount<=SILANALYSISMAXDEGREE+SILANALYSISONE)) || { 
        error::raise PROJECTION/FIDELITY 'finite chain dimension bound';
        return "$SILANALYSISONE"
    };
    homology::prime "$homologyPrime" || { 
        error::raise PROJECTION/FIDELITY 'coefficient domain is not an admitted prime field';
        return "$SILANALYSISONE"
    };
    for ((hcDegree=SILANALYSISZERO; hcDegree<hcCount; hcDegree+=SILANALYSISONE))
    do
        [[ -n ${homologyDimension[hcDegree]+yes} ]] && homology::integer "${homologyDimension[hcDegree]}" "$SILANALYSISMAXDIMENSION" && ((homologyDimension[hcDegree]>=SILANALYSISZERO)) || { 
            error::raise PROJECTION/FIDELITY 'chain rank lexical or range error';
            return "$SILANALYSISONE"
        };
    done;
    for hcKey in "${!homologyBoundary[@]}";
    do
        [[ $hcKey =~ ^(0|[1-9][0-9]*),(0|[1-9][0-9]*),(0|[1-9][0-9]*)$ ]] || { 
            error::raise PROJECTION/FIDELITY 'boundary index lexical error';
            return "$SILANALYSISONE"
        };
        hcDegree=${hcKey%%,*};
        hcTail=${hcKey#*,};
        hcRow=${hcTail%%,*};
        hcColumn=${hcTail#*,};
        homology::integer "$hcDegree" "$SILANALYSISMAXDEGREE" && homology::integer "$hcRow" "$SILANALYSISMAXDIMENSION" && homology::integer "$hcColumn" "$SILANALYSISMAXDIMENSION" || return "$SILANALYSISONE";
        ((hcDegree>=SILANALYSISONE && hcDegree<hcCount && hcRow<homologyDimension[hcDegree-SILANALYSISONE] && hcColumn<homologyDimension[hcDegree])) || { 
            error::raise PROJECTION/FIDELITY 'boundary cell outside declared chain module';
            return "$SILANALYSISONE"
        };
        homology::integer "${homologyBoundary[$hcKey]}" "$SILANALYSISMAXENTRY" || { 
            error::raise PROJECTION/FIDELITY 'boundary coefficient lexical or range error';
            return "$SILANALYSISONE"
        };
    done;
    for ((hcDegree=SILANALYSISTWO; hcDegree<hcCount; hcDegree+=SILANALYSISONE))
    do
        for ((hcRow=SILANALYSISZERO; hcRow<homologyDimension[hcDegree-SILANALYSISTWO]; hcRow+=SILANALYSISONE))
        do
            for ((hcColumn=SILANALYSISZERO; hcColumn<homologyDimension[hcDegree]; hcColumn+=SILANALYSISONE))
            do
                hcSum=$SILANALYSISZERO;
                for ((hcMiddle=SILANALYSISZERO; hcMiddle<homologyDimension[hcDegree-SILANALYSISONE]; hcMiddle+=SILANALYSISONE))
                do
                    hcSum=$(((hcSum+(${homologyBoundary[$((hcDegree-SILANALYSISONE)),$hcRow,$hcMiddle]:-$SILANALYSISZERO}%homologyPrime)*(${homologyBoundary[$hcDegree,$hcMiddle,$hcColumn]:-$SILANALYSISZERO}%homologyPrime))%homologyPrime));
                done;
                ((hcSum==SILANALYSISZERO)) || { 
                    error::raise PROJECTION/FIDELITY 'boundary composed with boundary is nonzero';
                    return "$SILANALYSISONE"
                };
            done;
        done;
    done;
    hcRanks[SILANALYSISZERO]=$SILANALYSISZERO;
    hcRanks[hcCount]=$SILANALYSISZERO;
    for ((hcDegree=SILANALYSISONE; hcDegree<hcCount; hcDegree+=SILANALYSISONE))
    do
        hcMatrix=();
        for ((hcRow=SILANALYSISZERO; hcRow<homologyDimension[hcDegree-SILANALYSISONE]; hcRow+=SILANALYSISONE))
        do
            for ((hcColumn=SILANALYSISZERO; hcColumn<homologyDimension[hcDegree]; hcColumn+=SILANALYSISONE))
            do
                hcValue=$((${homologyBoundary[$hcDegree,$hcRow,$hcColumn]:-$SILANALYSISZERO}%homologyPrime));
                ((hcValue>=SILANALYSISZERO)) || ((hcValue+=homologyPrime));
                hcMatrix+=("$hcValue");
            done;
        done;
        homology::rank "${homologyDimension[hcDegree-SILANALYSISONE]}" "${homologyDimension[hcDegree]}" hcMatrix "$homologyPrime" hcRank;
        hcRanks[hcDegree]=$hcRank;
    done;
    for ((hcDegree=SILANALYSISZERO; hcDegree<hcCount; hcDegree+=SILANALYSISONE))
    do
        hcBetti[hcDegree]=$((homologyDimension[hcDegree]-hcRanks[hcDegree]-hcRanks[hcDegree+SILANALYSISONE]));
        ((hcBetti[hcDegree]>=SILANALYSISZERO)) || { 
            error::raise PROJECTION/FIDELITY 'negative homology dimension';
            return "$SILANALYSISONE"
        };
        hcEuler=$((hcEuler+hcSign*homologyDimension[hcDegree]));
        hcBettiEuler=$((hcBettiEuler+hcSign*hcBetti[hcDegree]));
        hcSign=$((-hcSign));
    done;
    ((hcEuler==hcBettiEuler)) || { 
        error::raise PROJECTION/FIDELITY 'Euler equality failed';
        return "$SILANALYSISONE"
    };
    homologyBetti=("${hcBetti[@]}");
    homologyRank=("${hcRanks[@]}");
    homologyEuler=$hcEuler;
    homologyVerified=$SILANALYSISONE
}
