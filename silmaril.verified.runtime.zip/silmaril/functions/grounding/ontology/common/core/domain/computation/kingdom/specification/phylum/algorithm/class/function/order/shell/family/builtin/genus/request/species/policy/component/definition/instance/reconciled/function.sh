request::policy () 
{ 
    local rpPath=$1 rpKey rpRef rpFlag rpNumber rpSub;
    yaml::assertOnlyKeys "$rpPath" PARALLEL RETRY TIMEOUT FAILURE ROLLBACK || return 1;
    for rpKey in PARALLEL RETRY;
    do
        yaml::optionalScalar "$rpPath" "$rpKey" rpRef rpFlag || return 1;
        if ((rpFlag)); then
            rpNumber=${kvNumber[$rpRef]-};
            [[ -n $rpNumber ]] || { 
                error::raise PAIR/VALUE "$rpKey integer reference";
                return 1
            };
            case $rpKey in 
                PARALLEL)
                    schedulerParallel=$rpNumber
                ;;
                RETRY)
                    schedulerRetry=$rpNumber
                ;;
            esac;
        fi;
    done;
    if [[ -n ${yamlKind[$rpPath$SILMARILUS"TIMEOUT"]-} ]]; then
        yaml::requiredMap "$rpPath" TIMEOUT rpSub || return 1;
        yaml::assertOnlyKeys "$rpSub" MICROSECONDS || return 1;
        yaml::requiredScalar "$rpSub" MICROSECONDS rpRef || return 1;
        [[ -n ${kvNumber[$rpRef]-} ]] || { 
            error::raise PAIR/VALUE 'timeout integer reference';
            return 1
        };
        schedulerTimeout=${kvNumber[$rpRef]};
    fi;
    yaml::optionalScalar "$rpPath" FAILURE rpRef rpFlag || return 1;
    if ((rpFlag)); then
        case $rpRef in 
            "$REQUESTOPERATION":abort)
                schedulerDisposition=abort
            ;;
            "$REQUESTOPERATION":continue)
                schedulerDisposition=continue
            ;;
            "$REQUESTOPERATION":skip)
                schedulerDisposition=skip
            ;;
            *)
                error::raise PROTOCOL/OPERATION 'failure policy';
                return 1
            ;;
        esac;
    fi;
    yaml::optionalScalar "$rpPath" ROLLBACK rpRef rpFlag || return 1;
    if ((rpFlag)); then
        case $rpRef in 
            "$SILMARILTRUE")
                schedulerRollback=1
            ;;
            "$SILMARILFALSE")
                schedulerRollback=0
            ;;
            *)
                error::raise PAIR/VALUE 'rollback Boolean reference';
                return 1
            ;;
        esac;
    fi
}
