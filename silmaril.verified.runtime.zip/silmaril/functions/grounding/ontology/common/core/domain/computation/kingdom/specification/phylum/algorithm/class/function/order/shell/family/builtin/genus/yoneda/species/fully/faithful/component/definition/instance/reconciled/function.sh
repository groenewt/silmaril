yoneda::fullyFaithful () 
{ 
    category::check || return 1;
    local yfF yfG yfK yfA yfB yfC yfH yfM yfWords yfI=0 yfValues yfExpected yfX;
    local -A yfS=() yfT=() yfP=();
    for yfF in "${categoryArrows[@]}";
    do
        yfS[$yfF]=${categorySource[$yfF]};
        yfT[$yfF]=${categoryTarget[$yfF]};
    done;
    for yfK in "${!categoryComposite[@]}";
    do
        yfP[$yfK]=${categoryComposite[$yfK]};
    done;
    local -A categorySource=() categoryTarget=() categoryComposite=();
    local -A modelElements=() modelAction=();
    local -a modelNames=() equationNames=();
    for yfF in "${categoryArrows[@]}";
    do
        categorySource[$yfF]=${yfT[$yfF]};
        categoryTarget[$yfF]=${yfS[$yfF]};
    done;
    for yfK in "${!yfP[@]}";
    do
        yfG=${yfK%%"$SILMARILUS"*};
        yfF=${yfK#*"$SILMARILUS"};
        categoryComposite[$yfF$SILMARILUS$yfG]=${yfP[$yfK]};
    done;
    yonedaPairCount=0;
    for yfB in "${categoryObjects[@]}";
    do
        name::number "$yfI" yfWords;
        ((yfI+=1));
        yfM=$categoryName:component:presheaf:instance:$yfWords;
        modelNames+=("$yfM");
        for yfC in "${categoryObjects[@]}";
        do
            yfValues=;
            for yfH in "${categoryArrows[@]}";
            do
                [[ ${categorySource[$yfH]} != "$yfB" || ${categoryTarget[$yfH]} != "$yfC" ]] || yfValues+="$yfH ";
            done;
            modelElements[$yfM$SILMARILUS$yfC]=$yfValues;
        done;
        for yfG in "${categoryArrows[@]}";
        do
            yfC=${categorySource[$yfG]};
            for yfH in ${modelElements[$yfM$SILMARILUS$yfC]};
            do
                modelAction[$yfM$SILMARILUS$yfG$SILMARILUS$yfH]=${categoryComposite[$yfG$SILMARILUS$yfH]};
            done;
        done;
        for yfA in "${categoryObjects[@]}";
        do
            yoneda::check "$yfM" "$yfA" || return 1;
            yfExpected=0;
            for yfH in "${categoryArrows[@]}";
            do
                [[ ${yfS[$yfH]} != "$yfA" || ${yfT[$yfH]} != "$yfB" ]] || ((yfExpected+=1));
            done;
            ((yonedaCount==yfExpected)) || { 
                error::raise THEOREM/CERTIFICATE full:faithfulness;
                return 1
            };
            ((yonedaPairCount+=1));
        done;
    done;
    return 0
}
