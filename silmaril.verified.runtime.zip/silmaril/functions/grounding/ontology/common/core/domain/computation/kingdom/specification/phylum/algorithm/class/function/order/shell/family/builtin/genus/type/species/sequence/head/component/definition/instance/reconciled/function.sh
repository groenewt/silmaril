type::sequenceHead () 
{ 
    local sequence=$1;
    local outputName=$2;
    local -n outputReference=$outputName;
    if [[ $sequence == *"$SILMARILUS"* ]]; then
        outputReference=${sequence%%"$SILMARILUS"*};
    else
        outputReference=$sequence;
    fi
}
