rdf::load () 
{ 
    rdf::reset;
    rdf::append "$@"
}
