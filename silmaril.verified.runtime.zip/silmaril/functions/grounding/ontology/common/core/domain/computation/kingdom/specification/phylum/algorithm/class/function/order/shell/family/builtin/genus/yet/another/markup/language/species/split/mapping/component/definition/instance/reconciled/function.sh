yaml::splitMapping () 
{ 
    local input=$1;
    local keyName=$2;
    local valueName=$3;
    local hasValueName=$4;
    local -n keyReference=$keyName;
    local -n valueReference=$valueName;
    local -n hasValueReference=$hasValueName;
    local quote=;
    local escaped=$SILMARILZERO;
    local delimiter=-1;
    local index;
    local character;
    for ((index = SILMARILZERO; index < ${#input}; index += SILMARILONE ))
    do
        character=${input:index:SILMARILONE};
        if [[ $quote == double ]]; then
            if (( escaped == SILMARILONE )); then
                escaped=$SILMARILZERO;
            else
                if [[ $character == '\' ]]; then
                    escaped=$SILMARILONE;
                else
                    if [[ $character == '"' ]]; then
                        quote=;
                    fi;
                fi;
            fi;
            continue;
        fi;
        if [[ $quote == single ]]; then
            [[ $character == "'" ]] && quote=;
            continue;
        fi;
        case $character in 
            '"')
                quote=double
            ;;
            "'")
                quote=single
            ;;
            ':')
                if (( index + SILMARILONE == ${#input} )) || [[ ${input:index+SILMARILONE:SILMARILONE} == [[:space:]] ]]; then
                    delimiter=$index;
                    break;
                fi
            ;;
        esac;
    done;
    (( delimiter >= SILMARILZERO )) || { 
        engine::raise "$SILMARILERRORYAML" "mapping delimiter missing in $input";
        return "$SILMARILFAILURE"
    };
    local parsedKey=${input:SILMARILZERO:delimiter};
    local parsedValue=${input:delimiter+SILMARILONE};
    string::trim "$parsedKey" parsedKey;
    string::trim "$parsedValue" parsedValue;
    [[ $parsedKey =~ ^[A-Za-z][A-Za-z0-9]*$ && $parsedKey != *-* && $parsedKey != *_* ]] || { 
        engine::raise "$SILMARILERRORYAMLKEY" "$parsedKey";
        return "$SILMARILFAILURE"
    };
    keyReference=$parsedKey;
    valueReference=$parsedValue;
    if [[ -n $parsedValue ]]; then
        hasValueReference=$SILMARILONE;
    else
        hasValueReference=$SILMARILZERO;
    fi
}
