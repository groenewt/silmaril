object::getCount () 
{ 
    local identity=$1;
    local field=$2;
    local outputName=$3;
    local -n outputReference=$outputName;
    local key="${identity}${SILMARILUS}${field}";
    outputReference=${objectFieldCount[$key]:-$SILMARILZERO}
}
