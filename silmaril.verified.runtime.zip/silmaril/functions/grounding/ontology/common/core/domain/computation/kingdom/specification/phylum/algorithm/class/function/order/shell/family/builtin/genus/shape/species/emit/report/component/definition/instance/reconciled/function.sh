shape::emitReport () 
{ 
    local erIndex erFocus erShape erPath erValue erComponent erSeverity erTerm;
    ((shapeFailure==0 && shapeValidationComplete==1)) || { 
        shape::error 'no completed validation result to report';
        return 2
    };
    printf '_:report <%stype> <%sValidationReport> .\n' "$RDFNS" "$SHNS";
    if ((${#shapeResultFocus[@]})); then
        printf '_:report <%sconforms> "false"^^<%sboolean> .\n' "$SHNS" "$XSDNS";
    else
        printf '_:report <%sconforms> "true"^^<%sboolean> .\n' "$SHNS" "$XSDNS";
    fi;
    for erIndex in "${!shapeResultFocus[@]}";
    do
        rdf::renderTerm "${shapeResultFocus[erIndex]}" erFocus || return 1;
        rdf::renderTerm "${shapeResultShape[erIndex]}" erShape || return 1;
        erComponent=${shapeResultConstraint[erIndex]^}ConstraintComponent;
        shape::single "${shapeResultShape[erIndex]}" severity || return 2;
        if [[ -n $shapeParameter ]]; then
            rdf::renderTerm "$shapeParameter" erSeverity || return 1;
        else
            erSeverity="<${SHNS}Violation>";
        fi;
        printf '_:report <%sresult> _:result%s .\n' "$SHNS" "$erIndex";
        printf '_:result%s <%stype> <%sValidationResult> .\n' "$erIndex" "$RDFNS" "$SHNS";
        printf '_:result%s <%sfocusNode> %s .\n' "$erIndex" "$SHNS" "$erFocus";
        printf '_:result%s <%ssourceShape> %s .\n' "$erIndex" "$SHNS" "$erShape";
        printf '_:result%s <%ssourceConstraintComponent> <%s%s> .\n' "$erIndex" "$SHNS" "$SHNS" "$erComponent";
        printf '_:result%s <%sresultSeverity> %s .\n' "$erIndex" "$SHNS" "$erSeverity";
        if [[ -n ${shapeResultPath[erIndex]} ]]; then
            rdf::renderTerm "${shapeResultPath[erIndex]}" erPath || return 1;
            printf '_:result%s <%sresultPath> %s .\n' "$erIndex" "$SHNS" "$erPath";
        fi;
        if [[ -n ${shapeResultValue[erIndex]} ]]; then
            rdf::renderTerm "${shapeResultValue[erIndex]}" erValue || return 1;
            printf '_:result%s <%svalue> %s .\n' "$erIndex" "$SHNS" "$erValue";
        fi;
    done;
    rdf::emit "$shapeShapesGraph"
}
