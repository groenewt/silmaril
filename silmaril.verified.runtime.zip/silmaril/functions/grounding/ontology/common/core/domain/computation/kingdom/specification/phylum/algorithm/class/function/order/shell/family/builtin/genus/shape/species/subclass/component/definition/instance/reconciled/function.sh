shape::subclass () 
{ 
    local scChild=$1 scParent=$2 scCurrent scIndex scTarget scHead=0;
    local -a scQueue=("$scChild");
    local -A scSeen=();
    while ((scHead<${#scQueue[@]})); do
        scCurrent=${scQueue[scHead]};
        ((scHead+=1));
        [[ $scCurrent != "$scParent" ]] || return 0;
        [[ ! -n ${scSeen[$scCurrent]+yes} ]] || continue;
        scSeen[$scCurrent]=1;
        rdf::objects "$scCurrent" "${RDFSNS}subClassOf" "$shapeDataGraph";
        scQueue+=("${rdfValues[@]}");
    done;
    return 1
}
