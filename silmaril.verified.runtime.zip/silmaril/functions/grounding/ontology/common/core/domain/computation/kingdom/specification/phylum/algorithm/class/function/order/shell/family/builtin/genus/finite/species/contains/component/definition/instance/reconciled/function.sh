finite::contains () 
{ 
    [[ " $1 " == *" $2 "* ]]
}
