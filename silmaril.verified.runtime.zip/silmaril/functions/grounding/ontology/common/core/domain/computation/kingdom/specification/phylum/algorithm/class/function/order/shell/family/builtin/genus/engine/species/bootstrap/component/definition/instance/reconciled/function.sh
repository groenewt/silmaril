engine::bootstrap () 
{ 
    local ontologyPath=$1;
    local runtimePath=$2;
    ontology::load "$ontologyPath" || return "$SILMARILFAILURE";
    ontology::seal || return "$SILMARILFAILURE";
    runtimeconfig::load "$runtimePath" || return "$SILMARILFAILURE";
    ontology::materialize || return "$SILMARILFAILURE";
    engine::materializeRuntimeValues || return "$SILMARILFAILURE";
    engine::registerMethods || return "$SILMARILFAILURE";
    grounding::records
}
