shape::validate () 
{ 
    local svIndex svShape svTarget svPredicate svNode svType svStatus svKey;
    local -A svFocus=();
    shapeValidationComplete=0;
    shapeResultFocus=() shapeResultShape=() shapeResultPath=() shapeResultConstraint=() shapeResultValue=() shapeActive=() shapeFailure=0 shapeFocusCount=0 shapeDepth=0 shapeDetail=;
    shape::preflight || return 2;
    for svIndex in "${!rdfSubject[@]}";
    do
        [[ ${rdfGraph[svIndex]} == "$shapeShapesGraph" ]] || continue;
        svShape=${rdfSubject[svIndex]};
        svTarget=${rdfObject[svIndex]};
        svPredicate=${rdfTerm[${rdfPredicate[svIndex]}]};
        if [[ $svPredicate == "${SHNS}target" || $svPredicate == "${SHNS}sparql" || $svPredicate == "${SHNS}js" || $svPredicate == "${SHNS}rule" || $svPredicate == "${SHNS}parameter" ]]; then
            shape::error 'extension outside admitted profile';
            return 2;
        fi;
        case $svPredicate in 
            "${SHNS}targetNode")
                svFocus[$svShape,$svTarget]=1
            ;;
            "${SHNS}targetClass")
                for svNode in "${!rdfTerm[@]}";
                do
                    if shape::instance "$svNode" "$svTarget"; then
                        svFocus[$svShape,$svNode]=1;
                    fi;
                done
            ;;
            "${SHNS}targetSubjectsOf" | "${SHNS}targetObjectsOf")
                for svNode in "${!rdfSubject[@]}";
                do
                    [[ ${rdfGraph[svNode]} == "$shapeDataGraph" && ${rdfPredicate[svNode]} == "$svTarget" ]] || continue;
                    if [[ $svPredicate == "${SHNS}targetSubjectsOf" ]]; then
                        svFocus[$svShape,${rdfSubject[svNode]}]=1;
                    else
                        svFocus[$svShape,${rdfObject[svNode]}]=1;
                    fi;
                done
            ;;
        esac;
    done;
    shapeFocusCount=${#svFocus[@]};
    for svShape in "${!rdfTerm[@]}";
    do
        for svNode in "${!rdfTerm[@]}";
        do
            [[ -n ${svFocus[$svShape,$svNode]+yes} ]] || continue;
            svStatus=0;
            shape::node "$svNode" "$svShape" || svStatus=$?;
            ((svStatus!=2)) || return 2;
        done;
    done;
    shapeValidationComplete=1;
    if ((${#shapeResultFocus[@]})); then
        error::raise PROJECTION/FIDELITY "SHACL constraint violations: ${#shapeResultFocus[@]}";
        return 1;
    fi;
    return 0
}
