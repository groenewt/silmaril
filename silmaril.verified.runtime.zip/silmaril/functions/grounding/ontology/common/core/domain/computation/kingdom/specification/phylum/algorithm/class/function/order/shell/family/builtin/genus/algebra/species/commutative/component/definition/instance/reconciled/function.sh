algebra::commutative () 
{ 
    algebra::group || return 1;
    local acA acB;
    for acA in "${categoryArrows[@]}";
    do
        for acB in "${categoryArrows[@]}";
        do
            [[ ${categoryComposite[$acA$SILMARILUS$acB]} == "${categoryComposite[$acB$SILMARILUS$acA]}" ]] || { 
                error::raise CATEGORY/COMPOSITION 'noncommutative group';
                return 1
            };
        done;
    done
}
