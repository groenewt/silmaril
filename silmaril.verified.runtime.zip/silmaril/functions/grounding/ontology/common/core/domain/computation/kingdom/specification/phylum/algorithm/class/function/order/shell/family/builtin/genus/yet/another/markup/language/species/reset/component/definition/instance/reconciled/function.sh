yaml::reset () 
{ 
    yamlKind=();
    yamlValue=();
    yamlLine=();
    yamlLength=();
    yamlPathPair=();
    yamlPaths=();
    yamlPairCount=$SILMARILZERO;
    yamlPairIdentity=();
    yamlPairLeft=();
    yamlPairRight=();
    yamlPairParent=();
    yamlPairDepth=();
    yamlKind[$SILMARILYAMLROOT]=map;
    yamlLength[$SILMARILYAMLROOT]=$SILMARILZERO;
    yamlPathPair[$SILMARILYAMLROOT]=$SILMARILPAIRROOT
}
