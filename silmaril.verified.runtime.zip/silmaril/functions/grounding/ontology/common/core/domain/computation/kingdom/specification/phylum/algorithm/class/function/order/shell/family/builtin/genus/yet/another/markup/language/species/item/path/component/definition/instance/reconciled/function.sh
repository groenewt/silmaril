yaml::itemPath () 
{ 
    local outputName=$1;
    local sequencePath=$2;
    local index=$3;
    local -n outputReference=$outputName;
    outputReference="${sequencePath}${SILMARILUS}item${index}"
}
