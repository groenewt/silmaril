coend::root () 
{ 
    local crNode=$1 crOut=$2 crSteps=0;
    while [[ ${coendParent[$crNode]-} != "$crNode" ]]; do
        crNode=${coendParent[$crNode]-};
        ((crSteps+=1));
        [[ -n $crNode ]] && ((crSteps<=${#coendStates[@]})) || { 
            error::raise COEND/RELATION parent;
            return 1
        };
    done;
    printf -v "$crOut" '%s' "$crNode"
}
