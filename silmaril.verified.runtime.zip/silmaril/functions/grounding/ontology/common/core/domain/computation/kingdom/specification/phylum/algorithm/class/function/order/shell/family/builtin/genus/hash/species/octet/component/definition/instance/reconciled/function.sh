hash::octet () 
{ 
    local hoByte=$1 hoWord=$((hashFill/4));
    hashBlock[hoWord]=$(( ( ${hashBlock[hoWord]:-0} << 8 ) | hoByte ));
    ((hashFill+=1));
    ((hashBytes+=1));
    if ((hashFill==64)); then
        hash::compress;
    fi;
    return 0
}
