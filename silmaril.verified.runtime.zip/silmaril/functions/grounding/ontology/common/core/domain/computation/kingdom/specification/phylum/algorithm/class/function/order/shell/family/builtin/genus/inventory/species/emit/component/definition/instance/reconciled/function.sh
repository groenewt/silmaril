inventory::emit () 
{ 
    local ieRoot ieId ieObservation;
    inventory::check || return 1;
    name::number "$inventoryObservation" ieObservation;
    ieId="$INVENTORYBASE:component:observation:instance:$ieObservation";
    kvKnown[$ieId]=1;
    path::identify "${inventoryPath[0]}" ieRoot || return 1;
    printf 'IDENTITY: %s\nTYPE: %s\nSOURCE: %s\nVALUE:\n' "$ieId" "$INVENTORYBASE" "$ieRoot";
    publication::vector "${#inventoryPath[@]}" 2 inventory::emitItem
}
