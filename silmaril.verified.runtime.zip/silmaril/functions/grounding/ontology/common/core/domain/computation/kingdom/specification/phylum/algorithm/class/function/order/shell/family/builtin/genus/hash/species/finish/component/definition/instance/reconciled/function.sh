hash::finish () 
{ 
    local hfOut=$1 hfBits=$((hashBytes*8)) hfI hfHex= hfPart;
    hash::octet 128;
    while ((hashFill!=56)); do
        hash::octet 0;
    done;
    for ((hfI=56; hfI>=0; hfI-=8))
    do
        hash::octet "$(( (hfBits>>hfI)&255 ))";
    done;
    for hfI in "${hashState[@]}";
    do
        printf -v hfPart '%08x' "$hfI";
        hfHex+=$hfPart;
    done;
    printf -v "$hfOut" '%s' "$hfHex"
}
