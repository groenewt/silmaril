runtime::end () 
{ 
    local violationStatus=$SILMARILZERO;
    [[ -z $runtimeViolation ]] || violationStatus=$SILMARILFAILURE;
    trap - DEBUG;
    if (( runtimeHadExtdebug == SILMARILZERO )); then
        shopt -u extdebug;
    fi;
    if (( runtimeHadFunctrace == SILMARILZERO )); then
        set +T;
    fi;
    runtimeActive=$SILMARILZERO;
    runtimeOwner=;
    if ((runtimeErrWasSet)); then
        trap -- "$runtimeSavedErrAction" ERR;
    else
        trap - ERR;
    fi;
    if ((runtimeHadErrexit)); then
        set -e;
    fi;
    (( violationStatus == SILMARILZERO ))
}
