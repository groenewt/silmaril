node::join::run () 
{ 
    local identity=$1;
    local method=$2;
    local owner=$3;
    local outputName=$4;
    local count=${nodeInputCount[$identity]:-$SILMARILZERO};
    if (( count != SILMARILTWO )); then
        frame::failure "$SILMARILERRORGRAPHNODE" "$outputName";
        return "$SILMARILFAILURE";
    fi;
    local value;
    object::get "$identity" "$SILMARILFIELDVALUE" value || { 
        frame::failure "$SILMARILERRORGRAPHNODE" "$outputName";
        return "$SILMARILFAILURE"
    };
    frame::success "$value" "$SILMARILEFFECTNONE" "$outputName"
}
