import::closure () 
{ 
    local icIndex icSubject icObject icPred icName icVersion icImport icNode icType;
    local -a icImports=();
    importVersion=() importOntology=() importAlias=();
    for icIndex in "${!rdfSubject[@]}";
    do
        [[ ${rdfGraph[icIndex]} == "$importGraph" ]] || continue;
        icPred=${rdfTerm[${rdfPredicate[icIndex]}]};
        icObject=${rdfObject[icIndex]};
        if [[ $icPred == "${RDFNS}type" && ${rdfTerm[icObject]} == http://www.w3.org/2002/07/owl#Ontology ]]; then
            icSubject=${rdfSubject[icIndex]};
            icName=${rdfTerm[icSubject]};
            [[ ${rdfKind[icSubject]} == iri ]] || { 
                error::raise GROUNDING/CONTRADICTORY 'anonymous ontology';
                return 1
            };
            rdf::objects "$icSubject" http://www.w3.org/2002/07/owl#versionIRI "$importGraph";
            ((${#rdfValues[@]}==1)) || { 
                error::raise GROUNDING/CONTRADICTORY "one pinned ontology version required: $icName";
                return 1
            };
            icNode=${rdfValues[0]};
            [[ ${rdfKind[icNode]} == iri ]] || { 
                error::raise GROUNDING/CONTRADICTORY 'version is not IRI';
                return 1
            };
            icVersion=${rdfTerm[icNode]};
            if [[ -n ${importAlias[$icVersion]+yes} && ${importAlias[$icVersion]} != "$icName" ]]; then
                error::raise GROUNDING/CONTRADICTORY 'version assigned to two ontologies';
                return 1;
            fi;
            importVersion[$icName]=$icVersion;
            importOntology[$icName]=$icSubject;
            importAlias[$icName]=$icName;
            importAlias[$icVersion]=$icName;
        fi;
    done;
    ((${#importVersion[@]}>0)) || { 
        error::raise GROUNDING/MISSING 'no versioned ontology in import graph';
        return 1
    };
    for icName in "${!importOntology[@]}";
    do
        rdf::objects "${importOntology[$icName]}" http://www.w3.org/2002/07/owl#imports "$importGraph";
        icImports=("${rdfValues[@]}");
        for icNode in "${icImports[@]}";
        do
            icImport=${rdfTerm[icNode]};
            [[ ${rdfKind[icNode]} == iri && -n ${importAlias[$icImport]+yes} ]] || { 
                error::raise GROUNDING/MISSING "unresolved ontology import: $icImport";
                return 1
            };
        done;
    done
}
