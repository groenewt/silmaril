uri::percentCase () 
{ 
    local pcText=$1 pcOut=$2 pcI pcResult= pcChar pcHex;
    for ((pcI=0; pcI<${#pcText}; pcI++))
    do
        pcChar=${pcText:pcI:1};
        if [[ $pcChar == % ]]; then
            pcHex=${pcText:pcI+1:2};
            [[ $pcHex =~ ^[0-9A-Fa-f]{2}$ ]] || return 1;
            pcResult+=%${pcHex^^};
            ((pcI+=2));
        else
            pcResult+=$pcChar;
        fi;
    done;
    printf -v "$pcOut" '%s' "$pcResult"
}
