rdf::error () 
{ 
    rdfErrorDetail="byte $((rdfAbsoluteOffset+rdfCursor)): $*";
    error::raise PROJECTION/FIDELITY "$rdfErrorDetail"
}
