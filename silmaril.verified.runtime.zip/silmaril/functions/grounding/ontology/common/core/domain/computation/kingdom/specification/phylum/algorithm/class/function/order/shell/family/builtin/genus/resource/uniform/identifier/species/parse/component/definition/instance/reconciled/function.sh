uri::parse () 
{ 
    [[ $# == 1 ]] || { 
        error::raise PROTOCOL/LOCATOR arity;
        return 1
    };
    if ! uri::parseCandidate "$1"; then
        uri=();
        error::raise PROTOCOL/LOCATOR 'invalid URI notation';
        return 1;
    fi
}
