ontology::loadDefinitions () 
{ 
    local definitionsPath;
    local definitionsLength;
    yaml::requiredSequence "$SILMARILYAMLROOT" DEFINITIONS definitionsPath definitionsLength || return "$SILMARILFAILURE";
    local index;
    local itemPath;
    local identity;
    local identityType;
    local shortDescription;
    local longDescription;
    for ((index = SILMARILZERO; index < definitionsLength; index += SILMARILONE ))
    do
        yaml::sequenceMap "$definitionsPath" "$index" itemPath || return "$SILMARILFAILURE";
        yaml::assertOnlyKeys "$itemPath" IDENTITY TYPE ShortDescription LongDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" IDENTITY identity || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" TYPE identityType || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" ShortDescription shortDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" LongDescription longDescription || return "$SILMARILFAILURE";
        identity::requireRankedUrn "$identity" definition || return "$SILMARILFAILURE";
        [[ $identityType == "$SILMARILTYPEDEFINITION" ]] || { 
            engine::raise "$SILMARILERRORDEFINITION" "$identityType";
            return "$SILMARILFAILURE"
        };
        [[ ! -n ${definitionDefined[$identity]+present} ]] || { 
            engine::raise "$SILMARILERRORDEFINITION" "$identity";
            return "$SILMARILFAILURE"
        };
        definitionDefined[$identity]=$SILMARILONE;
        definitionType[$identity]=$identityType;
        definitionShortDescription[$identity]=$shortDescription;
        definitionLongDescription[$identity]=$longDescription;
        definitionOrder+=("$identity");
    done
}
