homology::integer () 
{ 
    local hiToken=$1 hiLimit=$2 hiMagnitude;
    [[ $hiToken =~ ^(0|[1-9][0-9]*|-[1-9][0-9]*)$ ]] || return "$SILANALYSISONE";
    hiMagnitude=${hiToken#-};
    ((${#hiMagnitude}<=${#hiLimit})) || return "$SILANALYSISONE";
    ((hiMagnitude<=hiLimit))
}
