publication::vectorNode () 
{ 
    local vnIndex=$1 vnIndent=$2 vnEmitter=$3 vnCount=$4 vnDigit vnNext vnKey;
    vnKey=${lexicalDigits[vnIndex%10]^^};
    printf '%*s%s:\n' "$vnIndent" '' "$vnKey";
    "$vnEmitter" "$vnIndex" "$((vnIndent+2))" || return 1;
    if ((vnIndex==0)); then
        return 0;
    fi;
    for ((vnDigit=0; vnDigit<10; vnDigit+=1))
    do
        vnNext=$((vnIndex*10+vnDigit));
        ((vnNext<vnCount)) || break;
        publication::vectorNode "$vnNext" "$((vnIndent+2))" "$vnEmitter" "$vnCount" || return 1;
    done
}
