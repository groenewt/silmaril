ontology::loadAxioms () 
{ 
    local axiomsPath;
    local axiomsLength;
    yaml::requiredSequence "$SILMARILYAMLROOT" AXIOMS axiomsPath axiomsLength || return "$SILMARILFAILURE";
    local index;
    local itemPath;
    local identity;
    local identityType;
    local domain;
    local shortDescription;
    local longDescription;
    for ((index = SILMARILZERO; index < axiomsLength; index += SILMARILONE ))
    do
        yaml::sequenceMap "$axiomsPath" "$index" itemPath || return "$SILMARILFAILURE";
        yaml::assertOnlyKeys "$itemPath" IDENTITY TYPE DOMAIN ShortDescription LongDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" IDENTITY identity || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" TYPE identityType || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" DOMAIN domain || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" ShortDescription shortDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" LongDescription longDescription || return "$SILMARILFAILURE";
        identity::requireRankedUrn "$identity" axiom || return "$SILMARILFAILURE";
        identity::requireRankedUrn "$domain" axiomdomain || return "$SILMARILFAILURE";
        [[ $identityType == "$SILMARILTYPEAXIOM" ]] || { 
            engine::raise "$SILMARILERRORAXIOM" "$identityType";
            return "$SILMARILFAILURE"
        };
        [[ ! -n ${axiomDefined[$identity]+present} ]] || { 
            engine::raise "$SILMARILERRORAXIOM" "$identity";
            return "$SILMARILFAILURE"
        };
        axiomDefined[$identity]=$SILMARILONE;
        axiomType[$identity]=$identityType;
        axiomDomain[$identity]=$domain;
        axiomShortDescription[$identity]=$shortDescription;
        axiomLongDescription[$identity]=$longDescription;
        axiomOrder+=("$identity");
    done
}
