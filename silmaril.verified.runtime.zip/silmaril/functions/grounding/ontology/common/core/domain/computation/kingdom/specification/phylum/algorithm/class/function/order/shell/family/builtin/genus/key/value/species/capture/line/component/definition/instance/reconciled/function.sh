kv::capture::line () 
{ 
    local clIndent=$1 clKey=$2 clValue=${3-} clText LC_ALL=C;
    if [[ -n $clValue ]]; then
        printf -v clText '%*s%s: %s\n' "$clIndent" '' "$clKey" "$clValue";
    else
        printf -v clText '%*s%s:\n' "$clIndent" '' "$clKey";
    fi;
    ((${#kvCaptureReceipt}+${#clText}<=SILCAPTUREMAXRECEIPT)) || { 
        error::raise PAIR/LIMIT 'capture receipt byte bound';
        return "$SILCAPTUREONE"
    };
    kvCaptureReceipt+=$clText
}
