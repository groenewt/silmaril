type::reset () 
{ 
    typeDefined=();
    typeDefinition=();
    typeAbstract=();
    typeParentCount=();
    typeParent=();
    typeMro=();
    typeVisiting=();
    typeAxiomCount=();
    typeAxiom=();
    typeGroundingCount=();
    typeGrounding=();
    typeTaxonomy=();
    typeShortDescription=();
    typeLongDescription=();
    typeOrder=()
}
