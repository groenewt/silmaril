object::getAt () 
{ 
    local identity=$1;
    local field=$2;
    local index=$3;
    local outputName=$4;
    local -n outputReference=$outputName;
    local key="${identity}${SILMARILUS}${field}";
    local count=${objectFieldCount[$key]:-$SILMARILZERO};
    (( index >= SILMARILZERO && index < count )) || { 
        engine::raise "$SILMARILERRORFIELD" 'index';
        return "$SILMARILFAILURE"
    };
    outputReference=${objectFieldValue[${key}${SILMARILUS}${index}]}
}
