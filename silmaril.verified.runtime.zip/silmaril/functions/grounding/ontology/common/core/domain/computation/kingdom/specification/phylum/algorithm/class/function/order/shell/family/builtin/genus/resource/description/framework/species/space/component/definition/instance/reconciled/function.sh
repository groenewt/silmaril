rdf::space () 
{ 
    local rsChar;
    while :; do
        if ((rdfCursor>=${#rdfText})); then
            rdf::more || break;
        fi;
        rsChar=${rdfText:rdfCursor:1};
        case $rsChar in 
            ' ' | '	' | '
' | '')
                ((rdfCursor+=1))
            ;;
            '#')
                while ((rdfCursor<${#rdfText})) && [[ ${rdfText:rdfCursor:1} != '
' ]]; do
                    ((rdfCursor+=1));
                done
            ;;
            *)
                break
            ;;
        esac;
    done;
    return 0
}
