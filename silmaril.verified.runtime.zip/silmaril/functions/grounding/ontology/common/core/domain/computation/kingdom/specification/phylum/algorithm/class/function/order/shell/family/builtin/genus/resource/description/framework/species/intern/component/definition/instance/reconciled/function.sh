rdf::intern () 
{ 
    local riKind=$1 riTerm=$2 riData=${3-} riLang=${4-} riKey riIndex;
    riKey="${riKind}${SILMARILUS}${riTerm}${SILMARILUS}${riData}${SILMARILUS}${riLang}";
    if [[ -n ${rdfIntern[$riKey]+yes} ]]; then
        rdfTermResult=${rdfIntern[$riKey]};
        return 0;
    fi;
    riIndex=${#rdfTerm[@]};
    rdfTerm[riIndex]=$riTerm;
    rdfKind[riIndex]=$riKind;
    rdfDatatype[riIndex]=$riData;
    rdfLanguage[riIndex]=$riLang;
    rdfLexical[riIndex]=;
    [[ $riKind != literal ]] || rdfLexical[riIndex]=$riTerm;
    rdfIntern[$riKey]=$riIndex;
    rdfTermResult=$riIndex
}
