schema::unsignedByte () 
{ 
    local suText=$1 suDigits suSign suResult;
    schemaValue=;
    schemaCanonical=;
    string::trim "$suText" suText;
    [[ $suText =~ ^([+-]?)([0-9]+)$ ]] || { 
        error::raise ENCODING/INVALID 'unsignedByte lexical space';
        return 1
    };
    suSign=${BASH_REMATCH[1]};
    suDigits=${BASH_REMATCH[2]};
    while [[ ${#suDigits} -gt 1 && $suDigits == 0* ]]; do
        suDigits=${suDigits:1};
    done;
    ((${#suDigits}<=3)) || { 
        error::raise BYTE/RANGE 'unsignedByte range';
        return 1
    };
    suResult=$((10#$suDigits));
    ((suResult<=255)) && [[ $suSign != - || $suResult == 0 ]] || { 
        error::raise BYTE/RANGE 'unsignedByte range';
        return 1
    };
    schemaValue=$suResult;
    schemaCanonical=$suResult
}
