reference::admit () 
{ 
    local raId=$1 raPath raTail raDigit raDigits= raN;
    if [[ $raId == "$PATHNOTATIONBASE":* ]]; then
        path::decode "$raId" raPath || return 1;
        kvKnown[$raId]=1;
        return 0;
    fi;
    raTail=${raId#"${SILMARILROOT}:grounding:ontology:basic:formal:domain:knowledge:representation:kingdom:specification:phylum:formal:contract:class:value:order:declared:family:seed:genus:registry:species:natural:component:decimal:instance:"};
    [[ $raTail != "$raId" ]] || return 1;
    while [[ -n $raTail ]]; do
        raDigit=${raTail%%:*};
        [[ $raTail == *:* ]] && raTail=${raTail#*:} || raTail=;
        case $raDigit in 
            zero)
                raDigits+=0
            ;;
            one)
                raDigits+=1
            ;;
            two)
                raDigits+=2
            ;;
            three)
                raDigits+=3
            ;;
            four)
                raDigits+=4
            ;;
            five)
                raDigits+=5
            ;;
            six)
                raDigits+=6
            ;;
            seven)
                raDigits+=7
            ;;
            eight)
                raDigits+=8
            ;;
            nine)
                raDigits+=9
            ;;
            *)
                return 1
            ;;
        esac;
    done;
    [[ $raDigits =~ ^(0|[1-9][0-9]{0,9})$ ]] || return 1;
    raN=$((10#$raDigits));
    ((raN<=3600000000)) || return 1;
    kvKnown[$raId]=1;
    kvNumber[$raId]=$raN
}
