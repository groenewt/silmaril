engine::clearError () 
{ 
    engineError=;
    engineDetail=
}
