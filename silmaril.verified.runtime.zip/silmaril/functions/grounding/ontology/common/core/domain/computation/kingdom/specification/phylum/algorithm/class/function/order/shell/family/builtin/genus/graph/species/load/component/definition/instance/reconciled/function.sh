graph::load () 
{ 
    local path=$1;
    (( graphLoaded == SILMARILZERO )) || { 
        engine::raise "$SILMARILERRORGRAPH" 'graph already loaded';
        return "$SILMARILFAILURE"
    };
    yaml::parse "$path" || return "$SILMARILFAILURE";
    yaml::assertOnlyKeys "$SILMARILYAMLROOT" IDENTITY TYPE PROTOCOL LOCATION POLICY NODES EDGES || return "$SILMARILFAILURE";
    local graphType;
    yaml::requiredScalar "$SILMARILYAMLROOT" IDENTITY graphIdentity || return "$SILMARILFAILURE";
    yaml::requiredScalar "$SILMARILYAMLROOT" TYPE graphType || return "$SILMARILFAILURE";
    yaml::requiredScalar "$SILMARILYAMLROOT" PROTOCOL graphProtocol || return "$SILMARILFAILURE";
    yaml::requiredScalar "$SILMARILYAMLROOT" LOCATION graphLocation || return "$SILMARILFAILURE";
    identity::requireRankedUrn "$graphIdentity" graph || return "$SILMARILFAILURE";
    identity::requireRankedUrn "$graphLocation" location || return "$SILMARILFAILURE";
    [[ $graphType == "$SILMARILTYPEGRAPH" ]] || { 
        engine::raise "$SILMARILERRORGRAPH" "$graphType";
        return "$SILMARILFAILURE"
    };
    [[ $graphProtocol == "$SILMARILPROTOCOLBUILTIN" ]] || { 
        engine::raise "$SILMARILERRORGRAPHPROTOCOL" "$graphProtocol";
        return "$SILMARILFAILURE"
    };
    object::exists "$graphProtocol" && type::isSubtype "${objectType[$graphProtocol]}" "$SILMARILTYPEPROTOCOL" || { 
        engine::raise "$SILMARILERRORGRAPHPROTOCOL" "$graphProtocol object";
        return "$SILMARILFAILURE"
    };
    local policyPath;
    yaml::requiredMap "$SILMARILYAMLROOT" POLICY policyPath || return "$SILMARILFAILURE";
    yaml::assertOnlyKeys "$policyPath" FAILURE ORDER || return "$SILMARILFAILURE";
    yaml::requiredScalar "$policyPath" FAILURE graphPolicyFailure || return "$SILMARILFAILURE";
    yaml::requiredScalar "$policyPath" ORDER graphPolicyOrder || return "$SILMARILFAILURE";
    [[ $graphPolicyFailure == "$SILMARILPOLICYFAILSTOP" && $graphPolicyOrder == "$SILMARILPOLICYORDERDECLARATION" ]] || { 
        engine::raise "$SILMARILERRORGRAPH" 'unsupported policy';
        return "$SILMARILFAILURE"
    };
    object::new "$graphIdentity" "$SILMARILTYPEGRAPH" || return "$SILMARILFAILURE";
    object::new "$graphLocation" "$SILMARILTYPEFILESYSTEMPATH" || return "$SILMARILFAILURE";
    object::set "$graphIdentity" "$SILMARILFIELDPROTOCOL" "$graphProtocol" || return "$SILMARILFAILURE";
    object::set "$graphIdentity" "$SILMARILFIELDLOCATION" "$graphLocation" || return "$SILMARILFAILURE";
    local nodesPath;
    local nodesLength;
    yaml::requiredSequence "$SILMARILYAMLROOT" NODES nodesPath nodesLength || return "$SILMARILFAILURE";
    local nodeIndex;
    local itemPath;
    local nodeIdentity;
    local nodeType;
    local nodeValue;
    local valuePresent;
    for ((nodeIndex = SILMARILZERO; nodeIndex < nodesLength; nodeIndex += SILMARILONE ))
    do
        yaml::sequenceMap "$nodesPath" "$nodeIndex" itemPath || return "$SILMARILFAILURE";
        yaml::assertOnlyKeys "$itemPath" IDENTITY TYPE VALUE || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" IDENTITY nodeIdentity || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" TYPE nodeType || return "$SILMARILFAILURE";
        identity::requireRankedUrn "$nodeIdentity" node || return "$SILMARILFAILURE";
        type::exists "$nodeType" && type::isSubtype "$nodeType" "$SILMARILTYPENODE" || { 
            engine::raise "$SILMARILERRORGRAPHNODE" "$nodeType";
            return "$SILMARILFAILURE"
        };
        object::new "$nodeIdentity" "$nodeType" || return "$SILMARILFAILURE";
        graphNodeIndex[$nodeIdentity]=$nodeIndex;
        graphNodes+=("$nodeIdentity");
        yaml::optionalScalar "$itemPath" VALUE nodeValue valuePresent || return "$SILMARILFAILURE";
        if (( valuePresent == SILMARILONE )); then
            value::ensureSymbol "$nodeValue" || return "$SILMARILFAILURE";
            object::set "$nodeIdentity" "$SILMARILFIELDVALUE" "$nodeValue" || return "$SILMARILFAILURE";
        fi;
    done;
    local edgesPath;
    local edgesLength;
    yaml::requiredSequence "$SILMARILYAMLROOT" EDGES edgesPath edgesLength || return "$SILMARILFAILURE";
    local edgeIndex;
    local edgeIdentity;
    local source;
    local target;
    local adjacencyKey;
    for ((edgeIndex = SILMARILZERO; edgeIndex < edgesLength; edgeIndex += SILMARILONE ))
    do
        yaml::sequenceMap "$edgesPath" "$edgeIndex" itemPath || return "$SILMARILFAILURE";
        yaml::assertOnlyKeys "$itemPath" IDENTITY SOURCE TARGET || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" IDENTITY edgeIdentity || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" SOURCE source || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" TARGET target || return "$SILMARILFAILURE";
        identity::requireRankedUrn "$edgeIdentity" edge || return "$SILMARILFAILURE";
        object::exists "$source" && object::exists "$target" || { 
            engine::raise "$SILMARILERRORGRAPHEDGE" "$edgeIdentity endpoints";
            return "$SILMARILFAILURE"
        };
        type::isSubtype "${objectType[$source]}" "$SILMARILTYPENODE" && type::isSubtype "${objectType[$target]}" "$SILMARILTYPENODE" || { 
            engine::raise "$SILMARILERRORGRAPHEDGE" "$edgeIdentity types";
            return "$SILMARILFAILURE"
        };
        [[ $source != "$target" ]] || { 
            engine::raise "$SILMARILERRORGRAPHCYCLE" "$edgeIdentity";
            return "$SILMARILFAILURE"
        };
        adjacencyKey="${source}${SILMARILUS}${target}";
        [[ ! -n ${graphAdjacency[$adjacencyKey]+present} ]] || { 
            engine::raise "$SILMARILERRORGRAPHEDGE" 'duplicate dependency';
            return "$SILMARILFAILURE"
        };
        object::new "$edgeIdentity" "$SILMARILTYPEEDGE" || return "$SILMARILFAILURE";
        object::set "$edgeIdentity" "$SILMARILFIELDSOURCE" "$source" || return "$SILMARILFAILURE";
        object::set "$edgeIdentity" "$SILMARILFIELDTARGET" "$target" || return "$SILMARILFAILURE";
        graphEdges+=("$edgeIdentity");
        graphEdgeSource[$edgeIdentity]=$source;
        graphEdgeTarget[$edgeIdentity]=$target;
        graphAdjacency[$adjacencyKey]=$edgeIdentity;
    done;
    graphSourcePath=$path;
    graphRaw=$kvRaw;
    graphLoaded=$SILMARILONE
}
