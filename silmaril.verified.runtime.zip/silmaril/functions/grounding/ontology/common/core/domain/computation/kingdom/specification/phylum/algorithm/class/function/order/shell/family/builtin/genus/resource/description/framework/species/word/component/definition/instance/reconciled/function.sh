rdf::word () 
{ 
    local rwToken= rwChar rwPrefix rwLocal rwResolved rwEscaped rwPercent rwStart=$rdfCursor rwIndex rwLocalStart;
    local -a rwFlags=();
    while ((rdfCursor<${#rdfText})); do
        rwChar=${rdfText:rdfCursor:1};
        case $rwChar in 
            ' ' | '	' | '' | '
' | '[' | ']' | '(' | ')' | ';' | ',' | '#' | '<' | '>' | '"' | "'")
                break
            ;;
        esac;
        rwEscaped=0;
        if [[ $rwChar == '\' ]]; then
            rwEscaped=1;
            ((rdfCursor+=1));
            rwChar=${rdfText:rdfCursor:1};
            [[ $rwChar == [_~.\!\$\&\'\(\)\*+,\;=/?#@%\-] ]] || { 
                rdf::error 'prefixed name escape';
                return 1
            };
        fi;
        if ((rwEscaped==0)); then
            [[ $rwChar == [A-Za-z0-9_:%.+-] ]] || { 
                rdf::error 'outside ASCII prefixed-name profile';
                return 1
            };
            if [[ $rwChar == '%' ]]; then
                rwPercent=${rdfText:rdfCursor+1:2};
                [[ ${#rwPercent} == 2 && $rwPercent != *[!0123456789abcdefABCDEF]* ]] || { 
                    rdf::error 'percent triplet';
                    return 1
                };
            fi;
        fi;
        rwFlags+=("$rwEscaped");
        rwToken+=$rwChar;
        ((rdfCursor+=1));
    done;
    while [[ $rwToken == *. && ${rwFlags[${#rwToken}-1]} == 0 ]]; do
        unset 'rwFlags[${#rwToken}-1]';
        rwToken=${rwToken%.};
        ((rdfCursor-=1));
    done;
    [[ -n $rwToken ]] || { 
        rdf::error 'term required';
        return 1
    };
    case $rwToken in 
        true | false)
            rdf::intern literal "$rwToken" "${XSDNS}boolean"
        ;;
        a)
            [[ ${rdfTermRole:-node} == predicate ]] || { 
                rdf::error 'keyword a is only a predicate';
                return 1
            };
            rdf::intern iri "${RDFNS}type"
        ;;
        _:*)
            rwLocal=${rwToken#_:};
            [[ $rwLocal =~ ^[A-Za-z0-9_][A-Za-z0-9_.-]*$ ]] || { 
                rdf::error 'blank node label';
                return 1
            };
            if [[ -n ${rdfBlankLabels[$rwLocal]+yes} ]]; then
                rdfTermResult=${rdfBlankLabels[$rwLocal]};
            else
                rdf::blank;
                rdfBlankLabels[$rwLocal]=$rdfTermResult;
            fi
        ;;
        *:*)
            rwPrefix=${rwToken%%:*};
            rwLocal=${rwToken#*:};
            [[ -n ${rdfPrefixes[$rwPrefix@]+yes} && $rwPrefix =~ ^([A-Za-z]([A-Za-z0-9_.-]*[A-Za-z0-9_-])?)?$ && $rwLocal != *'^^'* ]] || { 
                rdf::error 'unknown prefix or bad local name';
                return 1
            };
            rwLocalStart=$((${#rwPrefix}+1));
            for ((rwIndex=rwLocalStart; rwIndex<${#rwToken}; rwIndex+=1))
            do
                [[ ${rwFlags[rwIndex]} == 0 ]] || continue;
                rwChar=${rwToken:rwIndex:1};
                [[ $rwChar != + ]] || { 
                    rdf::error 'unescaped plus in local name';
                    return 1
                };
                if ((rwIndex==rwLocalStart)); then
                    [[ $rwChar != [-.] ]] || { 
                        rdf::error 'invalid initial local character';
                        return 1
                    };
                fi;
            done;
            rwResolved=${rdfPrefixes[$rwPrefix@]}$rwLocal;
            rdf::intern iri "$rwResolved"
        ;;
        *)
            if [[ $rwToken =~ ^[+-]?[0-9]+$ ]]; then
                rdf::intern literal "$rwToken" "${XSDNS}integer";
            else
                if [[ $rwToken =~ ^[+-]?([0-9]*\.[0-9]+)$ ]]; then
                    rdf::intern literal "$rwToken" "${XSDNS}decimal";
                else
                    if [[ $rwToken =~ ^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)[eE][+-]?[0-9]+$ ]]; then
                        rdf::intern literal "$rwToken" "${XSDNS}double";
                    else
                        rdf::error "invalid token $rwToken";
                        return 1;
                    fi;
                fi;
            fi
        ;;
    esac
}
