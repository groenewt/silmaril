kv::turtle () 
{ 
    local ktPath ktPair ktBind ktN;
    for ktPath in "${kvPaths[@]}";
    do
        ktPair=${kvPair[$ktPath]};
        ktBind=${kvBinding[$ktPath]};
        projection::triple "$ktPair" "$PROJECTIONBASE:type" "$PROJECTIONBASE:pair";
        projection::triple "$ktPair" "$PROJECTIONBASE:key" "${kvPredicate[$ktPath]}";
        projection::triple "$ktPair" "$PROJECTIONBASE:value" "${kvRight[$ktPath]}";
        projection::triple "$ktBind" "$PROJECTIONBASE:type" "$PROJECTIONBASE:binding";
        projection::triple "$ktBind" "$PROJECTIONBASE:pair" "$ktPair";
        projection::triple "$ktBind" "$PROJECTIONBASE:subject" "${kvSubject[$ktPath]}";
        projection::triple "$ktBind" "$PROJECTIONBASE:carrier" "${kvCarrier[$ktPath]}";
        projection::triple "$ktBind" "$PROJECTIONBASE:position" "${kvPosition[$ktPath]}";
        projection::triple "$ktBind" "$PROJECTIONBASE:provenance" "${kvProvenance[$ktPath]}";
        number::reference "${kvOffset[$ktPath]}" ktN;
        projection::triple "${kvPosition[$ktPath]}" "$PROJECTIONBASE:offset" "$ktN";
        number::reference "${kvSpan[$ktPath]}" ktN;
        projection::triple "${kvPosition[$ktPath]}" "$PROJECTIONBASE:length" "$ktN";
        if [[ $ktPath == */METADATA/SHORT/DESCRIPTION || $ktPath == */METADATA/LONG/DESCRIPTION ]]; then
            projection::literal "${kvRight[$ktPath]}" "$PROJECTIONBASE:notation" "${kvValue[$ktPath]}";
        fi;
    done
}
