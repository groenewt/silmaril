type::sequenceContains () 
{ 
    local sequence=$1;
    local needle=$2;
    local token;
    local remaining=$sequence;
    while [[ -n $remaining ]]; do
        type::sequenceHead "$remaining" token;
        [[ $token != "$needle" ]] || return "$SILMARILZERO";
        type::sequenceTail "$remaining" remaining;
    done;
    return "$SILMARILFAILURE"
}
