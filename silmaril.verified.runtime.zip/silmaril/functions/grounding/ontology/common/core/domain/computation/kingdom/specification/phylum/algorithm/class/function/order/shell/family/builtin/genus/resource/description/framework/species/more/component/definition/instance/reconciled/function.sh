rdf::more () 
{ 
    ((rdfLineIndex<${#rdfLines[@]})) || return 1;
    ((rdfAbsoluteOffset+=${#rdfText}));
    rdfText=${rdfLines[rdfLineIndex]};
    ((rdfLineIndex+=1));
    rdfText+='
';
    rdfCursor=0
}
