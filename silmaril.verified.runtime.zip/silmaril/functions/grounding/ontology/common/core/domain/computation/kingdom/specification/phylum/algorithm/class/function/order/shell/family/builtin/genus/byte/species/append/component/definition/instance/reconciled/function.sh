byte::append () 
{ 
    local streamIdentity=$1;
    local value=$2;
    [[ ${byteStreamDefined[$streamIdentity]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERROROBJECT" "$streamIdentity";
        return "$SILMARILFAILURE"
    };
    [[ $value =~ ^[0-9]+$ ]] && (( value >= SILMARILZERO && value <= 255 )) || { 
        engine::raise "$SILMARILERROROBJECT" 'byte range';
        return "$SILMARILFAILURE"
    };
    local count=${byteStreamCount[$streamIdentity]:-$SILMARILZERO};
    local byteWords;
    name::number "$count" byteWords || return 1;
    local byteIdentity="${streamIdentity}:occurrence:ordinal:${byteWords}";
    object::new "$byteIdentity" "$SILMARILTYPEBYTE" || return "$SILMARILFAILURE";
    byteStreamValue[${streamIdentity}${SILMARILUS}${count}]=$value;
    byteStreamObject[${streamIdentity}${SILMARILUS}${count}]=$byteIdentity;
    byteStreamCount[$streamIdentity]=$(( count + SILMARILONE ))
}
