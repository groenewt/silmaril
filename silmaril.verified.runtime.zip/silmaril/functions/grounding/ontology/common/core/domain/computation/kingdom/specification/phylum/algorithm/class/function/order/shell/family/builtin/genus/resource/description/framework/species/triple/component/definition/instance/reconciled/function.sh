rdf::triple () 
{ 
    local rtSubject=$1 rtPredicate=$2 rtObject=$3 rtKey rtIndex;
    [[ ${rdfKind[rtSubject]} != literal && ${rdfKind[rtPredicate]} == iri ]] || { 
        rdf::error 'invalid subject or predicate';
        return 1
    };
    rtKey="$rdfContext,$rtSubject,$rtPredicate,$rtObject";
    [[ ! -n ${rdfTriples[$rtKey]+yes} ]] || return 0;
    ((${#rdfSubject[@]} < rdfMaximumTriples)) || { 
        rdf::error 'triple capacity';
        return 1
    };
    rtIndex=${#rdfSubject[@]};
    rdfTriples[$rtKey]=$rtIndex;
    rdfSubject[rtIndex]=$rtSubject;
    rdfPredicate[rtIndex]=$rtPredicate;
    rdfObject[rtIndex]=$rtObject;
    rdfGraph[rtIndex]=$rdfContext;
    local rtForward="$rdfContext,$rtSubject,${rdfTerm[rtPredicate]}";
    rdfForward[$rtForward]+=" $rtObject";
    if [[ ${rdfTerm[rtPredicate]} == "http://www.w3.org/2000/01/rdf-schema#subClassOf" && ${rdfKind[rtObject]} != literal ]]; then
        rdfParents[$rtSubject]+=" $rtObject";
    fi
}
