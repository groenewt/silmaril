kv::emit () 
{ 
    local kePath keIndent keRest keKey keText kePrefix;
    for kePath in "${kvPaths[@]}";
    do
        keRest=${kePath#ROOT/};
        kePrefix=${keRest//[^\/]/};
        keIndent=$((${#kePrefix}*2));
        keKey=${kePath##*/};
        printf '%*s%s:' "$keIndent" '' "$keKey";
        if [[ ${kvKind[$kePath]} == scalar ]]; then
            keText=${kvValue[$kePath]};
            if [[ $kePath == */METADATA/SHORT/DESCRIPTION || $kePath == */METADATA/LONG/DESCRIPTION ]]; then
                keText=${keText//\\/\\\\};
                keText=${keText//\"/\\\"};
                keText=${keText//'
'/\\n};
                keText=${keText//'	'/\\t};
                keText=${keText//''/\\r};
                printf ' "%s"' "$keText";
            else
                printf ' %s' "$keText";
            fi;
        fi;
        printf '\n';
    done
}
