identity::rankValue () 
{ 
    local rvId=$1 rvRank=$2 rvOut=$3 rvTail rvCurrent rvNext rvHead rvPart;
    local -a rvRanks=(domain kingdom phylum class order family genus species);
    rvTail=${rvId#*:domain:};
    [[ $rvTail != "$rvId" ]] || return 1;
    local rvI;
    for ((rvI=0; rvI<${#rvRanks[@]}; rvI++))
    do
        rvCurrent=${rvRanks[$rvI]};
        rvNext=${rvRanks[$((rvI+1))]-component};
        rvHead=${rvTail%%:*};
        [[ -n $rvHead ]] || return 1;
        if [[ $rvTail == *:* ]]; then
            rvTail=${rvTail#*:};
            if [[ $rvTail == "$rvNext:"* ]]; then
                rvPart=$rvHead;
                rvTail=${rvTail#"$rvNext:"};
            else
                if [[ $rvTail == *":$rvNext:"* ]]; then
                    rvPart=$rvHead:${rvTail%%":$rvNext:"*};
                    rvTail=${rvTail#*":$rvNext:"};
                else
                    if [[ $rvCurrent == species ]]; then
                        rvPart=$rvHead:$rvTail;
                        rvTail=;
                    else
                        return 1;
                    fi;
                fi;
            fi;
        else
            rvPart=$rvHead;
            rvTail=;
        fi;
        if [[ $rvCurrent == "$rvRank" ]]; then
            rvPart=${rvPart%%:realm:*};
            rvPart=${rvPart%%:subdomain:*};
            printf -v "$rvOut" '%s' "$rvPart";
            return 0;
        fi;
    done;
    return 1
}
