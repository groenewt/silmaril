publication::member () 
{ 
    local pmI=$1 pmIndent=$2 pmOut=$3 pmWords pmDigit;
    name::number "$pmI" pmWords;
    pmWords=${pmWords^^};
    while [[ -n $pmWords ]]; do
        pmDigit=${pmWords%%:*};
        [[ $pmWords == *:* ]] && pmWords=${pmWords#*:} || pmWords=;
        printf '%*s%s:\n' "$pmIndent" '' "$pmDigit";
        ((pmIndent+=2));
    done;
    printf '%*sITEM:\n' "$pmIndent" '';
    ((pmIndent+=2));
    printf -v "$pmOut" '%s' "$pmIndent"
}
