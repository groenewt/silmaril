byte::count () 
{ 
    local streamIdentity=$1;
    local outputName=$2;
    [[ ${byteStreamDefined[$streamIdentity]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERROROBJECT" "$streamIdentity";
        return "$SILMARILFAILURE"
    };
    local -n outputReference=$outputName;
    outputReference=${byteStreamCount[$streamIdentity]}
}
