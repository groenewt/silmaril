uri::component () 
{ 
    local ucText=$1 ucMode=$2 ucI ucChar ucHex LC_ALL=C;
    for ((ucI=0; ucI<${#ucText}; ucI++))
    do
        ucChar=${ucText:ucI:1};
        if [[ $ucChar == % ]]; then
            ucHex=${ucText:ucI+1:2};
            [[ $ucHex =~ ^[0-9a-fA-F]{2}$ ]] || return 1;
            ((ucI+=2));
            continue;
        fi;
        case $ucChar in 
            [a-zA-Z0-9._~] | '!' | '$' | '&' | "'" | '(' | ')' | '*' | '+' | ',' | ';' | '=')
                :
            ;;
            ':')
                [[ $ucMode != host ]] || return 1
            ;;
            '@')
                [[ $ucMode != host && $ucMode != user ]] || return 1
            ;;
            '/')
                [[ $ucMode == path || $ucMode == query ]] || return 1
            ;;
            '?')
                [[ $ucMode == query ]] || return 1
            ;;
            *)
                return 1
            ;;
        esac;
    done;
    return 0
}
