kv::capture::candidate () 
{ 
    local ccFile=$1 ccObservation=$2 ccExpected=$3 ccReceipt=${4-};
    local ccActual ccLocation ccTail ccDelimiters ccWords ccCarrier ccPath ccPart ccId ccRead= ccStatus;
    local LC_ALL=C;
    identity::requireRankedUrn "$ccObservation" observation || return "$SILCAPTUREONE";
    [[ $ccExpected =~ ^[0-9a-f]+$ ]] && ((${#ccExpected}==SILCAPTUREDIGESTCHARACTERS)) || { 
        error::raise PROJECTION/FIDELITY 'capture requires an independent lowercase SHA256 pin';
        return "$SILCAPTUREONE"
    };
    kv::parse "$ccFile" || return "$SILCAPTUREONE";
    ((${#kvPaths[@]}<=SILCAPTUREMAXROWS)) || { 
        error::raise PAIR/LIMIT 'capture binding bound';
        return "$SILCAPTUREONE"
    };
    hash::text "$kvRaw" ccActual || return "$SILCAPTUREONE";
    [[ $ccActual == "$ccExpected" ]] || { 
        error::raise PROJECTION/FIDELITY 'capture input pin does not match source bytes';
        return "$SILCAPTUREONE"
    };
    path::identify "$ccFile" ccLocation || return "$SILCAPTUREONE";
    ccTail=${ccObservation#"$SILMARILROOT:"};
    ccDelimiters=${ccTail//[^:]/};
    name::number "$((${#ccDelimiters}+SILCAPTUREONE))" ccWords || return "$SILCAPTUREONE";
    ccCarrier="$SILCAPTUREBASE:component:bytes:instance:observation:length:$ccWords:lexeme:$ccTail:location${ccLocation#"$PATHNOTATIONBASE"}";
    [[ ! -n ${kvCapturePins[$ccCarrier]+present} || ${kvCapturePins[$ccCarrier]} == "$ccActual" ]] || { 
        error::raise PROJECTION/FIDELITY 'observed carrier identity cannot be rebound to different bytes';
        return "$SILCAPTUREONE"
    };
    for ccPath in "${kvPaths[@]}";
    do
        ccPart=${ccPath#ROOT/};
        ccPart=${ccPart,,};
        ccPart=${ccPart//\//:};
        kvBinding[$ccPath]="$ccCarrier:occurrence:binding:$ccPart";
        kvCarrier[$ccPath]=$ccCarrier;
        kvPosition[$ccPath]="$ccCarrier:occurrence:position:$ccPart";
        kvProvenance[$ccPath]="$ccCarrier:occurrence:derivation:$ccPart";
        if [[ $ccPath == */METADATA/SHORT/DESCRIPTION || $ccPath == */METADATA/LONG/DESCRIPTION ]]; then
            kvRight[$ccPath]="$ccCarrier:occurrence:description:$ccPart";
        fi;
        pair::identity "${kvPredicate[$ccPath]}" "${kvRight[$ccPath]}" ccId || return "$SILCAPTUREONE";
        kvPair[$ccPath]=$ccId;
    done;
    kv::check || return "$SILCAPTUREONE";
    kvCaptureObservation=$ccObservation;
    kvCaptureSource=$ccLocation;
    kvCaptureDigest=$ccActual;
    kvCaptureCount=${#kvPaths[@]};
    kvCaptureReceipt=;
    kv::capture::line "$SILCAPTUREZERO" IDENTITY "$ccCarrier:occurrence:account" || return "$SILCAPTUREONE";
    kv::capture::line "$SILCAPTUREZERO" DOCUMENT "$kvDocument" || return "$SILCAPTUREONE";
    kv::capture::line "$SILCAPTUREZERO" SNAPSHOT "$ccObservation" || return "$SILCAPTUREONE";
    kv::capture::line "$SILCAPTUREZERO" SOURCE "$ccLocation" || return "$SILCAPTUREONE";
    kv::capture::line "$SILCAPTUREZERO" ALGORITHM "$MANIFESTALGORITHM" || return "$SILCAPTUREONE";
    kv::capture::line "$SILCAPTUREZERO" DIGEST || return "$SILCAPTUREONE";
    kv::capture::vector "$SILCAPTUREDIGESTOCTETS" "$SILCAPTURETWO" digest || return "$SILCAPTUREONE";
    kv::capture::line "$SILCAPTUREZERO" BINDING || return "$SILCAPTUREONE";
    kv::capture::vector "$kvCaptureCount" "$SILCAPTURETWO" binding || return "$SILCAPTUREONE";
    if [[ -n $ccReceipt ]]; then
        path::requireReadable "$ccReceipt" || return "$SILCAPTUREONE";
        ccStatus=$SILCAPTUREZERO;
        IFS= read -r -d '' -n "$((SILCAPTUREMAXRECEIPT+SILCAPTUREONE))" ccRead < "$ccReceipt" || ccStatus=$?;
        ((ccStatus==SILCAPTUREONE && ${#ccRead}<=SILCAPTUREMAXRECEIPT)) && [[ $ccRead == "$kvCaptureReceipt" ]] || { 
            error::raise PROJECTION/FIDELITY 'capture receipt differs, is truncated, contains NUL, or exceeds its bound';
            return "$SILCAPTUREONE"
        };
    fi;
    kvKnown[$ccObservation]=1;
    for ccPath in "${kvPaths[@]}";
    do
        for ccId in "${kvBinding[$ccPath]}" "${kvCarrier[$ccPath]}" "${kvPosition[$ccPath]}" "${kvProvenance[$ccPath]}" "${kvPair[$ccPath]}" "${kvRight[$ccPath]}";
        do
            kvKnown[$ccId]=1;
        done;
    done;
    kvCapturePins[$ccCarrier]=$ccActual;
    kvCaptureVerified=$SILCAPTUREONE
}
