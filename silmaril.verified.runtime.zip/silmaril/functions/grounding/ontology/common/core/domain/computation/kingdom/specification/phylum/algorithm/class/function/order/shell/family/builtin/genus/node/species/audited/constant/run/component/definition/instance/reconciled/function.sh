node::auditedConstant::run () 
{ 
    local identity=$1;
    local method=$2;
    local owner=$3;
    local outputName=$4;
    local inheritedFrame=;
    object::callNext "$identity" "$method" "$owner" inheritedFrame || { 
        frame::failure "$SILMARILERRORDISPATCH" "$outputName";
        return "$SILMARILFAILURE"
    };
    if [[ -z $inheritedFrame ]]; then
        frame::failure "$SILMARILERRORDISPATCH" "$outputName";
        return 1;
    fi;
    if [[ ${frameStatus[$inheritedFrame]} != "$SILMARILSTATUSSUCCESS" ]]; then
        frame::forward "$inheritedFrame" "$outputName";
        return "$SILMARILFAILURE";
    fi;
    frame::success "${frameOutput[$inheritedFrame]}" "$SILMARILEFFECTAUDIT" "$outputName"
}
