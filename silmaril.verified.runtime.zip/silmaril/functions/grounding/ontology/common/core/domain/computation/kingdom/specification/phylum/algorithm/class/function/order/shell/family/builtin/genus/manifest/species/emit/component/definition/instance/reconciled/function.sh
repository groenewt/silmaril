manifest::emit () 
{ 
    local meRoot=$1 meManifest=$2 meIndex meCount meRef meDigest meSize;
    local -a mePaths=() meDigests=() meSizes=();
    path::requireSafe "$meRoot" && path::requireWritableTarget "$meManifest" || return 1;
    [[ $meManifest == "${meRoot%/}/"* ]] || { 
        error::raise PATH/ROOT 'manifest output must be inside the release root';
        return 1
    };
    inventory::scan "$meRoot" || return 1;
    for meIndex in "${!inventoryPath[@]}";
    do
        [[ ${inventoryKind[meIndex]} == file && ${inventoryPath[meIndex]} != "$meManifest" ]] || continue;
        hash::file "${inventoryPath[meIndex]}" meDigest meSize || return 1;
        mePaths+=("${inventoryPath[meIndex]}");
        meDigests+=("$meDigest");
        meSizes+=("$meSize");
    done;
    ((${#mePaths[@]}>0)) || { 
        error::raise VECTOR/CARDINALITY 'empty release';
        return 1
    };
    path::identify "$meRoot" meRef || return 1;
    number::reference "${#mePaths[@]}" meCount;
    printf 'IDENTITY: %s\nSOURCE: %s\nALGORITHM: %s\nCOUNT: %s\nMEMBERS:\n' "$MANIFESTALGORITHM:component:manifest:instance:release" "$meRef" "$MANIFESTALGORITHM" "$meCount";
    publication::vector "${#mePaths[@]}" 2 manifest::emitItem
}
