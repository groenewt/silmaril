yaml::requiredSequence () 
{ 
    local parent=$1;
    local key=$2;
    local outputName=$3;
    local lengthName=$4;
    local -n outputReference=$outputName;
    local -n lengthReference=$lengthName;
    local pathValue;
    yaml::join pathValue "$parent" "$key";
    [[ ${yamlKind[$pathValue]-} == sequence ]] || { 
        engine::raise "$SILMARILERRORYAML" "required sequence $key";
        return "$SILMARILFAILURE"
    };
    outputReference=$pathValue;
    lengthReference=${yamlLength[$pathValue]:-$SILMARILZERO}
}
