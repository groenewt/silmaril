yaml::join () 
{ 
    local outputName=$1;
    local parent=$2;
    local segment=$3;
    local -n outputReference=$outputName;
    outputReference="${parent}${SILMARILUS}${segment}"
}
