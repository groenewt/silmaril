finite::certify () 
{ 
    local fcFile=$1 fcM fcA fcN;
    finite::load "$fcFile" && category::check || return 1;
    for fcM in "${modelNames[@]}";
    do
        model::check "$fcM" && elements::build "$fcM" && elements::check || return 1;
        for fcA in "${categoryObjects[@]}";
        do
            coend::check "$fcM" "$fcA" && yoneda::check "$fcM" "$fcA" || return 1;
        done;
    done;
    for fcN in "${naturalNames[@]}";
    do
        natural::check "$fcN" || return 1;
    done;
    yoneda::fullyFaithful
}
