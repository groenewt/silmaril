identity::requireUrn () 
{ 
    local iuValue=${1-} iuLabel=${2-identity};
    [[ $iuValue == "$SILMARILROOT":* && $iuValue =~ ^urn:silmaril(:[a-z][a-z0-9]*)+$ ]] || { 
        error::raise RESOURCE/UNIFORM/NAME/SYNTAX "$iuLabel";
        return 1
    }
}
