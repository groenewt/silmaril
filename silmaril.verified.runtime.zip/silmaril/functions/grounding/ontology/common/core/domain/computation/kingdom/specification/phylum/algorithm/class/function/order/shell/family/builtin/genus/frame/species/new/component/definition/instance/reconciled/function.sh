frame::new () 
{ 
    local status=$1;
    local output=$2;
    local effect=$3;
    local error=$4;
    local outputName=$5;
    local -n outputReference=$outputName;
    value::ensureSymbol "$status" || return "$SILMARILFAILURE";
    value::ensureSymbol "$effect" || return "$SILMARILFAILURE";
    value::ensureSymbol "$error" || return "$SILMARILFAILURE";
    object::exists "$output" || { 
        engine::raise "$SILMARILERRORFRAME" "$output";
        return "$SILMARILFAILURE"
    };
    type::isSubtype "${objectType[$output]}" "$SILMARILTYPEVALUE" || { 
        engine::raise "$SILMARILERRORFRAME" 'output type';
        return "$SILMARILFAILURE"
    };
    local frameWords;
    name::number "$frameCounter" frameWords;
    local createdFrame="urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:computation:kingdom:execution:phylum:frame:class:occurrence:order:runtime:family:frame:genus:result:species:frame:component:frame:instance:${frameWords}";
    (( frameCounter += SILMARILONE ));
    object::new "$createdFrame" "$SILMARILTYPEFRAME" || return "$SILMARILFAILURE";
    object::set "$createdFrame" "$SILMARILFIELDOUTPUT" "$output" || return "$SILMARILFAILURE";
    object::set "$createdFrame" "$SILMARILFIELDEFFECT" "$effect" || return "$SILMARILFAILURE";
    object::set "$createdFrame" "$SILMARILFIELDERROR" "$error" || return "$SILMARILFAILURE";
    object::set "$createdFrame" "$SILMARILFIELDSTATUS" "$status" || return "$SILMARILFAILURE";
    frameStatus[$createdFrame]=$status;
    frameOutput[$createdFrame]=$output;
    frameEffect[$createdFrame]=$effect;
    frameError[$createdFrame]=$error;
    frameOrder+=("$createdFrame");
    outputReference=$createdFrame
}
