publication::state () 
{ 
    local psState=$1 psOut=$2;
    case $psState in 
        compensationmissing)
            psState=compensation:missing
        ;;
        compensationfailed)
            psState=compensation:failed
        ;;
    esac;
    printf -v "$psOut" '%s' "$CHECKPOINTSTATEBASE:$psState"
}
