engine::registerMethods () 
{ 
    method::define "$SILMARILTYPECONSTANTNODE" "$SILMARILMETHODRUN" node::constant::run || return "$SILMARILFAILURE";
    method::define "$SILMARILTYPEAUDITEDCONSTANTNODE" "$SILMARILMETHODRUN" node::auditedConstant::run || return "$SILMARILFAILURE";
    method::define "$SILMARILTYPEIDENTITYNODE" "$SILMARILMETHODRUN" node::identity::run || return "$SILMARILFAILURE";
    method::define "$SILMARILTYPEJOINNODE" "$SILMARILMETHODRUN" node::join::run || return "$SILMARILFAILURE"
}
