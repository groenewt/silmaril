topology::check () 
{ 
    local tcA tcB tcMax tcU tcI;
    local -A tcSeen=();
    [[ $topologyCarrier =~ ^(0|[1-9][0-9]?)$ ]] && ((topologyCarrier<=12)) || { 
        error::raise PAIR/LIMIT 'finite topology carrier';
        return 1
    };
    tcMax=$(((1<<topologyCarrier)-1));
    for tcA in "${topologyOpen[@]}";
    do
        [[ $tcA =~ ^(0|[1-9][0-9]{0,3})$ ]] && ((tcA<=tcMax)) && [[ ! -n ${tcSeen[$tcA]+present} ]] || { 
            error::raise CATEGORY/EQUATION 'open subset';
            return 1
        };
        tcSeen[$tcA]=1;
    done;
    [[ -n ${tcSeen[0]+present} && -n ${tcSeen[$tcMax]+present} ]] || { 
        error::raise CATEGORY/EQUATION 'empty and total opens';
        return 1
    };
    for tcA in "${topologyOpen[@]}";
    do
        for tcB in "${topologyOpen[@]}";
        do
            tcU=$((tcA|tcB));
            tcI=$((tcA&tcB));
            [[ -n ${tcSeen[$tcU]+present} && -n ${tcSeen[$tcI]+present} ]] || { 
                error::raise CATEGORY/EQUATION 'open union or intersection closure';
                return 1
            };
        done;
    done
}
