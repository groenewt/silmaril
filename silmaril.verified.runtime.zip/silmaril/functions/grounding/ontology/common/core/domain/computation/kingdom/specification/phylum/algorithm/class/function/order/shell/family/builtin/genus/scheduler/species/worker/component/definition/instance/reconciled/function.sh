scheduler::worker () 
{ 
    local swNode=$1 swMethod=$2 schedulerAttempt=$3 swFrame= swStatus=0 swGuard=0;
    runtime::begin || return 1;
    object::call "$swNode" "$swMethod" swFrame || swStatus=$?;
    runtime::end || swGuard=$?;
    if ((swGuard)); then
        frame::failure "$SILMARILERRORRUNTIMEEXTERNAL" swFrame || return 1;
        swStatus=1;
    fi;
    if [[ -z $swFrame || ! -n ${frameStatus[$swFrame]+present} ]]; then
        frame::failure "$SILMARILERRORGRAPHNODE" swFrame || return 1;
        swStatus=1;
    fi;
    if ((swStatus)) && [[ ${frameStatus[$swFrame]} == "$SILMARILSTATUSSUCCESS" ]]; then
        frame::failure "$SILMARILERRORGRAPHNODE" swFrame || return 1;
    fi;
    printf 'STATUS: %s\nOUTPUT: %s\nEFFECT: %s\nERROR: %s\n' "${frameStatus[$swFrame]}" "${frameOutput[$swFrame]}" "${frameEffect[$swFrame]}" "${frameError[$swFrame]}"
}
