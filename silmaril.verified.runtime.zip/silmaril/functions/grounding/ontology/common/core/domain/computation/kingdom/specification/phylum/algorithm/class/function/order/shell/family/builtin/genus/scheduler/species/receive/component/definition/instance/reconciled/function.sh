scheduler::receive () 
{ 
    local srFd=$1 srPid=$2 srStart=$3 srOut=$4 srWire= srRc=0 srWait=0 srNow srRemaining srSeconds srFraction srTimeout;
    local srLine srKey srValue srN=0 srFrame srError=;
    local -A srValues=();
    if ((schedulerTimeout>0)); then
        scheduler::clock srNow || return 1;
        srRemaining=$((schedulerTimeout-(srNow-srStart)));
        if ((srRemaining<=0)); then
            srError=EXECUTION/TIMEOUT;
        else
            srSeconds=$((srRemaining/1000000));
            srFraction=$((srRemaining%1000000));
            printf -v srTimeout '%s.%06d' "$srSeconds" "$srFraction";
            IFS= read -r -d '' -n 131073 -t "$srTimeout" srWire <&"$srFd" || srRc=$?;
            ((srRc<=128)) || srError=EXECUTION/TIMEOUT;
        fi;
    else
        IFS= read -r -d '' -n 131073 srWire <&"$srFd" || srRc=$?;
    fi;
    if [[ -n $srError ]]; then
        scheduler::stop "$srPid";
        exec {srFd}>&-;
        frame::failure "${errorRegistry[$srError]}" srFrame || return 1;
        printf -v "$srOut" '%s' "$srFrame";
        error::raise "$srError" 'worker deadline';
        return 1;
    fi;
    if ((srRc!=1 || ${#srWire}>131072)) || [[ $srWire != *'
' ]]; then
        scheduler::stop "$srPid";
        exec {srFd}>&-;
        frame::failure "${errorRegistry[PROJECTION/FIDELITY]}" srFrame || return 1;
        printf -v "$srOut" '%s' "$srFrame";
        error::raise PROJECTION/FIDELITY 'worker envelope';
        return 1;
    fi;
    exec {srFd}>&-;
    wait "$srPid" || srWait=$?;
    while IFS= read -r srLine; do
        [[ -n $srLine ]] || continue;
        [[ $srLine =~ ^(STATUS|OUTPUT|EFFECT|ERROR):\ (urn:silmaril(:[a-z][a-z0-9]*)+)$ ]] || { 
            srError=PROJECTION/FIDELITY;
            break
        };
        srKey=${BASH_REMATCH[1]};
        srValue=${BASH_REMATCH[2]};
        [[ ! -n ${srValues[$srKey]+present} ]] || { 
            srError=PROJECTION/FIDELITY;
            break
        };
        srValues[$srKey]=$srValue;
        ((srN+=1));
    done <<< "$srWire";
    if ((srN!=4 || srWait!=0)); then
        srError=PROJECTION/FIDELITY;
    fi;
    if [[ -z $srError ]]; then
        [[ ${srValues[STATUS]-} == "$SILMARILSTATUSSUCCESS" || ${srValues[STATUS]-} == "$SILMARILSTATUSFAILURE" ]] || srError=PROJECTION/FIDELITY;
        object::exists "${srValues[OUTPUT]-}" || srError=PROJECTION/FIDELITY;
        [[ -n ${kvKnown[${srValues[EFFECT]-}]-}${objectDefined[${srValues[EFFECT]-}]-} ]] || srError=PROJECTION/FIDELITY;
        [[ -n ${kvKnown[${srValues[ERROR]-}]-}${objectDefined[${srValues[ERROR]-}]-} ]] || srError=PROJECTION/FIDELITY;
    fi;
    if [[ -n $srError ]]; then
        frame::failure "${errorRegistry[$srError]}" srFrame || return 1;
        printf -v "$srOut" '%s' "$srFrame";
        error::raise "$srError" 'worker result';
        return 1;
    fi;
    frame::new "${srValues[STATUS]}" "${srValues[OUTPUT]}" "${srValues[EFFECT]}" "${srValues[ERROR]}" srFrame || return 1;
    printf -v "$srOut" '%s' "$srFrame";
    if [[ ${srValues[STATUS]} != "$SILMARILSTATUSSUCCESS" ]]; then
        engineError=${srValues[ERROR]};
        return 1;
    fi
}
