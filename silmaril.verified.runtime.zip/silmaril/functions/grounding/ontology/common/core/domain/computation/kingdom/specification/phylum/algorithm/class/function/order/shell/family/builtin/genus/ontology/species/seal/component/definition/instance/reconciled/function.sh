ontology::seal () 
{ 
    local required;
    local -a requiredTypes=("$SILMARILTYPEOBJECT" "$SILMARILTYPETYPE" "$SILMARILTYPEDEFINITION" "$SILMARILTYPEAXIOM" "$SILMARILTYPEPAIR" "$SILMARILTYPEKEYVALUEPAIR" "$SILMARILTYPEBYTE" "$SILMARILTYPEBYTESTREAM" "$SILMARILTYPEFRAME" "$SILMARILTYPESET" "$SILMARILTYPEGROUP" "$SILMARILTYPECLASS" "$SILMARILTYPECATEGORY" "$SILMARILTYPETOPOLOGY" "$SILMARILTYPEGEOMETRY" "$SILMARILTYPEMETRICSPACE" "$SILMARILTYPEFILESYSTEMPATH" "$SILMARILTYPEBUILTINPROTOCOL" "$SILMARILTYPEGRAPH" "$SILMARILTYPENODE");
    for required in "${requiredTypes[@]}";
    do
        type::exists "$required" || { 
            engine::raise "$SILMARILERRORTYPE" "$required";
            return "$SILMARILFAILURE"
        };
    done;
    [[ ${groundingDefined[$SILMARILGROUNDINGBASICFORMAL]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERRORGROUNDING" "$SILMARILGROUNDINGBASICFORMAL";
        return "$SILMARILFAILURE"
    };
    type::isSubtype "$SILMARILTYPEGROUP" "$SILMARILTYPEMONOID" || { 
        engine::raise "$SILMARILERRORTYPE" 'group ancestry';
        return "$SILMARILFAILURE"
    };
    type::isSubtype "$SILMARILTYPEMETRICSPACE" "$SILMARILTYPETOPOLOGY" || { 
        engine::raise "$SILMARILERRORTYPE" 'metric topology ancestry';
        return "$SILMARILFAILURE"
    };
    type::isSubtype "$SILMARILTYPEMETRICSPACE" "$SILMARILTYPEGEOMETRY" || { 
        engine::raise "$SILMARILERRORTYPE" 'metric geometry ancestry';
        return "$SILMARILFAILURE"
    };
    if type::isSubtype "$SILMARILTYPECLASS" "$SILMARILTYPESET"; then
        engine::raise "$SILMARILERRORTYPE" 'class set collapse';
        return "$SILMARILFAILURE";
    fi;
    local identity;
    for identity in "${typeOrder[@]}";
    do
        (( ${typeGroundingCount[$identity]:-$SILMARILZERO} >= SILMARILONE )) || { 
            engine::raise "$SILMARILERRORGROUNDING" "$identity";
            return "$SILMARILFAILURE"
        };
        (( ${typeAxiomCount[$identity]:-$SILMARILZERO} >= SILMARILONE )) || { 
            engine::raise "$SILMARILERRORAXIOM" "$identity";
            return "$SILMARILFAILURE"
        };
    done
}
