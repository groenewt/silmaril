rdf::term () 
{ 
    ((rdfDepth+=1));
    ((rdfDepth<=rdfMaximumDepth)) || { 
        rdf::error 'nesting capacity';
        return 1
    };
    rdf::space;
    local rdfTermRole=${1:-node};
    local rtmChar=${rdfText:rdfCursor:1} rtmSubject rtmItem rtmHead= rtmTail= rtmFirst rtmRest rtmNil;
    case $rtmChar in 
        '<')
            rdf::iri || return 1
        ;;
        '"' | "'")
            rdf::quoted || return 1
        ;;
        '[')
            ((rdfCursor+=1));
            rdf::blank;
            rtmSubject=$rdfTermResult;
            rdf::space;
            if [[ ${rdfText:rdfCursor:1} != ']' ]]; then
                rdf::predicates "$rtmSubject" || return 1;
            fi;
            rdf::expect ']' || return 1;
            rdfTermResult=$rtmSubject
        ;;
        '(')
            ((rdfCursor+=1));
            rdf::intern iri "${RDFNS}first";
            rtmFirst=$rdfTermResult;
            rdf::intern iri "${RDFNS}rest";
            rtmRest=$rdfTermResult;
            rdf::intern iri "${RDFNS}nil";
            rtmNil=$rdfTermResult;
            rdf::space;
            while [[ ${rdfText:rdfCursor:1} != ')' ]]; do
                rdf::term || return 1;
                rtmItem=$rdfTermResult;
                rdf::blank;
                rtmSubject=$rdfTermResult;
                [[ -n $rtmHead ]] || rtmHead=$rtmSubject;
                [[ -z $rtmTail ]] || rdf::triple "$rtmTail" "$rtmRest" "$rtmSubject" || return 1;
                rdf::triple "$rtmSubject" "$rtmFirst" "$rtmItem" || return 1;
                rtmTail=$rtmSubject;
                rdf::space;
            done;
            ((rdfCursor+=1));
            if [[ -z $rtmHead ]]; then
                rdfTermResult=$rtmNil;
            else
                rdf::triple "$rtmTail" "$rtmRest" "$rtmNil" || return 1;
                rdfTermResult=$rtmHead;
            fi
        ;;
        *)
            rdf::word || return 1
        ;;
    esac;
    ((rdfDepth-=1));
    return 0
}
