shape::instance () 
{ 
    local siNode=$1 siClass=$2 siType;
    rdf::objects "$siNode" "${RDFNS}type" "$shapeDataGraph";
    local -a siTypes=("${rdfValues[@]}");
    for siType in "${siTypes[@]}";
    do
        if shape::subclass "$siType" "$siClass"; then
            return 0;
        fi;
    done;
    return 1
}
