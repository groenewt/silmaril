request::capture::perform () 
{ 
    local cpInput=$1 cpObservation=$2 cpPin=$3 cpReceipt=$4 cpMode=$5;
    requestCaptureEffect=$SILMARILEFFECTNONE;
    path::requireWritableTarget "$cpReceipt" || return "$SILCAPTUREONE";
    [[ $cpInput != "$cpReceipt" && ! $cpInput -ef $cpReceipt ]] || { 
        error::raise PATH/ROOT 'capture source overlap';
        return "$SILCAPTUREONE"
    };
    if [[ $cpMode == "$REQUESTOPERATION":capture:verify || -e $cpReceipt ]]; then
        kv::capture::verify "$cpInput" "$cpObservation" "$cpPin" "$cpReceipt";
        return "$?";
    fi;
    kv::capture "$cpInput" "$cpObservation" "$cpPin" || return "$SILCAPTUREONE";
    if ! ( set -C;
    printf '%s' "$kvCaptureReceipt" > "$cpReceipt" ); then
        kv::capture::reset;
        error::raise PATH/ROOT 'capture exclusive publication failed';
        return "$SILCAPTUREONE";
    fi;
    kv::capture::verify "$cpInput" "$cpObservation" "$cpPin" "$cpReceipt" || return "$SILCAPTUREONE";
    requestCaptureEffect=$SILMARILEFFECTAUDIT
}
