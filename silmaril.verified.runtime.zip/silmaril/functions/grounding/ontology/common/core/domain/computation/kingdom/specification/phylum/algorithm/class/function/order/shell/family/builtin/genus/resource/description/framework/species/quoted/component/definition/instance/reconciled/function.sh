rdf::quoted () 
{ 
    local rqQuote=${rdfText:rdfCursor:1} rqLong=0 rqChar rqClosed=0 rdfString= rdfCharacter= rdfNull=0 rqData="${XSDNS}string" rqLang=;
    ((rdfCursor+=1));
    if [[ ${rdfText:rdfCursor:2} == "$rqQuote$rqQuote" ]]; then
        rqLong=1;
        ((rdfCursor+=2));
    fi;
    while :; do
        if ((rdfCursor>=${#rdfText})); then
            if ((rqLong)) && rdf::more; then
                :;
            else
                break;
            fi;
        fi;
        rqChar=${rdfText:rdfCursor:1};
        ((rdfCursor+=1));
        if [[ $rqChar == "$rqQuote" ]]; then
            if ((rqLong==0)); then
                rqClosed=1;
                break;
            else
                if [[ ${rdfText:rdfCursor:2} == "$rqQuote$rqQuote" ]]; then
                    ((rdfCursor+=2));
                    rqClosed=1;
                    break;
                fi;
            fi;
        fi;
        if [[ $rqChar == '\' ]]; then
            rdf::escape || return 1;
            if ((rdfNull)); then
                rdfString+='\u0000';
                continue;
            fi;
            rqChar=$rdfCharacter;
        else
            if ((rqLong==0)) && [[ $rqChar == '
' || $rqChar == '' ]]; then
                rdf::error 'newline in short literal';
                return 1;
            fi;
        fi;
        rdf::literalChar "$rqChar";
    done;
    ((rqClosed)) || { 
        rdf::error 'unterminated literal';
        return 1
    };
    if [[ ${rdfText:rdfCursor:1} == @ ]]; then
        ((rdfCursor+=1));
        local rqStart=$rdfCursor;
        while [[ ${rdfText:rdfCursor:1} == [a-zA-Z0-9-] ]]; do
            ((rdfCursor+=1));
        done;
        rqLang=${rdfText:rqStart:rdfCursor-rqStart};
        rqLang=${rqLang,,};
        [[ $rqLang =~ ^[a-z]+(-[a-z0-9]+)*$ ]] || { 
            rdf::error 'language tag';
            return 1
        };
        rqData="${RDFNS}langString";
    else
        if [[ ${rdfText:rdfCursor:2} == '^^' ]]; then
            ((rdfCursor+=2));
            rdf::term || return 1;
            [[ ${rdfKind[rdfTermResult]} == iri ]] || { 
                rdf::error 'literal datatype must be IRI';
                return 1
            };
            rqData=${rdfTerm[rdfTermResult]};
        fi;
    fi;
    rdf::intern literal "$rdfString" "$rqData" "$rqLang"
}
