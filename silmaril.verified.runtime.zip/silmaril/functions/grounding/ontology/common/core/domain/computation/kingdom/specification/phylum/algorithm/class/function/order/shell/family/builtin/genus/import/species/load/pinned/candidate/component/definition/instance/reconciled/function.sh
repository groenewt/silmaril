import::loadPinnedCandidate () 
{ 
    local ilFile=$1 ilExpected=$2 ilOntology=$3 ilVersion=$4 ilRaw= ilStatus ilBase ilDigest LC_ALL=C;
    [[ $ilExpected =~ ^[0-9a-f]{64}$ ]] || { 
        error::raise GROUNDING/MISSING 'SHA256 pin required';
        return 1
    };
    path::requireReadable "$ilFile" || return 1;
    if IFS= read -r -d '' -n "$((rdfMaximumBytes+1))" ilRaw < "$ilFile"; then
        error::raise PROJECTION/FIDELITY 'NUL or imported source capacity';
        return 1;
    else
        ilStatus=$?;
    fi;
    ((ilStatus==1 && ${#ilRaw}<=rdfMaximumBytes)) || { 
        error::raise PROJECTION/FIDELITY 'import read';
        return 1
    };
    hash::text "$ilRaw" ilDigest || return 1;
    [[ $ilDigest == "$ilExpected" ]] || { 
        error::raise GROUNDING/CONTRADICTORY 'import digest mismatch';
        return 1
    };
    path::toFileUri "$ilFile" ilBase || return 1;
    rdf::reset;
    rdf::content "$ilRaw" "$importGraph" "$ilBase" || return 1;
    import::closure || return 1;
    [[ ${importVersion[$ilOntology]-} == "$ilVersion" ]] || { 
        error::raise GROUNDING/CONTRADICTORY 'ontology version mismatch';
        return 1
    };
    importDigest=$ilDigest;
    importSource=$ilFile
}
