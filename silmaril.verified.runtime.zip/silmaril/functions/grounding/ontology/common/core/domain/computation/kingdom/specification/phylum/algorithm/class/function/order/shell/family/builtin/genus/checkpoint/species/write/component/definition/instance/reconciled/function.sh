checkpoint::write () 
{ 
    local cwPath=$1 cwSnapshot=$2 cwId;
    [[ $cwPath != "$cwSnapshot" && $cwPath != "$graphSourcePath" && $cwSnapshot != "$graphSourcePath" ]] || { 
        error::raise PATH/ROOT 'checkpoint overlaps input';
        return 1
    };
    path::requireWritableTarget "$cwPath" && path::requireWritableTarget "$cwSnapshot" || return 1;
    path::identify "$cwSnapshot" cwId || return 1;
    printf '%s' "$graphRaw" > "$cwSnapshot" || { 
        error::raise EXECUTION/RESUME 'snapshot write';
        return 1
    };
    checkpoint::emit "$cwId" > "$cwPath" || { 
        error::raise EXECUTION/RESUME 'checkpoint write';
        return 1
    }
}
