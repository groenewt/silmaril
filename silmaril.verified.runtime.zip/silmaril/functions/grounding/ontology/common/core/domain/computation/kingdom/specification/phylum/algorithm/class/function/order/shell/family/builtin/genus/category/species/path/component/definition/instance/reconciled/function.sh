category::path () 
{ 
    local cpObject=$1 cpWord=$2 cpOut=$3 cpAccum=${categoryIdentity[$1]-} cpArrow;
    [[ -n $cpAccum ]] || { 
        error::raise CATEGORY/IDENTITY "$cpObject";
        return 1
    };
    for cpArrow in $cpWord;
    do
        [[ ${categorySource[$cpArrow]-} == "$cpObject" ]] || { 
            error::raise CATEGORY/EQUATION path;
            return 1
        };
        cpAccum=${categoryComposite[$cpArrow$SILMARILUS$cpAccum]-};
        [[ -n $cpAccum ]] || { 
            error::raise CATEGORY/COMPOSITION path;
            return 1
        };
        cpObject=${categoryTarget[$cpArrow]};
    done;
    printf -v "$cpOut" '%s' "$cpAccum"
}
