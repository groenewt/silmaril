graph::emitReceipts () 
{ 
    printf 'IDENTITY: %s\nGRAPH:\n  IDENTITY: %s\nSTATUS: %s\nNODES:\n' "$graphIdentity:occurrence:report" "$graphIdentity" "${graphStatus:-$SILMARILSTATUSFAILURE}";
    publication::vector "${#graphNodes[@]}" 2 graph::emitReceiptItem
}
