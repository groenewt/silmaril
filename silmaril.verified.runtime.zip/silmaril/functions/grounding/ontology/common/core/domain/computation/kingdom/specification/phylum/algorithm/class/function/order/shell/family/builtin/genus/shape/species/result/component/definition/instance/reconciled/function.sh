shape::result () 
{ 
    shapeResultFocus+=("$1");
    shapeResultShape+=("$2");
    shapeResultPath+=("${3-}");
    shapeResultConstraint+=("$4");
    shapeResultValue+=("${5-}")
}
