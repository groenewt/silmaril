rdf::literalChar () 
{ 
    local rlChar=$1 rlCode;
    case $rlChar in 
        '\')
            rdfString+='\\'
        ;;
        '"')
            rdfString+='\"'
        ;;
        '
')
            rdfString+='\n'
        ;;
        '')
            rdfString+='\r'
        ;;
        '	')
            rdfString+='\t'
        ;;
        '')
            rdfString+='\b'
        ;;
        '')
            rdfString+='\f'
        ;;
        *)
            printf -v rlCode '%d' "'$rlChar";
            if ((rlCode<32 || rlCode==127)); then
                printf -v rlChar '\\u%04X' "$rlCode";
            fi;
            rdfString+=$rlChar
        ;;
    esac
}
