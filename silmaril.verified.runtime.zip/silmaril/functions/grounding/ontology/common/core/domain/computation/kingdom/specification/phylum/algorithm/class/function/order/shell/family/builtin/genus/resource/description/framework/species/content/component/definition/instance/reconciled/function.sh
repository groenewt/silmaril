rdf::content () 
{ 
    local rxName rxKey rxStatus=0;
    local -a rxIndexed=(rdfTerm rdfKind rdfLexical rdfDatatype rdfLanguage rdfSubject rdfPredicate rdfObject rdfGraph rdfLines);
    local -a rxMaps=(rdfIntern rdfTriples rdfPrefixes rdfBlankLabels rdfForward rdfParents);
    local rxBase=$rdfBase rxContext=$rdfContext rxText=$rdfText rxCursor=$rdfCursor rxDepth=$rdfDepth rxDocument=$rdfDocumentCounter rxBlank=$rdfBlankCounter rxLine=$rdfLineIndex rxOffset=$rdfAbsoluteOffset rxResult=$rdfTermResult;
    for rxName in "${rxIndexed[@]}";
    do
        local -a "saved${rxName}=()";
        local -n rxOriginal=$rxName rxSaved=saved$rxName;
        rxSaved=("${rxOriginal[@]}");
    done;
    for rxName in "${rxMaps[@]}";
    do
        local -A "saved${rxName}=()";
        local -n rxOriginal=$rxName rxSaved=saved$rxName;
        for rxKey in "${!rxOriginal[@]}";
        do
            rxSaved[$rxKey]=${rxOriginal[$rxKey]};
        done;
    done;
    rdf::contentCandidate "$@" || rxStatus=$?;
    if ((rxStatus)); then
        for rxName in "${rxIndexed[@]}";
        do
            local -n rxOriginal=$rxName rxSaved=saved$rxName;
            rxOriginal=("${rxSaved[@]}");
        done;
        for rxName in "${rxMaps[@]}";
        do
            local -n rxOriginal=$rxName rxSaved=saved$rxName;
            rxOriginal=();
            for rxKey in "${!rxSaved[@]}";
            do
                rxOriginal[$rxKey]=${rxSaved[$rxKey]};
            done;
        done;
        rdfBase=$rxBase rdfContext=$rxContext rdfText=$rxText rdfCursor=$rxCursor rdfDepth=$rxDepth rdfDocumentCounter=$rxDocument rdfBlankCounter=$rxBlank rdfLineIndex=$rxLine rdfAbsoluteOffset=$rxOffset rdfTermResult=$rxResult;
        return "$rxStatus";
    fi;
    return 0
}
