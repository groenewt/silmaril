import::term () 
{ 
    local itKey="iri${SILMARILUS}$1${SILMARILUS}${SILMARILUS}";
    [[ -n ${rdfIntern[$itKey]+yes} ]] || { 
        error::raise GROUNDING/MISSING "missing imported class: $1";
        return 1
    };
    importTerm=${rdfIntern[$itKey]}
}
