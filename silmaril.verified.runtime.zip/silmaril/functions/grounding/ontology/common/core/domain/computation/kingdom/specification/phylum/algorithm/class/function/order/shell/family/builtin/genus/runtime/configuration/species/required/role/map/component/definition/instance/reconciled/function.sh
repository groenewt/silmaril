runtimeconfig::requiredRoleMap () 
{ 
    local parent=$1;
    local role=$2;
    local expectedIdentity=$3;
    local expectedOwner=$4;
    local expectedValue=$5;
    local expectedCardinality=$6;
    local rolePath;
    yaml::requiredMap "$parent" "$role" rolePath || return "$SILMARILFAILURE";
    yaml::assertOnlyKeys "$rolePath" IDENTITY OWNER VALUE CARDINALITY || return "$SILMARILFAILURE";
    local identity;
    local owner;
    local valueType;
    local cardinality;
    yaml::requiredScalar "$rolePath" IDENTITY identity || return "$SILMARILFAILURE";
    yaml::requiredScalar "$rolePath" OWNER owner || return "$SILMARILFAILURE";
    yaml::requiredScalar "$rolePath" VALUE valueType || return "$SILMARILFAILURE";
    yaml::requiredScalar "$rolePath" CARDINALITY cardinality || return "$SILMARILFAILURE";
    [[ $identity == "$expectedIdentity" && $owner == "$expectedOwner" && $valueType == "$expectedValue" && $cardinality == "$expectedCardinality" ]] || { 
        engine::raise "$SILMARILERRORFIELD" "$role";
        return "$SILMARILFAILURE"
    };
    field::define "$identity" "$owner" "$valueType" "$cardinality"
}
