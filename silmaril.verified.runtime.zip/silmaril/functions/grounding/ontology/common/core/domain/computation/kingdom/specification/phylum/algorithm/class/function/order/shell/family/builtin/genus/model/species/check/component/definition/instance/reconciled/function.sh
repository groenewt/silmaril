model::check () 
{ 
    local mcM=$1 mcO mcF mcG mcH mcX mcY mcZ mcK mcExpected=0 mcActual=0;
    category::check || return 1;
    finite::contains "${modelNames[*]}" "$mcM" || { 
        error::raise FUNCTOR/TOTALITY model;
        return 1
    };
    for mcO in "${categoryObjects[@]}";
    do
        [[ -n ${modelElements[$mcM$SILMARILUS$mcO]+present} ]] || { 
            error::raise FUNCTOR/TOTALITY carrier;
            return 1
        };
        mcF=${categoryIdentity[$mcO]};
        for mcX in ${modelElements[$mcM$SILMARILUS$mcO]};
        do
            [[ ${modelAction[$mcM$SILMARILUS$mcF$SILMARILUS$mcX]-} == "$mcX" ]] || { 
                error::raise FUNCTOR/IDENTITY "$mcM $mcX";
                return 1
            };
            ((finiteChecks+=1));
        done;
    done;
    for mcF in "${categoryArrows[@]}";
    do
        for mcX in ${modelElements[$mcM$SILMARILUS${categorySource[$mcF]}]};
        do
            ((mcExpected+=1));
            mcY=${modelAction[$mcM$SILMARILUS$mcF$SILMARILUS$mcX]-};
            [[ -n $mcY ]] && finite::contains "${modelElements[$mcM$SILMARILUS${categoryTarget[$mcF]}]}" "$mcY" || { 
                error::raise FUNCTOR/TOTALITY "$mcF $mcX";
                return 1
            };
            for mcG in "${categoryArrows[@]}";
            do
                [[ ${categoryTarget[$mcF]} == "${categorySource[$mcG]}" ]] || continue;
                mcH=${categoryComposite[$mcG$SILMARILUS$mcF]};
                [[ ${modelAction[$mcM$SILMARILUS$mcG$SILMARILUS$mcY]-} == "${modelAction[$mcM$SILMARILUS$mcH$SILMARILUS$mcX]-}" ]] || { 
                    error::raise FUNCTOR/COMPOSITION "$mcF $mcG $mcX";
                    return 1
                };
                ((finiteChecks+=1));
            done;
        done;
    done;
    for mcK in "${!modelAction[@]}";
    do
        [[ $mcK != "$mcM$SILMARILUS"* ]] || ((mcActual+=1));
    done;
    ((mcActual==mcExpected)) || { 
        error::raise FUNCTOR/TOTALITY surplus;
        return 1
    };
    return 0
}
