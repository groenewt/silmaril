checkpoint::emit () 
{ 
    printf 'IDENTITY: %s\nGRAPH:\n  IDENTITY: %s\nSNAPSHOT: %s\nNODES:\n' "$graphIdentity:occurrence:checkpoint" "$graphIdentity" "$1";
    publication::vector "${#graphNodes[@]}" 2 checkpoint::emitItem || return 1;
    printf 'COMPLETE: %s\n' "$SILMARILTRUE"
}
