string::trim () 
{ 
    local input=${1-};
    local outputName=$2;
    local -n outputReference=$outputName;
    while [[ $input == [[:space:]]* ]]; do
        input=${input#?};
    done;
    while [[ $input == *[[:space:]] ]]; do
        input=${input%?};
    done;
    outputReference=$input
}
