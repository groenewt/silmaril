field::define () 
{ 
    local field=$1;
    local owner=$2;
    local valueType=$3;
    local cardinality=$4;
    identity::requireRankedUrn "$field" field || return "$SILMARILFAILURE";
    type::exists "$owner" && type::exists "$valueType" || { 
        engine::raise "$SILMARILERRORFIELD" "$field";
        return "$SILMARILFAILURE"
    };
    [[ $cardinality == "$SILMARILCARDINALITYONE" || $cardinality == "$SILMARILCARDINALITYOPTIONAL" || $cardinality == "$SILMARILCARDINALITYMANY" ]] || { 
        engine::raise "$SILMARILERRORFIELD" 'cardinality';
        return "$SILMARILFAILURE"
    };
    [[ ! -n ${fieldDefined[$field]+present} ]] || { 
        engine::raise "$SILMARILERRORFIELD" "$field duplicate";
        return "$SILMARILFAILURE"
    };
    fieldDefined[$field]=$SILMARILONE;
    fieldOwner[$field]=$owner;
    fieldValueType[$field]=$valueType;
    fieldCardinality[$field]=$cardinality
}
