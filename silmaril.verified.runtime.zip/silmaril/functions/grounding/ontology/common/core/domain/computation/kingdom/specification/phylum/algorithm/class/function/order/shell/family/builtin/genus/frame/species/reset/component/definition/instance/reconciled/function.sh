frame::reset () 
{ 
    frameStatus=();
    frameOutput=();
    frameEffect=();
    frameError=();
    frameOrder=();
    if ((${#objectOrder[@]}==0)); then
        frameCounter=$SILMARILZERO;
    fi
}
