hash::file () 
{ 
    local hfile=$1 hout=$2 hc hs hi hn hb LC_ALL=C;
    local -a hashState=(0x6a09e667 0xbb67ae85 0x3c6ef372 0xa54ff53a 0x510e527f 0x9b05688c 0x1f83d9ab 0x5be0cd19) hashBlock=();
    local hashFill=0 hashBytes=0;
    path::requireReadable "$hfile" || return 1;
    [[ $hashMaximumBytes =~ ^[1-9][0-9]{0,8}$ ]] || { 
        error::raise PAIR/LIMIT 'hash bound';
        return 1
    };
    while :; do
        hc=;
        hs=0;
        IFS= read -r -d '' -n 4096 hc || hs=$?;
        ((hs==0 || hs==1)) || { 
            error::raise PAIR/CARRIER 'hash read';
            return 1
        };
        ((hashBytes+${#hc}<=hashMaximumBytes)) || { 
            error::raise PAIR/LIMIT 'hash byte bound';
            return 1
        };
        for ((hi=0; hi<${#hc}; hi++))
        do
            hb=${hc:hi:1};
            printf -v hn '%d' "'$hb";
            hash::octet "$hn";
        done;
        if ((hs==0 && ${#hc}<4096)); then
            ((hashBytes<hashMaximumBytes)) || { 
                error::raise PAIR/LIMIT 'hash byte bound';
                return 1
            };
            hash::octet 0;
        fi;
        ((hs==0)) || break;
    done < "$hfile";
    local hExtent=$hashBytes;
    hash::finish "$hout" || return 1;
    if (($#>2)); then
        printf -v "$3" '%s' "$hExtent";
    fi;
    return 0
}
