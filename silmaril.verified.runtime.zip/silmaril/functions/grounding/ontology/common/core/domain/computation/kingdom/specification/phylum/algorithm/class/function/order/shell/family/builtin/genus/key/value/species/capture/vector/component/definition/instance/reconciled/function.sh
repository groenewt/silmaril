kv::capture::vector () 
{ 
    local cvCount=$1 cvIndent=$2 cvKind=$3 cvRef cvDigit;
    number::reference "$cvCount" cvRef || return "$SILCAPTUREONE";
    kv::capture::line "$cvIndent" VECTOR "$KVTYPEVECTOR" || return "$SILCAPTUREONE";
    kv::capture::line "$cvIndent" COUNT "$cvRef" || return "$SILCAPTUREONE";
    if ((cvCount==SILCAPTUREZERO)); then
        kv::capture::line "$cvIndent" MEMBER "$KVEMPTYVECTOR" || return "$SILCAPTUREONE";
    else
        kv::capture::line "$cvIndent" MEMBER || return "$SILCAPTUREONE";
        for ((cvDigit=SILCAPTUREZERO; cvDigit<SILCAPTURETEN && cvDigit<cvCount; cvDigit+=SILCAPTUREONE))
        do
            kv::capture::member "$cvDigit" "$((cvIndent+SILCAPTURETWO))" "$cvKind" "$cvCount" || return "$SILCAPTUREONE";
        done;
    fi
}
