shape::preflight () 
{ 
    local pfIndex pfPredicate pfSubject pfObject pfKey pfType pfPath;
    local -A pfSeen=();
    for pfIndex in "${!rdfSubject[@]}";
    do
        [[ ${rdfGraph[pfIndex]} == "$shapeShapesGraph" ]] || continue;
        pfPredicate=${rdfTerm[${rdfPredicate[pfIndex]}]};
        pfSubject=${rdfSubject[pfIndex]};
        pfObject=${rdfObject[pfIndex]};
        [[ $pfPredicate == "$SHNS"* ]] || continue;
        pfPredicate=${pfPredicate#"$SHNS"};
        case $pfPredicate in 
            path | deactivated | targetNode | targetClass | targetSubjectsOf | targetObjectsOf | name | description | message | severity | order | group | ignoredProperties | minCount | maxCount | property | node | not | and | or | xone | hasValue | in | nodeKind | class | datatype | closed | equals | disjoint | inversePath)
                :
            ;;
            *)
                shape::error "unsupported constraint or shape vocabulary: $pfPredicate";
                return 2
            ;;
        esac;
        case $pfPredicate in 
            path | deactivated | ignoredProperties | minCount | maxCount | in | nodeKind | datatype | closed | inversePath | severity)
                pfKey=$pfSubject,$pfPredicate;
                [[ ! -n ${pfSeen[$pfKey]+yes} ]] || { 
                    shape::error "multiple values for singleton constraint: $pfPredicate";
                    return 2
                };
                pfSeen[$pfKey]=1
            ;;
        esac;
        case $pfPredicate in 
            minCount | maxCount)
                shape::number "$pfObject" || return 2
            ;;
        esac;
    done
}
