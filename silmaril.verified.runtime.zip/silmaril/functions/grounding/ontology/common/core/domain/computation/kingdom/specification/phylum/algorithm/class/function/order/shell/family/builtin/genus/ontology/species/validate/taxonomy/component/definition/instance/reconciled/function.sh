ontology::validateTaxonomy () 
{ 
    local vtIdentity=$1 vtPath=$2 vtRank vtKey vtValue vtExpected vtActual;
    yaml::assertOnlyKeys "$vtPath" DOMAIN KINGDOM PHYLUM CLASS ORDER FAMILY GENUS SPECIES || return 1;
    for vtRank in domain kingdom phylum class order family genus species;
    do
        vtKey=${vtRank^^};
        yaml::requiredScalar "$vtPath" "$vtKey" vtValue || return 1;
        identity::requireUrn "$vtValue" taxonomy || return 1;
        [[ $vtValue == *":taxonomy:rank:${vtRank}:specimen:"* ]] || { 
            error::raise RANK/MISPLACED "$vtValue";
            return 1
        };
        identity::rankValue "$vtIdentity" "$vtRank" vtExpected || return 1;
        vtActual=${vtValue##*:specimen:};
        [[ $vtExpected == "$vtActual" ]] || { 
            error::raise GROUNDING/CONTRADICTORY "$vtRank $vtExpected $vtActual";
            return 1
        };
        typeTaxonomy[$vtIdentity$SILMARILUS$vtRank]=$vtValue;
    done
}
