path::requireSafe () 
{ 
    local psInput=$1 psPart psRest psCurrent= psLast=0;
    [[ $psInput == /* && $psInput != *'
'* && $psInput != *''* && $psInput != *'//'* ]] || { 
        error::raise PATH/ROOT "$psInput";
        return 1
    };
    [[ $psInput != / ]] || return 0;
    psRest=${psInput#/};
    while [[ -n $psRest ]]; do
        psPart=${psRest%%/*};
        if [[ $psRest == */* ]]; then
            psRest=${psRest#*/};
        else
            psRest=;
        fi;
        [[ -n $psPart && $psPart != . && $psPart != .. ]] || { 
            error::raise PATH/SEGMENT "$psInput";
            return 1
        };
        psCurrent+=/$psPart;
        [[ ! -L $psCurrent ]] || { 
            error::raise PATH/PARENT "symbolic link $psCurrent";
            return 1
        };
        [[ -z $psRest || -d $psCurrent ]] || { 
            error::raise PATH/PARENT "$psCurrent";
            return 1
        };
    done
}
