yaml::parse () 
{ 
    local ypFile=$1 ypPath ypParent ypKey ypIndex=0;
    kv::parse "$ypFile" || return 1;
    yaml::reset;
    kv::project ROOT "$SILMARILYAMLROOT" || return 1;
    for ypPath in "${kvPaths[@]}";
    do
        ypParent=${ypPath%/*};
        ypKey=${ypPath##*/};
        yamlPairIdentity[$ypIndex]=${kvBinding[$ypPath]};
        yamlPairLeft[$ypIndex]=${kvPredicate[$ypPath]};
        yamlPairRight[$ypIndex]=${kvRight[$ypPath]};
        yamlPairParent[$ypIndex]=${kvMap[$ypParent]};
        ypKey=${ypPath//[^\/]/};
        yamlPairDepth[$ypIndex]=${#ypKey};
        ((ypIndex+=1));
    done;
    yamlPairCount=$ypIndex
}
