object::reset () 
{ 
    objectDefined=();
    objectType=();
    objectFieldCount=();
    objectFieldValue=();
    objectOrder=()
}
