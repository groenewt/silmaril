graph::execute () 
{ 
    (( graphValidated == SILMARILONE )) || { 
        engine::raise "$SILMARILERRORGRAPH" 'graph not validated';
        return "$SILMARILFAILURE"
    };
    frame::reset;
    nodeInputCount=();
    nodeInput=();
    nodeOutput=();
    nodeFrame=();
    receiptOrder=();
    receiptNode=();
    receiptFrame=();
    receiptCounter=$SILMARILZERO;
    graphStatus=;
    graphFailureFrame=;
    runtime::begin || return "$SILMARILFAILURE";
    local node;
    local predecessor;
    local inputCount;
    local frameIdentity;
    local callStatus;
    local adjacencyKey;
    for node in "${graphOrder[@]}";
    do
        inputCount=$SILMARILZERO;
        for predecessor in "${graphNodes[@]}";
        do
            adjacencyKey="${predecessor}${SILMARILUS}${node}";
            [[ -n ${graphAdjacency[$adjacencyKey]+present} ]] || continue;
            nodeInput[${node}${SILMARILUS}${inputCount}]=${nodeOutput[$predecessor]};
            (( inputCount += SILMARILONE ));
        done;
        nodeInputCount[$node]=$inputCount;
        frameIdentity=;
        callStatus=$SILMARILZERO;
        object::call "$node" "$SILMARILMETHODRUN" frameIdentity || callStatus=$?;
        if [[ -n $runtimeViolation ]]; then
            frame::failure "$SILMARILERRORRUNTIMEEXTERNAL" frameIdentity || :;
            callStatus=$SILMARILFAILURE;
        fi;
        if (( callStatus != SILMARILZERO )) || [[ -z $frameIdentity || ${frameStatus[$frameIdentity]-} != "$SILMARILSTATUSSUCCESS" ]]; then
            [[ -n $frameIdentity ]] || frame::failure "$SILMARILERRORGRAPHNODE" frameIdentity || :;
            nodeFrame[$node]=$frameIdentity;
            receipt::new "$node" "$frameIdentity";
            graphFailureFrame=$frameIdentity;
            graphStatus=$SILMARILSTATUSFAILURE;
            break;
        fi;
        nodeFrame[$node]=$frameIdentity;
        nodeOutput[$node]=${frameOutput[$frameIdentity]};
        receipt::new "$node" "$frameIdentity";
    done;
    local guardStatus=$SILMARILZERO;
    runtime::end || guardStatus=$?;
    if (( guardStatus != SILMARILZERO )); then
        graphStatus=$SILMARILSTATUSFAILURE;
        [[ -n $graphFailureFrame ]] || frame::failure "$SILMARILERRORRUNTIMEEXTERNAL" graphFailureFrame || :;
        return "$SILMARILFAILURE";
    fi;
    if [[ $graphStatus == "$SILMARILSTATUSFAILURE" ]]; then
        return "$SILMARILFAILURE";
    fi;
    graphStatus=$SILMARILSTATUSSUCCESS
}
