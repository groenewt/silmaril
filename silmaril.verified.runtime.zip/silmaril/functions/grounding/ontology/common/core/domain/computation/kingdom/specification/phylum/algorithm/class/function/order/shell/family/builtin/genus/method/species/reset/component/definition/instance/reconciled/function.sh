method::reset () 
{ 
    methodDefined=();
    methodImplementation=()
}
