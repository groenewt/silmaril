type::addAxiom () 
{ 
    local identity=$1;
    local axiom=$2;
    type::exists "$identity" || { 
        engine::raise "$SILMARILERRORTYPE" "$identity";
        return "$SILMARILFAILURE"
    };
    [[ ${axiomDefined[$axiom]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERRORAXIOM" "$axiom";
        return "$SILMARILFAILURE"
    };
    local declaredDomain=${axiomDomain[$axiom]};
    type::isSubtype "$identity" "$declaredDomain" || { 
        engine::raise "$SILMARILERRORAXIOM" "$axiom domain";
        return "$SILMARILFAILURE"
    };
    local count=${typeAxiomCount[$identity]:-$SILMARILZERO};
    local index;
    for ((index = SILMARILZERO; index < count; index += SILMARILONE ))
    do
        [[ ${typeAxiom[${identity}${SILMARILUS}${index}]} != "$axiom" ]] || return "$SILMARILZERO";
    done;
    typeAxiom[${identity}${SILMARILUS}${count}]=$axiom;
    typeAxiomCount[$identity]=$(( count + SILMARILONE ))
}
