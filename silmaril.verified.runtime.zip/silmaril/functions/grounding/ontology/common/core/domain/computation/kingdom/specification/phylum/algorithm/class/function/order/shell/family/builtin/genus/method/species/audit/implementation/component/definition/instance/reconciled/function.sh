method::auditImplementation () 
{ 
    local implementation=$1;
    [[ $(type -t -- "$implementation" 2> /dev/null || :) == function ]] || { 
        engine::raise "$SILMARILERRORMETHOD" "$implementation";
        return "$SILMARILFAILURE"
    };
    local body;
    body=$(declare -f "$implementation") || { 
        engine::raise "$SILMARILERRORMETHOD" "$implementation";
        return "$SILMARILFAILURE"
    };
    local protected;
    local -a protectedNames=(runtimeActive runtimeExternalCount runtimeHadExtdebug runtimeHadFunctrace runtimeOwner runtimeViolation runtimeViolationCommand engineError engineDetail BASH_COMMAND BASHOPTS SHELLOPTS BASH_ENV FUNCNAME DEBUG);
    for protected in "${protectedNames[@]}";
    do
        [[ $body != *"$protected"* ]] || { 
            engine::raise "$SILMARILERRORRUNTIMEESCAPE" "$implementation protected $protected";
            return "$SILMARILFAILURE"
        };
    done;
    [[ $body != *'/bin/'* && $body != *'/usr/bin/'* && $body != *'$('* && $body != *'<('* && $body != *'>('* && $body != *'`'* ]] || { 
        engine::raise "$SILMARILERRORRUNTIMEESCAPE" "$implementation shell escape";
        return "$SILMARILFAILURE"
    };
    local forbidden;
    local -a forbiddenFragments=('declare -g' 'typeset -g' 'local -n' 'printf -v' 'read -v' 'mapfile ' 'readarray ' 'unset ' 'export ' 'readonly ' 'trap ' 'shopt ' 'eval ' 'source ' 'exec ' 'enable ' 'coproc ' 'command ' 'builtin ');
    for forbidden in "${forbiddenFragments[@]}";
    do
        [[ $body != *"$forbidden"* ]] || { 
            engine::raise "$SILMARILERRORRUNTIMEESCAPE" "$implementation fragment $forbidden";
            return "$SILMARILFAILURE"
        };
    done
}
