receipt::new () 
{ 
    local node=$1;
    local frame=$2;
    local receiptNumber;
    name::number "$receiptCounter" receiptNumber;
    local receiptIdentity="urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:computation:kingdom:evidence:phylum:receipt:class:execution:order:runtime:family:node:genus:receipt:species:receipt:component:receipt:instance:${receiptNumber}";
    (( receiptCounter += SILMARILONE ));
    receiptOrder+=("$receiptIdentity");
    receiptNode[$receiptIdentity]=$node;
    receiptFrame[$receiptIdentity]=$frame
}
