byte::reset () 
{ 
    byteStreamDefined=();
    byteStreamCount=();
    byteStreamValue=();
    byteStreamObject=()
}
