graph::validate () 
{ 
    (( graphLoaded == SILMARILONE )) || { 
        engine::raise "$SILMARILERRORGRAPH" 'graph not loaded';
        return "$SILMARILFAILURE"
    };
    graph::topological || return "$SILMARILFAILURE";
    local node;
    for node in "${graphNodes[@]}";
    do
        graph::validateNodeContract "$node" || return "$SILMARILFAILURE";
    done;
    graphValidated=$SILMARILONE
}
