identity::requireRankedUrn () 
{ 
    local irValue=${1-} irLabel=${2-identity} irTail irRank irRest irPart;
    identity::requireUrn "$irValue" "$irLabel" || return 1;
    [[ $irValue == "$SILMARILROOT":grounding:ontology:*:domain:* ]] || { 
        error::raise GROUNDING/MISSING "$irLabel";
        return 1
    };
    irTail=${irValue#*:domain:};
    local -a irRanks=(kingdom phylum class order family genus species);
    for irRank in "${irRanks[@]}";
    do
        [[ $irTail == *":${irRank}:"* ]] || { 
            error::raise RANK/MISSING "$irLabel $irRank";
            return 1
        };
        irPart=${irTail%%":${irRank}:"*};
        [[ -n $irPart ]] || { 
            error::raise RANK/PADDED "$irLabel $irRank";
            return 1
        };
        irTail=${irTail#*":${irRank}:"};
    done;
    [[ -n $irTail ]] || { 
        error::raise RANK/MISSING "$irLabel species";
        return 1
    }
}
