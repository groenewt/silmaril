kv::capture () 
{ 
    kv::capture::reset;
    [[ $# == 3 || ( $# == 4 && -n ${4-} ) ]] || { 
        error::raise PROTOCOL/OPERATION 'capture requires source, observation and pin, with optional nonempty receipt';
        return "$SILCAPTUREONE"
    };
    local ctName ctKey ctStatus=$SILCAPTUREZERO;
    local -a ctNames=(kvKind kvValue kvChildren kvLine kvOffset kvSpan kvPair kvBinding kvSubject kvMap kvPredicate kvRight kvCarrier kvPosition kvProvenance kvKnown kvNumber);
    local -a ctPaths=("${kvPaths[@]}");
    local ctDocument=$kvDocument ctSource=$kvSource ctRaw=$kvRaw ctCounter=$kvObservationCounter;
    kvCaptureVerified=$SILCAPTUREZERO;
    kvCaptureCount=$SILCAPTUREZERO;
    kvCaptureReceipt=;
    kvCaptureObservation=;
    kvCaptureDigest=;
    kvCaptureSource=;
    for ctName in "${ctNames[@]}";
    do
        local -A "captureSaved${ctName}=()";
        local -n ctOriginal=$ctName ctCopy=captureSaved${ctName};
        for ctKey in "${!ctOriginal[@]}";
        do
            ctCopy[$ctKey]=${ctOriginal[$ctKey]};
        done;
    done;
    kv::capture::candidate "$@" || ctStatus=$?;
    if ((ctStatus)); then
        for ctName in "${ctNames[@]}";
        do
            local -n ctOriginal=$ctName ctCopy=captureSaved${ctName};
            ctOriginal=();
            for ctKey in "${!ctCopy[@]}";
            do
                ctOriginal[$ctKey]=${ctCopy[$ctKey]};
            done;
        done;
        kvPaths=("${ctPaths[@]}");
        kvDocument=$ctDocument;
        kvSource=$ctSource;
        kvRaw=$ctRaw;
        kvObservationCounter=$ctCounter;
        kvCaptureVerified=$SILCAPTUREZERO;
        kvCaptureCount=$SILCAPTUREZERO;
        kvCaptureReceipt=;
        kvCaptureObservation=;
        kvCaptureDigest=;
        kvCaptureSource=;
        return "$ctStatus";
    fi
}
