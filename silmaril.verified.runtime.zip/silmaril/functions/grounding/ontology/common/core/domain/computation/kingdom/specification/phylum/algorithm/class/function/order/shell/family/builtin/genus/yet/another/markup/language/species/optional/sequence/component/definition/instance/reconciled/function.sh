yaml::optionalSequence () 
{ 
    local parent=$1;
    local key=$2;
    local outputName=$3;
    local lengthName=$4;
    local presentName=$5;
    local -n outputReference=$outputName;
    local -n lengthReference=$lengthName;
    local -n presentReference=$presentName;
    local pathValue;
    yaml::join pathValue "$parent" "$key";
    if [[ ${yamlKind[$pathValue]-} == sequence ]]; then
        outputReference=$pathValue;
        lengthReference=${yamlLength[$pathValue]:-$SILMARILZERO};
        presentReference=$SILMARILONE;
        return "$SILMARILZERO";
    fi;
    if [[ ! -n ${yamlKind[$pathValue]+present} ]]; then
        outputReference=;
        lengthReference=$SILMARILZERO;
        presentReference=$SILMARILZERO;
        return "$SILMARILZERO";
    fi;
    engine::raise "$SILMARILERRORYAML" "optional sequence has non sequence kind $key"
}
