wide::initialize () 
{ 
    ontology::load "$1" || return 1;
    ontology::seal || return 1
}
