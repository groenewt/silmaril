shape::path () 
{ 
    local spNode=$1 spPath=$2 spIndex spInverse spChild spValue spMember;
    shapePathValues=();
    if [[ ${rdfKind[spPath]} == iri ]]; then
        rdf::objects "$spNode" "${rdfTerm[spPath]}" "$shapeDataGraph";
        shapePathValues=("${rdfValues[@]}");
        return 0;
    fi;
    shape::single "$spPath" inversePath || return 2;
    spInverse=$shapeParameter;
    if [[ -n $spInverse ]]; then
        [[ ${rdfKind[spInverse]} == iri ]] || { 
            shape::error 'only simple inverse path supported';
            return 2
        };
        for spIndex in "${!rdfSubject[@]}";
        do
            if [[ ${rdfGraph[spIndex]} == "$shapeDataGraph" && ${rdfObject[spIndex]} == "$spNode" && ${rdfTerm[${rdfPredicate[spIndex]}]} == "${rdfTerm[spInverse]}" ]]; then
                shapePathValues+=("${rdfSubject[spIndex]}");
            fi;
        done;
        return 0;
    fi;
    shape::error 'unsupported property path';
    return 2
}
