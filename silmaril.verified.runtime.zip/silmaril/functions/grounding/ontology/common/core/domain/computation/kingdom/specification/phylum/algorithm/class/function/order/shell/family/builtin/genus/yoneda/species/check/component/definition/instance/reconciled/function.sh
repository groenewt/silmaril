yoneda::check () 
{ 
    local ycM=$1 ycA=$2 ycF ycG ycH ycO ycX ycY ycI ycJ ycN ycTotal=1 ycCode ycChoice ycGood ycId ycExpected=0;
    model::check "$ycM" || return 1;
    finite::contains "${categoryObjects[*]}" "$ycA" || { 
        error::raise THEOREM/CERTIFICATE object;
        return 1
    };
    local -a ycSlots=() ycRadix=() ycValues=();
    local -A ycAssigned=();
    yonedaCount=0;
    yonedaObservation=();
    for ycF in "${categoryArrows[@]}";
    do
        [[ ${categorySource[$ycF]} == "$ycA" ]] || continue;
        ycSlots+=("$ycF");
        ycValues=();
        for ycY in ${modelElements[$ycM$SILMARILUS${categoryTarget[$ycF]}]};
        do
            ycValues+=("$ycY");
        done;
        ycN=${#ycValues[@]};
        ycRadix+=("$ycN");
        ((ycN==0 || ycTotal<=yonedaMaximumCandidates/ycN)) || { 
            error::raise PAIR/LIMIT yoneda;
            return 1
        };
        ((ycTotal*=ycN));
    done;
    yonedaCandidateCount=$ycTotal;
    for ((ycCode=0; ycCode<ycTotal; ycCode++))
    do
        ycChoice=$ycCode;
        ycAssigned=();
        for ((ycI=0; ycI<${#ycSlots[@]}; ycI++))
        do
            ycF=${ycSlots[$ycI]};
            ycN=${ycRadix[$ycI]};
            ycValues=();
            for ycY in ${modelElements[$ycM$SILMARILUS${categoryTarget[$ycF]}]};
            do
                ycValues+=("$ycY");
            done;
            ycJ=$((ycChoice%ycN));
            ycChoice=$((ycChoice/ycN));
            ycAssigned[$ycF]=${ycValues[$ycJ]};
        done;
        ycGood=1;
        for ycF in "${ycSlots[@]}";
        do
            for ycG in "${categoryArrows[@]}";
            do
                [[ ${categoryTarget[$ycF]} == "${categorySource[$ycG]}" ]] || continue;
                ycH=${categoryComposite[$ycG$SILMARILUS$ycF]};
                ycY=${ycAssigned[$ycF]};
                [[ ${modelAction[$ycM$SILMARILUS$ycG$SILMARILUS$ycY]} == "${ycAssigned[$ycH]}" ]] || { 
                    ycGood=0;
                    break
                };
            done;
            ((ycGood)) || break;
        done;
        ((ycGood)) || continue;
        ycId=${categoryIdentity[$ycA]};
        ycX=${ycAssigned[$ycId]};
        [[ ! -n ${yonedaObservation[$ycX]+present} ]] || { 
            error::raise THEOREM/CERTIFICATE yoneda:injective;
            return 1
        };
        for ycF in "${ycSlots[@]}";
        do
            [[ ${ycAssigned[$ycF]} == "${modelAction[$ycM$SILMARILUS$ycF$SILMARILUS$ycX]}" ]] || { 
                error::raise THEOREM/CERTIFICATE yoneda:inverse;
                return 1
            };
            ((finiteChecks+=1));
        done;
        yonedaObservation[$ycX]=1;
        ((yonedaCount+=1));
    done;
    for ycX in ${modelElements[$ycM$SILMARILUS$ycA]};
    do
        ((ycExpected+=1));
        [[ ${yonedaObservation[$ycX]-} == 1 ]] || { 
            error::raise THEOREM/CERTIFICATE yoneda:surjective;
            return 1
        };
    done;
    ((ycExpected==yonedaCount)) || { 
        error::raise THEOREM/CERTIFICATE yoneda:cardinality;
        return 1
    };
    return 0
}
