kv::capture::verify () 
{ 
    kv::capture::reset;
    [[ $# == 4 && -n ${4-} ]] || { 
        error::raise PATH/ROOT 'capture receipt is required';
        return "$SILCAPTUREONE"
    };
    kv::capture "$@"
}
