kv::emitBindingItem () 
{ 
    local ebPath=${kvPaths[$1]} ebIndent=$2 ebLine ebOffset ebSpan;
    printf '%*sITEM:\n' "$ebIndent" '';
    ((ebIndent+=2));
    printf '%*sIDENTITY: %s\n%*sPAIR: %s\n%*sSUBJECT: %s\n' "$ebIndent" '' "${kvBinding[$ebPath]}" "$ebIndent" '' "${kvPair[$ebPath]}" "$ebIndent" '' "${kvSubject[$ebPath]}";
    printf '%*sKEY: %s\n%*sVALUE: %s\n' "$ebIndent" '' "${kvPredicate[$ebPath]}" "$ebIndent" '' "${kvRight[$ebPath]}";
    printf '%*sCARRIER: %s\n%*sPOSITION: %s\n%*sPROVENANCE: %s\n' "$ebIndent" '' "${kvCarrier[$ebPath]}" "$ebIndent" '' "${kvPosition[$ebPath]}" "$ebIndent" '' "${kvProvenance[$ebPath]}";
    number::reference "${kvLine[$ebPath]}" ebLine;
    number::reference "${kvOffset[$ebPath]}" ebOffset;
    number::reference "${kvSpan[$ebPath]}" ebSpan;
    printf '%*sLINE: %s\n%*sOFFSET: %s\n%*sLENGTH: %s\n' "$ebIndent" '' "$ebLine" "$ebIndent" '' "$ebOffset" "$ebIndent" '' "$ebSpan"
}
