value::ensureSymbol () 
{ 
    local identity=$1;
    identity::requireRankedUrn "$identity" value || return "$SILMARILFAILURE";
    if object::exists "$identity"; then
        type::isSubtype "${objectType[$identity]}" "$SILMARILTYPEVALUE" || { 
            engine::raise "$SILMARILERROROBJECT" "$identity";
            return "$SILMARILFAILURE"
        };
        return "$SILMARILZERO";
    fi;
    object::new "$identity" "$SILMARILTYPESYMBOL"
}
