string::unquoteScalar () 
{ 
    local input=${1-};
    local outputName=$2;
    local -n outputReference=$outputName;
    local first=;
    local last=;
    local output=;
    local index;
    local character;
    local escaped=$SILMARILZERO;
    [[ -z $input ]] || { 
        first=${input:SILMARILZERO:SILMARILONE};
        last=${input: -SILMARILONE}
    };
    if [[ $first == "'" ]]; then
        [[ $last == "'" && ${#input} -ge $SILMARILTWO ]] || { 
            engine::raise "$SILMARILERRORYAMLSCALAR" 'invalid single quoted scalar';
            return "$SILMARILFAILURE"
        };
        output=${input:SILMARILONE:${#input}-SILMARILTWO};
        [[ $output != *"'"* ]] || { 
            engine::raise "$SILMARILERRORYAMLSCALAR" 'embedded single quote is outside the canonical subset';
            return "$SILMARILFAILURE"
        };
        outputReference=$output;
        return "$SILMARILZERO";
    fi;
    if [[ $first == '"' ]]; then
        [[ $last == '"' && ${#input} -ge $SILMARILTWO ]] || { 
            engine::raise "$SILMARILERRORYAMLSCALAR" 'invalid double quoted scalar';
            return "$SILMARILFAILURE"
        };
        input=${input:SILMARILONE:${#input}-SILMARILTWO};
        for ((index = SILMARILZERO; index < ${#input}; index += SILMARILONE ))
        do
            character=${input:index:SILMARILONE};
            if (( escaped == SILMARILONE )); then
                case $character in 
                    '\' | '"')
                        output+=$character
                    ;;
                    n)
                        output+='
'
                    ;;
                    r)
                        output+=''
                    ;;
                    t)
                        output+='	'
                    ;;
                    *)
                        engine::raise "$SILMARILERRORYAMLSCALAR" 'unsupported double quoted escape';
                        return "$SILMARILFAILURE"
                    ;;
                esac;
                escaped=$SILMARILZERO;
                continue;
            fi;
            if [[ $character == '\' ]]; then
                escaped=$SILMARILONE;
            else
                output+=$character;
            fi;
        done;
        (( escaped == SILMARILZERO )) || { 
            engine::raise "$SILMARILERRORYAMLSCALAR" 'trailing scalar escape';
            return "$SILMARILFAILURE"
        };
        outputReference=$output;
        return "$SILMARILZERO";
    fi;
    [[ $input != *'['* && $input != *']'* && $input != *'{'* && $input != *'}'* ]] || { 
        engine::raise "$SILMARILERRORYAMLSCALAR" 'flow collection syntax is prohibited';
        return "$SILMARILFAILURE"
    };
    [[ $input != '&'* && $input != '*'* && $input != '!'* && $input != '|'* && $input != '>'* && $input != '@'* && $input != '`'* ]] || { 
        engine::raise "$SILMARILERRORYAMLSCALAR" 'anchor alias tag or block scalar syntax is prohibited';
        return "$SILMARILFAILURE"
    };
    outputReference=$input
}
