graph::validateNodeContract () 
{ 
    local node=$1;
    local nodeType=${objectType[$node]};
    local incoming=${graphIncomingCount[$node]:-$SILMARILZERO};
    local owner;
    local implementation;
    dispatch::resolve "$node" "$SILMARILMETHODRUN" "$SILMARILZERO" owner implementation || return "$SILMARILFAILURE";
    if type::isSubtype "$nodeType" "$SILMARILTYPECONSTANTNODE"; then
        (( incoming == SILMARILZERO )) || { 
            engine::raise "$SILMARILERRORGRAPHNODE" 'constant input cardinality';
            return "$SILMARILFAILURE"
        };
        local value;
        object::get "$node" "$SILMARILFIELDVALUE" value || return "$SILMARILFAILURE";
    else
        if type::isSubtype "$nodeType" "$SILMARILTYPEIDENTITYNODE"; then
            (( incoming == SILMARILONE )) || { 
                engine::raise "$SILMARILERRORGRAPHNODE" 'identity input cardinality';
                return "$SILMARILFAILURE"
            };
        else
            if type::isSubtype "$nodeType" "$SILMARILTYPEJOINNODE"; then
                (( incoming == SILMARILTWO )) || { 
                    engine::raise "$SILMARILERRORGRAPHNODE" 'join input cardinality';
                    return "$SILMARILFAILURE"
                };
                local value;
                object::get "$node" "$SILMARILFIELDVALUE" value || return "$SILMARILFAILURE";
            fi;
        fi;
    fi
}
