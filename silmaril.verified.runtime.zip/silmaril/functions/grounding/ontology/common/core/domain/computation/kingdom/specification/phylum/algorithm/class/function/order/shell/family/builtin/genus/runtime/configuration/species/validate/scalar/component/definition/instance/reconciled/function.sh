runtimeconfig::validateScalar () 
{ 
    local parent=$1;
    local key=$2;
    local expected=$3;
    local actual;
    yaml::requiredScalar "$parent" "$key" actual || return "$SILMARILFAILURE";
    [[ $actual == "$expected" ]] || { 
        engine::raise "$SILMARILERRORYAML" "$key mismatch";
        return "$SILMARILFAILURE"
    }
}
