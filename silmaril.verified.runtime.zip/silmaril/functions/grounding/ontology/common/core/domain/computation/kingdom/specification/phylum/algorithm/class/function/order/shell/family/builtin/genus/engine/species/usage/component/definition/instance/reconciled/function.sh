engine::usage () 
{ 
    printf '%s\n' 'engine.sh apply REQUEST' 'engine.sh validate GRAPH' 'engine.sh analyze GRAPH' 'engine.sh order GRAPH' 'engine.sh run GRAPH [REPORT]' 'engine.sh certify FINITEMODEL' 'engine.sh pairs DOCUMENT' 'engine.sh selftest' 1>&2
}
