type::define () 
{ 
    local identity=$1;
    local definition=$2;
    local abstract=$3;
    local parentCount=$4;
    shift "$SILMARILFOUR";
    identity::requireRankedUrn "$identity" type || return "$SILMARILFAILURE";
    [[ ${definitionDefined[$definition]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERRORDEFINITION" "$definition";
        return "$SILMARILFAILURE"
    };
    [[ $abstract == "$SILMARILTRUE" || $abstract == "$SILMARILFALSE" ]] || { 
        engine::raise "$SILMARILERRORTYPE" 'abstract value';
        return "$SILMARILFAILURE"
    };
    [[ $parentCount =~ ^[0-9]+$ && $# -eq $parentCount ]] || { 
        engine::raise "$SILMARILERRORTYPEPARENT" "$identity";
        return "$SILMARILFAILURE"
    };
    [[ ! -n ${typeDefined[$identity]+present} ]] || { 
        engine::raise "$SILMARILERRORTYPEDUPLICATE" "$identity";
        return "$SILMARILFAILURE"
    };
    local -A seen=();
    local parentIdentity;
    local index=$SILMARILZERO;
    for parentIdentity in "$@";
    do
        type::exists "$parentIdentity" || { 
            engine::raise "$SILMARILERRORTYPEPARENT" "$parentIdentity";
            return "$SILMARILFAILURE"
        };
        [[ ! -n ${seen[$parentIdentity]+present} ]] || { 
            engine::raise "$SILMARILERRORTYPEPARENT" "duplicate $parentIdentity";
            return "$SILMARILFAILURE"
        };
        seen[$parentIdentity]=$SILMARILONE;
        typeParent[${identity}${SILMARILUS}${index}]=$parentIdentity;
        (( index += SILMARILONE ));
    done;
    typeDefined[$identity]=$SILMARILONE;
    typeDefinition[$identity]=$definition;
    typeAbstract[$identity]=$abstract;
    typeParentCount[$identity]=$parentCount;
    typeAxiomCount[$identity]=$SILMARILZERO;
    typeGroundingCount[$identity]=$SILMARILZERO;
    if ! type::linearize "$identity"; then
        unset 'typeDefined[$identity]' 'typeDefinition[$identity]' 'typeAbstract[$identity]' 'typeParentCount[$identity]' 'typeAxiomCount[$identity]' 'typeGroundingCount[$identity]';
        for ((index = SILMARILZERO; index < parentCount; index += SILMARILONE ))
        do
            unset 'typeParent[${identity}${SILMARILUS}${index}]';
        done;
        return "$SILMARILFAILURE";
    fi;
    typeOrder+=("$identity")
}
