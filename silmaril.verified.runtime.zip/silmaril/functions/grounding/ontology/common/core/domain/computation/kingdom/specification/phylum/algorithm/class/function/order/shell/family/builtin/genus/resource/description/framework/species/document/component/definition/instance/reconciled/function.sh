rdf::document () 
{ 
    local rdKeyword rdPrefix rdStart rdSubject rdAt;
    rdfCursor=0 rdfDepth=0 rdfPrefixes=() rdfBlankLabels=();
    while :; do
        rdf::space;
        ((rdfCursor<${#rdfText})) || break;
        rdAt=0 rdKeyword=;
        if [[ ${rdfText:rdfCursor:7} == '@prefix' && ${rdfText:rdfCursor+7:1} == [[:space:]] ]]; then
            rdKeyword=prefix;
            rdAt=1;
            ((rdfCursor+=7));
        fi;
        if [[ -z $rdKeyword ]]; then
            if [[ ${rdfText:rdfCursor:5} == '@base' && ${rdfText:rdfCursor+5:1} == [[:space:]] ]]; then
                rdKeyword=base;
                rdAt=1;
                ((rdfCursor+=5));
            fi;
        fi;
        if [[ -z $rdKeyword && ${rdfText:rdfCursor:6} == [pP][rR][eE][fF][iI][xX] && ${rdfText:rdfCursor+6:1} == [[:space:]] ]]; then
            rdKeyword=prefix;
            ((rdfCursor+=6));
        fi;
        if [[ -z $rdKeyword && ${rdfText:rdfCursor:4} == [bB][aA][sS][eE] && ${rdfText:rdfCursor+4:1} == [[:space:]] ]]; then
            rdKeyword=base;
            ((rdfCursor+=4));
        fi;
        if [[ -n $rdKeyword ]]; then
            rdf::space;
            if [[ $rdKeyword == prefix ]]; then
                rdStart=$rdfCursor;
                while [[ ${rdfText:rdfCursor:1} == [A-Za-z0-9_.-] ]]; do
                    ((rdfCursor+=1));
                done;
                rdPrefix=${rdfText:rdStart:rdfCursor-rdStart};
                rdf::expect ':' || return 1;
                rdf::space;
            fi;
            [[ ${rdfText:rdfCursor:1} == '<' ]] || { 
                rdf::error 'directive IRI required';
                return 1
            };
            rdf::iri || return 1;
            if [[ $rdKeyword == prefix ]]; then
                rdfPrefixes[$rdPrefix@]=${rdfTerm[rdfTermResult]};
            else
                rdfBase=${rdfTerm[rdfTermResult]};
            fi;
            if ((rdAt)); then
                rdf::expect '.' || return 1;
            fi;
        else
            rdf::term || return 1;
            rdSubject=$rdfTermResult;
            rdf::predicates "$rdSubject" || return 1;
            rdf::expect '.' || return 1;
        fi;
    done
}
