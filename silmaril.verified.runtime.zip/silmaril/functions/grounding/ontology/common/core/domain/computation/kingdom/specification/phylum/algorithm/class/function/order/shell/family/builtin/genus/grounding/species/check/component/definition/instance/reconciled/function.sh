grounding::check () 
{ 
    local gcProfile=$1 gcClass gcChain= gcCount=0;
    [[ -n ${groundingImported[$gcProfile]-} && -n ${groundingVersion[$gcProfile]-} ]] || { 
        error::raise GROUNDING/MISSING 'exact imported profile unavailable';
        return 1
    };
    [[ ${groundingVersion[$gcProfile]} == http://purl.obolibrary.org/obo/bfo/2020/bfo-core.owl ]] || { 
        error::raise GROUNDING/CONTRADICTORY 'version mismatch';
        return 1
    };
    gcClass=${groundingImported[$gcProfile]};
    while [[ -n $gcClass ]]; do
        [[ -z $gcChain ]] || gcChain+=' ';
        gcChain+=$gcClass;
        gcClass=${groundingParent[$gcClass]-};
        ((gcCount+=1));
        ((gcCount<=8)) || { 
            error::raise GROUNDING/CONTRADICTORY 'ancestry cycle';
            return 1
        };
    done;
    [[ $gcChain == "${groundingExpected[$gcProfile]}" ]] || { 
        error::raise GROUNDING/CONTRADICTORY 'imported class chain mismatch';
        return 1
    }
}
