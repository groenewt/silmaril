wide::reverse () 
{ 
    local wrText=$1 wrResult= wrIndex;
    for ((wrIndex=${#wrText}-1; wrIndex>=0; wrIndex-=1))
    do
        wrResult+=${wrText:wrIndex:1};
    done;
    printf -v "$2" '%s' "$wrResult"
}
