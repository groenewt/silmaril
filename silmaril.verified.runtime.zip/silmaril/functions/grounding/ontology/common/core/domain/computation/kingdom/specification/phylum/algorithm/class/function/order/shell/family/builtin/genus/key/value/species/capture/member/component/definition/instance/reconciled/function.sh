kv::capture::member () 
{ 
    local cmIndex=$1 cmIndent=$2 cmKind=$3 cmCount=$4 cmDigit cmNext cmRef cmPath cmField cmValue;
    cmDigit=${lexicalDigits[cmIndex%SILCAPTURETEN]^^};
    kv::capture::line "$cmIndent" "$cmDigit" || return "$SILCAPTUREONE";
    ((cmIndent+=SILCAPTURETWO));
    if [[ $cmKind == digest ]]; then
        number::reference "$((16#${kvCaptureDigest:cmIndex*SILCAPTURETWO:SILCAPTURETWO}))" cmRef || return "$SILCAPTUREONE";
        kv::capture::line "$cmIndent" ITEM "$cmRef" || return "$SILCAPTUREONE";
    else
        cmPath=${kvPaths[cmIndex]};
        kv::capture::line "$cmIndent" ITEM || return "$SILCAPTUREONE";
        for cmField in IDENTITY PAIR SUBJECT KEY VALUE CARRIER POSITION PROVENANCE LINE OFFSET LENGTH;
        do
            case $cmField in 
                IDENTITY)
                    cmValue=${kvBinding[$cmPath]}
                ;;
                PAIR)
                    cmValue=${kvPair[$cmPath]}
                ;;
                SUBJECT)
                    cmValue=${kvSubject[$cmPath]}
                ;;
                KEY)
                    cmValue=${kvPredicate[$cmPath]}
                ;;
                VALUE)
                    cmValue=${kvRight[$cmPath]}
                ;;
                CARRIER)
                    cmValue=${kvCarrier[$cmPath]}
                ;;
                POSITION)
                    cmValue=${kvPosition[$cmPath]}
                ;;
                PROVENANCE)
                    cmValue=${kvProvenance[$cmPath]}
                ;;
                LINE)
                    number::reference "${kvLine[$cmPath]}" cmValue || return "$SILCAPTUREONE"
                ;;
                OFFSET)
                    number::reference "${kvOffset[$cmPath]}" cmValue || return "$SILCAPTUREONE"
                ;;
                LENGTH)
                    number::reference "${kvSpan[$cmPath]}" cmValue || return "$SILCAPTUREONE"
                ;;
            esac;
            kv::capture::line "$((cmIndent+SILCAPTURETWO))" "$cmField" "$cmValue" || return "$SILCAPTUREONE";
        done;
    fi;
    if ((cmIndex==SILCAPTUREZERO)); then
        return "$SILCAPTUREZERO";
    fi;
    for ((cmDigit=SILCAPTUREZERO; cmDigit<SILCAPTURETEN; cmDigit+=SILCAPTUREONE))
    do
        cmNext=$((cmIndex*SILCAPTURETEN+cmDigit));
        ((cmNext<cmCount)) || break;
        kv::capture::member "$cmNext" "$cmIndent" "$cmKind" "$cmCount" || return "$SILCAPTUREONE";
    done
}
