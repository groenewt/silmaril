rdf::emit () 
{ 
    local emGraph=$1 emIndex emSubject emPredicate emObject;
    for emIndex in "${!rdfSubject[@]}";
    do
        [[ ${rdfGraph[emIndex]} == "$emGraph" ]] || continue;
        rdf::renderTerm "${rdfSubject[emIndex]}" emSubject || return 1;
        rdf::renderTerm "${rdfPredicate[emIndex]}" emPredicate || return 1;
        rdf::renderTerm "${rdfObject[emIndex]}" emObject || return 1;
        printf '%s %s %s .\n' "$emSubject" "$emPredicate" "$emObject";
    done
}
