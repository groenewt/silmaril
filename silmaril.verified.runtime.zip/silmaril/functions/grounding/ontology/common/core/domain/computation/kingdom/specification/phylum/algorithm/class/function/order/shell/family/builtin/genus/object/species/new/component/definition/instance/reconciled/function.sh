object::new () 
{ 
    local identity=$1;
    local identityType=$2;
    identity::requireRankedUrn "$identity" object || return "$SILMARILFAILURE";
    type::exists "$identityType" || { 
        engine::raise "$SILMARILERROROBJECT" "$identityType";
        return "$SILMARILFAILURE"
    };
    [[ ${typeAbstract[$identityType]} == "$SILMARILFALSE" ]] || { 
        engine::raise "$SILMARILERRORTYPEABSTRACT" "$identityType";
        return "$SILMARILFAILURE"
    };
    [[ ! -n ${objectDefined[$identity]+present} ]] || { 
        engine::raise "$SILMARILERROROBJECT" "$identity duplicate";
        return "$SILMARILFAILURE"
    };
    objectDefined[$identity]=$SILMARILONE;
    objectType[$identity]=$identityType;
    objectOrder+=("$identity")
}
