node::identity::run () 
{ 
    local identity=$1;
    local method=$2;
    local owner=$3;
    local outputName=$4;
    local count=${nodeInputCount[$identity]:-$SILMARILZERO};
    if (( count != SILMARILONE )); then
        frame::failure "$SILMARILERRORGRAPHNODE" "$outputName";
        return "$SILMARILFAILURE";
    fi;
    frame::success "${nodeInput[${identity}${SILMARILUS}${SILMARILZERO}]}" "$SILMARILEFFECTNONE" "$outputName"
}
