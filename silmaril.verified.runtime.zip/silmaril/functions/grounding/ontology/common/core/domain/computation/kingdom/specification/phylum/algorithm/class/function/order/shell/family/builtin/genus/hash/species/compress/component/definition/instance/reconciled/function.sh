hash::compress () 
{ 
    local a=${hashState[0]} b=${hashState[1]} c=${hashState[2]} d=${hashState[3]};
    local e=${hashState[4]} f=${hashState[5]} g=${hashState[6]} h=${hashState[7]};
    local i x y s0 s1 t1 t2 ch maj;
    for ((i=16; i<64; i++))
    do
        x=${hashBlock[i-15]};
        y=${hashBlock[i-2]};
        s0=$(( ((x>>7)|(x<<25)) ^ ((x>>18)|(x<<14)) ^ (x>>3) ));
        s1=$(( ((y>>17)|(y<<15)) ^ ((y>>19)|(y<<13)) ^ (y>>10) ));
        hashBlock[i]=$(( (hashBlock[i-16]+s0+hashBlock[i-7]+s1)&HASHMASK ));
    done;
    for ((i=0; i<64; i++))
    do
        s1=$(( ((e>>6)|(e<<26)) ^ ((e>>11)|(e<<21)) ^ ((e>>25)|(e<<7)) ));
        ch=$(( (e&f)^((~e)&g) ));
        t1=$(( (h+s1+ch+hashConstants[i]+hashBlock[i])&HASHMASK ));
        s0=$(( ((a>>2)|(a<<30)) ^ ((a>>13)|(a<<19)) ^ ((a>>22)|(a<<10)) ));
        maj=$(( (a&b)^(a&c)^(b&c) ));
        t2=$(( (s0+maj)&HASHMASK ));
        h=$g;
        g=$f;
        f=$e;
        e=$(( (d+t1)&HASHMASK ));
        d=$c;
        c=$b;
        b=$a;
        a=$(( (t1+t2)&HASHMASK ));
    done;
    hashState[0]=$(( (hashState[0]+a)&HASHMASK ));
    hashState[1]=$(( (hashState[1]+b)&HASHMASK ));
    hashState[2]=$(( (hashState[2]+c)&HASHMASK ));
    hashState[3]=$(( (hashState[3]+d)&HASHMASK ));
    hashState[4]=$(( (hashState[4]+e)&HASHMASK ));
    hashState[5]=$(( (hashState[5]+f)&HASHMASK ));
    hashState[6]=$(( (hashState[6]+g)&HASHMASK ));
    hashState[7]=$(( (hashState[7]+h)&HASHMASK ));
    hashBlock=();
    hashFill=0
}
