inventory::scan () 
{ 
    local inRoot=$1 inPath inIndex=0 inOrdinal inNull=0 inDot=0 inFailure=0 inCount inKind inObservation LC_ALL=C GLOBIGNORE=;
    local -a inPaths=("$inRoot") inParents=(-1) inDepths=(0) inOrdinals=(0) inKinds=(directory) inChildren=(0) inEntries=();
    path::requireSafe "$inRoot" || return 1;
    [[ -d $inRoot && -r $inRoot && -x $inRoot ]] || { 
        error::raise PATH/ROOT 'readable and searchable directory required';
        return 1
    };
    ((inventoryMaximumEntries>0)) || { 
        error::raise PAIR/LIMIT 'inventory capacity';
        return 1
    };
    shopt -q nullglob && inNull=1;
    shopt -q dotglob && inDot=1;
    shopt -s nullglob dotglob;
    while ((inIndex<${#inPaths[@]})); do
        if [[ ${inKinds[inIndex]} != directory ]]; then
            ((inIndex+=1));
            continue;
        fi;
        [[ -r ${inPaths[inIndex]} && -x ${inPaths[inIndex]} ]] || { 
            error::raise PATH/ROOT 'inaccessible observed directory';
            inFailure=1;
            break
        };
        inEntries=("${inPaths[inIndex]%/}"/*);
        inOrdinal=0;
        inChildren[inIndex]=${#inEntries[@]};
        for inPath in "${inEntries[@]}";
        do
            if [[ -L $inPath ]]; then
                error::raise PATH/SEGMENT 'symbolic link in governed tree';
                inFailure=1;
                break;
            fi;
            if [[ -d $inPath ]]; then
                inKind=directory;
            else
                if [[ -f $inPath ]]; then
                    inKind=file;
                else
                    error::raise PATH/SEGMENT 'nonregular object in file-tree profile';
                    inFailure=1;
                    break;
                fi;
            fi;
            ((${#inPaths[@]}<inventoryMaximumEntries)) || { 
                error::raise PAIR/LIMIT 'inventory capacity';
                inFailure=1;
                break
            };
            inPaths+=("$inPath");
            inParents+=("$inIndex");
            inDepths+=("$((inDepths[inIndex]+1))");
            inOrdinals+=("$inOrdinal");
            inKinds+=("$inKind");
            inChildren+=(0);
            ((inOrdinal+=1));
        done;
        ((inFailure==0)) || break;
        ((inIndex+=1));
    done;
    ((inNull)) || shopt -u nullglob;
    ((inDot)) || shopt -u dotglob;
    ((inFailure==0)) || return 1;
    inventoryPath=("${inPaths[@]}");
    inventoryParent=("${inParents[@]}");
    inventoryDepth=("${inDepths[@]}");
    inventoryOrdinal=("${inOrdinals[@]}");
    inventoryKind=("${inKinds[@]}");
    inventoryChildren=("${inChildren[@]}");
    ((inventoryObservation+=1));
    inventory::check
}
