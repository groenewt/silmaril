engine::apply () 
{ 
    local axStatus=0 axError=;
    engineResult=;
    engineRequestIdentity=$REQUESTTYPE:component:bootstrap:instance:failure;
    request::execute "$@" || axStatus=$?;
    if ((axStatus)); then
        axError=${engineError:-${errorRegistry[PROTOCOL/OPERATION]}};
        if type::exists "$SILMARILTYPEFRAME"; then
            if [[ -z $engineResult || ${frameStatus[$engineResult]-} == "$SILMARILSTATUSSUCCESS" ]]; then
                frame::failure "$axError" engineResult || return 1;
            fi;
        fi;
        engineError=$axError;
    fi;
    return "$axStatus"
}
