type::exists () 
{ 
    local identity=$1;
    [[ ${typeDefined[$identity]-} == "$SILMARILONE" ]]
}
