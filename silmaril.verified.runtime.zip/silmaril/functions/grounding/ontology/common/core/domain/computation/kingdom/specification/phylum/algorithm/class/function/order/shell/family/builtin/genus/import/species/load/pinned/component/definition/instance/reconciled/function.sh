import::loadPinned () 
{ 
    local ixName ixKey ixStatus=0 ixDigest=$importDigest ixSource=$importSource;
    local -a ixArrays=(rdfTerm rdfKind rdfLexical rdfDatatype rdfLanguage rdfSubject rdfPredicate rdfObject rdfGraph rdfLines);
    local -a ixMaps=(rdfIntern rdfTriples rdfPrefixes rdfBlankLabels rdfForward rdfParents importVersion importOntology importAlias);
    local ixBase=$rdfBase ixContext=$rdfContext ixText=$rdfText ixCursor=$rdfCursor ixDepth=$rdfDepth ixDocument=$rdfDocumentCounter ixBlank=$rdfBlankCounter ixLine=$rdfLineIndex ixOffset=$rdfAbsoluteOffset ixResult=$rdfTermResult;
    for ixName in "${ixArrays[@]}";
    do
        local -a "saved${ixName}=()";
        local -n ixOriginal=$ixName ixSaved=saved$ixName;
        ixSaved=("${ixOriginal[@]}");
    done;
    for ixName in "${ixMaps[@]}";
    do
        local -A "saved${ixName}=()";
        local -n ixOriginal=$ixName ixSaved=saved$ixName;
        for ixKey in "${!ixOriginal[@]}";
        do
            ixSaved[$ixKey]=${ixOriginal[$ixKey]};
        done;
    done;
    import::loadPinnedCandidate "$@" || ixStatus=$?;
    if ((ixStatus)); then
        for ixName in "${ixArrays[@]}";
        do
            local -n ixOriginal=$ixName ixSaved=saved$ixName;
            ixOriginal=("${ixSaved[@]}");
        done;
        for ixName in "${ixMaps[@]}";
        do
            local -n ixOriginal=$ixName ixSaved=saved$ixName;
            ixOriginal=();
            for ixKey in "${!ixSaved[@]}";
            do
                ixOriginal[$ixKey]=${ixSaved[$ixKey]};
            done;
        done;
        rdfBase=$ixBase rdfContext=$ixContext rdfText=$ixText rdfCursor=$ixCursor rdfDepth=$ixDepth rdfDocumentCounter=$ixDocument rdfBlankCounter=$ixBlank rdfLineIndex=$ixLine rdfAbsoluteOffset=$ixOffset rdfTermResult=$ixResult;
        importDigest=$ixDigest importSource=$ixSource;
        return "$ixStatus";
    fi;
    return 0
}
