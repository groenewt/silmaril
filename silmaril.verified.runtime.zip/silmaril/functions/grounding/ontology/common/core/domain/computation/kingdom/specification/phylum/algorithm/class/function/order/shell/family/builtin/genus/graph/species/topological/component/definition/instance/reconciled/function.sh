graph::topological () 
{ 
    local -A indegree=() emitted=();
    local node edge target selected candidate adjacencyKey;
    for node in "${graphNodes[@]}";
    do
        indegree[$node]=$SILMARILZERO;
    done;
    for edge in "${graphEdges[@]}";
    do
        target=${graphEdgeTarget[$edge]};
        indegree[$target]=$(( ${indegree[$target]} + SILMARILONE ));
    done;
    graphIncomingCount=();
    for node in "${graphNodes[@]}";
    do
        graphIncomingCount[$node]=${indegree[$node]};
    done;
    graphOrder=();
    while (( ${#graphOrder[@]} < ${#graphNodes[@]} )); do
        selected=;
        for node in "${graphNodes[@]}";
        do
            if [[ -z ${emitted[$node]+yes} ]] && ((indegree[$node]==SILMARILZERO)); then
                selected=$node;
                break;
            fi;
        done;
        [[ -n $selected ]] || { 
            engine::raise "$SILMARILERRORGRAPHCYCLE" "$graphIdentity";
            return "$SILMARILFAILURE"
        };
        emitted[$selected]=$SILMARILONE;
        graphOrder+=("$selected");
        for candidate in "${graphNodes[@]}";
        do
            adjacencyKey="$selected$SILMARILUS$candidate";
            [[ -n ${graphAdjacency[$adjacencyKey]+present} ]] || continue;
            indegree[$candidate]=$((indegree[$candidate]-SILMARILONE));
        done;
    done
}
