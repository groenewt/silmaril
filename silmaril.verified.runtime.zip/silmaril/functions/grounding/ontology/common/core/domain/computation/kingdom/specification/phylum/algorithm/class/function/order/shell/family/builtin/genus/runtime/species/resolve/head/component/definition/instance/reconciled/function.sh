runtime::resolveHead () 
{ 
    local commandText=$1;
    local headName=$2;
    local assignmentName=$3;
    local -n headReference=$headName;
    local -n assignmentReference=$assignmentName;
    local trimmed;
    string::trim "$commandText" trimmed;
    assignmentReference=;
    if [[ $trimmed == '(('* ]]; then
        headReference='((';
        return "$SILMARILZERO";
    fi;
    if [[ $trimmed == '[['* ]]; then
        headReference='[[';
        return "$SILMARILZERO";
    fi;
    if [[ $trimmed =~ ^([A-Za-z_][A-Za-z0-9_]*)(\[[^]]+\])?\+?= ]]; then
        headReference=assignment;
        assignmentReference=${BASH_REMATCH[1]};
        return "$SILMARILZERO";
    fi;
    local parsedHead=${trimmed%%[[:space:]]*};
    local variableName=;
    local resolved=$parsedHead;
    if [[ $parsedHead == '"$'*'"' ]]; then
        variableName=${parsedHead:2:${#parsedHead}-SILMARILTHREE};
    else
        if [[ $parsedHead == '$'* ]]; then
            variableName=${parsedHead:SILMARILONE};
        else
            if [[ $parsedHead == '"${'*'}"' ]]; then
                variableName=${parsedHead:SILMARILTHREE:${#parsedHead}-SILMARILSIX};
            fi;
        fi;
    fi;
    if [[ -n $variableName && $variableName =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]]; then
        resolved=${!variableName-};
    fi;
    headReference=$resolved
}
