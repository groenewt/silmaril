runtime::debug () 
{ 
    local commandText=$BASH_COMMAND;
    local caller=${FUNCNAME[1]-main};
    local callerTrusted=${runtimeTrusted[$caller]-$SILMARILZERO};
    local head;
    local assignmentTarget;
    runtime::resolveHead "$commandText" head assignmentTarget;
    if (( callerTrusted == SILMARILZERO )) && runtime::containsProtected "$commandText"; then
        runtime::recordViolation "$commandText" "$head" || :;
        return "$SILMARILFAILURE";
    fi;
    if [[ $head == assignment ]]; then
        if (( callerTrusted == SILMARILZERO )) && runtime::containsProtected "$assignmentTarget"; then
            runtime::recordViolation "$commandText" "$assignmentTarget" || :;
            return "$SILMARILFAILURE";
        fi;
        return "$SILMARILZERO";
    fi;
    case $head in 
        '((' | '[[')
            return "$SILMARILZERO"
        ;;
    esac;
    local kind=;
    if declare -F -- "$head" > /dev/null; then
        kind=function;
    else
        if [[ -n ${runtimeBuiltinKind[$head]+present} ]]; then
            kind=${runtimeBuiltinKind[$head]};
        fi;
    fi;
    if [[ $kind == function ]]; then
        if [[ $head == runtime::end && $caller == "$runtimeOwner" ]]; then
            return "$SILMARILZERO";
        fi;
        if [[ ${runtimeTrusted[$head]-$SILMARILZERO} == "$SILMARILONE" && $callerTrusted == "$SILMARILZERO" && ${runtimeCallable[$head]-$SILMARILZERO} != "$SILMARILONE" ]]; then
            runtime::recordViolation "$commandText" "$head" || :;
            return "$SILMARILFAILURE";
        fi;
        return "$SILMARILZERO";
    fi;
    case $head in 
        command | builtin | exec | source | . | enable | eval | coproc | time | unset | export | readonly | typeset | declare)
            runtime::recordViolation "$commandText" "$head" || :;
            return "$SILMARILFAILURE"
        ;;
        trap | shopt | set)
            if [[ $caller == runtime::end ]]; then
                return "$SILMARILZERO";
            fi;
            runtime::recordViolation "$commandText" "$head" || :;
            return "$SILMARILFAILURE"
        ;;
        local)
            if (( callerTrusted == SILMARILZERO )) && [[ $commandText == *' -n '* || $commandText == *' -g '* ]]; then
                runtime::recordViolation "$commandText" "$head" || :;
                return "$SILMARILFAILURE";
            fi;
            return "$SILMARILZERO"
        ;;
        printf)
            if (( callerTrusted == SILMARILZERO )) && [[ $commandText == *' -v '* ]]; then
                runtime::recordViolation "$commandText" "$head" || :;
                return "$SILMARILFAILURE";
            fi;
            return "$SILMARILZERO"
        ;;
        read | mapfile | readarray)
            if (( callerTrusted == SILMARILZERO )); then
                runtime::recordViolation "$commandText" "$head" || :;
                return "$SILMARILFAILURE";
            fi;
            return "$SILMARILZERO"
        ;;
    esac;
    case $kind in 
        builtin | keyword)
            return "$SILMARILZERO"
        ;;
        *)
            runtime::recordViolation "$commandText" "$head" || :;
            return "$SILMARILFAILURE"
        ;;
    esac
}
