node::constant::run () 
{ 
    local identity=$1;
    local method=$2;
    local owner=$3;
    local outputName=$4;
    local value;
    object::get "$identity" "$SILMARILFIELDVALUE" value || { 
        frame::failure "$SILMARILERRORGRAPHNODE" "$outputName";
        return "$SILMARILFAILURE"
    };
    frame::success "$value" "$SILMARILEFFECTNONE" "$outputName"
}
