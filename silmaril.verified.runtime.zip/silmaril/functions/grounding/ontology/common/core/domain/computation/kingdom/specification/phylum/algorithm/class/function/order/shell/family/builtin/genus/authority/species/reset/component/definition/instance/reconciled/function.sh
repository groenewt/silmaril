authority::reset () 
{ 
    groundingDefined=();
    groundingOrder=();
    definitionDefined=();
    definitionType=();
    definitionShortDescription=();
    definitionLongDescription=();
    definitionOrder=();
    axiomDefined=();
    axiomType=();
    axiomDomain=();
    axiomShortDescription=();
    axiomLongDescription=();
    axiomOrder=()
}
