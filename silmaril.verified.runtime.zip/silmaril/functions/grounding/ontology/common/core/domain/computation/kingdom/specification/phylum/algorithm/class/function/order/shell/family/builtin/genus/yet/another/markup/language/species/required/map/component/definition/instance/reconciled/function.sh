yaml::requiredMap () 
{ 
    local parent=$1;
    local key=$2;
    local outputName=$3;
    local -n outputReference=$outputName;
    local pathValue;
    yaml::join pathValue "$parent" "$key";
    [[ ${yamlKind[$pathValue]-} == map ]] || { 
        engine::raise "$SILMARILERRORYAML" "required map $key";
        return "$SILMARILFAILURE"
    };
    outputReference=$pathValue
}
