pair::identity () 
{ 
    local pxKey=$1 pxValue=$2 pxOut=$3 pxLeft pxRight pxRest pxCount pxWord pxName;
    identity::requireUrn "$pxKey" key && identity::requireUrn "$pxValue" value || return 1;
    pxLeft=${pxKey#"$SILMARILROOT:"};
    pxRight=${pxValue#"$SILMARILROOT:"};
    pxName=$PAIRPRODUCTBASE:component:product:instance;
    for pxRest in "$pxLeft" "$pxRight";
    do
        pxCount=${pxRest//[^:]/};
        name::number "$((${#pxCount}+1))" pxWord;
        pxName+=:extent:$pxWord:content:$pxRest;
    done;
    printf -v "$pxOut" '%s' "$pxName"
}
