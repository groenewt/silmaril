object::callNext () 
{ 
    local identity=$1;
    local method=$2;
    local currentOwner=$3;
    local outputName=$4;
    shift "$SILMARILFOUR";
    local -a resolution=();
    type::mro "${objectType[$identity]}" resolution || return "$SILMARILFAILURE";
    local currentIndex=-1;
    local index;
    for ((index = SILMARILZERO; index < ${#resolution[@]}; index += SILMARILONE ))
    do
        if [[ ${resolution[$index]} == "$currentOwner" ]]; then
            currentIndex=$index;
            break;
        fi;
    done;
    (( currentIndex >= SILMARILZERO )) || { 
        engine::raise "$SILMARILERRORDISPATCH" "$currentOwner";
        return "$SILMARILFAILURE"
    };
    local owner;
    local implementation;
    dispatch::resolve "$identity" "$method" "$(( currentIndex + SILMARILONE ))" owner implementation || return "$SILMARILFAILURE";
    "$implementation" "$identity" "$method" "$owner" "$outputName" "$@"
}
