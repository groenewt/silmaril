source::verifyFile () 
{ 
    local svFunction=$1 svFile=$2 svExpected svActual= svStatus;
    [[ ${runtimeTrusted[$svFunction]-} == "$SILMARILONE" && -n ${sourcePath[$svFunction]+yes} ]] || { 
        error::raise PROJECTION/FIDELITY 'unregistered source projection';
        return 1
    };
    path::requireReadable "$svFile" || return 1;
    svExpected=$(declare -f "$svFunction") || return 1;
    if IFS= read -r -d '' -n "$((kvMaximumBytes+1))" svActual < "$svFile"; then
        error::raise PROJECTION/FIDELITY 'NUL or oversized source projection';
        return 1;
    else
        svStatus=$?;
    fi;
    ((svStatus==1)) || { 
        error::raise PROJECTION/FIDELITY 'source projection read';
        return 1
    };
    [[ $svActual == "$svExpected"'
' ]] || { 
        error::raise PROJECTION/FIDELITY "function projection differs: $svFunction";
        return 1
    }
}
