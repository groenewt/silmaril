yaml::sequenceScalar () 
{ 
    local sequencePath=$1;
    local index=$2;
    local outputName=$3;
    local -n outputReference=$outputName;
    local itemPath;
    yaml::itemPath itemPath "$sequencePath" "$index";
    [[ ${yamlKind[$itemPath]-} == scalar ]] || { 
        engine::raise "$SILMARILERRORYAML" "sequence scalar $index";
        return "$SILMARILFAILURE"
    };
    outputReference=${yamlValue[$itemPath]}
}
