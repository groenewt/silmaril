byte::writeFile () 
{ 
    local bwId=$1 bwPath=$2 bwN bwI bwValue bwOct;
    byte::count "$bwId" bwN || return 1;
    path::requireWritableTarget "$bwPath" || return 1;
    for ((bwI=0; bwI<bwN; bwI++))
    do
        byte::at "$bwId" "$bwI" bwValue || return 1;
        [[ $bwValue =~ ^[0-9]+$ ]] && ((bwValue>=0 && bwValue<256)) || { 
            error::raise BYTE/RANGE "$bwI";
            return 1
        };
    done;
    { 
        for ((bwI=0; bwI<bwN; bwI++))
        do
            byte::at "$bwId" "$bwI" bwValue || return 1;
            printf -v bwOct '\\%03o' "$bwValue";
            printf '%b' "$bwOct" || { 
                error::raise PAIR/CARRIER write;
                return 1
            };
        done
    } > "$bwPath"
}
