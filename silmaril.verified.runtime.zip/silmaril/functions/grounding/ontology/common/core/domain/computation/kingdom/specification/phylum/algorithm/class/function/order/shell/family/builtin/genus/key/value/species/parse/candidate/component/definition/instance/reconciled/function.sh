kv::parseCandidate () 
{ 
    local kpFile=$1 kpLine kpPrefix kpBody kpKey kpValue kpIndent kpDepth kpPath kpParent;
    local kpNumber=0 kpOffset=0 kpWidth kpPrevDepth=0 kpPrevKind=map kpPart kpProse kpId kpDocPath;
    local -a kpStack=(ROOT);
    local -A kpDeclared=();
    local LC_ALL=C kpStatus=0 kpCarrier;
    path::requireReadable "$kpFile" || return 1;
    kv::reset;
    kvSource=$kpFile;
    IFS= read -r -d '' -n "$((kvMaximumBytes+1))" kvRaw < "$kpFile" || kpStatus=$?;
    (( ${#kvRaw} <= kvMaximumBytes )) || { 
        error::raise PAIR/LIMIT 'text byte limit';
        return 1
    };
    ((kpStatus!=0)) || { 
        error::raise PAIR/CARRIER 'NUL in canonical text';
        return 1
    };
    text::utfEight "$kvRaw" || return 1;
    [[ $kvRaw == *'
' ]] || { 
        error::raise PAIR/CARRIER 'canonical text requires final LF';
        return 1
    };
    while IFS= read -r kpLine; do
        ((kpNumber+=1));
        kpWidth=${#kpLine};
        [[ $kpLine != *'	'* && $kpLine != *''* ]] || { 
            error::raise PAIR/CARRIER "line $kpNumber";
            return 1
        };
        if [[ -z $kpLine || $kpLine =~ ^[[:space:]]*# ]]; then
            ((kpOffset+=kpWidth+1));
            continue;
        fi;
        kpPrefix=${kpLine%%[! ]*};
        kpIndent=${#kpPrefix};
        kpDepth=$((kpIndent/2));
        ((kpIndent%2==0 && kpDepth<kvMaximumDepth && kpDepth<=kpPrevDepth+1)) || { 
            error::raise PATH/DEPTH "line $kpNumber";
            return 1
        };
        if ((kpDepth>kpPrevDepth)) && [[ $kpPrevKind != map ]]; then
            error::raise PATH/PARENT "line $kpNumber";
            return 1;
        fi;
        kpBody=${kpLine:kpIndent};
        [[ $kpBody =~ ^([A-Z]+):([[:space:]].*)?$ ]] || { 
            error::raise PAIR/KEY "line $kpNumber";
            return 1
        };
        kpKey=${BASH_REMATCH[1]};
        kpValue=${BASH_REMATCH[2]-};
        [[ -n ${kvKeyKnown[$kpKey]-} ]] || { 
            error::raise PAIR/KEY "$kpKey";
            return 1
        };
        string::trim "$kpValue" kpValue;
        kpParent=${kpStack[$kpDepth]-};
        [[ -n $kpParent && ${kvKind[$kpParent]-} == map ]] || { 
            error::raise PATH/PARENT "line $kpNumber";
            return 1
        };
        kpPath=$kpParent/$kpKey;
        [[ ! -n ${kvKind[$kpPath]+present} ]] || { 
            error::raise PAIR/DUPLICATE "$kpPath";
            return 1
        };
        kvPaths+=("$kpPath");
        kvChildren[$kpParent]+="$kpKey ";
        kvLine[$kpPath]=$kpNumber;
        kvOffset[$kpPath]=$kpOffset;
        kvSpan[$kpPath]=$((kpWidth+1));
        if [[ -z $kpValue ]]; then
            kvKind[$kpPath]=map;
            kpStack[$((kpDepth+1))]=$kpPath;
            kpPrevKind=map;
        else
            kvKind[$kpPath]=scalar;
            kpPrevKind=scalar;
            kpProse=0;
            [[ $kpPath == */METADATA/SHORT/DESCRIPTION || $kpPath == */METADATA/LONG/DESCRIPTION ]] && kpProse=1;
            if ((kpProse)); then
                kv::prose "$kpValue" kpValue || return 1;
            else
                identity::requireUrn "$kpValue" "$kpPath" || return 1;
            fi;
            kvValue[$kpPath]=$kpValue;
            [[ $kpKey != IDENTITY ]] || kpDeclared[$kpValue]=1;
        fi;
        kpPrevDepth=$kpDepth;
        ((kpOffset+=kpWidth+1));
        ((${#kvPaths[@]}<=kvMaximumPairs)) || { 
            error::raise PAIR/LIMIT 'binding limit';
            return 1
        };
    done <<< "$kvRaw";
    kvDocument=${kvValue[ROOT/IDENTITY]-};
    [[ -n $kvDocument ]] || { 
        error::raise PAIR/SUBJECT 'document IDENTITY missing';
        return 1
    };
    identity::requireRankedUrn "$kvDocument" document || return 1;
    kvMap[ROOT]=$kvDocument;
    path::identify "$kpFile" kpCarrier || return 1;
    local kpObservation;
    name::number "$((kvObservationCounter+1))" kpObservation;
    kpCarrier+=:occurrence:observation:$kpObservation;
    for kpPath in "${kvPaths[@]}";
    do
        kpPart=${kpPath#ROOT/};
        kpPart=${kpPart,,};
        kpPart=${kpPart//\//:};
        kvBinding[$kpPath]="${kpCarrier}:occurrence:binding:${kpPart}";
        kvCarrier[$kpPath]=$kpCarrier;
        kvPosition[$kpPath]="${kpCarrier}:occurrence:position:${kpPart}";
        kvProvenance[$kpPath]="${kpCarrier}:occurrence:derivation:${kpPart}";
        if [[ ${kvKind[$kpPath]} == map ]]; then
            [[ -n ${kvChildren[$kpPath]-} ]] || { 
                error::raise PAIR/VALUE "empty anonymous map $kpPath";
                return 1
            };
            kvMap[$kpPath]=${kvValue[$kpPath/IDENTITY]-"${kvDocument}:occurrence:mapping:${kpPart}"};
            kvRight[$kpPath]=${kvMap[$kpPath]};
        else
            if [[ $kpPath == */METADATA/SHORT/DESCRIPTION || $kpPath == */METADATA/LONG/DESCRIPTION ]]; then
                kvRight[$kpPath]="${kvDocument}:occurrence:description:${kpPart}:observation:${kpObservation}";
            else
                kpValue=${kvValue[$kpPath]};
                [[ ${kvKnown[$kpValue]-} == 1 || ${kpDeclared[$kpValue]-} == 1 || ${objectDefined[$kpValue]-} == 1 ]] || reference::admit "$kpValue" || { 
                    error::raise PAIR/VALUE "unresolved reference at $kpPath";
                    return 1
                };
                kvRight[$kpPath]=$kpValue;
            fi;
        fi;
        kpKey=${kpPath##*/};
        kvPredicate[$kpPath]=${kvKeyKnown[$kpKey]};
        pair::identity "${kvPredicate[$kpPath]}" "${kvRight[$kpPath]}" kpId || return 1;
        kvPair[$kpPath]=$kpId;
    done;
    for kpPath in "${kvPaths[@]}";
    do
        kpParent=${kpPath%/*};
        kvSubject[$kpPath]=${kvMap[$kpParent]};
    done;
    kv::check
}
