request::execute () 
{ 
    [[ $# == 1 ]] || { 
        error::raise PROTOCOL/OPERATION 'unary arity';
        return 1
    };
    local eaRequest=$1 eaDir eaType eaIdentity eaOp eaInput eaOutput= eaCheckpoint= eaSnapshot= eaPolicy eaFlag eaRef eaRc=0 eaNode eaReceipt= eaObservation= eaPin= eaCapture=0 eaEffect=$SILMARILEFFECTNONE;
    engine::directory eaDir;
    path::absolute "$eaDir" eaDir;
    engine::reset;
    engine::bootstrap "$eaDir/ontology/primordial.yaml" "$eaDir/ontology/runtime.yaml" || return 1;
    scheduler::defaults;
    yaml::parse "$eaRequest" || { 
        frame::failure "$engineError" engineResult;
        return 1
    };
    yaml::assertOnlyKeys "$SILMARILYAMLROOT" IDENTITY TYPE OPERATION INPUT OUTPUT POLICY CHECKPOINT SNAPSHOT OBSERVATION DIGEST RECEIPT || { 
        frame::failure "$engineError" engineResult;
        return 1
    };
    yaml::requiredScalar "$SILMARILYAMLROOT" IDENTITY eaIdentity || return 1;
    engineRequestIdentity=$eaIdentity;
    yaml::requiredScalar "$SILMARILYAMLROOT" TYPE eaType || return 1;
    [[ $eaType == "$REQUESTTYPE" ]] || { 
        error::raise PROTOCOL/OPERATION 'request type';
        frame::failure "$engineError" engineResult;
        return 1
    };
    yaml::requiredScalar "$SILMARILYAMLROOT" OPERATION eaOp || return 1;
    yaml::requiredScalar "$SILMARILYAMLROOT" INPUT eaRef || return 1;
    path::decode "$eaRef" eaInput || return 1;
    if [[ $eaOp == "$REQUESTOPERATION":capture || $eaOp == "$REQUESTOPERATION":capture:verify ]]; then
        eaCapture=$SILCAPTUREONE;
        for eaNode in POLICY CHECKPOINT SNAPSHOT;
        do
            [[ ! -n ${yamlKind[$SILMARILYAMLROOT$SILMARILUS"$eaNode"]+present} ]] || { 
                error::raise PROTOCOL/OPERATION 'unrelated capture request field';
                return "$SILCAPTUREONE"
            };
        done;
        yaml::requiredMap "$SILMARILYAMLROOT" OBSERVATION eaPolicy || return "$SILCAPTUREONE";
        yaml::assertOnlyKeys "$eaPolicy" IDENTITY || return "$SILCAPTUREONE";
        yaml::requiredScalar "$eaPolicy" IDENTITY eaObservation || return "$SILCAPTUREONE";
        request::capture::digest eaPin || return "$SILCAPTUREONE";
        yaml::requiredScalar "$SILMARILYAMLROOT" RECEIPT eaRef || return "$SILCAPTUREONE";
        path::decode "$eaRef" eaReceipt || return "$SILCAPTUREONE";
        [[ $eaReceipt != "$eaRequest" && ! $eaReceipt -ef $eaRequest && $eaReceipt != "$eaInput" && ! $eaReceipt -ef $eaInput ]] || { 
            error::raise PATH/ROOT 'capture request receipt overlap';
            return "$SILCAPTUREONE"
        };
    else
        for eaNode in OBSERVATION DIGEST RECEIPT;
        do
            [[ ! -n ${yamlKind[$SILMARILYAMLROOT$SILMARILUS"$eaNode"]+present} ]] || { 
                error::raise PROTOCOL/OPERATION 'capture fields on a different operation';
                return "$SILCAPTUREONE"
            };
        done;
    fi;
    for eaNode in OUTPUT CHECKPOINT SNAPSHOT;
    do
        yaml::optionalScalar "$SILMARILYAMLROOT" "$eaNode" eaRef eaFlag || return 1;
        if ((eaFlag)); then
            case $eaNode in 
                OUTPUT)
                    path::decode "$eaRef" eaOutput || return 1
                ;;
                CHECKPOINT)
                    path::decode "$eaRef" eaCheckpoint || return 1
                ;;
                SNAPSHOT)
                    path::decode "$eaRef" eaSnapshot || return 1
                ;;
            esac;
        fi;
    done;
    if [[ -n ${yamlKind[$SILMARILYAMLROOT$SILMARILUS"POLICY"]-} ]]; then
        yaml::requiredMap "$SILMARILYAMLROOT" POLICY eaPolicy && request::policy "$eaPolicy" || return 1;
    fi;
    if [[ -n $eaOutput ]]; then
        [[ $eaOutput != "$eaInput" && $eaOutput != "$eaRequest" && $eaOutput != "$eaCheckpoint" && $eaOutput != "$eaSnapshot" ]] || { 
            error::raise PATH/ROOT 'output overlaps source';
            return 1
        };
        path::requireWritableTarget "$eaOutput" || return 1;
        if ((eaCapture)); then
            [[ $eaOutput != "$eaReceipt" && ! $eaOutput -ef $eaReceipt && ! -e $eaOutput ]] || { 
                error::raise PATH/ROOT 'capture frame publication overlap';
                return "$SILCAPTUREONE"
            };
        fi;
    fi;
    if [[ -n $eaCheckpoint || -n $eaSnapshot ]]; then
        [[ -n $eaCheckpoint && -n $eaSnapshot && $eaCheckpoint != "$eaSnapshot" && $eaCheckpoint != "$eaInput" && $eaSnapshot != "$eaInput" && $eaCheckpoint != "$eaRequest" && $eaSnapshot != "$eaRequest" ]] || { 
            error::raise PATH/ROOT 'checkpoint target overlap';
            return 1
        };
        if [[ $eaOp == "$REQUESTOPERATION":run || $eaOp == "$REQUESTOPERATION":resume ]]; then
            path::requireWritableTarget "$eaCheckpoint" && path::requireWritableTarget "$eaSnapshot" || return 1;
        fi;
    fi;
    if ((eaCapture)); then
        request::capture::perform "$eaInput" "$eaObservation" "$eaPin" "$eaReceipt" "$eaOp" || eaRc=$?;
        eaEffect=$requestCaptureEffect;
    else
        if [[ $eaOp == "$REQUESTOPERATION":certify ]]; then
            finite::certify "$eaInput" || eaRc=$?;
        else
            if [[ $eaOp == "$REQUESTOPERATION":pairs ]]; then
                kv::parse "$eaInput" || eaRc=$?;
            else
                graph::load "$eaInput" && graph::validate || eaRc=$?;
                if ((eaRc==0)); then
                    case $eaOp in 
                        "$REQUESTOPERATION":validate | "$REQUESTOPERATION":order)
                            :
                        ;;
                        "$REQUESTOPERATION":run)
                            scheduler::run || eaRc=$?
                        ;;
                        "$REQUESTOPERATION":resume)
                            [[ -n $eaCheckpoint && -n $eaSnapshot ]] && checkpoint::load "$eaCheckpoint" "$eaSnapshot" && scheduler::run || eaRc=1
                        ;;
                        "$REQUESTOPERATION":status)
                            [[ -n $eaCheckpoint && -n $eaSnapshot ]] && checkpoint::load "$eaCheckpoint" "$eaSnapshot" || eaRc=1
                        ;;
                        *)
                            error::raise PROTOCOL/OPERATION 'unsupported action';
                            eaRc=1
                        ;;
                    esac;
                fi;
            fi;
        fi;
    fi;
    if ((eaRc)); then
        frame::failure "${engineError:-${errorRegistry[PROTOCOL/OPERATION]}}" engineResult || return 1;
    else
        eaNode=$SILMARILTRUE;
        if [[ $eaOp == "$REQUESTOPERATION":run || $eaOp == "$REQUESTOPERATION":resume ]]; then
            if ((${#graphOrder[@]}>0)); then
                eaNode=${nodeOutput[${graphOrder[${#graphOrder[@]}-1]}]:-$SILMARILTRUE};
            fi;
        fi;
        frame::success "$eaNode" "$eaEffect" engineResult || return 1;
    fi;
    if [[ -n $eaCheckpoint && ( $eaOp == "$REQUESTOPERATION":run || $eaOp == "$REQUESTOPERATION":resume ) ]]; then
        [[ -n $eaSnapshot ]] && checkpoint::write "$eaCheckpoint" "$eaSnapshot" || return 1;
    fi;
    if [[ -n $eaOutput ]]; then
        [[ $eaOutput != "$eaInput" && $eaOutput != "$eaRequest" && $eaOutput != "$eaCheckpoint" && $eaOutput != "$eaSnapshot" ]] || { 
            error::raise PATH/ROOT 'output overlaps source';
            return 1
        };
        path::requireWritableTarget "$eaOutput" || return 1;
        publication::frame "$engineResult" "$eaIdentity:occurrence:result" > "$eaOutput" || return 1;
    fi;
    return "$eaRc"
}
