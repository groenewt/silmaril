projection::semanticVerify () 
{ 
    local veFile=$1 veExpected veIndex veKey veLeft=0 veRight=0;
    local -A veSet=();
    path::requireReadable "$veFile" || return 1;
    veExpected=$(kv::turtle) || return 1;
    rdf::reset;
    rdf::content "$veExpected" expected '' || return 1;
    rdf::append "$veFile" observed || return 1;
    for veIndex in "${!rdfSubject[@]}";
    do
        veKey="${rdfSubject[veIndex]},${rdfPredicate[veIndex]},${rdfObject[veIndex]}";
        if [[ ${rdfGraph[veIndex]} == expected ]]; then
            veSet[$veKey]=1;
            ((veLeft+=1));
        fi;
    done;
    for veIndex in "${!rdfSubject[@]}";
    do
        [[ ${rdfGraph[veIndex]} == observed ]] || continue;
        veKey="${rdfSubject[veIndex]},${rdfPredicate[veIndex]},${rdfObject[veIndex]}";
        [[ -n ${veSet[$veKey]+yes} ]] || { 
            error::raise PROJECTION/FIDELITY 'unexpected semantic triple';
            return 1
        };
        ((veRight+=1));
    done;
    ((veLeft==veRight)) || { 
        error::raise PROJECTION/FIDELITY 'missing semantic triples';
        return 1
    }
}
