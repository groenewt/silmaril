kv::capture::emit () 
{ 
    [[ $kvCaptureVerified == "$SILCAPTUREONE" && -n $kvCaptureReceipt ]] || { 
        error::raise PROJECTION/FIDELITY 'no verified capture result';
        return "$SILCAPTUREONE"
    };
    printf '%s' "$kvCaptureReceipt"
}
