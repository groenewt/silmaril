scheduler::clock () 
{ 
    local scOut=$1 scNow=${EPOCHREALTIME};
    scNow=${scNow/./};
    [[ $scNow =~ ^[0-9]{16}$ ]] || return 1;
    printf -v "$scOut" '%s' "$scNow"
}
