wide::schema () 
{ 
    local wsId=$1 wsWidth=$2 wsBit=$3 wsOctet=$4 wsEncoding=$5;
    identity::requireRankedUrn "$wsId" schema || return 1;
    [[ $wsWidth =~ ^[1-9][0-9]{0,2}$ ]] && ((wsWidth<=128)) || { 
        error::raise BYTE/RANGE 'registered byte width must be from one through one hundred twenty eight';
        return 1
    };
    [[ $wsBit == "$WIDEMOST" || $wsBit == "$WIDELEAST" ]] || { 
        error::raise ENCODING/INVALID 'bit order';
        return 1
    };
    [[ $wsOctet == "$WIDEFORWARD" || $wsOctet == "$WIDEREVERSE" ]] || { 
        error::raise ENCODING/INVALID 'octet order';
        return 1
    };
    [[ $wsEncoding == "$WIDERAW" ]] || { 
        error::raise ENCODING/INVALID 'unregistered encoding';
        return 1
    };
    if [[ $wsOctet == "$WIDEREVERSE" ]] && ((wsWidth%8)); then
        error::raise PROJECTION/FIDELITY 'octet permutation requires whole octets';
        return 1;
    fi;
    object::new "$wsId" "$WIDETYPESCHEMA" || return 1;
    wideSchemaWidth[$wsId]=$wsWidth;
    wideSchemaBit[$wsId]=$wsBit;
    wideSchemaOctet[$wsId]=$wsOctet;
    wideSchemaEncoding[$wsId]=$wsEncoding;
    kvKnown[$wsId]=1
}
