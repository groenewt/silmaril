yaml::promote () 
{ 
    local path=$1;
    local requiredKind=$2;
    local presentKind=${yamlKind[$path]-};
    case $presentKind in 
        container)
            yamlKind[$path]=$requiredKind
        ;;
        "$requiredKind")

        ;;
        '')
            engine::raise "$SILMARILERRORYAML" "missing parent $path";
            return "$SILMARILFAILURE"
        ;;
        *)
            engine::raise "$SILMARILERRORYAML" "mixed container kinds at $path";
            return "$SILMARILFAILURE"
        ;;
    esac
}
