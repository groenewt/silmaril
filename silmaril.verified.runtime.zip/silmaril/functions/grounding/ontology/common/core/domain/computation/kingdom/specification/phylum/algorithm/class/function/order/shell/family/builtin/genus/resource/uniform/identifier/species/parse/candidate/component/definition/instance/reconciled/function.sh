uri::parseCandidate () 
{ 
    local upText=$1 upWork upPart upHead upRest;
    local -A up=([SCHEME]='' [AUTHORITY]='' [PATH]='' [QUERY]='' [FRAGMENT]='' [USER]='' [HOST]='' [PORT]='' [SCHEMEPRESENT]=0 [AUTHORITYPRESENT]=0 [QUERYPRESENT]=0 [FRAGMENTPRESENT]=0 [USERPRESENT]=0 [PORTPRESENT]=0);
    local LC_ALL=C;
    ((${#upText}<=addressMaximumBytes)) || return 1;
    upWork=$upText;
    if [[ $upWork == *'#'* ]]; then
        up[FRAGMENTPRESENT]=1;
        up[FRAGMENT]=${upWork#*#};
        upWork=${upWork%%#*};
        uri::component "${up[FRAGMENT]}" query || return 1;
    fi;
    if [[ $upWork == *'?'* ]]; then
        up[QUERYPRESENT]=1;
        up[QUERY]=${upWork#*\?};
        upWork=${upWork%%\?*};
        uri::component "${up[QUERY]}" query || return 1;
    fi;
    if [[ $upWork =~ ^([a-zA-Z][a-zA-Z0-9+.-]*): ]]; then
        up[SCHEME]=${BASH_REMATCH[1]};
        up[SCHEMEPRESENT]=1;
        upWork=${upWork#*:};
    fi;
    if [[ $upWork == //* ]]; then
        up[AUTHORITYPRESENT]=1;
        upWork=${upWork#//};
        up[AUTHORITY]=${upWork%%/*};
        if [[ $upWork == */* ]]; then
            upWork=/${upWork#*/};
        else
            upWork=;
        fi;
        upPart=${up[AUTHORITY]};
        if [[ $upPart == *@* ]]; then
            up[USERPRESENT]=1;
            up[USER]=${upPart%%@*};
            upPart=${upPart#*@};
            [[ $upPart != *@* ]] && uri::component "${up[USER]}" user || return 1;
        fi;
        if [[ $upPart == '['* ]]; then
            [[ $upPart == *']'* ]] || return 1;
            upHead=${upPart%%]*};
            upHead=${upHead#[};
            uri::ipLiteral "$upHead" || return 1;
            up[HOST]=[$upHead];
            upRest=${upPart#*]};
            if [[ -n $upRest ]]; then
                [[ $upRest == :* ]] || return 1;
                up[PORTPRESENT]=1;
                up[PORT]=${upRest#:};
            fi;
        else
            if [[ $upPart == *:* ]]; then
                up[PORTPRESENT]=1;
                up[PORT]=${upPart#*:};
                up[HOST]=${upPart%%:*};
            else
                up[HOST]=$upPart;
            fi;
            uri::component "${up[HOST]}" host || return 1;
        fi;
        [[ ${up[PORT]} =~ ^[0-9]*$ ]] || return 1;
    else
        [[ $upWork != //* ]] || return 1;
        if [[ ${up[SCHEMEPRESENT]} == 0 && $upWork != /* ]]; then
            [[ ${upWork%%/*} != *:* ]] || return 1;
        fi;
    fi;
    up[PATH]=$upWork;
    uri::component "$upWork" path || return 1;
    uri=();
    for upPart in "${!up[@]}";
    do
        uri[$upPart]=${up[$upPart]};
    done;
    return 0
}
