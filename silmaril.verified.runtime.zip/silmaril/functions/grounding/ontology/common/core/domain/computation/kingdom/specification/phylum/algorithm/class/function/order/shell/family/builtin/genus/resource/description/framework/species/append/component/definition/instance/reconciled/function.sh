rdf::append () 
{ 
    local raFile=$1 raGraph=${2:-data} raStatus raText= LC_ALL=C;
    path::requireReadable "$raFile" || return 1;
    if IFS= read -r -d '' -n "$((rdfMaximumBytes+1))" raText < "$raFile"; then
        rdf::error 'NUL or input capacity';
        return 1;
    else
        raStatus=$?;
    fi;
    ((raStatus==1 && ${#raText}<=rdfMaximumBytes)) || { 
        rdf::error 'input failure';
        return 1
    };
    local raBase;
    path::toFileUri "$raFile" raBase || return 1;
    rdf::content "$raText" "$raGraph" "$raBase"
}
