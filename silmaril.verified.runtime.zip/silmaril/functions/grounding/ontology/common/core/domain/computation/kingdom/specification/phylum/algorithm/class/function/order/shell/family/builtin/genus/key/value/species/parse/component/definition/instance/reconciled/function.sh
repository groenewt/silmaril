kv::parse () 
{ 
    kv::capture::reset;
    local txName txKey txStatus=0;
    local -a txNames=(kvKind kvValue kvChildren kvLine kvOffset kvSpan kvPair kvBinding kvSubject kvMap kvPredicate kvRight kvCarrier kvPosition kvProvenance kvKnown kvNumber);
    local -a txPaths=("${kvPaths[@]}");
    local txDocument=$kvDocument txSource=$kvSource txRaw=$kvRaw;
    for txName in "${txNames[@]}";
    do
        local -A "saved${txName}=()";
        local -n txOriginal=$txName txCopy=saved${txName};
        for txKey in "${!txOriginal[@]}";
        do
            txCopy[$txKey]=${txOriginal[$txKey]};
        done;
    done;
    kv::parseCandidate "$@" || txStatus=$?;
    if ((txStatus)); then
        for txName in "${txNames[@]}";
        do
            local -n txOriginal=$txName txCopy=saved${txName};
            txOriginal=();
            for txKey in "${!txCopy[@]}";
            do
                txOriginal[$txKey]=${txCopy[$txKey]};
            done;
        done;
        kvPaths=("${txPaths[@]}");
        kvDocument=$txDocument;
        kvSource=$txSource;
        kvRaw=$txRaw;
        return "$txStatus";
    fi;
    kvKnown[$kvDocument]=1;
    for txName in kvMap kvPair kvBinding kvSubject kvPredicate kvRight kvCarrier kvPosition kvProvenance;
    do
        local -n txOriginal=$txName;
        for txKey in "${!txOriginal[@]}";
        do
            kvKnown[${txOriginal[$txKey]}]=1;
        done;
    done;
    ((kvObservationCounter+=1));
    return 0
}
