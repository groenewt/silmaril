yaml::assertOnlyKeys () 
{ 
    local parent=$1;
    shift;
    local prefix="${parent}${SILMARILUS}";
    local pathValue;
    local remainder;
    local allowed;
    local matched;
    for pathValue in "${yamlPaths[@]}";
    do
        [[ $pathValue == "$prefix"* ]] || continue;
        remainder=${pathValue#"$prefix"};
        [[ $remainder != *"$SILMARILUS"* ]] || continue;
        matched=$SILMARILZERO;
        for allowed in "$@";
        do
            if [[ $remainder == "$allowed" ]]; then
                matched=$SILMARILONE;
                break;
            fi;
        done;
        (( matched == SILMARILONE )) || { 
            engine::raise "$SILMARILERRORYAMLKEY" "$remainder";
            return "$SILMARILFAILURE"
        };
    done
}
