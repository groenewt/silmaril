path::decode () 
{ 
    local pdId=$1 pdOut=$2 pdRest pdDigit pdWord pdI pdJ pdN pdOct pdChar pdResult=;
    [[ $pdId == "$PATHNOTATIONBASE:octet:"* ]] || { 
        error::raise PATH/ROUND/TRIP identity;
        return 1
    };
    pdRest=${pdId#"$PATHNOTATIONBASE"};
    while [[ -n $pdRest ]]; do
        [[ $pdRest == :octet:* ]] || { 
            error::raise PATH/ROUND/TRIP octet;
            return 1
        };
        pdRest=${pdRest#:octet:};
        pdN=0;
        for ((pdI=0; pdI<3; pdI++))
        do
            pdWord=${pdRest%%:*};
            [[ $pdRest == *:* ]] && pdRest=${pdRest#*:} || pdRest=;
            pdDigit=;
            for ((pdJ=0; pdJ<10; pdJ++))
            do
                [[ $pdWord != "${lexicalDigits[$pdJ]}" ]] || { 
                    pdDigit=$pdJ;
                    break
                };
            done;
            [[ -n $pdDigit ]] || { 
                error::raise PATH/ROUND/TRIP digit;
                return 1
            };
            pdN=$((pdN*10+pdDigit));
        done;
        ((pdN>0 && pdN<256)) || { 
            error::raise PATH/ROUND/TRIP range;
            return 1
        };
        printf -v pdOct '\\%03o' "$pdN";
        printf -v pdChar '%b' "$pdOct";
        pdResult+=$pdChar;
        [[ -z $pdRest ]] || pdRest=:$pdRest;
    done;
    path::lexical "$pdResult" || { 
        error::raise PATH/ROUND/TRIP "decoded lexical path";
        return 1
    };
    printf -v "$pdOut" '%s' "$pdResult"
}
