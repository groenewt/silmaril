grounding::records () 
{ 
    grounding::check "$GROUNDINGRECORD" || return 1;
    local grObject;
    for grObject in "${objectOrder[@]}";
    do
        groundingRecord[$grObject]=$GROUNDINGRECORD;
    done
}
