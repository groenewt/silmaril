homology::inverse () 
{ 
    local hvValue=$1 hvPrime=$2 hvOut=$3 hvExponent hvBase hvResult=$SILANALYSISONE;
    hvExponent=$((hvPrime-SILANALYSISTWO));
    hvBase=$hvValue;
    while ((hvExponent)); do
        if ((hvExponent%SILANALYSISTWO)); then
            hvResult=$((hvResult*hvBase%hvPrime));
        fi;
        hvBase=$((hvBase*hvBase%hvPrime));
        hvExponent=$((hvExponent/SILANALYSISTWO));
    done;
    printf -v "$hvOut" '%s' "$hvResult"
}
