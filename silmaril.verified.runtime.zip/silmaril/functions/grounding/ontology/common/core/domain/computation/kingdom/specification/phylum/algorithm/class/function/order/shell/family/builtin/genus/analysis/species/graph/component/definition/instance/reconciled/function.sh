analysis::graph () 
{ 
    analysisVerified=$SILANALYSISZERO;
    analysisAcyclic=$SILANALYSISZERO;
    analysisComponents=$SILANALYSISZERO;
    analysisCycles=$SILANALYSISZERO;
    analysisEuler=$SILANALYSISZERO;
    analysisCriticalEdges=$((-SILANALYSISONE));
    analysisVertexCount=${#graphNodes[@]};
    analysisEdgeCount=$SILANALYSISZERO;
    local agNode agOther agEdge agSource agTarget agFrom agTo agChanged agSelected agProcessed=$SILANALYSISZERO agLongest=$SILANALYSISZERO;
    local -A agIndex=() agComponent=() agDegree=() agDone=() agDepth=();
    for agNode in "${graphNodes[@]}";
    do
        [[ -n $agNode && -z ${agIndex[$agNode]+yes} ]] || { 
            error::raise PROJECTION/FIDELITY 'duplicate or empty vertex';
            return "$SILANALYSISONE"
        };
        agIndex[$agNode]=$SILANALYSISONE;
        agComponent[$agNode]=$agNode;
        agDegree[$agNode]=$SILANALYSISZERO;
        agDepth[$agNode]=$SILANALYSISZERO;
    done;
    for agEdge in "${!graphAdjacency[@]}";
    do
        [[ $agEdge == *"$SILMARILUS"* ]] || return "$SILANALYSISONE";
        agSource=${agEdge%%"$SILMARILUS"*};
        agTarget=${agEdge#*"$SILMARILUS"};
        [[ -n ${agIndex[$agSource]+yes} && -n ${agIndex[$agTarget]+yes} && $agSource != "$agTarget" ]] || { 
            error::raise PROJECTION/FIDELITY 'edge endpoint outside simple graph';
            return "$SILANALYSISONE"
        };
        ((analysisEdgeCount+=SILANALYSISONE));
        ((agDegree[$agTarget]+=SILANALYSISONE));
        agFrom=${agComponent[$agSource]};
        agTo=${agComponent[$agTarget]};
        if [[ $agFrom != "$agTo" ]]; then
            for agNode in "${graphNodes[@]}";
            do
                [[ ${agComponent[$agNode]} != "$agTo" ]] || agComponent[$agNode]=$agFrom;
            done;
        fi;
    done;
    for agNode in "${graphNodes[@]}";
    do
        [[ ${agComponent[$agNode]} != "$agNode" ]] || ((analysisComponents+=SILANALYSISONE));
    done;
    analysisCycles=$((analysisEdgeCount-analysisVertexCount+analysisComponents));
    analysisEuler=$((analysisVertexCount-analysisEdgeCount));
    while ((agProcessed<analysisVertexCount)); do
        agSelected=;
        for agNode in "${graphNodes[@]}";
        do
            if [[ -z ${agDone[$agNode]+yes} ]] && ((agDegree[$agNode]==SILANALYSISZERO)); then
                agSelected=$agNode;
                break;
            fi;
        done;
        [[ -n $agSelected ]] || break;
        agDone[$agSelected]=$SILANALYSISONE;
        ((agProcessed+=SILANALYSISONE));
        ((agLongest>=agDepth[$agSelected])) || agLongest=${agDepth[$agSelected]};
        for agOther in "${graphNodes[@]}";
        do
            [[ -n ${graphAdjacency[$agSelected$SILMARILUS$agOther]+yes} ]] || continue;
            agDegree[$agOther]=$((agDegree[$agOther]-SILANALYSISONE));
            if ((agDepth[$agOther]<agDepth[$agSelected]+SILANALYSISONE)); then
                agDepth[$agOther]=$((agDepth[$agSelected]+SILANALYSISONE));
            fi;
        done;
    done;
    if ((agProcessed==analysisVertexCount)); then
        analysisAcyclic=$SILANALYSISONE;
        analysisCriticalEdges=$agLongest;
    fi;
    analysisVerified=$SILANALYSISONE
}
