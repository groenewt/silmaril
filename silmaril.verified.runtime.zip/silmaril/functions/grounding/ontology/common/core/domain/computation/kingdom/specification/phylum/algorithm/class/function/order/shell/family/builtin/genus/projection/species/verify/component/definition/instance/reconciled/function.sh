projection::verify () 
{ 
    local pvFile=$1 pvFd pvExpected pvActual pvBad=0 pvPid;
    path::requireReadable "$pvFile" || return 1;
    exec {pvFd}< <(kv::turtle);
    pvPid=$!;
    while IFS= read -r pvExpected <&"$pvFd"; do
        if ! IFS= read -r pvActual; then
            pvBad=1;
            break;
        fi;
        [[ $pvExpected == "$pvActual" ]] || { 
            pvBad=1;
            break
        };
    done < "$pvFile";
    exec {pvFd}>&-;
    if ((pvBad)); then
        scheduler::stop "$pvPid";
        error::raise PROJECTION/FIDELITY 'projection differs';
        return 1;
    fi;
    wait "$pvPid" || return 1;
    local pvRaw= pvOut= pvRc=0;
    IFS= read -r -d '' pvRaw < "$pvFile" || pvRc=$?;
    pvOut=$(kv::turtle);
    pvOut+='
';
    [[ $pvRc == 1 && $pvRaw == "$pvOut" ]] || { 
        error::raise PROJECTION/FIDELITY 'projection extent';
        return 1
    }
}
