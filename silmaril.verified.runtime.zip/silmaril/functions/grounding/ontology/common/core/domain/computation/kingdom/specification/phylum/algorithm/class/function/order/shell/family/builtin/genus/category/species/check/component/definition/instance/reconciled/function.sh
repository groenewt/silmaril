category::check () 
{ 
    local ccO ccF ccG ccH ccC ccD ccE ccL ccR ccK ccExpected=0;
    ((${#categoryObjects[@]}<=finiteMaximumObjects && ${#categoryArrows[@]}<=finiteMaximumArrows)) || { 
        error::raise PAIR/LIMIT category;
        return 1
    };
    for ccO in "${categoryObjects[@]}";
    do
        ccF=${categoryIdentity[$ccO]-};
        [[ -n $ccF && ${categorySource[$ccF]-} == "$ccO" && ${categoryTarget[$ccF]-} == "$ccO" ]] || { 
            error::raise CATEGORY/IDENTITY "$ccO";
            return 1
        };
        ((finiteChecks+=1));
    done;
    ((${#categoryIdentity[@]}==${#categoryObjects[@]})) || { 
        error::raise CATEGORY/IDENTITY surplus;
        return 1
    };
    for ccF in "${categoryArrows[@]}";
    do
        ccC=${categorySource[$ccF]-};
        ccD=${categoryTarget[$ccF]-};
        finite::contains "${categoryObjects[*]}" "$ccC" && finite::contains "${categoryObjects[*]}" "$ccD" || { 
            error::raise CATEGORY/COMPOSITION endpoints;
            return 1
        };
        ccL=${categoryIdentity[$ccC]};
        ccR=${categoryIdentity[$ccD]};
        [[ ${categoryComposite[$ccF$SILMARILUS$ccL]-} == "$ccF" && ${categoryComposite[$ccR$SILMARILUS$ccF]-} == "$ccF" ]] || { 
            error::raise CATEGORY/IDENTITY units;
            return 1
        };
        ((finiteChecks+=2));
        for ccG in "${categoryArrows[@]}";
        do
            ccK=$ccG$SILMARILUS$ccF;
            if [[ ${categorySource[$ccG]} == "$ccD" ]]; then
                ((ccExpected+=1));
                ccH=${categoryComposite[$ccK]-};
                [[ -n $ccH && ${categorySource[$ccH]-} == "$ccC" && ${categoryTarget[$ccH]-} == "${categoryTarget[$ccG]}" ]] || { 
                    error::raise CATEGORY/COMPOSITION "$ccK";
                    return 1
                };
                ((finiteChecks+=1));
            else
                if [[ -n ${categoryComposite[$ccK]-} ]]; then
                    error::raise CATEGORY/COMPOSITION noncomposable;
                    return 1;
                fi;
            fi;
        done;
    done;
    ((${#categoryComposite[@]}==ccExpected)) || { 
        error::raise CATEGORY/COMPOSITION surplus;
        return 1
    };
    for ccF in "${categoryArrows[@]}";
    do
        for ccG in "${categoryArrows[@]}";
        do
            [[ ${categoryTarget[$ccF]} == "${categorySource[$ccG]}" ]] || continue;
            for ccH in "${categoryArrows[@]}";
            do
                [[ ${categoryTarget[$ccG]} == "${categorySource[$ccH]}" ]] || continue;
                ccL=${categoryComposite[$ccG$SILMARILUS$ccF]};
                ccR=${categoryComposite[$ccH$SILMARILUS$ccG]};
                [[ ${categoryComposite[$ccH$SILMARILUS$ccL]-} == "${categoryComposite[$ccR$SILMARILUS$ccF]-}" ]] || { 
                    error::raise CATEGORY/ASSOCIATIVITY "$ccF $ccG $ccH";
                    return 1
                };
                ((finiteChecks+=1));
            done;
        done;
    done;
    for ccE in "${equationNames[@]}";
    do
        category::path "${equationSource[$ccE]}" "${equationLeft[$ccE]}" ccL || return 1;
        category::path "${equationSource[$ccE]}" "${equationRight[$ccE]}" ccR || return 1;
        [[ $ccL == "$ccR" ]] || { 
            error::raise CATEGORY/EQUATION "$ccE";
            return 1
        };
        ((finiteChecks+=1));
    done;
    return 0
}
