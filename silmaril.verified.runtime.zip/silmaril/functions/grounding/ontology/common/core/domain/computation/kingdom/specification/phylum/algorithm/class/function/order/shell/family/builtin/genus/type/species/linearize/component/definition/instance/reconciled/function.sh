type::linearize () 
{ 
    local identity=$1;
    [[ -z ${typeMro[$identity]-} ]] || return "$SILMARILZERO";
    [[ ${typeVisiting[$identity]-} != "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERRORTYPEC3" "$identity";
        return "$SILMARILFAILURE"
    };
    typeVisiting[$identity]=$SILMARILONE;
    local parentCount=${typeParentCount[$identity]:-$SILMARILZERO};
    local -a sequences=();
    local parentSequence=;
    local parentIdentity;
    local index;
    for ((index = SILMARILZERO; index < parentCount; index += SILMARILONE ))
    do
        parentIdentity=${typeParent[${identity}${SILMARILUS}${index}]};
        type::linearize "$parentIdentity" || { 
            unset 'typeVisiting[$identity]';
            return "$SILMARILFAILURE"
        };
        sequences+=("${typeMro[$parentIdentity]}");
        [[ -z $parentSequence ]] || parentSequence+=$SILMARILUS;
        parentSequence+=$parentIdentity;
    done;
    [[ -z $parentSequence ]] || sequences+=("$parentSequence");
    local merged=$identity;
    local any;
    local candidate;
    local candidateHead;
    local candidateGood;
    local sequence;
    local otherSequence;
    local otherTail;
    local sequenceIndex;
    local otherIndex;
    while :; do
        any=$SILMARILZERO;
        for sequence in "${sequences[@]}";
        do
            [[ -z $sequence ]] || { 
                any=$SILMARILONE;
                break
            };
        done;
        (( any == SILMARILONE )) || break;
        candidate=;
        for ((sequenceIndex = SILMARILZERO; sequenceIndex < ${#sequences[@]}; sequenceIndex += SILMARILONE ))
        do
            sequence=${sequences[$sequenceIndex]};
            [[ -n $sequence ]] || continue;
            type::sequenceHead "$sequence" candidateHead;
            candidateGood=$SILMARILONE;
            for ((otherIndex = SILMARILZERO; otherIndex < ${#sequences[@]}; otherIndex += SILMARILONE ))
            do
                otherSequence=${sequences[$otherIndex]};
                [[ -n $otherSequence ]] || continue;
                type::sequenceTail "$otherSequence" otherTail;
                if [[ -n $otherTail ]] && type::sequenceContains "$otherTail" "$candidateHead"; then
                    candidateGood=$SILMARILZERO;
                    break;
                fi;
            done;
            if (( candidateGood == SILMARILONE )); then
                candidate=$candidateHead;
                break;
            fi;
        done;
        [[ -n $candidate ]] || { 
            unset 'typeVisiting[$identity]';
            engine::raise "$SILMARILERRORTYPEC3" "$identity";
            return "$SILMARILFAILURE"
        };
        merged+="${SILMARILUS}${candidate}";
        for ((sequenceIndex = SILMARILZERO; sequenceIndex < ${#sequences[@]}; sequenceIndex += SILMARILONE ))
        do
            sequence=${sequences[$sequenceIndex]};
            [[ -n $sequence ]] || continue;
            type::sequenceHead "$sequence" candidateHead;
            if [[ $candidateHead == "$candidate" ]]; then
                type::sequenceTail "$sequence" sequences[$sequenceIndex];
            fi;
        done;
    done;
    typeMro[$identity]=$merged;
    unset 'typeVisiting[$identity]'
}
