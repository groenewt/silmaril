shape::number () 
{ 
    local snTerm=$1 snValue=${rdfTerm[$1]};
    [[ ${rdfKind[snTerm]} == literal && ${rdfDatatype[snTerm]} == "${XSDNS}integer" && $snValue =~ ^\+?[0-9]{1,9}$ ]] || { 
        shape::error 'count must be a bounded nonnegative xsd:integer';
        return 2
    };
    snValue=${snValue#+};
    shapeNumber=$((10#$snValue));
    return 0
}
