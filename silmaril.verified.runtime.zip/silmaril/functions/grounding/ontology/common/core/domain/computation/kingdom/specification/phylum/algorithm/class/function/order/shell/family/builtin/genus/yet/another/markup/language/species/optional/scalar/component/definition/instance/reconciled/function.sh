yaml::optionalScalar () 
{ 
    local parent=$1;
    local key=$2;
    local outputName=$3;
    local presentName=$4;
    local -n outputReference=$outputName;
    local -n presentReference=$presentName;
    local pathValue;
    yaml::join pathValue "$parent" "$key";
    if [[ ${yamlKind[$pathValue]-} == scalar ]]; then
        outputReference=${yamlValue[$pathValue]};
        presentReference=$SILMARILONE;
        return "$SILMARILZERO";
    fi;
    if [[ ! -n ${yamlKind[$pathValue]+present} ]]; then
        outputReference=;
        presentReference=$SILMARILZERO;
        return "$SILMARILZERO";
    fi;
    engine::raise "$SILMARILERRORYAML" "optional scalar has non scalar kind $key"
}
