finite::load () 
{ 
    local ffFile=$1 ffCat ffPath ffN ffI ffItem ffId ffS ffT ffF ffG ffH ffV ffP ffL ffJ ffCell ffModel ffK ffQ ffR;
    finite::reset;
    yaml::parse "$ffFile" || return 1;
    finiteDocument=$kvDocument;
    yaml::assertOnlyKeys ROOT IDENTITY CATEGORY MODELS NATURAL || return 1;
    yaml::requiredMap ROOT CATEGORY ffCat || return 1;
    yaml::assertOnlyKeys "$ffCat" IDENTITY OBJECTS MORPHISMS IDENTITIES COMPOSITION EQUATIONS || return 1;
    yaml::requiredScalar "$ffCat" IDENTITY categoryName || return 1;
    yaml::requiredSequence "$ffCat" OBJECTS ffPath ffN || return 1;
    ((ffN<=finiteMaximumObjects)) || { 
        error::raise PAIR/LIMIT objects;
        return 1
    };
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" IDENTITY || return 1;
        yaml::requiredScalar "$ffItem" IDENTITY ffId || return 1;
        finite::contains "${categoryObjects[*]}" "$ffId" && { 
            error::raise PAIR/DUPLICATE "$ffId";
            return 1
        };
        categoryObjects+=("$ffId");
    done;
    yaml::requiredSequence "$ffCat" MORPHISMS ffPath ffN || return 1;
    ((ffN<=finiteMaximumArrows)) || { 
        error::raise PAIR/LIMIT morphisms;
        return 1
    };
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" IDENTITY SOURCE TARGET || return 1;
        yaml::requiredScalar "$ffItem" IDENTITY ffId || return 1;
        yaml::requiredScalar "$ffItem" SOURCE ffS || return 1;
        yaml::requiredScalar "$ffItem" TARGET ffT || return 1;
        [[ ! -n ${categorySource[$ffId]+present} ]] || { 
            error::raise PAIR/DUPLICATE "$ffId";
            return 1
        };
        categoryArrows+=("$ffId");
        categorySource[$ffId]=$ffS;
        categoryTarget[$ffId]=$ffT;
    done;
    yaml::requiredSequence "$ffCat" IDENTITIES ffPath ffN || return 1;
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" OBJECT ARROW || return 1;
        yaml::requiredScalar "$ffItem" OBJECT ffS || return 1;
        yaml::requiredScalar "$ffItem" ARROW ffF || return 1;
        [[ ! -n ${categoryIdentity[$ffS]+present} ]] || { 
            error::raise PAIR/DUPLICATE identity;
            return 1
        };
        categoryIdentity[$ffS]=$ffF;
    done;
    yaml::requiredSequence "$ffCat" COMPOSITION ffPath ffN || return 1;
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" FIRST SECOND RESULT || return 1;
        yaml::requiredScalar "$ffItem" FIRST ffF || return 1;
        yaml::requiredScalar "$ffItem" SECOND ffG || return 1;
        yaml::requiredScalar "$ffItem" RESULT ffH || return 1;
        [[ ! -n ${categoryComposite[$ffG$SILMARILUS$ffF]+present} ]] || { 
            error::raise PAIR/DUPLICATE composition;
            return 1
        };
        categoryComposite[$ffG$SILMARILUS$ffF]=$ffH;
    done;
    yaml::requiredSequence "$ffCat" EQUATIONS ffPath ffN || return 1;
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" IDENTITY SOURCE LEFT RIGHT || return 1;
        yaml::requiredScalar "$ffItem" IDENTITY ffId || return 1;
        [[ ! -n ${equationSource[$ffId]+present} ]] || { 
            error::raise PAIR/DUPLICATE equation;
            return 1
        };
        equationNames+=("$ffId");
        yaml::requiredScalar "$ffItem" SOURCE ffS || return 1;
        equationSource[$ffId]=$ffS;
        finite::list "$ffItem" LEFT ffV || return 1;
        equationLeft[$ffId]=$ffV;
        finite::list "$ffItem" RIGHT ffV || return 1;
        equationRight[$ffId]=$ffV;
    done;
    yaml::requiredSequence ROOT MODELS ffPath ffN || return 1;
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" IDENTITY CARRIERS ACTIONS || return 1;
        yaml::requiredScalar "$ffItem" IDENTITY ffModel || return 1;
        finite::contains "${modelNames[*]}" "$ffModel" && { 
            error::raise PAIR/DUPLICATE model;
            return 1
        };
        modelNames+=("$ffModel");
        yaml::requiredSequence "$ffItem" CARRIERS ffP ffL || return 1;
        for ((ffJ=0; ffJ<ffL; ffJ++))
        do
            yaml::sequenceMap "$ffP" "$ffJ" ffCell || return 1;
            yaml::assertOnlyKeys "$ffCell" OBJECT ELEMENTS || return 1;
            yaml::requiredScalar "$ffCell" OBJECT ffS || return 1;
            [[ ! -n ${modelElements[$ffModel$SILMARILUS$ffS]+present} ]] || { 
                error::raise PAIR/DUPLICATE carrier;
                return 1
            };
            yaml::requiredSequence "$ffCell" ELEMENTS ffQ ffR || return 1;
            ((ffR<=finiteMaximumElements)) || { 
                error::raise PAIR/LIMIT elements;
                return 1
            };
            ffV=;
            for ((ffK=0; ffK<ffR; ffK++))
            do
                yaml::sequenceMap "$ffQ" "$ffK" ffCell || return 1;
                yaml::assertOnlyKeys "$ffCell" IDENTITY || return 1;
                yaml::requiredScalar "$ffCell" IDENTITY ffId || return 1;
                finite::contains "$ffV" "$ffId" && { 
                    error::raise PAIR/DUPLICATE element;
                    return 1
                };
                ffV+="$ffId ";
            done;
            modelElements[$ffModel$SILMARILUS$ffS]=$ffV;
        done;
        yaml::requiredSequence "$ffItem" ACTIONS ffP ffL || return 1;
        for ((ffJ=0; ffJ<ffL; ffJ++))
        do
            yaml::sequenceMap "$ffP" "$ffJ" ffCell || return 1;
            yaml::assertOnlyKeys "$ffCell" ARROW INPUT OUTPUT || return 1;
            yaml::requiredScalar "$ffCell" ARROW ffF || return 1;
            yaml::requiredScalar "$ffCell" INPUT ffS || return 1;
            yaml::requiredScalar "$ffCell" OUTPUT ffT || return 1;
            [[ ! -n ${modelAction[$ffModel$SILMARILUS$ffF$SILMARILUS$ffS]+present} ]] || { 
                error::raise PAIR/DUPLICATE action;
                return 1
            };
            modelAction[$ffModel$SILMARILUS$ffF$SILMARILUS$ffS]=$ffT;
        done;
    done;
    yaml::requiredSequence ROOT NATURAL ffPath ffN || return 1;
    for ((ffI=0; ffI<ffN; ffI++))
    do
        yaml::sequenceMap "$ffPath" "$ffI" ffItem || return 1;
        yaml::assertOnlyKeys "$ffItem" IDENTITY SOURCE TARGET COMPONENTS || return 1;
        yaml::requiredScalar "$ffItem" IDENTITY ffId || return 1;
        [[ ! -n ${naturalSource[$ffId]+present} ]] || { 
            error::raise PAIR/DUPLICATE natural;
            return 1
        };
        naturalNames+=("$ffId");
        yaml::requiredScalar "$ffItem" SOURCE ffS || return 1;
        naturalSource[$ffId]=$ffS;
        yaml::requiredScalar "$ffItem" TARGET ffT || return 1;
        naturalTarget[$ffId]=$ffT;
        yaml::requiredSequence "$ffItem" COMPONENTS ffP ffL || return 1;
        for ((ffJ=0; ffJ<ffL; ffJ++))
        do
            yaml::sequenceMap "$ffP" "$ffJ" ffCell || return 1;
            yaml::assertOnlyKeys "$ffCell" OBJECT INPUT OUTPUT || return 1;
            yaml::requiredScalar "$ffCell" OBJECT ffF || return 1;
            yaml::requiredScalar "$ffCell" INPUT ffS || return 1;
            yaml::requiredScalar "$ffCell" OUTPUT ffT || return 1;
            [[ ! -n ${naturalComponent[$ffId$SILMARILUS$ffF$SILMARILUS$ffS]+present} ]] || { 
                error::raise PAIR/DUPLICATE component;
                return 1
            };
            naturalComponent[$ffId$SILMARILUS$ffF$SILMARILUS$ffS]=$ffT;
        done;
    done
}
