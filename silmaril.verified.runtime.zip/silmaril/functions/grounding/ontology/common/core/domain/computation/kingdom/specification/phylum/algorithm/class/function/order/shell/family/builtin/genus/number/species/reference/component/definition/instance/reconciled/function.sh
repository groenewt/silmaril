number::reference () 
{ 
    local nrValue=$1 nrOut=$2 nrWords nrRef;
    name::number "$nrValue" nrWords || return 1;
    nrRef="${SILMARILROOT}:grounding:ontology:basic:formal:domain:knowledge:representation:kingdom:specification:phylum:formal:contract:class:value:order:declared:family:seed:genus:registry:species:natural:component:decimal:instance:${nrWords}";
    kvNumber[$nrRef]=$nrValue;
    kvKnown[$nrRef]=1;
    printf -v "$nrOut" '%s' "$nrRef"
}
