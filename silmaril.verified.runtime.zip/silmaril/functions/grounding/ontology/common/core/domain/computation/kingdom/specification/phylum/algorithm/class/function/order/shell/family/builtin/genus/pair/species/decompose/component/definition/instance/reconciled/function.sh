pair::decompose () 
{ 
    local pdName=$1 pdTail pdLength pdDigits pdDigit pdCount pdI pdPart pdTerm pdWhich;
    local -a pdTerms=();
    pairKeyResult=;
    pairValueResult=;
    [[ $pdName == "$PAIRPRODUCTBASE:component:product:instance:"* ]] || return 1;
    pdTail=${pdName#"$PAIRPRODUCTBASE:component:product:instance"};
    for pdWhich in key value;
    do
        [[ $pdTail == :extent:*:content:* ]] || return 1;
        pdTail=${pdTail#:extent:};
        pdLength=${pdTail%%:content:*};
        pdTail=${pdTail#*:content:};
        pdDigits=;
        while [[ -n $pdLength ]]; do
            pdDigit=${pdLength%%:*};
            [[ $pdLength == *:* ]] && pdLength=${pdLength#*:} || pdLength=;
            case $pdDigit in 
                zero)
                    pdDigits+=0
                ;;
                one)
                    pdDigits+=1
                ;;
                two)
                    pdDigits+=2
                ;;
                three)
                    pdDigits+=3
                ;;
                four)
                    pdDigits+=4
                ;;
                five)
                    pdDigits+=5
                ;;
                six)
                    pdDigits+=6
                ;;
                seven)
                    pdDigits+=7
                ;;
                eight)
                    pdDigits+=8
                ;;
                nine)
                    pdDigits+=9
                ;;
                *)
                    return 1
                ;;
            esac;
        done;
        [[ $pdDigits =~ ^[1-9][0-9]{0,4}$ ]] || return 1;
        pdCount=$((10#$pdDigits));
        pdTerm=$SILMARILROOT;
        for ((pdI=0; pdI<pdCount; pdI++))
        do
            [[ -n $pdTail ]] || return 1;
            pdPart=${pdTail%%:*};
            [[ $pdPart =~ ^[a-z][a-z0-9]*$ ]] || return 1;
            pdTerm+=:$pdPart;
            if [[ $pdTail == *:* ]]; then
                pdTail=${pdTail#*:};
            else
                pdTail=;
            fi;
        done;
        pdTerms+=("$pdTerm");
        if [[ $pdWhich == key ]]; then
            pdTail=:$pdTail;
        fi;
    done;
    [[ -z $pdTail ]] || return 1;
    pairKeyResult=${pdTerms[0]};
    pairValueResult=${pdTerms[1]}
}
