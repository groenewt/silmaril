request::write () 
{ 
    [[ $# == 3 || $# == 4 ]] || { 
        error::raise PROTOCOL/OPERATION 'request constructor arity';
        return 1
    };
    local rwOperation=$1 rwInput=$2 rwRequest=$3 rwOutput=${4-} rwInputRef rwOutputRef;
    case $rwOperation in 
        validate | order | run | certify | pairs)
            :
        ;;
        *)
            error::raise PROTOCOL/OPERATION 'constructor operation';
            return 1
        ;;
    esac;
    path::requireReadable "$rwInput" && path::requireWritableTarget "$rwRequest" || return 1;
    [[ $rwInput != "$rwRequest" && $rwOutput != "$rwInput" && $rwOutput != "$rwRequest" ]] || { 
        error::raise PATH/ROOT 'constructor overlap';
        return 1
    };
    path::identify "$rwInput" rwInputRef || return 1;
    if [[ -n $rwOutput ]]; then
        path::requireWritableTarget "$rwOutput" && path::identify "$rwOutput" rwOutputRef || return 1;
    fi;
    { 
        printf 'IDENTITY: %s\nTYPE: %s\nOPERATION: %s\nINPUT: %s\n' "$REQUESTTYPE:component:request:instance:$rwOperation" "$REQUESTTYPE" "$REQUESTOPERATION:$rwOperation" "$rwInputRef";
        if [[ -n $rwOutput ]]; then
            printf 'OUTPUT: %s\n' "$rwOutputRef";
        fi
    } > "$rwRequest"
}
