algebra::group () 
{ 
    category::check || return 1;
    ((${#categoryObjects[@]}==1)) || { 
        error::raise CATEGORY/COMPOSITION 'group requires one object';
        return 1
    };
    local agObject=${categoryObjects[0]} agA agB agFound agUnit;
    agUnit=${categoryIdentity[$agObject]};
    for agA in "${categoryArrows[@]}";
    do
        agFound=0;
        for agB in "${categoryArrows[@]}";
        do
            if [[ ${categoryComposite[$agA$SILMARILUS$agB]} == "$agUnit" && ${categoryComposite[$agB$SILMARILUS$agA]} == "$agUnit" ]]; then
                agFound=1;
                break;
            fi;
        done;
        ((agFound)) || { 
            error::raise CATEGORY/COMPOSITION 'noninvertible group element';
            return 1
        };
    done
}
