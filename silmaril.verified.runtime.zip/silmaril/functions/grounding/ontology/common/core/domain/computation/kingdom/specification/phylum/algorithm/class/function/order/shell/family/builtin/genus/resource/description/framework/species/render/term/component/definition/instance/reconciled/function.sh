rdf::renderTerm () 
{ 
    local reTerm=$1 reOut=$2 reText reResult reChar reIndex reCode LC_ALL=C;
    [[ $reTerm =~ ^(0|[1-9][0-9]*)$ && -n ${rdfKind[reTerm]+yes} ]] || { 
        rdf::error 'unknown term for rendering';
        return 1
    };
    case ${rdfKind[reTerm]} in 
        iri)
            reText=${rdfTerm[reTerm]};
            reResult='<';
            for ((reIndex=0; reIndex<${#reText}; reIndex+=1))
            do
                reChar=${reText:reIndex:1};
                printf -v reCode '%d' "'$reChar";
                if ((reCode<33 || reCode==127)) || [[ $reChar == [\<\>\"\{\}\|\^\`\\] ]]; then
                    printf -v reChar '\\u%04X' "$reCode";
                fi;
                reResult+=$reChar;
            done;
            reResult+='>'
        ;;
        blank)
            reResult="_:${rdfTerm[reTerm]}"
        ;;
        literal)
            reResult="\"${rdfLexical[reTerm]}\"";
            if [[ -n ${rdfLanguage[reTerm]} ]]; then
                reResult+="@${rdfLanguage[reTerm]}";
            else
                reResult+="^^<${rdfDatatype[reTerm]}>";
            fi
        ;;
        *)
            rdf::error 'unknown RDF term species';
            return 1
        ;;
    esac;
    printf -v "$reOut" '%s' "$reResult"
}
