string::stripComment () 
{ 
    local input=${1-};
    local outputName=$2;
    local -n outputReference=$outputName;
    local output=;
    local quote=;
    local escaped=$SILMARILZERO;
    local previous=;
    local index;
    local character;
    for ((index = SILMARILZERO; index < ${#input}; index += SILMARILONE ))
    do
        character=${input:index:SILMARILONE};
        if [[ $quote == double ]]; then
            if (( escaped == SILMARILONE )); then
                escaped=$SILMARILZERO;
            else
                if [[ $character == '\' ]]; then
                    escaped=$SILMARILONE;
                else
                    if [[ $character == '"' ]]; then
                        quote=;
                    fi;
                fi;
            fi;
            output+=$character;
            previous=$character;
            continue;
        fi;
        if [[ $quote == single ]]; then
            [[ $character == "'" ]] && quote=;
            output+=$character;
            previous=$character;
            continue;
        fi;
        if [[ $character == '"' ]]; then
            quote=double;
            output+=$character;
            previous=$character;
            continue;
        fi;
        if [[ $character == "'" ]]; then
            quote=single;
            output+=$character;
            previous=$character;
            continue;
        fi;
        if [[ $character == '#' && ( $index -eq $SILMARILZERO || $previous == [[:space:]] ) ]]; then
            break;
        fi;
        output+=$character;
        previous=$character;
    done;
    [[ -z $quote ]] || { 
        engine::raise "$SILMARILERRORYAMLSCALAR" 'unterminated quoted scalar';
        return "$SILMARILFAILURE"
    };
    outputReference=$output
}
