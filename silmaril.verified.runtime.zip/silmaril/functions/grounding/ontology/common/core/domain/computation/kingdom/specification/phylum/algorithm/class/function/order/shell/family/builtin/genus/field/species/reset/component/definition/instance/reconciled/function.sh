field::reset () 
{ 
    fieldDefined=();
    fieldOwner=();
    fieldValueType=();
    fieldCardinality=()
}
