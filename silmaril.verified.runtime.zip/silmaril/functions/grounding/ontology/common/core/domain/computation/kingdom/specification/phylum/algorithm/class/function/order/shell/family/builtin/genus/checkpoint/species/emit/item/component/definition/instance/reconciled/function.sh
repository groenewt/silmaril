checkpoint::emitItem () 
{ 
    local ceNode=${graphNodes[$1]} ceIndent=$2 ceAttempt ceOutput ceState;
    printf '%*sITEM:\n' "$ceIndent" '';
    ((ceIndent+=2));
    number::reference "${schedulerAttempts[$ceNode]:-0}" ceAttempt;
    ceOutput=${nodeOutput[$ceNode]:-$SILMARILVALUENONE};
    publication::state "${schedulerState[$ceNode]:-pending}" ceState;
    printf '%*sIDENTITY: %s\n%*sSTATE: %s\n%*sATTEMPT: %s\n%*sOUTPUT: %s\n' "$ceIndent" '' "$ceNode" "$ceIndent" '' "$ceState" "$ceIndent" '' "$ceAttempt" "$ceIndent" '' "$ceOutput"
}
