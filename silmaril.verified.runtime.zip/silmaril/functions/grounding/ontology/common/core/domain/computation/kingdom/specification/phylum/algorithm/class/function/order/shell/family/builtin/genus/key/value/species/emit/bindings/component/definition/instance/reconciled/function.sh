kv::emitBindings () 
{ 
    printf 'IDENTITY: %s\nDOCUMENT: %s\nBINDING:\n' "${kvDocument}:occurrence:pair:account" "$kvDocument";
    publication::vector "${#kvPaths[@]}" 2 kv::emitBindingItem
}
