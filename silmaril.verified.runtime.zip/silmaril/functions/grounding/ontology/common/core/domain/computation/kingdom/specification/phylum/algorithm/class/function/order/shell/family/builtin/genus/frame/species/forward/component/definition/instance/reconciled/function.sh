frame::forward () 
{ 
    local identity=$1;
    local outputName=$2;
    local -n outputReference=$outputName;
    outputReference=$identity
}
