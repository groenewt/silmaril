kv::project () 
{ 
    local kjSource=$1 kjTarget=$2 kjKey kjChild kjGroup kjPattern kjTo kjI kjN kjCount kjWord kjMember kjActual;
    if [[ ${kvKind[$kjSource]-} == scalar ]]; then
        [[ ! -n ${yamlKind[$kjTarget]+present} ]] || { 
            error::raise PROJECTION/FIDELITY "collision $kjSource";
            return 1
        };
        yamlKind[$kjTarget]=scalar;
        yamlValue[$kjTarget]=${kvValue[$kjSource]};
        yamlPaths+=("$kjTarget");
        return 0;
    fi;
    if [[ ${kvValue[$kjSource/VECTOR]-} == "$KVTYPEVECTOR" ]]; then
        [[ ${kvChildren[$kjSource]-} == 'VECTOR COUNT MEMBER ' ]] || { 
            error::raise VECTOR/CARDINALITY "$kjSource keys";
            return 1
        };
        kjCount=${kvValue[$kjSource/COUNT]-};
        kjN=${kvNumber[$kjCount]-};
        [[ -n $kjN ]] || { 
            error::raise VECTOR/CARDINALITY "$kjSource count";
            return 1
        };
        yamlKind[$kjTarget]=sequence;
        yamlLength[$kjTarget]=$kjN;
        yamlPaths+=("$kjTarget");
        if ((kjN==0)); then
            [[ ${kvValue[$kjSource/MEMBER]-} == "$KVEMPTYVECTOR" ]] || { 
                error::raise VECTOR/CARDINALITY "$kjSource empty";
                return 1
            };
        else
            for ((kjI=0; kjI<kjN; kjI++))
            do
                name::number "$kjI" kjWord;
                kjWord=${kjWord^^};
                kjWord=${kjWord//:/\/};
                kjMember=$kjSource/MEMBER/$kjWord/ITEM;
                [[ -n ${kvKind[$kjMember]-} ]] || { 
                    error::raise VECTOR/CARDINALITY "$kjMember missing";
                    return 1
                };
                kv::project "$kjMember" "${kjTarget}${SILMARILUS}item${kjI}" || return 1;
            done;
            kjActual=0;
            local -a kjPending=("$kjSource/MEMBER");
            local kjHead=0 kjBranch kjDigit;
            while ((kjHead<${#kjPending[@]})); do
                kjBranch=${kjPending[kjHead]};
                ((kjHead+=1));
                [[ ${kvKind[$kjBranch]-} == map ]] || { 
                    error::raise VECTOR/CARDINALITY "$kjBranch mapping";
                    return 1
                };
                for kjDigit in ${kvChildren[$kjBranch]-};
                do
                    case $kjDigit in 
                        ITEM)
                            [[ $kjBranch != "$kjSource/MEMBER" ]] || { 
                                error::raise VECTOR/CARDINALITY "$kjBranch ordinal";
                                return 1
                            };
                            ((kjActual+=1))
                        ;;
                        ZERO | ONE | TWO | THREE | FOUR | FIVE | SIX | SEVEN | EIGHT | NINE)
                            kjPending+=("$kjBranch/$kjDigit")
                        ;;
                        *)
                            error::raise VECTOR/CARDINALITY "$kjBranch/$kjDigit nonordinal member";
                            return 1
                        ;;
                    esac;
                done;
            done;
            ((kjActual==kjN)) || { 
                error::raise VECTOR/CARDINALITY "$kjSource extras";
                return 1
            };
        fi;
        return 0;
    fi;
    yamlKind[$kjTarget]=map;
    yamlPaths+=("$kjTarget");
    for kjKey in ${kvChildren[$kjSource]-};
    do
        kjChild=$kjSource/$kjKey;
        kjGroup=0;
        if [[ ${kvKind[$kjChild]} == map && ( $kjKey == METADATA || $kjSource == ROOT/VALUES || $kjSource == ROOT/ERRORS ) ]]; then
            for kjPattern in "${!kvLegacyKey[@]}";
            do
                [[ $kjPattern != "$kjKey/"* ]] || { 
                    kjGroup=1;
                    break
                };
            done;
        fi;
        if ((kjGroup)); then
            kv::projectGroup "$kjChild" "$kjTarget" "$kjKey" || return 1;
        else
            kv::project "$kjChild" "$kjTarget$SILMARILUS$kjKey" || return 1;
        fi;
    done
}
