shape::single () 
{ 
    shape::property "$1" "$2";
    ((${#rdfValues[@]}<=1)) || { 
        shape::error "duplicate parameter $2";
        return 2
    };
    shapeParameter=${rdfValues[0]-}
}
