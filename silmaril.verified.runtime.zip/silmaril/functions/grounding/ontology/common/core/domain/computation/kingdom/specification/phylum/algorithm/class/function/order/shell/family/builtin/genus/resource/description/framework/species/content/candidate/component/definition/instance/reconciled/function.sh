rdf::contentCandidate () 
{ 
    shapeValidationComplete=0;
    local rcText=$1 rcGraph=$2 rcBase=$3 LC_ALL=C;
    ((${#rcText}<=rdfMaximumBytes)) || { 
        rdf::error 'source capacity';
        return 1
    };
    text::utfEight "$rcText" || return 1;
    mapfile -t rdfLines <<< "$rcText";
    rdfText=;
    rdfLineIndex=0;
    rdfAbsoluteOffset=0;
    rdfContext=$rcGraph;
    ((rdfDocumentCounter+=1));
    rdfBase=$rcBase;
    if rdf::document; then
        return 0;
    else
        local rcDetail=$rdfErrorDetail;
        rdf::reset;
        error::raise PROJECTION/FIDELITY "RDF document rejected: $rcDetail";
        return 1;
    fi
}
