runtime::recordViolation () 
{ 
    local commandText=$1;
    local head=$2;
    declare -g runtimeViolation="${head}${SILMARILRS}${commandText}";
    declare -g runtimeViolationCommand=$head;
    declare -gi runtimeExternalCount=$(( runtimeExternalCount + SILMARILONE ));
    declare -g engineError=$SILMARILERRORRUNTIMEEXTERNAL;
    declare -g engineDetail=$head;
    return "$SILMARILFAILURE"
}
