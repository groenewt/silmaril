object::get () 
{ 
    local identity=$1;
    local field=$2;
    local outputName=$3;
    local -n outputReference=$outputName;
    object::exists "$identity" || { 
        engine::raise "$SILMARILERROROBJECT" "$identity";
        return "$SILMARILFAILURE"
    };
    local key="${identity}${SILMARILUS}${field}";
    local count=${objectFieldCount[$key]:-$SILMARILZERO};
    (( count >= SILMARILONE )) || { 
        engine::raise "$SILMARILERRORFIELD" "missing $field";
        return "$SILMARILFAILURE"
    };
    outputReference=${objectFieldValue[${key}${SILMARILUS}${SILMARILZERO}]}
}
