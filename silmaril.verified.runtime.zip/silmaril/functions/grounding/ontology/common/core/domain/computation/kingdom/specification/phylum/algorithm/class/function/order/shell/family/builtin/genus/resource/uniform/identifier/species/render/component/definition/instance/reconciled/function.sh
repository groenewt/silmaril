uri::render () 
{ 
    local urOut=$1 urText=;
    [[ -n ${uri[SCHEMEPRESENT]-} ]] || return 1;
    if [[ ${uri[SCHEMEPRESENT]} == 1 ]]; then
        urText=${uri[SCHEME]}:;
    fi;
    if [[ ${uri[AUTHORITYPRESENT]} == 1 ]]; then
        urText+=//${uri[AUTHORITY]};
    fi;
    urText+=${uri[PATH]};
    if [[ ${uri[QUERYPRESENT]} == 1 ]]; then
        urText+=?${uri[QUERY]};
    fi;
    if [[ ${uri[FRAGMENTPRESENT]} == 1 ]]; then
        urText+=#${uri[FRAGMENT]};
    fi;
    printf -v "$urOut" '%s' "$urText"
}
