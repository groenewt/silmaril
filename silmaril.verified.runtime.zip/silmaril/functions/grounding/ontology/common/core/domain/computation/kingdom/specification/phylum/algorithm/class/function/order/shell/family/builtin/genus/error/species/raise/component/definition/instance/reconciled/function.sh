error::raise () 
{ 
    local erPath=$1 erDetail=${2-};
    engineError=${errorRegistry[$erPath]-$SILMARILERRORUSAGE};
    engineDetail=$erDetail;
    return 1
}
