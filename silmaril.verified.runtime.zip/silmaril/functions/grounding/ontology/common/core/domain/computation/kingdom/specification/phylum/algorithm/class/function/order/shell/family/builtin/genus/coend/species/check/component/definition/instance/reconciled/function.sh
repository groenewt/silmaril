coend::check () 
{ 
    local coM=$1 coC=$2 coD coE coX coY coF coG coH coId coWords coP coQ coR coS coV coI=0;
    model::check "$coM" || return 1;
    finite::contains "${categoryObjects[*]}" "$coC" || { 
        error::raise COEND/RELATION target;
        return 1
    };
    coendModel=$coM;
    coendTarget=$coC;
    coendStates=();
    coendObject=();
    coendValue=();
    coendArrow=();
    coendParent=();
    coendIndex=();
    coendEvaluation=();
    coendClassCount=0;
    for coF in "${categoryArrows[@]}";
    do
        [[ ${categoryTarget[$coF]} == "$coC" ]] || continue;
        coD=${categorySource[$coF]};
        for coX in ${modelElements[$coM$SILMARILUS$coD]};
        do
            name::number "$coI" coWords;
            ((coI+=1));
            coId=$coM:component:coend:instance:$coWords;
            coendStates+=("$coId");
            coendObject[$coId]=$coD;
            coendValue[$coId]=$coX;
            coendArrow[$coId]=$coF;
            coendParent[$coId]=$coId;
            coendIndex[$coD$SILMARILUS$coX$SILMARILUS$coF]=$coId;
            coendEvaluation[$coId]=${modelAction[$coM$SILMARILUS$coF$SILMARILUS$coX]};
        done;
    done;
    for coG in "${categoryArrows[@]}";
    do
        coD=${categorySource[$coG]};
        coE=${categoryTarget[$coG]};
        for coH in "${categoryArrows[@]}";
        do
            [[ ${categorySource[$coH]} == "$coE" && ${categoryTarget[$coH]} == "$coC" ]] || continue;
            coF=${categoryComposite[$coH$SILMARILUS$coG]};
            for coX in ${modelElements[$coM$SILMARILUS$coD]};
            do
                coY=${modelAction[$coM$SILMARILUS$coG$SILMARILUS$coX]};
                coP=${coendIndex[$coE$SILMARILUS$coY$SILMARILUS$coH]};
                coQ=${coendIndex[$coD$SILMARILUS$coX$SILMARILUS$coF]};
                coend::root "$coP" coR || return 1;
                coend::root "$coQ" coS || return 1;
                coendParent[$coS]=$coR;
            done;
        done;
    done;
    local -A coClasses=() coByValue=();
    for coP in "${coendStates[@]}";
    do
        coend::root "$coP" coR || return 1;
        coV=${coendEvaluation[$coP]};
        [[ -z ${coClasses[$coR]-} || ${coClasses[$coR]} == "$coV" ]] || { 
            error::raise COEND/RELATION well:defined;
            return 1
        };
        [[ -z ${coByValue[$coV]-} || ${coByValue[$coV]} == "$coR" ]] || { 
            error::raise COEND/RELATION injective;
            return 1
        };
        coClasses[$coR]=$coV;
        coByValue[$coV]=$coR;
        ((finiteChecks+=1));
    done;
    for coV in ${modelElements[$coM$SILMARILUS$coC]};
    do
        [[ -n ${coByValue[$coV]-} ]] || { 
            error::raise COEND/RELATION surjective;
            return 1
        };
    done;
    coendClassCount=${#coClasses[@]};
    return 0
}
