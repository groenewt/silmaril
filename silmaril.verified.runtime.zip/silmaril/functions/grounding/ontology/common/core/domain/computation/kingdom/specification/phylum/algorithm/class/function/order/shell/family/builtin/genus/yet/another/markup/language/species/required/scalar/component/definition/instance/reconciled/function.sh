yaml::requiredScalar () 
{ 
    local parent=$1;
    local key=$2;
    local outputName=$3;
    local -n outputReference=$outputName;
    local pathValue;
    yaml::join pathValue "$parent" "$key";
    [[ ${yamlKind[$pathValue]-} == scalar ]] || { 
        engine::raise "$SILMARILERRORYAML" "required scalar $key";
        return "$SILMARILFAILURE"
    };
    outputReference=${yamlValue[$pathValue]}
}
