rdf::predicates () 
{ 
    local rpSubject=$1 rpPredicate rpObject;
    while :; do
        rdf::term predicate || return 1;
        rpPredicate=$rdfTermResult;
        [[ ${rdfKind[rpPredicate]} == iri ]] || { 
            rdf::error 'predicate not IRI';
            return 1
        };
        while :; do
            rdf::term || return 1;
            rpObject=$rdfTermResult;
            rdf::triple "$rpSubject" "$rpPredicate" "$rpObject" || return 1;
            rdf::space;
            [[ ${rdfText:rdfCursor:1} == ',' ]] || break;
            ((rdfCursor+=1));
        done;
        [[ ${rdfText:rdfCursor:1} == ';' ]] || break;
        while [[ ${rdfText:rdfCursor:1} == ';' ]]; do
            ((rdfCursor+=1));
            rdf::space;
        done;
        [[ ${rdfText:rdfCursor:1} != ']' && ${rdfText:rdfCursor:1} != '.' ]] || break;
    done
}
