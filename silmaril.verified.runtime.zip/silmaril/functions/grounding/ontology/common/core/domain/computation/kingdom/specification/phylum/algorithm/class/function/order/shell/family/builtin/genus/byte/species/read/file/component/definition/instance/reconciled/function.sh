byte::readFile () 
{ 
    local brPath=$1 brId=$2 brChunk brStatus brI brChar brNumber brNull;
    local LC_ALL=C;
    path::requireReadable "$brPath" || return 1;
    identity::requireRankedUrn "$brId" stream || return 1;
    [[ ! -n ${byteStreamDefined[$brId]+present} && ! -n ${objectDefined[$brId]+present} ]] || { 
        error::raise PAIR/DUPLICATE stream;
        return 1
    };
    [[ $byteChunkSize =~ ^[1-9][0-9]*$ && $byteMaximumLength =~ ^[1-9][0-9]*$ ]] && ((byteChunkSize<=65536 && byteMaximumLength<=1048576)) || { 
        error::raise PAIR/LIMIT configuration;
        return 1
    };
    local -a brValues=();
    while :; do
        brChunk=;
        brStatus=0;
        brNull=0;
        IFS= read -r -d '' -n "$byteChunkSize" brChunk || brStatus=$?;
        if ((brStatus==0 && ${#brChunk}<byteChunkSize)); then
            brNull=1;
        fi;
        for ((brI=0; brI<${#brChunk}; brI++))
        do
            brChar=${brChunk:brI:1};
            printf -v brNumber '%d' "'$brChar";
            brValues+=("$brNumber");
        done;
        ((brNull==0)) || brValues+=(0);
        ((${#brValues[@]}<=byteMaximumLength)) || { 
            error::raise PAIR/LIMIT stream;
            return 1
        };
        ((brStatus==0)) || break;
    done < "$brPath";
    object::new "$brId" "$SILMARILTYPEBYTESTREAM" || return 1;
    byteStreamDefined[$brId]=1;
    byteStreamCount[$brId]=0;
    for brNumber in "${brValues[@]}";
    do
        byte::append "$brId" "$brNumber" || return 1;
    done;
    return 0
}
