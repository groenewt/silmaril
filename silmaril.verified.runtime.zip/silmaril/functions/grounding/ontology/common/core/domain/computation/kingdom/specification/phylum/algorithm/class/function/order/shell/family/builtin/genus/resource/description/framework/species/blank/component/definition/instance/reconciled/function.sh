rdf::blank () 
{ 
    ((rdfBlankCounter+=1));
    rdf::intern blank "document${rdfDocumentCounter}node${rdfBlankCounter}"
}
