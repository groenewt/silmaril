checkpoint::load () 
{ 
    local clPath=$1 clSnapshot=$2 clText= clRc=0 clGraph clSaved clExpected clDone clNodes clCount clI clItem clNode clState clOutput clAttempt clPred;
    local -A clSeen=();
    schedulerRestored=();
    path::requireReadable "$clSnapshot" || return 1;
    IFS= read -r -d '' -n "$((kvMaximumBytes+1))" clText < "$clSnapshot" || clRc=$?;
    [[ $clRc == 1 && $clText == "$graphRaw" ]] || { 
        error::raise EXECUTION/RESUME 'snapshot differs';
        return 1
    };
    path::identify "$clSnapshot" clExpected || return 1;
    yaml::parse "$clPath" || return 1;
    yaml::assertOnlyKeys "$SILMARILYAMLROOT" IDENTITY GRAPH SNAPSHOT NODES COMPLETE || return 1;
    yaml::requiredMap "$SILMARILYAMLROOT" GRAPH clGraph || return 1;
    yaml::assertOnlyKeys "$clGraph" IDENTITY || return 1;
    yaml::requiredScalar "$clGraph" IDENTITY clSaved || return 1;
    [[ $clSaved == "$graphIdentity" ]] || { 
        error::raise EXECUTION/RESUME 'graph identity mismatch';
        return 1
    };
    yaml::requiredScalar "$SILMARILYAMLROOT" SNAPSHOT clSaved || return 1;
    [[ $clSaved == "$clExpected" ]] || { 
        error::raise EXECUTION/RESUME 'snapshot address mismatch';
        return 1
    };
    yaml::requiredScalar "$SILMARILYAMLROOT" COMPLETE clDone || return 1;
    [[ $clDone == "$SILMARILTRUE" ]] || { 
        error::raise EXECUTION/RESUME 'not complete';
        return 1
    };
    yaml::requiredSequence "$SILMARILYAMLROOT" NODES clNodes clCount || return 1;
    ((clCount==${#graphNodes[@]})) || { 
        error::raise EXECUTION/RESUME 'node account incomplete';
        return 1
    };
    for ((clI=0; clI<clCount; clI++))
    do
        yaml::sequenceMap "$clNodes" "$clI" clItem || return 1;
        yaml::assertOnlyKeys "$clItem" IDENTITY STATE ATTEMPT OUTPUT || return 1;
        yaml::requiredScalar "$clItem" IDENTITY clNode || return 1;
        [[ -n ${graphNodeIndex[$clNode]+present} && ! -n ${clSeen[$clNode]+present} ]] || { 
            error::raise EXECUTION/RESUME 'node identity';
            return 1
        };
        clSeen[$clNode]=1;
        yaml::requiredScalar "$clItem" STATE clState || return 1;
        yaml::requiredScalar "$clItem" OUTPUT clOutput || return 1;
        yaml::requiredScalar "$clItem" ATTEMPT clAttempt || return 1;
        [[ -n ${kvNumber[$clAttempt]-} ]] || { 
            error::raise EXECUTION/RESUME 'attempt type';
            return 1
        };
        case $clState in 
            "$CHECKPOINTSTATEBASE":success)
                object::exists "$clOutput" && type::isSubtype "${objectType[$clOutput]}" "$SILMARILTYPEVALUE" || { 
                    error::raise EXECUTION/RESUME 'output unresolved';
                    return 1
                };
                schedulerRestored[$clNode]=$clOutput
            ;;
            "$CHECKPOINTSTATEBASE":failure | "$CHECKPOINTSTATEBASE":blocked | "$CHECKPOINTSTATEBASE":pending | "$CHECKPOINTSTATEBASE":running | "$CHECKPOINTSTATEBASE":rolled | "$CHECKPOINTSTATEBASE":compensation:missing | "$CHECKPOINTSTATEBASE":compensation:failed)
                :
            ;;
            *)
                error::raise EXECUTION/RESUME 'state type';
                return 1
            ;;
        esac;
    done;
    for clNode in "${!schedulerRestored[@]}";
    do
        for clPred in "${graphNodes[@]}";
        do
            [[ ! -n ${graphAdjacency[$clPred$SILMARILUS$clNode]+present} || -n ${schedulerRestored[$clPred]+present} ]] || { 
                schedulerRestored=();
                error::raise EXECUTION/RESUME 'successful node lacks successful dependency';
                return 1
            };
        done;
    done
}
