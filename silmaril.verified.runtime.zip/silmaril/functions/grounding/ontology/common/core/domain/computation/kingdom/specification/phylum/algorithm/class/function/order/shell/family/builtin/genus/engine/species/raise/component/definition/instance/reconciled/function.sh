engine::raise () 
{ 
    engineError=${1-};
    engineDetail=${2-};
    return "$SILMARILFAILURE"
}
