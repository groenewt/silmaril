dispatch::resolve () 
{ 
    local identity=$1;
    local method=$2;
    local start=$3;
    local ownerName=$4;
    local implementationName=$5;
    local -n ownerReference=$ownerName;
    local -n implementationReference=$implementationName;
    object::exists "$identity" || { 
        engine::raise "$SILMARILERRORDISPATCH" "$identity";
        return "$SILMARILFAILURE"
    };
    local -a resolution=();
    type::mro "${objectType[$identity]}" resolution || return "$SILMARILFAILURE";
    local index;
    local candidateOwner;
    local key;
    for ((index = start; index < ${#resolution[@]}; index += SILMARILONE ))
    do
        candidateOwner=${resolution[$index]};
        key="${candidateOwner}${SILMARILUS}${method}";
        if [[ ${methodDefined[$key]-} == "$SILMARILONE" ]]; then
            ownerReference=$candidateOwner;
            implementationReference=${methodImplementation[$key]};
            return "$SILMARILZERO";
        fi;
    done;
    engine::raise "$SILMARILERRORDISPATCH" "$method"
}
