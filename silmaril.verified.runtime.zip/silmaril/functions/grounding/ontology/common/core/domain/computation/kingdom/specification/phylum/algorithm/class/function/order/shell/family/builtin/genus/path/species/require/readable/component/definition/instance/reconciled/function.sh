path::requireReadable () 
{ 
    local prPath=${1-};
    path::requireSafe "$prPath" || return 1;
    [[ -f $prPath && -r $prPath ]] || { 
        error::raise PATH/ROOT "$prPath";
        return 1
    }
}
