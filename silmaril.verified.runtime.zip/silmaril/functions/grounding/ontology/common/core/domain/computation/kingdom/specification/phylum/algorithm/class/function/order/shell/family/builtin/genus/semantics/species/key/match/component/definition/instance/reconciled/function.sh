semantics::keyMatch () 
{ 
    local kmX=$1 kmY=$2 kmP kmA kmB kmMatch;
    [[ ${keyNamed[$kmX]-} == 1 && ${keyNamed[$kmY]-} == 1 && ${keyClass[$kmX]-} == 1 && ${keyClass[$kmY]-} == 1 ]] || return 1;
    for kmP in "${keyObjectProperties[@]}";
    do
        kmMatch=0;
        for kmA in ${keyValues[$kmX,$kmP]-};
        do
            [[ ${keyNamed[$kmA]-} == 1 ]] || continue;
            for kmB in ${keyValues[$kmY,$kmP]-};
            do
                [[ $kmA != "$kmB" ]] || kmMatch=1;
            done;
        done;
        ((kmMatch)) || return 1;
    done;
    for kmP in "${keyDataProperties[@]}";
    do
        kmMatch=0;
        for kmA in ${keyValues[$kmX,$kmP]-};
        do
            for kmB in ${keyValues[$kmY,$kmP]-};
            do
                [[ $kmA != "$kmB" ]] || kmMatch=1;
            done;
        done;
        ((kmMatch)) || return 1;
    done
}
