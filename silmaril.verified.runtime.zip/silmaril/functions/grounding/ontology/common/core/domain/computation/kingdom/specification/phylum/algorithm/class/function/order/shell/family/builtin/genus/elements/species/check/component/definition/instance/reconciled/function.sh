elements::check () 
{ 
    local ecF ecG ecH ecL ecR ecS ecT ecO ecA ecX ecY ecCount=0;
    for ecO in "${elementObjects[@]}";
    do
        ecF=${elementIdentity[$ecO]-};
        [[ -n $ecF && ${elementSource[$ecF]-} == "$ecO" && ${elementTarget[$ecF]-} == "$ecO" ]] || { 
            error::raise CATEGORY/IDENTITY element;
            return 1
        };
    done;
    for ecF in "${elementArrows[@]}";
    do
        ecS=${elementSource[$ecF]};
        ecT=${elementTarget[$ecF]};
        ecA=${elementArrowBase[$ecF]};
        ecX=${elementValue[$ecS]};
        ecY=${elementValue[$ecT]};
        [[ ${modelAction[$elementModel$SILMARILUS$ecA$SILMARILUS$ecX]-} == "$ecY" ]] || { 
            error::raise FUNCTOR/TOTALITY lift;
            return 1
        };
        ecL=${elementIdentity[$ecS]};
        ecR=${elementIdentity[$ecT]};
        [[ ${elementComposite[$ecF$SILMARILUS$ecL]-} == "$ecF" && ${elementComposite[$ecR$SILMARILUS$ecF]-} == "$ecF" ]] || { 
            error::raise CATEGORY/IDENTITY lift;
            return 1
        };
        for ecG in "${elementArrows[@]}";
        do
            [[ $ecT == "${elementSource[$ecG]}" ]] || continue;
            for ecH in "${elementArrows[@]}";
            do
                [[ ${elementTarget[$ecG]} == "${elementSource[$ecH]}" ]] || continue;
                ecL=${elementComposite[$ecG$SILMARILUS$ecF]};
                ecR=${elementComposite[$ecH$SILMARILUS$ecG]};
                [[ ${elementComposite[$ecH$SILMARILUS$ecL]-} == "${elementComposite[$ecR$SILMARILUS$ecF]-}" ]] || { 
                    error::raise CATEGORY/ASSOCIATIVITY lift;
                    return 1
                };
                ((finiteChecks+=1));
            done;
        done;
    done;
    return 0
}
