engine::audit () 
{ 
    local key;
    local implementation;
    for key in "${!methodImplementation[@]}";
    do
        implementation=${methodImplementation[$key]};
        method::auditImplementation "$implementation" || return "$SILMARILFAILURE";
    done;
    (( runtimeExternalCount == SILMARILZERO )) || { 
        engine::raise "$SILMARILERRORRUNTIMEEXTERNAL" "$runtimeExternalCount";
        return "$SILMARILFAILURE"
    };
    ontology::seal || return "$SILMARILFAILURE"
}
