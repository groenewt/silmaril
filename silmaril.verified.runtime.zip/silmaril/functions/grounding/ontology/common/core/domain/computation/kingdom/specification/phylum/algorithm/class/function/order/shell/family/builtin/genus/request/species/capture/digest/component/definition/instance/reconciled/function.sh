request::capture::digest () 
{ 
    local cdOut=$1 cdPath cdCount cdIndex cdRef cdNumber cdPart cdText=;
    yaml::requiredSequence "$SILMARILYAMLROOT" DIGEST cdPath cdCount || return "$SILCAPTUREONE";
    ((cdCount==SILCAPTUREDIGESTOCTETS)) || { 
        error::raise PAIR/VALUE 'capture digest width';
        return "$SILCAPTUREONE"
    };
    for ((cdIndex=SILCAPTUREZERO; cdIndex<cdCount; cdIndex+=SILCAPTUREONE))
    do
        yaml::sequenceScalar "$cdPath" "$cdIndex" cdRef || return "$SILCAPTUREONE";
        cdNumber=${kvNumber[$cdRef]-};
        [[ $cdNumber =~ ^(0|[1-9][0-9]{0,2})$ ]] && ((cdNumber<=255)) || { 
            error::raise PAIR/VALUE 'capture digest octet';
            return "$SILCAPTUREONE"
        };
        printf -v cdPart '%02x' "$cdNumber";
        cdText+=$cdPart;
    done;
    printf -v "$cdOut" '%s' "$cdText"
}
