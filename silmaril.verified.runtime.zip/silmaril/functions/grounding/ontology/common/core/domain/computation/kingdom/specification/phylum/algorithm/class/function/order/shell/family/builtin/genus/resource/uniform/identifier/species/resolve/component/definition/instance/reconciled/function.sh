uri::resolve () 
{ 
    local rrBase=$1 rrReference=$2 rrOut=$3 rrK rrMerged rrPath rrText;
    local -A rrB=() rrR=() rrT=();
    uri::parse "$rrBase" || return 1;
    [[ ${uri[SCHEMEPRESENT]} == 1 && ${uri[SCHEME],,} != urn ]] || { 
        error::raise PROTOCOL/LOCATOR 'base must be absolute and hierarchical';
        return 1
    };
    for rrK in "${!uri[@]}";
    do
        rrB[$rrK]=${uri[$rrK]};
    done;
    uri::parse "$rrReference" || return 1;
    for rrK in "${!uri[@]}";
    do
        rrR[$rrK]=${uri[$rrK]};
        rrT[$rrK]=${uri[$rrK]};
    done;
    if [[ ${rrR[SCHEMEPRESENT]} == 1 ]]; then
        uri::removeDots "${rrR[PATH]}" rrPath;
    else
        rrT[SCHEME]=${rrB[SCHEME]};
        rrT[SCHEMEPRESENT]=1;
        if [[ ${rrR[AUTHORITYPRESENT]} == 1 ]]; then
            uri::removeDots "${rrR[PATH]}" rrPath;
        else
            rrT[AUTHORITY]=${rrB[AUTHORITY]};
            rrT[AUTHORITYPRESENT]=${rrB[AUTHORITYPRESENT]};
            if [[ -z ${rrR[PATH]} ]]; then
                rrPath=${rrB[PATH]};
                if [[ ${rrR[QUERYPRESENT]} == 0 ]]; then
                    rrT[QUERY]=${rrB[QUERY]};
                    rrT[QUERYPRESENT]=${rrB[QUERYPRESENT]};
                fi;
            else
                if [[ ${rrR[PATH]} == /* ]]; then
                    uri::removeDots "${rrR[PATH]}" rrPath;
                else
                    if [[ ${rrB[AUTHORITYPRESENT]} == 1 && -z ${rrB[PATH]} ]]; then
                        rrMerged=/${rrR[PATH]};
                    else
                        if [[ ${rrB[PATH]} == */* ]]; then
                            rrMerged=${rrB[PATH]%/*}/${rrR[PATH]};
                        else
                            rrMerged=${rrR[PATH]};
                        fi;
                    fi;
                    uri::removeDots "$rrMerged" rrPath;
                fi;
            fi;
        fi;
    fi;
    rrT[PATH]=$rrPath;
    uri=();
    for rrK in "${!rrT[@]}";
    do
        uri[$rrK]=${rrT[$rrK]};
    done;
    uri::render rrText;
    uri::parse "$rrText" || return 1;
    printf -v "$rrOut" '%s' "$rrText"
}
