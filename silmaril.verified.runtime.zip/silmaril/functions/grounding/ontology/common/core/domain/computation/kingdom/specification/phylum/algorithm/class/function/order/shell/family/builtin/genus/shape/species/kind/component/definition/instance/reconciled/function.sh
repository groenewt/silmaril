shape::kind () 
{ 
    local skNode=$1 skKind=${rdfTerm[$2]} skActual=${rdfKind[$1]};
    case $skKind in 
        "${SHNS}IRI")
            [[ $skActual == iri ]]
        ;;
        "${SHNS}BlankNode")
            [[ $skActual == blank ]]
        ;;
        "${SHNS}Literal")
            [[ $skActual == literal ]]
        ;;
        "${SHNS}BlankNodeOrIRI")
            [[ $skActual != literal ]]
        ;;
        "${SHNS}BlankNodeOrLiteral")
            [[ $skActual != iri ]]
        ;;
        "${SHNS}IRIOrLiteral")
            [[ $skActual != blank ]]
        ;;
        *)
            shape::error 'unknown nodeKind';
            return 2
        ;;
    esac
}
