ontology::loadTypes () 
{ 
    local typesPath;
    local typesLength;
    yaml::requiredSequence "$SILMARILYAMLROOT" TYPES typesPath typesLength || return "$SILMARILFAILURE";
    local typeIndex;
    local itemPath;
    local identity;
    local definition;
    local abstract;
    local shortDescription;
    local longDescription;
    local groundingPath;
    local groundingLength;
    local taxonomyPath;
    local parentsPath;
    local parentsLength;
    local parentsPresent;
    local axiomsPath;
    local axiomsLength;
    local parentIndex;
    local groundingIndex;
    local axiomIndex;
    local parentIdentity;
    local groundingIdentity;
    local axiomIdentity;
    local -a parents=();
    for ((typeIndex = SILMARILZERO; typeIndex < typesLength; typeIndex += SILMARILONE ))
    do
        yaml::sequenceMap "$typesPath" "$typeIndex" itemPath || return "$SILMARILFAILURE";
        yaml::assertOnlyKeys "$itemPath" IDENTITY DEFINITION ABSTRACT GROUNDING TAXONOMY ShortDescription LongDescription PARENTS AXIOMS || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" IDENTITY identity || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" DEFINITION definition || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" ABSTRACT abstract || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" ShortDescription shortDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" LongDescription longDescription || return "$SILMARILFAILURE";
        yaml::requiredSequence "$itemPath" GROUNDING groundingPath groundingLength || return "$SILMARILFAILURE";
        yaml::requiredMap "$itemPath" TAXONOMY taxonomyPath || return "$SILMARILFAILURE";
        yaml::optionalSequence "$itemPath" PARENTS parentsPath parentsLength parentsPresent || return "$SILMARILFAILURE";
        yaml::requiredSequence "$itemPath" AXIOMS axiomsPath axiomsLength || return "$SILMARILFAILURE";
        parents=();
        if (( parentsPresent == SILMARILONE )); then
            for ((parentIndex = SILMARILZERO; parentIndex < parentsLength; parentIndex += SILMARILONE ))
            do
                yaml::sequenceScalar "$parentsPath" "$parentIndex" parentIdentity || return "$SILMARILFAILURE";
                parents+=("$parentIdentity");
            done;
        fi;
        type::define "$identity" "$definition" "$abstract" "${#parents[@]}" "${parents[@]}" || return "$SILMARILFAILURE";
        typeShortDescription[$identity]=$shortDescription;
        typeLongDescription[$identity]=$longDescription;
        for ((groundingIndex = SILMARILZERO; groundingIndex < groundingLength; groundingIndex += SILMARILONE ))
        do
            yaml::sequenceScalar "$groundingPath" "$groundingIndex" groundingIdentity || return "$SILMARILFAILURE";
            type::addGrounding "$identity" "$groundingIdentity" || return "$SILMARILFAILURE";
        done;
        ontology::validateTaxonomy "$identity" "$taxonomyPath" || return "$SILMARILFAILURE";
        for ((axiomIndex = SILMARILZERO; axiomIndex < axiomsLength; axiomIndex += SILMARILONE ))
        do
            yaml::sequenceScalar "$axiomsPath" "$axiomIndex" axiomIdentity || return "$SILMARILFAILURE";
            type::addAxiom "$identity" "$axiomIdentity" || return "$SILMARILFAILURE";
        done;
    done
}
