rdf::objects () 
{ 
    local roKey="${3:-data},$1,$2";
    rdfValues=();
    if [[ -n ${rdfForward[$roKey]+yes} ]]; then
        read -r -a rdfValues <<< "${rdfForward[$roKey]}";
    fi;
    return 0
}
