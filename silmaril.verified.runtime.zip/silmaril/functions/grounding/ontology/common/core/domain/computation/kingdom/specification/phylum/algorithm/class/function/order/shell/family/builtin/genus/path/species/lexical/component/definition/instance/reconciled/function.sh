path::lexical () 
{ 
    local plInput=$1 plPart plRest;
    [[ $plInput == /* && $plInput != *'//'* && $plInput != *'
'* && $plInput != *''* ]] || return 1;
    [[ $plInput == / || $plInput != */ ]] || return 1;
    plRest=${plInput#/};
    while [[ -n $plRest ]]; do
        plPart=${plRest%%/*};
        [[ -n $plPart && $plPart != . && $plPart != .. ]] || return 1;
        [[ $plRest == */* ]] && plRest=${plRest#*/} || plRest=;
    done
}
