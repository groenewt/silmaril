scheduler::inputs () 
{ 
    local siNode=$1 siPred siN=0;
    for siPred in "${graphNodes[@]}";
    do
        [[ -n ${graphAdjacency[$siPred$SILMARILUS$siNode]+present} ]] || continue;
        [[ ${schedulerState[$siPred]-} == success ]] || return 1;
        nodeInput[$siNode$SILMARILUS$siN]=${nodeOutput[$siPred]};
        ((siN+=1));
    done;
    nodeInputCount[$siNode]=$siN
}
