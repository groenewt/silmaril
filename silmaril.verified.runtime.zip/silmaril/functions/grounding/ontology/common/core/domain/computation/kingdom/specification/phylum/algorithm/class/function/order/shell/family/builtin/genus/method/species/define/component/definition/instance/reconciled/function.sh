method::define () 
{ 
    local owner=$1;
    local method=$2;
    local implementation=$3;
    type::exists "$owner" || { 
        engine::raise "$SILMARILERRORMETHOD" "$owner";
        return "$SILMARILFAILURE"
    };
    identity::requireRankedUrn "$method" method || return "$SILMARILFAILURE";
    method::auditImplementation "$implementation" || return "$SILMARILFAILURE";
    local key="${owner}${SILMARILUS}${method}";
    [[ ! -n ${methodDefined[$key]+present} ]] || { 
        engine::raise "$SILMARILERRORMETHOD" "$key duplicate";
        return "$SILMARILFAILURE"
    };
    methodDefined[$key]=$SILMARILONE;
    methodImplementation[$key]=$implementation;
    readonly -f "$implementation"
}
