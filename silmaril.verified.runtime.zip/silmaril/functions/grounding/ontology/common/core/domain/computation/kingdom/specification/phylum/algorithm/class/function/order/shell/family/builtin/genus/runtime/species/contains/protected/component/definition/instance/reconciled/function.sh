runtime::containsProtected () 
{ 
    local commandText=$1;
    [[ $commandText =~ (runtimeActive|runtimeExternalCount|runtimeHadExtdebug|runtimeHadFunctrace|runtimeHadErrexit|runtimeSavedErrAction|runtimeErrWasSet|runtimeOwner|runtimeViolation|runtimeViolationCommand|engineError|engineDetail|BASH_COMMAND|BASHOPTS|SHELLOPTS|BASH_ENV|FUNCNAME) ]]
}
