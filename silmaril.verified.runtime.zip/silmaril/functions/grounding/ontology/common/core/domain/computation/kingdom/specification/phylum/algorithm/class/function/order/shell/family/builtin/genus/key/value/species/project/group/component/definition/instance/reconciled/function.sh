kv::projectGroup () 
{ 
    local kgSource=$1 kgTarget=$2 kgRel=$3 kgKey kgChild kgAlias kgTail kgTo;
    for kgKey in ${kvChildren[$kgSource]-};
    do
        kgChild=$kgSource/$kgKey;
        kgTail=$kgRel/$kgKey;
        if [[ $kgKey == ITEM && ${kvKind[$kgChild]} == scalar ]]; then
            kgAlias=${kgRel##*/};
        else
            kgAlias=${kvLegacyKey[$kgTail]-};
        fi;
        if [[ -n $kgAlias ]]; then
            kgTo=$kgTarget$SILMARILUS$kgAlias;
            kv::project "$kgChild" "$kgTo" || return 1;
        else
            if [[ ${kvKind[$kgChild]} == map ]]; then
                kv::projectGroup "$kgChild" "$kgTarget" "$kgTail" || return 1;
            else
                error::raise PROJECTION/FIDELITY "$kgTail";
                return 1;
            fi;
        fi;
    done
}
