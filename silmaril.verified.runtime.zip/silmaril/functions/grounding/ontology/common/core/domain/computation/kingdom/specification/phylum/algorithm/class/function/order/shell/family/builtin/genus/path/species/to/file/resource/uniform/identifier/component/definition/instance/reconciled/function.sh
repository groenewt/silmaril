path::toFileUri () 
{ 
    local fuPath=$1 fuOut=$2 fuI fuC fuN fuHex fuResult=file:// LC_ALL=C;
    path::lexical "$fuPath" || { 
        error::raise PATH/SEGMENT 'absolute canonical lexical path required';
        return 1
    };
    for ((fuI=0; fuI<${#fuPath}; fuI++))
    do
        fuC=${fuPath:fuI:1};
        case $fuC in 
            [a-zA-Z0-9._~] | /)
                fuResult+=$fuC
            ;;
            *)
                printf -v fuN '%d' "'$fuC";
                printf -v fuHex '%%%02X' "$fuN";
                fuResult+=$fuHex
            ;;
        esac;
    done;
    printf -v "$fuOut" '%s' "$fuResult"
}
