yaml::keySpecimen () 
{ 
    local key=$1;
    local outputName=$2;
    local -n outputReference=$outputName;
    local atom=${key,,};
    atom=${atom//[^a-z0-9]/};
    [[ $atom =~ ^[a-z][a-z0-9]*$ ]] || atom=member;
    outputReference="urn:silmaril:type:graph:instance:instruction:code:property:grounding:ontology:basic:formal:domain:knowledge:kingdom:representation:phylum:yet:another:markup:language:class:key:order:canonical:family:key:genus:lexical:species:${atom}"
}
