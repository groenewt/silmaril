kv::prose () 
{ 
    local prText=$1 prOut=$2 prResult= prC prEscape=0 prI;
    [[ $prText == '"'*'"' && ${#prText} > 1 ]] || { 
        error::raise PAIR/VALUE 'description requires double quotes';
        return 1
    };
    prText=${prText:1:${#prText}-2};
    for ((prI=0; prI<${#prText}; prI++))
    do
        prC=${prText:prI:1};
        if ((prEscape)); then
            case $prC in 
                '"' | '\')
                    prResult+=$prC
                ;;
                n)
                    prResult+='
'
                ;;
                t)
                    prResult+='	'
                ;;
                r)
                    prResult+=''
                ;;
                *)
                    error::raise PAIR/VALUE 'unsupported description escape';
                    return 1
                ;;
            esac;
            prEscape=0;
        else
            if [[ $prC == '\' ]]; then
                prEscape=1;
            else
                if [[ $prC == '"' || $prC < ' ' ]]; then
                    error::raise PAIR/VALUE 'unescaped quote or control';
                    return 1;
                else
                    prResult+=$prC;
                fi;
            fi;
        fi;
    done;
    ((prEscape==0)) || { 
        error::raise PAIR/VALUE 'trailing escape';
        return 1
    };
    printf -v "$prOut" '%s' "$prResult"
}
