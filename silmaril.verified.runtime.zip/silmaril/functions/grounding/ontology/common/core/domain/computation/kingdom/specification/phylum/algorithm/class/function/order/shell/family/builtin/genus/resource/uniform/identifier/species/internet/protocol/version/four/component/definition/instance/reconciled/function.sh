uri::ipvfour () 
{ 
    local ivText=$1 ivPart ivCount=0;
    while :; do
        ivPart=${ivText%%.*};
        [[ $ivPart =~ ^(0|[1-9][0-9]{0,2})$ ]] && ((10#$ivPart<=255)) || return 1;
        ((ivCount+=1));
        [[ $ivText == *.* ]] || break;
        ivText=${ivText#*.};
    done;
    ((ivCount==4))
}
