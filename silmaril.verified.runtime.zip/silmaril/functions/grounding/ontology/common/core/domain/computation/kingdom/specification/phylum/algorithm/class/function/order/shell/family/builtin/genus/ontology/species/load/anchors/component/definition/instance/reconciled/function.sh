ontology::loadAnchors () 
{ 
    local anchorsPath;
    local anchorsLength;
    yaml::requiredSequence "$SILMARILYAMLROOT" ANCHORS anchorsPath anchorsLength || return "$SILMARILFAILURE";
    local index;
    local itemPath;
    local identity;
    local shortDescription;
    local longDescription;
    for ((index = SILMARILZERO; index < anchorsLength; index += SILMARILONE ))
    do
        yaml::sequenceMap "$anchorsPath" "$index" itemPath || return "$SILMARILFAILURE";
        yaml::assertOnlyKeys "$itemPath" IDENTITY ShortDescription LongDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" IDENTITY identity || return "$SILMARILFAILURE";
        identity::requireUrn "$identity" grounding || return "$SILMARILFAILURE";
        [[ ! -n ${groundingDefined[$identity]+present} ]] || { 
            engine::raise "$SILMARILERRORGROUNDING" "$identity";
            return "$SILMARILFAILURE"
        };
        yaml::requiredScalar "$itemPath" ShortDescription shortDescription || return "$SILMARILFAILURE";
        yaml::requiredScalar "$itemPath" LongDescription longDescription || return "$SILMARILFAILURE";
        groundingDefined[$identity]=$SILMARILONE;
        groundingOrder+=("$identity");
    done
}
