scheduler::compensate () 
{ 
    local soI soNode soFrame soOwner soImpl soFd soPid soStart soFailed=0;
    schedulerRolled=();
    for ((soI=${#schedulerCommit[@]}-1; soI>=0; soI--))
    do
        soNode=${schedulerCommit[$soI]};
        if ! dispatch::resolve "$soNode" "$SCHEDULERMETHODROLLBACK" 0 soOwner soImpl; then
            schedulerState[$soNode]=compensationmissing;
            soFailed=1;
            continue;
        fi;
        scheduler::clock soStart || return 1;
        scheduler::launch "$soNode" "$SCHEDULERMETHODROLLBACK" 1 soFd soPid || return 1;
        if scheduler::receive "$soFd" "$soPid" "$soStart" soFrame; then
            schedulerState[$soNode]=rolled;
            schedulerRolled+=("$soNode");
        else
            schedulerState[$soNode]=compensationfailed;
            soFailed=1;
        fi;
    done;
    ((soFailed==0)) || { 
        error::raise EXECUTION/ROLLBACK 'compensation incomplete';
        return 1
    }
}
