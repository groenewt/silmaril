type::isSubtype () 
{ 
    local child=$1;
    local parent=$2;
    type::exists "$child" && type::exists "$parent" || return "$SILMARILFAILURE";
    type::sequenceContains "${typeMro[$child]}" "$parent"
}
