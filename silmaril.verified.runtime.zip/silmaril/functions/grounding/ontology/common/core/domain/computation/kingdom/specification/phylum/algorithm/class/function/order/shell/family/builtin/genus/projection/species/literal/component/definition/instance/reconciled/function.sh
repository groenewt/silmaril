projection::literal () 
{ 
    local plText=$3;
    plText=${plText//\\/\\\\};
    plText=${plText//\"/\\\"};
    plText=${plText//'
'/\\n};
    plText=${plText//''/\\r};
    plText=${plText//'	'/\\t};
    printf '<%s> <%s> "%s" .\n' "$1" "$2" "$plText"
}
