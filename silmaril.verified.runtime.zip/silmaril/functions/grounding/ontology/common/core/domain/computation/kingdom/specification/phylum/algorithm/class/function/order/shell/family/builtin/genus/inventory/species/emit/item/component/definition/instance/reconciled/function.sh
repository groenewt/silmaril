inventory::emitItem () 
{ 
    local ieIndex=$1 ieIndent=$2 ieRef iePath ieParent ieAbsolute ieDepth ieLayer ieOrdinal ieChildren ieType ieWord ieEntry;
    iePath=${inventoryPath[ieIndex]};
    path::identify "$iePath" ieRef || return 1;
    if ((ieIndex)); then
        ieParent=${inventoryPath[${inventoryParent[ieIndex]}]};
    else
        ieParent=${iePath%/*};
        [[ -n $ieParent ]] || ieParent=/;
    fi;
    path::identify "$ieParent" ieParent || return 1;
    ieAbsolute=${iePath//[^\/]/};
    [[ $iePath != / ]] || ieAbsolute=;
    number::reference "${#ieAbsolute}" ieDepth;
    number::reference "${inventoryDepth[ieIndex]}" ieLayer;
    number::reference "${inventoryOrdinal[ieIndex]}" ieOrdinal;
    number::reference "${inventoryChildren[ieIndex]}" ieChildren;
    if [[ ${inventoryKind[ieIndex]} == directory ]]; then
        ieType=$INVENTORYDIRECTORY;
    else
        ieType=$INVENTORYFILE;
    fi;
    name::number "$ieIndex" ieWord;
    ieEntry="$ieId:occurrence:entry:$ieWord";
    kvKnown[$ieEntry]=1;
    printf '%*sITEM:\n' "$ieIndent" '';
    ((ieIndent+=2));
    printf '%*sIDENTITY: %s\n%*sLOCATION: %s\n%*sTYPE: %s\n%*sPARENT: %s\n' "$ieIndent" '' "$ieEntry" "$ieIndent" '' "$ieRef" "$ieIndent" '' "$ieType" "$ieIndent" '' "$ieParent";
    printf '%*sDEPTH: %s\n%*sLAYER: %s\n%*sORDINAL: %s\n%*sCHILD: %s\n' "$ieIndent" '' "$ieDepth" "$ieIndent" '' "$ieLayer" "$ieIndent" '' "$ieOrdinal" "$ieIndent" '' "$ieChildren"
}
