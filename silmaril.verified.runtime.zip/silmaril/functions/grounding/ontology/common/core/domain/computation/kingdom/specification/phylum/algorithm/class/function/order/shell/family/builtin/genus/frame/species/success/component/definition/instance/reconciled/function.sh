frame::success () 
{ 
    local output=$1;
    local effect=$2;
    local outputName=$3;
    frame::new "$SILMARILSTATUSSUCCESS" "$output" "$effect" "$SILMARILVALUENONE" "$outputName"
}
