object::call () 
{ 
    local identity=$1;
    local method=$2;
    local outputName=$3;
    shift "$SILMARILTHREE";
    local owner;
    local implementation;
    dispatch::resolve "$identity" "$method" "$SILMARILZERO" owner implementation || return "$SILMARILFAILURE";
    "$implementation" "$identity" "$method" "$owner" "$outputName" "$@"
}
