unicode::decode () 
{ 
    local udStream=$1 udN udI=0 udB udJ udK udC udMin udWidth udStart;
    local -a udPoints=() udOffsets=() udWidths=();
    byte::count "$udStream" udN || return 1;
    while ((udI<udN)); do
        udStart=$udI;
        byte::at "$udStream" "$udI" udB || return 1;
        ((udI+=1));
        if ((udB<128)); then
            udC=$udB;
            udK=0;
            udMin=0;
        else
            if ((udB>=194 && udB<=223)); then
                udC=$((udB&31));
                udK=1;
                udMin=128;
            else
                if ((udB>=224 && udB<=239)); then
                    udC=$((udB&15));
                    udK=2;
                    udMin=2048;
                else
                    if ((udB>=240 && udB<=244)); then
                        udC=$((udB&7));
                        udK=3;
                        udMin=65536;
                    else
                        error::raise ENCODING/INVALID "lead at $udStart";
                        return 1;
                    fi;
                fi;
            fi;
        fi;
        udWidth=$((udK+1));
        for ((udJ=0; udJ<udK; udJ++))
        do
            ((udI<udN)) || { 
                error::raise ENCODING/INVALID truncated;
                return 1
            };
            byte::at "$udStream" "$udI" udB || return 1;
            ((udI+=1));
            ((udB>=128 && udB<=191)) || { 
                error::raise ENCODING/INVALID continuation;
                return 1
            };
            udC=$((udC*64+(udB&63)));
        done;
        ((udC>=udMin && udC<=1114111 && (udC<55296 || udC>57343))) || { 
            error::raise ENCODING/INVALID scalar;
            return 1
        };
        udPoints+=("$udC");
        udOffsets+=("$udStart");
        udWidths+=("$udWidth");
    done;
    unicodeValues=("${udPoints[@]}");
    unicodeOffsets=("${udOffsets[@]}");
    unicodeWidths=("${udWidths[@]}")
}
