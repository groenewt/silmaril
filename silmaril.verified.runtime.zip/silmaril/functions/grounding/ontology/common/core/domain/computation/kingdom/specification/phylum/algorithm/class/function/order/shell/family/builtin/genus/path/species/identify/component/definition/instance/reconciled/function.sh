path::identify () 
{ 
    local piPath=$1 piOut=$2 piIndex piNumber piWords piId=$PATHNOTATIONBASE piChar;
    local LC_ALL=C;
    path::requireSafe "$piPath" || return 1;
    for ((piIndex=0; piIndex<${#piPath}; piIndex++))
    do
        piChar=${piPath:piIndex:1};
        printf -v piNumber '%d' "'$piChar";
        printf -v piNumber '%03d' "$piNumber";
        piWords=${lexicalDigits[${piNumber:0:1}]}:${lexicalDigits[${piNumber:1:1}]}:${lexicalDigits[${piNumber:2:1}]};
        piId+=:octet:$piWords;
    done;
    kvKnown[$piId]=1;
    printf -v "$piOut" '%s' "$piId"
}
