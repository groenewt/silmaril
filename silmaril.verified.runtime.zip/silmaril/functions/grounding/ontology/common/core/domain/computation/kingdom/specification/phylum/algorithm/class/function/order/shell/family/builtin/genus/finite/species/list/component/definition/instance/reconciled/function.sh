finite::list () 
{ 
    local flParent=$1 flKey=$2 flOut=$3 flPath flN flI flItem flValue flResult=;
    yaml::requiredSequence "$flParent" "$flKey" flPath flN || return 1;
    for ((flI=0; flI<flN; flI++))
    do
        yaml::sequenceScalar "$flPath" "$flI" flValue || return 1;
        flResult+="$flValue ";
    done;
    printf -v "$flOut" '%s' "$flResult"
}
