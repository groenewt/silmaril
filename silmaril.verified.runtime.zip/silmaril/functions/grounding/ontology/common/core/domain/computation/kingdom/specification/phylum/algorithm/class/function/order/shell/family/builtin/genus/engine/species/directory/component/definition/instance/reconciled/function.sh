engine::directory () 
{ 
    local outputName=$1;
    local -n outputReference=$outputName;
    local source=${BASH_SOURCE[0]};
    if [[ $source == */* ]]; then
        outputReference=${source%/*};
    else
        outputReference=.;
    fi
}
