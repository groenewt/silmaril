type::addGrounding () 
{ 
    local identity=$1;
    local grounding=$2;
    type::exists "$identity" || { 
        engine::raise "$SILMARILERRORTYPE" "$identity";
        return "$SILMARILFAILURE"
    };
    [[ ${groundingDefined[$grounding]-} == "$SILMARILONE" ]] || { 
        engine::raise "$SILMARILERRORGROUNDING" "$grounding";
        return "$SILMARILFAILURE"
    };
    local count=${typeGroundingCount[$identity]:-$SILMARILZERO};
    local index;
    for ((index = SILMARILZERO; index < count; index += SILMARILONE ))
    do
        [[ ${typeGrounding[${identity}${SILMARILUS}${index}]} != "$grounding" ]] || return "$SILMARILZERO";
    done;
    typeGrounding[${identity}${SILMARILUS}${count}]=$grounding;
    typeGroundingCount[$identity]=$(( count + SILMARILONE ))
}
