uri::ipLiteral () 
{ 
    local ilText=$1 ilRest ilPart ilCount=0 ilCompressed=0 ilLast;
    if [[ $ilText =~ ^[vV][0-9a-fA-F]+\..+$ ]]; then
        ilRest=${ilText#*.};
        uri::component "$ilRest" user;
        return;
    fi;
    if [[ $ilText == *.* ]]; then
        ilLast=${ilText##*:};
        uri::ipvfour "$ilLast" || return 1;
        [[ $ilText == *:* ]] || return 1;
        ilText=${ilText%:*}:0:0;
    fi;
    [[ $ilText =~ ^[0-9A-Fa-f:]+$ && $ilText != *:::* ]] || return 1;
    if [[ $ilText == *::* ]]; then
        ilRest=${ilText#*::};
        [[ $ilRest != *::* ]] || return 1;
        ilCompressed=1;
        ilText=${ilText/::/:};
        ilText=${ilText#:};
        ilText=${ilText%:};
    else
        [[ $ilText != :* && $ilText != *: ]] || return 1;
    fi;
    if [[ -n $ilText ]]; then
        while :; do
            ilPart=${ilText%%:*};
            [[ $ilPart =~ ^[0-9a-fA-F]{1,4}$ ]] || return 1;
            ((ilCount+=1));
            [[ $ilText == *:* ]] || break;
            ilText=${ilText#*:};
        done;
    fi;
    if ((ilCompressed)); then
        ((ilCount<8));
    else
        ((ilCount==8));
    fi
}
