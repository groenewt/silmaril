error::lookup () 
{ 
    local elPath=$1 elOut=$2;
    [[ -n ${errorRegistry[$elPath]-} ]] || return 1;
    printf -v "$elOut" '%s' "${errorRegistry[$elPath]}"
}
