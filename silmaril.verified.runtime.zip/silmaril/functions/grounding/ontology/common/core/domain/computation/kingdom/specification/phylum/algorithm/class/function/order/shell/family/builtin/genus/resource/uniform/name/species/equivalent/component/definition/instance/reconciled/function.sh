urn::equivalent () 
{ 
    local ueA=$1 ueB=$2 ueAssigned;
    urn::parse "$ueA" || return 1;
    ueAssigned=${urn[ASSIGNED]};
    urn::parse "$ueB" || return 1;
    [[ $ueAssigned == "${urn[ASSIGNED]}" ]]
}
