shape::list () 
{ 
    local slNode=$1 slGraph=${2:-$shapeShapesGraph} slSeen=, slNext slItem;
    shapeList=();
    while [[ ${rdfTerm[slNode]} != "${RDFNS}nil" ]]; do
        [[ $slSeen != *",$slNode,"* ]] || { 
            shape::error 'cyclic RDF list';
            return 2
        };
        slSeen+="$slNode,";
        rdf::objects "$slNode" "${RDFNS}first" "$slGraph";
        ((${#rdfValues[@]}==1)) || { 
            shape::error 'list first cardinality';
            return 2
        };
        slItem=${rdfValues[0]};
        rdf::objects "$slNode" "${RDFNS}rest" "$slGraph";
        ((${#rdfValues[@]}==1)) || { 
            shape::error 'list rest cardinality';
            return 2
        };
        slNext=${rdfValues[0]};
        shapeList+=("$slItem");
        slNode=$slNext;
    done
}
