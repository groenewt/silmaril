wide::octets () 
{ 
    local woId=$1 woSchema woBits woPart woIndex woValue woBit;
    local -a woBytes=();
    wideOctets=();
    [[ -n ${wideSchema[$woId]+yes} && ${objectType[$woId]-} == "$WIDETYPEBYTE" ]] || { 
        error::raise GROUNDING/MISSING 'byte object absent';
        return 1
    };
    woSchema=${wideSchema[$woId]};
    woBits=${wideBits[$woId]};
    ((${#woBits}%8==0)) || { 
        error::raise PROJECTION/FIDELITY 'no implicit octet padding';
        return 1
    };
    if [[ ${wideSchemaBit[$woSchema]} == "$WIDELEAST" ]]; then
        wide::reverse "$woBits" woBits;
    fi;
    for ((woIndex=0; woIndex<${#woBits}; woIndex+=8))
    do
        woPart=${woBits:woIndex:8};
        woValue=0;
        for ((woBit=0; woBit<8; woBit+=1))
        do
            woValue=$((woValue*2+${woPart:woBit:1}));
        done;
        woBytes+=("$woValue");
    done;
    if [[ ${wideSchemaOctet[$woSchema]} == "$WIDEREVERSE" ]]; then
        for ((woIndex=${#woBytes[@]}-1; woIndex>=0; woIndex-=1))
        do
            wideOctets+=("${woBytes[woIndex]}");
        done;
    else
        wideOctets=("${woBytes[@]}");
    fi
}
