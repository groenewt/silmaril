name::number () 
{ 
    local nnValue=$1 nnOut=$2 nnDigit nnWords=;
    [[ $nnValue =~ ^(0|[1-9][0-9]*)$ ]] || return 1;
    while [[ -n $nnValue ]]; do
        nnDigit=${nnValue:0:1};
        nnValue=${nnValue:1};
        [[ -z $nnWords ]] || nnWords+=:;
        nnWords+=${lexicalDigits[$nnDigit]};
    done;
    printf -v "$nnOut" '%s' "$nnWords"
}
