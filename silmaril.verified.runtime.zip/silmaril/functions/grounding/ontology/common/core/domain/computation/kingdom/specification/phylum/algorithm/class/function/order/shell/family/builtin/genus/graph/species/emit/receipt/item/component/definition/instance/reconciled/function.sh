graph::emitReceiptItem () 
{ 
    local grNode=${graphNodes[$1]} grIndent=$2 grFrame grState;
    printf '%*sITEM:\n' "$grIndent" '';
    ((grIndent+=2));
    printf '%*sIDENTITY: %s\n' "$grIndent" '' "$grNode";
    grFrame=${nodeFrame[$grNode]-};
    if [[ -n $grFrame ]]; then
        printf '%*sFRAME:\n' "$grIndent" '';
        ((grIndent+=2));
        printf '%*sIDENTITY: %s\n%*sTYPE: %s\n%*sSTATUS: %s\n%*sOUTPUT: %s\n%*sEFFECT: %s\n%*sERROR: %s\n' "$grIndent" '' "$grFrame" "$grIndent" '' "$SILMARILTYPEFRAME" "$grIndent" '' "${frameStatus[$grFrame]}" "$grIndent" '' "${frameOutput[$grFrame]}" "$grIndent" '' "${frameEffect[$grFrame]}" "$grIndent" '' "${frameError[$grFrame]}";
    else
        publication::state "${schedulerState[$grNode]:-pending}" grState;
        printf '%*sSTATE: %s\n%*sOUTPUT: %s\n' "$grIndent" '' "$grState" "$grIndent" '' "${nodeOutput[$grNode]:-$SILMARILVALUENONE}";
    fi
}
