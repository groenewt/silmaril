scheduler::defaults () 
{ 
    schedulerParallel=1;
    schedulerRetry=0;
    schedulerTimeout=0;
    schedulerRollback=0;
    schedulerDisposition=abort;
    schedulerCheckpoint=;
    schedulerSnapshot=;
    schedulerRestored=()
}
