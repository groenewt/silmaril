manifest::verify () 
{ 
    local mvRoot=$1 mvManifest=$2 mvSourceRef mvSourceRoot mvAlgorithm mvMembers mvCount mvTotalRef mvTotal mvItem mvI mvFileRef mvFile mvRelative mvActualFile mvExtentRef mvExtent mvDigestPath mvDigestCount mvJ mvOctet mvByte mvExpected mvActual mvActualExtent mvPart mvVerified=0 mvBytes=0 mvTree;
    local -A mvFiles=();
    manifestVerified=0 manifestCheckedBytes=0;
    path::requireSafe "$mvRoot" && path::requireReadable "$mvManifest" || return 1;
    [[ -d $mvRoot && $mvManifest == "${mvRoot%/}/"* ]] || { 
        error::raise PATH/ROOT 'manifest must be in the verified tree';
        return 1
    };
    yaml::parse "$mvManifest" || return 1;
    yaml::assertOnlyKeys "$SILMARILYAMLROOT" IDENTITY SOURCE ALGORITHM COUNT MEMBERS METADATA || return 1;
    yaml::requiredScalar "$SILMARILYAMLROOT" SOURCE mvSourceRef || return 1;
    path::decode "$mvSourceRef" mvSourceRoot || return 1;
    yaml::requiredScalar "$SILMARILYAMLROOT" ALGORITHM mvAlgorithm || return 1;
    [[ $mvAlgorithm == "$MANIFESTALGORITHM" ]] || { 
        error::raise PROTOCOL/OPERATION 'unsupported manifest digest algorithm';
        return 1
    };
    yaml::requiredScalar "$SILMARILYAMLROOT" COUNT mvTotalRef || return 1;
    [[ -n ${kvNumber[$mvTotalRef]+yes} ]] || { 
        error::raise VECTOR/CARDINALITY 'manifest count reference';
        return 1
    };
    mvTotal=${kvNumber[$mvTotalRef]};
    yaml::requiredSequence "$SILMARILYAMLROOT" MEMBERS mvMembers mvCount || return 1;
    ((mvCount==mvTotal && mvCount>0)) || { 
        error::raise VECTOR/CARDINALITY 'manifest entry count';
        return 1
    };
    for ((mvI=0; mvI<mvCount; mvI++))
    do
        yaml::sequenceMap "$mvMembers" "$mvI" mvItem || return 1;
        yaml::assertOnlyKeys "$mvItem" IDENTITY SOURCE COUNT DIGEST METADATA || return 1;
        yaml::requiredScalar "$mvItem" SOURCE mvFileRef || return 1;
        path::decode "$mvFileRef" mvFile || return 1;
        [[ $mvFile == "${mvSourceRoot%/}/"* ]] || { 
            error::raise PATH/ROOT 'manifest member escapes declared source root';
            return 1
        };
        mvRelative=${mvFile#"${mvSourceRoot%/}/"};
        mvActualFile=${mvRoot%/}/$mvRelative;
        [[ $mvActualFile != "$mvManifest" && ! -n ${mvFiles[$mvActualFile]+yes} ]] || { 
            error::raise PAIR/DUPLICATE 'self-inclusion or duplicate manifest member';
            return 1
        };
        path::requireReadable "$mvActualFile" || return 1;
        mvFiles[$mvActualFile]=1;
        yaml::requiredScalar "$mvItem" COUNT mvExtentRef || return 1;
        [[ -n ${kvNumber[$mvExtentRef]+yes} ]] || { 
            error::raise VECTOR/CARDINALITY 'byte extent reference';
            return 1
        };
        mvExtent=${kvNumber[$mvExtentRef]};
        yaml::requiredSequence "$mvItem" DIGEST mvDigestPath mvDigestCount || return 1;
        ((mvDigestCount==32)) || { 
            error::raise VECTOR/CARDINALITY 'SHA256 requires thirty two octets';
            return 1
        };
        mvExpected=;
        for ((mvJ=0; mvJ<mvDigestCount; mvJ++))
        do
            yaml::sequenceScalar "$mvDigestPath" "$mvJ" mvOctet || return 1;
            [[ -n ${kvNumber[$mvOctet]+yes} ]] || { 
                error::raise BYTE/RANGE 'digest octet reference';
                return 1
            };
            mvByte=${kvNumber[$mvOctet]};
            ((mvByte>=0 && mvByte<=255)) || { 
                error::raise BYTE/RANGE 'digest octet range';
                return 1
            };
            printf -v mvPart '%02x' "$mvByte";
            mvExpected+=$mvPart;
        done;
        hash::file "$mvActualFile" mvActual mvActualExtent || return 1;
        [[ $mvActual == "$mvExpected" && $mvActualExtent == "$mvExtent" ]] || { 
            error::raise PROJECTION/FIDELITY "manifest mismatch: $mvRelative";
            return 1
        };
        ((mvVerified+=1));
        ((mvBytes+=mvExtent));
    done;
    inventory::scan "$mvRoot" || return 1;
    for mvTree in "${!inventoryPath[@]}";
    do
        [[ ${inventoryKind[mvTree]} == file && ${inventoryPath[mvTree]} != "$mvManifest" ]] || continue;
        [[ -n ${mvFiles[${inventoryPath[mvTree]}]+yes} ]] || { 
            error::raise PROJECTION/FIDELITY 'unlisted release file';
            return 1
        };
    done;
    manifestVerified=$mvVerified;
    manifestCheckedBytes=$mvBytes
}
