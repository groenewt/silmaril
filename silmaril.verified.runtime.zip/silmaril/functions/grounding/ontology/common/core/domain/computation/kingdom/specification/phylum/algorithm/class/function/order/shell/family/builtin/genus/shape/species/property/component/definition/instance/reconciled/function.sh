shape::property () 
{ 
    rdf::objects "$1" "$SHNS$2" "$shapeShapesGraph"
}
