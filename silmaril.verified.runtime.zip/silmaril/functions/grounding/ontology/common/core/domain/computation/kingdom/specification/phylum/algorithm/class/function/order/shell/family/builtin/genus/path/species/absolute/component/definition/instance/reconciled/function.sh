path::absolute () 
{ 
    local paInput=$1 paOut=$2 paPart paResult= paRest;
    [[ $paInput == /* ]] || paInput=$PWD/$paInput;
    paRest=${paInput#/};
    local -a paStack=();
    while [[ -n $paRest ]]; do
        paPart=${paRest%%/*};
        if [[ $paRest == */* ]]; then
            paRest=${paRest#*/};
        else
            paRest=;
        fi;
        case $paPart in 
            '' | .)
                :
            ;;
            ..)
                ((${#paStack[@]}>0)) || return 1;
                unset 'paStack[${#paStack[@]}-1]'
            ;;
            *)
                paStack+=("$paPart")
            ;;
        esac;
    done;
    for paPart in "${paStack[@]}";
    do
        paResult+=/$paPart;
    done;
    printf -v "$paOut" '%s' "${paResult:-/}"
}
