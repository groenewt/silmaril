wide::reset () 
{ 
    wideSchemaWidth=();
    wideSchemaBit=();
    wideSchemaOctet=();
    wideSchemaEncoding=();
    wideSchema=();
    wideBits=();
    wideOctets=()
}
