hash::text () 
{ 
    local htText=$1 htOut=$2 htI htN htChar htOffset htChunk LC_ALL=C;
    local -a hashState=(0x6a09e667 0xbb67ae85 0x3c6ef372 0xa54ff53a 0x510e527f 0x9b05688c 0x1f83d9ab 0x5be0cd19) hashBlock=();
    local hashFill=0 hashBytes=0;
    [[ $hashMaximumBytes =~ ^[1-9][0-9]{0,8}$ ]] && (( ${#htText}<=hashMaximumBytes )) || { 
        error::raise PAIR/LIMIT 'hash byte bound';
        return 1
    };
    for ((htOffset=0; htOffset<${#htText}; htOffset+=4096))
    do
        htChunk=${htText:htOffset:4096};
        for ((htI=0; htI<${#htChunk}; htI++))
        do
            htChar=${htChunk:htI:1};
            printf -v htN '%d' "'$htChar";
            hash::octet "$htN";
        done;
    done;
    hash::finish "$htOut"
}
