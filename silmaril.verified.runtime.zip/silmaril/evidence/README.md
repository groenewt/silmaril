# Evidence directory

This directory is preprovisioned for test outputs. external/ preserves the imported-source provenance. The final delivery report and clean-extraction test log accompany the archive externally. Verify manifest.yaml before running tests, because tests intentionally create additional files.
