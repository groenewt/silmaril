#!/bin/bash
set -Eeuo pipefail
source "${BASH_SOURCE[0]%/*}/../../engine.sh"
homologyDimension=(2 2 1)
homologyBoundary=([1,0,0]=-1 [1,0,1]=-1 [1,1,0]=1 [1,1,1]=1 [2,0,0]=-1 [2,1,0]=1)
homologyPrime=2
homology::compute
printf 'cell dimensions: %s\nboundary ranks: %s\nBetti over field two: %s\nEuler: %s\nverified: %s\n' "${homologyDimension[*]}" "${homologyRank[*]}" "${homologyBetti[*]}" "$homologyEuler" "$homologyVerified"
