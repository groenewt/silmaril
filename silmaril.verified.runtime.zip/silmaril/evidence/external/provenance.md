# External ontology projection provenance

Source: user Library file `SILMARIL-FULL-CONSOLIDATED-BFO-CCO-CPO-OWL-SHACL.ttl`, file id `file_00000000269081fbbb61310689c0fe14`.
Source SHA-256: `cea9f1c3e019959dab740d4b5cd97820568e84e86a00a5aba3140202d350419a`.
Source graph: 27507 triples.
External projection: 14690 triples, selected named subjects in the Basic Formal, Common Core, and Cognitive Process namespaces plus recursively connected blank-node object descriptions.
Projection SHA-256: `601d8e1fec86084ab5c51805e22119c48a022eb1c1a89b7d0624b89b0b2c9f2c`.

This is an extraction from the preserved user-supplied consolidated ontology artifact, not a claim of byte identity with upstream downloads. Raw upstream downloads failed in this environment. The CPO ontology and version identifiers and its CCO import were independently compared to the official repository. Version/source checks do not prove OWL consistency or that every source assertion is correct. The original source is evidence only and is not loaded as the active local Silmaril ontology.

Named superclass chains are checked as actual assertions in the imported graph. BFO named-edge profiles do not imply that an abstract mathematical set is a material object, or that a Bash process is automatically a cognitive mental process. The import roles are distinct from object-oriented inheritance.
